/*
================================================================================
barrier_module.h - Barrier-Proximal Subproblem Solver for 4 Cone Types

Stage 1.4: BPGrad Subproblem Solver (host CPU path)

Solves:  x* = argmin_{x ∈ K} { <g,x> + (1/2μ)||x-x_k||² + μ·τ(x) }

via Barrier-Proximal Gradient (BPGrad):
  1. Compute descent direction: d = (x - x_k)/μ + g + μ·∇τ(x)
  2. Backtracking Armijo line search on F(x) = (1/2μ)||x-x_k||² + <g,x> + μ·τ(x)
  3. Project trial point back to cone: x_trial = π_K(x - α·d)
  4. Iterate until convergence or fallback

Key design decisions:
  - Host CPU path for first implementation (will be GPU-kernelized in Stage 1.7)
  - All 4 cone types supported (RSOC, StdSOC, EXP, Power)
  - Fallback uses Euclidean projection (PDHCG native kernels via cudaMemcpy roundtrip)
  - Rescaling-aware: works in rescaled space then applies barrier in same space

References:
  - PDCS bpgrad_soc (Julia, exp-3.4)
  - PDCS apply_exp_primal_barrier_force!
================================================================================
*/

#pragma once

#include "barrier_params.h"
#include "boundary_metric.h"

#ifdef __cplusplus
extern "C"
{
#endif

/* =============================================================================
 * BPGrad Stats (per trigger, returned to caller)
 * ============================================================================= */

typedef struct {
    int outer_iter;          /* BPGrad outer iterations completed */
    int inner_iter;          /* Line search steps taken (sum across outer iters) */
    bool fallback_used;      /* Did we fall back to Euclidean projection? */
    bool converged;          /* Did BPGrad converge to a local optimum? */
    double final_residual;   /* Final gradient norm ||d|| */
    double mu_used;          /* mu value actually used */
    double rho_initial;      /* Initial boundary metric ρ */
    double rho_final;        /* Final boundary metric ρ (after BPGrad) */
} bpgrad_stats_t;

/* =============================================================================
 * Cone-specific feasibility / projection helpers (host CPU)
 * ============================================================================= */

/*
 * Check feasibility of a point in the cone interior.
 * Returns: boundary_metric_t (rho = 0 if infeasible)
 */
boundary_metric_t check_cone_feasibility(
    cone_type_t cone_type,
    int v_dim,
    const double *x,
    const double *d,
    double alpha
);

/*
 * Host-side Euclidean projection onto each cone.
 * This mirrors the GPU kernels in pdhcg_conic_kernels.cu but runs on CPU.
 *
 * Args:
 *   cone_type - which cone
 *   v_dim - dimension of cone block (k for SOC, 3 for EXP/Power, alpha for Power)
 *   x - input/output cone block
 *   d - variable rescaling (may be NULL)
 *   alpha - power cone parameter (ignored for non-power)
 *   warm_start - optional warm-start scalar (for SOC/RSOC Newton-like method, may be NULL)
 *
 * The function MODIFIES x in-place.
 */
void host_cone_project(
    cone_type_t cone_type,
    int v_dim,
    double *x,
    const double *d,
    double alpha,
    double *warm_start
);

/* =============================================================================
 * Main BPGrad Solver
 * ============================================================================= */

/*
 * bpgrad_solve - solve the Barrier-Proximal subproblem for one cone block.
 *
 * Args:
 *   cone_type  - which cone (RSOC / StdSOC / EXP / Power)
 *   v_dim      - dimension of the cone block
 *   x_block    - host pointer to the cone block (size depends on cone_type)
 *                MODIFIED IN-PLACE
 *   g_block    - host pointer to gradient at x_block (size matches x_block)
 *   d_block    - host pointer to variable rescaling (may be NULL)
 *   alpha      - power cone parameter (only used for CONE_POWER)
 *   tau        - PDHG step size
 *   mu         - barrier parameter
 *   params     - barrier parameters
 *
 * Returns:
 *   bpgrad_stats_t with iteration counts, fallback flag, etc.
 */
bpgrad_stats_t bpgrad_solve(
    cone_type_t cone_type,
    int v_dim,
    double *x_block,
    const double *g_block,
    const double *d_block,
    double alpha,
    double tau,
    double mu,
    const barrier_params_t *params
);

/* =============================================================================
 * Cone-type specific BPGrad solvers (internal but exposed for testing)
 * ============================================================================= */

bpgrad_stats_t bpgrad_solve_rsoc(
    int k,
    double *x,
    const double *g,
    const double *d,
    double tau,
    double mu,
    const barrier_params_t *params
);

bpgrad_stats_t bpgrad_solve_std_soc(
    int k,
    double *x,
    const double *g,
    const double *d,
    double tau,
    double mu,
    const barrier_params_t *params
);

bpgrad_stats_t bpgrad_solve_exp(
    double *x,
    const double *g,
    const double *d,
    double tau,
    double mu,
    const barrier_params_t *params
);

bpgrad_stats_t bpgrad_solve_power(
    double *x,
    const double *g,
    const double *d,
    double alpha,
    double tau,
    double mu,
    const barrier_params_t *params
);

#ifdef __cplusplus
}
#endif

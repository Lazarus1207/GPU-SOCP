/*
================================================================================
barrier_params.h - Barrier Parameters for PDHCG

Defines all tunable parameters for the Barrier-PDHG enhancement.
Separated from pdhcg_types.h to keep the core ABI stable.

Design:
  - barrier_params_t: immutable parameters (set once, read many)
  - barrier_state_t: mutable runtime state (triggers, fallbacks, mu, etc.)
  - Both are allocated separately and linked via pointers from
    pdhg_parameters_t and pdhg_solver_state_t

References:
  - PDCS barrier_module.jl (Julia, exp-3.4)
  - PDCS barrier_trigger.jl (Stage 4 trigger architecture)
  - PDCS barrier_metric.jl (Stage 3 boundary metric Ï)
================================================================================
*/

#pragma once

#include "pdhcg_types.h"

#ifdef __cplusplus
extern "C"
{
#endif

/* =============================================================================
 * Section 1: Mu Scheduling Strategy
 * ============================================================================= */

typedef enum {
    BARRIER_MU_CONSTANT = 0,    /* Fixed mu = mu_init throughout */
    BARRIER_MU_EXPONENTIAL = 1, /* mu_k = mu_init * rho^k */
    BARRIER_MU_ADAPTIVE = 2,    /* Adaptive: increase near boundary, decrease near solution */
    BARRIER_MU_HOMOTOPY = 3,    /* IPM-style: mu_k = mu_init / (1 + alpha*iter)^beta */
    BARRIER_MU_NUM_STRATEGIES
} barrier_mu_strategy_t;

/* =============================================================================
 * Section 2: Barrier Option (insertion point in main loop)
 * ============================================================================= */

typedef enum {
    BARRIER_OPTION_DISABLED = 0,  /* No barrier */
    BARRIER_OPTION_1 = 1,        /* After cone projection, before recompute_reflected */
    BARRIER_OPTION_2 = 2,        /* After halpern_update (Nesterov acceleration) */
    BARRIER_OPTION_MAX
} barrier_option_t;

/* =============================================================================
 * Section 3: Cone-Kind Enum (mirrors PDCS barrier_trigger.jl)
 * ============================================================================= */

typedef enum {
    CONE_KIND_RSOC_PRIMAL = 0,
    CONE_KIND_RSOC_DUAL = 1,
    CONE_KIND_STD_SOC_PRIMAL = 2,
    CONE_KIND_STD_SOC_DUAL = 3,
    CONE_KIND_EXP_PRIMAL = 4,
    CONE_KIND_EXP_DUAL = 5,
    CONE_KIND_POWER_PRIMAL = 6,
    CONE_KIND_POWER_DUAL = 7,
    CONE_KIND_NUM_KINDS = 8
} cone_kind_t;

/* =============================================================================
 * Section 4: Trigger Decision Reasons (for logging)
 * ============================================================================= */

typedef enum {
    TRIGGER_OFF = 0,          /* Global switch off */
    TRIGGER_ALWAYS = 1,       /* Always trigger (mode=always) */
    TRIGGER_GAP = 2,          /* Gap filter: gap too large */
    TRIGGER_BOUNDARY = 3,      /* Boundary proximity: rho <= threshold */
    TRIGGER_FIXED_SLOT = 4,   /* Fixed cone slot: skip */
    TRIGGER_NUMERIC = 5,       /* NaN or inf detected */
    TRIGGER_SAFETY = 6,       /* Safety guard rejected */
    TRIGGER_CHECK_SKIP = 7,    /* Iter % check_every != 0 */
    TRIGGER_NUM_REASONS
} trigger_reason_t;

/* =============================================================================
 * Section 5: Barrier Parameters (immutable, set once)
 * ============================================================================= */

typedef struct barrier_params_t {
    /* --- Global switch --- */
    bool barrier_enabled;

    /* --- Option (1 = pre-Halpern, 2 = post-Halpern) --- */
    barrier_option_t barrier_option;

    /* --- Mu scheduling --- */
    barrier_mu_strategy_t barrier_mu_strategy;
    double barrier_mu_init;   /* Global default (used if per-cone not specified) */
    double barrier_mu_final;  /* Target mu for EXPONENTIAL/ADAPTIVE (Default: 1e-6) */
    double barrier_mu_rho;    /* Decay rate for EXPONENTIAL, Default: 0.95 */

    /* IPM-style homotopy parameters (BARRIER_MU_HOMOTOPY)
     *
     * mu_k = mu_init / (1 + alpha*iter)^beta
     *
     * Defaults follow standard interior-point method theory:
     *   alpha = 1.0, beta = 2.0 → mu ~ 1/iter² (fast, quadratic)
     *   alpha = 1.0, beta = 1.0 → mu ~ 1/iter   (slow, linear, safer)
     *
     * This will be needed when barrier is integrated with full IPM.
     */
    double barrier_homotopy_alpha;
    double barrier_homotopy_beta;

    /* Per-cone mu_init overrides (PDCS-aligned defaults from barrier_trigger.jl §7.5)
     * If non-zero, overrides the global barrier_mu_init for that cone kind.
     * Defaults:
     *   - SOC/RSOC/StdSOC: 1e-1
     *   - EXP/Power:       1e-2
     * Set to 0 to use barrier_mu_init.
     */
    double soc_rsoc_mu_init;
    double std_soc_mu_init;
    double exp_mu_init;
    double power_mu_init;

    /* --- Per-cone max_ratio thresholds (PDCS Stage 2) ---
     * These are converted to rho_threshold = 1/sqrt(max_ratio) at runtime.
     * Default values follow PDCS exp-3.4 v5 experience:
     *   - SOC/StdSOC: 10.0 (rho â 0.316)
     *   - EXP:         3.0 (rho â 0.577)
     *   - Power:       5.0 (rho â 0.447)
     */
    double soc_rsoc_max_ratio;    /* Default: 10.0 */
    double std_soc_max_ratio;     /* Default: 10.0 */
    double exp_max_ratio;         /* Default: 3.0 */
    double power_max_ratio;      /* Default: 5.0 */

    /* --- BPGrad inner solver controls --- */
    int barrier_max_iter;        /* Outer BPGrad iterations, Default: 20 */
    int barrier_inner_max_iter;   /* Armijo line search max steps, Default: 10 */
    double barrier_tol;          /* BPGrad subproblem tolerance, Default: 1e-8 */
    double barrier_ls_alpha0;    /* Line search initial step, Default: 1.0 */
    double barrier_ls_beta;      /* Line search backoff factor, Default: 0.5 */
    double barrier_ls_c;         /* Armijo constant, Default: 1e-4 */

    /* --- 5-layer protection mechanisms (PDCS Â§6) --- */
    double barrier_step_norm_cap;    /* Max allowed ||Îx|| / typical_step, Default: 2.0 */
    double barrier_primal_res_factor; /* Max primal res degradation factor, Default: 1.5 */
    int barrier_check_every;         /* Trigger check frequency, Default: 1 (every iter) */
    double barrier_gap_threshold;    /* Gap filter: trigger only if gap <= thresh, Default: 1e-3 */

    /* --- Adaptive threshold (PDCS Stage 5) --- */
    bool barrier_adaptive_threshold;  /* Enable adaptive threshold adjustment, Default: true */
    double barrier_fallback_high;     /* Fallback rate high watermark, Default: 0.3 */
    double barrier_fallback_low;      /* Fallback rate low watermark, Default: 0.05 */
    int barrier_window_size;          /* Sliding window for fallback rate, Default: 100 */

    /* --- Per-cone trigger mode (PDCS Stage 4 L1) ---
     * 0=off, 1=adaptive, 2=conservative, 3=always
     * Maps to cone_kind_t
     */
    int cone_trigger_mode[CONE_KIND_NUM_KINDS];

    /* --- GPU BPGrad acceleration (Stage 1.6) ---
     * When true, batch boundary-metric + BPGrad kernels are launched per bucket,
     * reducing per-block cudaMemcpy round-trips. Requires the GPU buffers in
     * barrier_state_t to be allocated (state->gpu_buffers_allocated == true).
     * Default: true (best performance on modern GPUs).
     * Set to false to force the per-block host BPGrad path (useful for
     * debugging, CPU profiling, or older GPUs with limited shared memory).
     */
    bool barrier_use_gpu_bpgrad;

    /* --- Verbosity --- */
    int barrier_verbose;  /* 0=silent, 1=summary, 2=detailed */
} barrier_params_t;

/* =============================================================================
 * Section 6: Barrier Runtime State (mutable, updated every trigger)
 * ============================================================================= */

typedef struct barrier_state_t {
    /* --- Trigger counts (8 cone kinds x primal/dual) --- */
    long long trigger_count_total;
    long long trigger_count[CONE_KIND_NUM_KINDS];

    /* --- Fallback / rejection counts --- */
    long long fallback_count_total;
    long long nan_reject_count;
    long long step_norm_reject_count;
    long long primal_res_reject_count;

    /* --- Per-cone current mu (for ADAPTIVE strategy) --- */
    double mu_current[CONE_KIND_NUM_KINDS];

    /* --- Per-cone stagnation counters (for ADAPTIVE strategy) --- */
    int stagnation_count[CONE_KIND_NUM_KINDS];

    /* --- Per-cone adaptive rho thresholds (adjusted by L3) --- */
    double rho_threshold[CONE_KIND_NUM_KINDS];

    /* --- Fallback rate sliding window (L3 adaptation) --- */
    double *fallback_window;       /* [window_size Ã CONE_KIND_NUM_KINDS] flattened */
    int window_size;
    int window_pos;                /* Circular buffer position */

    /* --- BPGrad host buffers (pre-allocated) --- */
    double *host_cone_block;      /* Single cone block, size = max_v_dim + 2 */
    double *host_cone_grad;        /* Gradient buffer, same size */
    double *host_cone_dir;        /* Descent direction buffer, same size */
    int max_cone_v_dim;           /* Max v_dim across all cone blocks */

    /* --- Device memory for GPU BPGrad (Stage 1.7 / 1.6) --- */
    double *dev_cone_block;
    double *dev_cone_grad;
    double *dev_rho_out;
    /* GPU BPGrad batch path (Stage 1.6) */
    int    *dev_start_idx_held;   /* device, [max_cone_blocks_per_bucket]  (host upload) */
    int    *dev_v_dim_held;        /* device, [max_cone_blocks_per_bucket]  (host upload) */
    double *dev_alpha_held;        /* device, [max_cone_blocks_per_bucket]  (host upload, for Power only) */
    int    *dev_converged;         /* device, [max_cone_blocks_per_bucket]  (BPGrad output flags) */
    int     max_cone_blocks_per_bucket;
    bool    gpu_buffers_allocated;

    /* --- Quick-access copies (set from params, avoid pointer chase) --- */
    bool enabled;
    barrier_option_t option;
    int verbose;

    /* Primal residual snapshot for L5 guard (PDCS §6, primal_res_budget formula)
     * Set by apply_barrier_to_state() from state->absolute_primal_residual
     * each iteration. If unavailable, L5 uses gap as fallback.
     */
    double current_primal_residual;
} barrier_state_t;

/* =============================================================================
 * Section 7: Function declarations
 * ============================================================================= */

/* Parameter management */
void set_default_barrier_params(barrier_params_t *params);
void print_barrier_params(const barrier_params_t *params);
double barrier_rho_threshold(cone_kind_t kind, const barrier_params_t *params);

/* State management */
barrier_state_t *create_barrier_state(const barrier_params_t *params, int max_v_dim);
void free_barrier_state(barrier_state_t *state);
void reset_barrier_state(barrier_state_t *state, const barrier_params_t *params);
void barrier_state_add_fallback(barrier_state_t *state, cone_kind_t kind, int accepted);
double barrier_state_fallback_rate(barrier_state_t *state, cone_kind_t kind);
void barrier_state_adapt_threshold(barrier_state_t *state, barrier_params_t *params, cone_kind_t kind);

/* GPU buffer management (Stage 1.6)
 * Call allocate_barrier_gpu_buffers once after create_barrier_state
 * (typically in solver_state.cu, right after barrier_state is created).
 * The buffers are reused across iterations; free_barrier_state handles cleanup.
 */
int  allocate_barrier_gpu_buffers(barrier_state_t *state, int max_blocks_per_bucket);
void free_barrier_gpu_buffers(barrier_state_t *state);

/* Utility */
const char *cone_kind_to_string(cone_kind_t kind);
const char *trigger_reason_to_string(trigger_reason_t reason);
cone_kind_t cone_type_to_cone_kind(cone_type_t type, bool is_dual);

#ifdef __cplusplus
}
#endif

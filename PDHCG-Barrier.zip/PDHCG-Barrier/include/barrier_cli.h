/*
================================================================================
barrier_cli.h - CLI Integration for Barrier Parameters
================================================================================
*/

#pragma once

#include "pdhcg.h"
#include "pdhcg_types.h"
#include <getopt.h>

/* glibc exposes struct option only under _GNU_SOURCE; provide a harmless
 * forward declaration so the prototype below is well-formed everywhere. */
#ifndef _WIN32
struct option;
#endif

#ifdef __cplusplus
extern "C"
{
#endif

/* =============================================================================
 * Barrier CLI option codes (getopt_long `val` values).
 *
 * These are shared by:
 *   - add_barrier_cli_options()  (builds the long-option table)
 *   - parse_barrier_cli_option() (dispatches on the code)
 *   - src/cli.c                  (the switch statement)
 *
 * Using named constants instead of raw numbers means the three places can
 * never drift apart.  The numeric values (3001..3026) live above the core
 * CLI range (1001..1032) so they cannot collide with a core option.
 * ========================================================================== */
typedef enum {
    OPT_BARRIER_ENABLED = 3001,
    OPT_BARRIER_OPTION = 3002,
    OPT_BARRIER_MU_INIT = 3003,
    OPT_BARRIER_MU_FINAL = 3004,
    OPT_BARRIER_MU_STRATEGY = 3005,
    OPT_BARRIER_MU_RHO = 3006,
    OPT_BARRIER_SOC_RSOC_RATIO = 3007,
    OPT_BARRIER_STD_SOC_RATIO = 3008,
    OPT_BARRIER_EXP_RATIO = 3009,
    OPT_BARRIER_POWER_RATIO = 3010,
    OPT_BARRIER_MAX_ITER = 3011,
    OPT_BARRIER_INNER_MAX_ITER = 3012,
    OPT_BARRIER_TOL = 3013,
    OPT_BARRIER_CHECK_EVERY = 3014,
    OPT_BARRIER_GAP_THRESHOLD = 3015,
    OPT_BARRIER_STEP_NORM_CAP = 3016,
    OPT_BARRIER_PRIMAL_RES_FACTOR = 3017,
    OPT_BARRIER_ADAPTIVE_THRESHOLD = 3018,
    OPT_BARRIER_VERBOSE = 3019,
    OPT_BARRIER_HOMOTOPY_ALPHA = 3020,
    OPT_BARRIER_HOMOTOPY_BETA = 3021,
    OPT_BARRIER_SOC_RSOC_MU_INIT = 3022,
    OPT_BARRIER_STD_SOC_MU_INIT = 3023,
    OPT_BARRIER_EXP_MU_INIT = 3024,
    OPT_BARRIER_POWER_MU_INIT = 3025,
    OPT_BARRIER_USE_GPU_BPGRAD = 3026
} barrier_cli_option_t;

/* Allocate and initialize a barrier_params_t with defaults.
 * Must be freed by free_barrier_params.
 * Returns NULL on failure.
 */
struct barrier_params_t *create_default_barrier_params(void);
void free_barrier_params(struct barrier_params_t *bp);

/* Parse CLI arguments to set barrier parameters.
 * This is called from the main PDHG CLI loop.
 *
 * Args:
 *   bp - barrier parameters (modified in-place)
 *   opt - the getopt long option code (assigned in main CLI loop)
 *   optarg - the argument value (for required_argument options)
 *
 * Returns: 1 if the option was recognized and parsed, 0 otherwise
 */
int parse_barrier_cli_option(struct barrier_params_t *bp, int opt, const char *optarg);

/* Add barrier options to a getopt_long option table.
 * The caller must allocate an array large enough and set the last entry to {0,0,0,0}.
 *
 * Args:
 *   options - array of struct option to fill
 *   max_size - max number of entries in the array
 *
 * Returns: number of entries added
 */
int add_barrier_cli_options(struct option *options, int max_size);

/* Print barrier CLI help (appended to main usage) */
void print_barrier_cli_help(void);

#ifdef __cplusplus
}
#endif

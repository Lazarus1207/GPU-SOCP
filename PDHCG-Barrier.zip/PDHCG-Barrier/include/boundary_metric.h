/*
================================================================================
boundary_metric.h - Boundary Metric (Ï) for 4 Cone Types

Stage 1.3: Boundary Metric Computation

Provides cone-specific boundary metrics Ï â [0, 1] that are:
  - Geometrically meaningful (clear physical interpretation)
  - Scale-invariant (independent of block scale ||x||)
  - Cross-cone consistent (same semantic: smaller Ï = closer to boundary)

Ï definitions:
  - RSOC: x = (v[1..k], s, t), Ï = sqrt(2st - ||v||Â²) / sqrt(2st)
  - StdSOC: x = (t, u[1..k]), Ï = sqrt(tÂ² - ||u||Â²) / |t|
  - EXP:   x = (x1, x2, x3), Ï = (x1 - x2*exp(x3/x2)) / x1 = slack/x1
  - Power: x = (x, y, z),  Ï = (x^Î±Â·y^(1-Î±) - |z|) / x^Î±Â·y^(1-Î±)

Trigger condition: barrier triggers iff Ï <= rho_threshold.

References:
  - PDCS barrier_metric.jl (Julia, Stage 3)
  - BARRIER_TRIGGER_ARCHITECTURE.md Â§2.2 and Â§4
================================================================================
*/

#pragma once

#include "barrier_params.h"

#ifdef __cplusplus
extern "C"
{
#endif

/* =============================================================================
 * Boundary Metric Result
 * ============================================================================= */

typedef struct {
    double rho;        /* Ï â [0, 1], smaller = closer to boundary */
    double slack;      /* Cone-specific slack measure */
    bool feasible;    /* Whether the point is in the cone interior */
} boundary_metric_t;

/* =============================================================================
 * Per-cone boundary metric functions
 * ============================================================================= */

/*
 * RSOC boundary metric: Ï = sqrt(2*s*t - ||v||Â²) / sqrt(2*s*t)
 *
 * x = (v[0..k-1], s, t) with vâR^k, s,tâR
 * Feasibility: 2*s*t >= ||v||Â² and s >= 0 and t >= 0
 * Boundary: 2*s*t == ||v||Â²  (Ï = 0)
 * Axis (v=0): 2*s*t > 0 and ||v||=0  (Ï = 1)
 *
 * Args:
 *   k - dimension of v vector (v_dim = k, total size = k + 2)
 *   x - pointer to cone block, layout: [v0,...,vk-1, s, t]
 *   d - variable rescaling factors (may be NULL for no rescaling)
 *       layout: [d_v0,...,d_vk-1, d_s, d_t]
 *
 * Returns: boundary_metric_t with rho â [0, 1]
 */
boundary_metric_t boundary_metric_rsoc(int k, const double *x, const double *d);

/*
 * StdSOC (standard second-order cone) boundary metric: Ï = sqrt(tÂ² - ||u||Â²) / |t|
 *
 * x = (t, u[0..k-1]) with tâR, uâR^k
 * Feasibility: ||u|| <= t and t >= 0
 * Boundary: ||u|| == t  (Ï = 0)
 * Axis (u=0): t > 0 and ||u||=0  (Ï = 1)
 *
 * Args:
 *   k - dimension of u vector (v_dim = k, total size = k + 1)
 *   x - pointer to cone block, layout: [t, u0,...,uk-1]
 *   d - variable rescaling factors (may be NULL for no rescaling)
 *       layout: [d_t, d_u0,...,d_uk-1]
 *
 * Returns: boundary_metric_t with rho â [0, 1]
 */
boundary_metric_t boundary_metric_std_soc(int k, const double *x, const double *d);

/*
 * EXP (exponential cone) boundary metric: Ï = slack / x1
 *
 * x = (x1, x2, x3)
 * Feasibility: x2 > 0, x3 > 0, x1 >= x2 * exp(x3/x2)
 * slack = x1 - x2 * exp(x3/x2)
 * Boundary: slack = 0  (Ï = 0)
 * Interior: slack > 0  (Ï = slack/x1)
 *
 * Args:
 *   x - pointer to 3-element cone block [x1, x2, x3]
 *   d - variable rescaling factors (may be NULL)
 *       layout: [d1, d2, d3]
 *
 * Returns: boundary_metric_t with rho â [0, 1]
 */
boundary_metric_t boundary_metric_exp(const double *x, const double *d);

/*
 * POWER (3-dim power cone) boundary metric: Ï = slack / (x^Î± Â· y^(1-Î±))
 *
 * x = (x, y, z) with x >= 0, y >= 0, x^Î± * y^(1-Î±) >= |z|
 * slack = x^Î± * y^(1-Î±) - |z|
 * boundary: slack = 0  (Ï = 0)
 * interior: slack > 0  (Ï = slack / (x^Î±*y^(1-Î±)))
 *
 * Args:
 *   x - pointer to 3-element cone block [x, y, z]
 *   alpha - power cone parameter, 0 < alpha < 1
 *   d - variable rescaling factors (may be NULL)
 *       layout: [d_x, d_y, d_z]
 *
 * Returns: boundary_metric_t with rho â [0, 1]
 */
boundary_metric_t boundary_metric_power(const double *x, double alpha, const double *d);

/* =============================================================================
 * Generic dispatcher
 * ============================================================================= */

/*
 * boundary_metric_generic - compute Ï for any cone type
 *
 * Args:
 *   cone_type - from pdhcg_types.h cone_type_t
 *   v_dim - dimension of the cone block
 *   x - pointer to cone block
 *   d - variable rescaling (may be NULL)
 *   alpha - power cone parameter (used only if cone_type == CONE_POWER)
 *   is_dual - whether this is a dual cone (for bookkeeping, all PDHCG cones are self-dual)
 *
 * Returns: boundary_metric_t
 */
boundary_metric_t boundary_metric_generic(
    cone_type_t cone_type,
    int v_dim,
    const double *x,
    const double *d,
    double alpha,
    bool is_dual
);

/*
 * should_trigger_by_rho - check if barrier should trigger based on Ï
 *
 * Args:
 *   rho - boundary metric value
 *   rho_threshold - trigger threshold (from barrier_params)
 *   cone_kind - for logging
 *
 * Returns: true iff rho <= rho_threshold and rho > 0
 */
bool should_trigger_by_rho(double rho, double rho_threshold, cone_kind_t cone_kind);

/* =============================================================================
 * Max-ratio to rho threshold conversion (for CLI/API compatibility)
 * ============================================================================= */

/*
 * Convert max_ratio (PDCS legacy parameter) to rho_threshold.
 *
 * For SOC/RSOC: rho_threshold = 1 / sqrt(max_ratio)
 * For EXP/Power: rho_threshold = 1 / max_ratio
 *
 * See PDCS barrier_metric.jl: max_ratio_to_boundary_threshold_soc()
 */
double max_ratio_to_rho_threshold(double max_ratio, cone_type_t cone_type);

#ifdef __cplusplus
}
#endif

/* cbf_header.h -- minimal CBF header reader.
 *
 * Reads just enough of a CBF (gzipped or plain) file to extract
 * geometry used by the benchmark driver:
 *
 *   - VAR  (number of variables, "n")
 *   - CON  (number of constraints, "m")
 *   - FCOORD nnz (or ACOORD nnz) -- constraint matrix nnz
 *   - CONES (number of cone definitions)
 *
 * The reader stops at the first non-header, non-data keyword (OBJSENSE,
 * OBJACOORD, OBJBCOORD, BOUND, QQ, QR, EXP, F, L=, L+, L-, CHANGE)
 * that signals the end of geometry-relevant content.  It is NOT a
 * full CBF parser -- for that, see cbf_parser.c.
 */
#ifndef PDHCG_CBF_HEADER_H
#define PDHCG_CBF_HEADER_H

#include <stdbool.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    int  num_variables;
    int  num_constraints;
    int  num_nonzeros;       /* constraint matrix nnz (from FCOORD) */
    int  num_cones;          /* CONES count */
    int  num_soc_cones;      /* number of Q (standard SOC) entries */
    int  num_rsoc_cones;     /* number of QR (rotated SOC) entries */
    int  num_exp_cones;      /* number of EXP entries */
    bool parse_failed;
    char errmsg[256];
} pdhcg_cbf_geometry_t;

/* Read a CBF (or CBF.gz) file's header from disk and return the
 * geometry.  On failure, `parse_failed` is true and `errmsg` holds
 * a short message.  The geometry is zero-initialised on entry. */
void pdhcg_cbf_read_geometry(const char *path,
                             pdhcg_cbf_geometry_t *g);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* PDHCG_CBF_HEADER_H */

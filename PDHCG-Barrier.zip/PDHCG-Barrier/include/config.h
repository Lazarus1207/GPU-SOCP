/* config.h -- C-side geometry-based PDHG configuration.
 *
 * Port of PDHCG/python/../config.py -- the Python submission's geometry
 * classifier that picks (pock_chambolle_alpha, restart_threshold) from
 * a problem's row/column/nonzero/cone statistics.  The classification
 * is identical to the Python version (no per-problem whitelists).
 *
 * The runner calls `pdhcg_config_select()` to compute a recommended
 * (alpha, restart) pair for a given problem, and then either applies
 * that pair or lets the user override via CLI flags.
 */
#ifndef PDHCG_CONFIG_H
#define PDHCG_CONFIG_H

#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Sentinel for `restart_threshold`: the runner should pass
 * `pdhcg_restart_default` through to the C defaults (currently 0.36)
 * instead of overriding. */
#define PDHCG_RESTART_DEFAULT_STR "default"

/* The classifier output.  When `restart_is_default` is true, the
 * caller MUST NOT override the C-side `artificial_restart_threshold`
 * and instead leave the C default of 0.36 in place. */
typedef struct {
    double alpha;              /* pock_chambolle_alpha, in (0, 2] */
    double restart_threshold;  /* used only if !restart_is_default */
    bool   restart_is_default; /* true => caller leaves C default 0.36 */
} pdhcg_config_t;

/* A "default" config: alpha=1.0, restart=default.  Used when geometry
 * is unknown / unparseable, mirroring config.py's final return. */
static const pdhcg_config_t PDHCG_CONFIG_DEFAULT = {
    /*.alpha              = */ 1.0,
    /*.restart_threshold  = */ 0.36,
    /*.restart_is_default = */ true,
};

/* Run the geometry classifier.
 *
 * Inputs:
 *   num_constraints   -- m (number of rows)
 *   num_variables     -- n (number of columns)
 *   num_nonzeros      -- nnz of A
 *   num_quadratic_constr -- count of SOC/RSOC cones that originate from
 *                           quadratic constraints (kept for API parity
 *                           with config.py; the C classifier does not
 *                           currently use it but downstream code does).
 *
 * Returns: a `pdhcg_config_t` whose alpha is in (0, 2] and whose
 * restart threshold is either a positive double (when the classifier
 * overrides the C default of 0.36) or the C default (when
 * `restart_is_default` is true).
 */
pdhcg_config_t pdhcg_config_select(int num_constraints,
                                   int num_variables,
                                   int num_nonzeros,
                                   int num_quadratic_constr);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* PDHCG_CONFIG_H */

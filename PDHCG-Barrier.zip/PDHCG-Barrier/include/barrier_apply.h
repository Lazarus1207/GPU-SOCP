/*
================================================================================
barrier_apply.h - Main Loop Integration (Option 1 + Option 2)

Stage 1.6: Main Loop Integration

Two insertion points (controlled by barrier_option_t):

  Option 1 (BARRIER_OPTION_1): After cone projection, BEFORE halpern_update.
    - Acts on pdhg_primal_solution (the point after Euclidean projection)
    - Rationale: clean up the projected point before acceleration pushes it

  Option 2 (BARRIER_OPTION_2): After halpern_update, at the end of the iteration.
    - Acts on current_primal_solution (the Halpern-accelerated point)
    - Rationale: barrier corrects the accelerated point that may have been
      pushed toward boundary

Both options:
  - Iterate over cone buckets (cones.buckets)
  - For each cone, compute ρ for every block
  - Call decide_trigger() per block
  - If triggered, extract block to host, run BPGrad, write back to device

5-Layer Protection (PDCS §6):
  L1: Gap filter (gap > thresh)
  L2: Boundary proximity filter (rho > rho_threshold)
  L3: NaN guard (after BPGrad)
  L4: Step-norm cap (||Δx|| <= cap * typical_step)
  L5: Primal-res guard (primal_res_new <= factor * primal_res_old)
================================================================================
*/

#pragma once

#include "barrier_params.h"
#include "barrier_module.h"
#include "barrier_trigger.h"
#include "internal_types.h"

#ifdef __cplusplus
extern "C"
{
#endif

/* =============================================================================
 * High-level barrier application functions
 * ============================================================================= */

/*
 * apply_barrier_to_state - Apply barrier to a single primal solution buffer.
 *
 * This is the core function that iterates over all cone blocks and applies
 * BPGrad where triggered. It is called from the main PDHG loop at the
 * appropriate insertion point (Option 1 or Option 2).
 *
 * Args:
 *   state       - PDHG solver state (for accessing cone buckets, primal_solution, etc.)
 *   params      - barrier parameters
 *   bs          - barrier state (mutable, updated with trigger counts)
 *   primal_buf  - device pointer to the primal solution to be modified
 *   iter        - current iteration number
 *
 * Returns: number of blocks that triggered barrier
 */
int apply_barrier_to_state(
    pdhg_solver_state_t *state,
    const barrier_params_t *params,
    barrier_state_t *bs,
    double *primal_buf,
    int iter
);

/*
 * Apply barrier to pdhg_primal_solution (Option 1 insertion point).
 * Called from within pdhg_update() AFTER dispatch_cone_projection().
 */
int apply_barrier_option_1(
    pdhg_solver_state_t *state,
    const barrier_params_t *params,
    barrier_state_t *bs,
    int iter
);

/*
 * Apply barrier to current_primal_solution (Option 2 insertion point).
 * Called from solver.cu main loop AFTER halpern_update().
 */
int apply_barrier_option_2(
    pdhg_solver_state_t *state,
    const barrier_params_t *params,
    barrier_state_t *bs,
    int iter
);

/*
 * Apply barrier to both points (Option 1 AND Option 2).
 * Used for ablation studies where both insertion points are tested.
 */
int apply_barrier_option_both(
    pdhg_solver_state_t *state,
    const barrier_params_t *params,
    barrier_state_t *bs,
    int iter
);

/* =============================================================================
 * Internal helper: apply barrier to a single cone block
 * ============================================================================= */

typedef struct {
    int block_global_idx;       /* Index in the global cone block list */
    int v_dim;                  /* Dimension of the cone block */
    cone_type_t cone_type;      /* Which cone type */
    double alpha;               /* Power cone alpha (0 for non-power) */
    int start_idx;              /* Start index in primal buffer */
    const char *is_fixed_d;     /* Device pointer to fixed slot flags (may be NULL) */
} cone_block_info_t;

/*
 * apply_barrier_to_single_block - Apply BPGrad to one cone block.
 *
 * This function:
 *   1. Extracts the cone block from primal_buf to host
 *   2. Computes boundary metric ρ
 *   3. Runs trigger decision
 *   4. If triggered, runs BPGrad
 *   5. Writes result back to device
 *   6. Updates barrier state counters
 *
 * Returns: 1 if barrier was applied, 0 otherwise
 */
int apply_barrier_to_single_block(
    cone_block_info_t *info,
    double *primal_buf_d,       /* Device primal buffer (full length) */
    const barrier_params_t *params,
    barrier_state_t *bs,
    double rho_hint,            /* Pre-computed ρ (avoids redundant computation) */
    double tau,                 /* PDHG step size */
    double gap,                 /* Current relative gap */
    int iter
);

#ifdef __cplusplus
}
#endif

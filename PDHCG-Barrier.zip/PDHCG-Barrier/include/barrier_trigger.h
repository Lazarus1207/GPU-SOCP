/*
================================================================================
barrier_trigger.h - Barrier Trigger Decision Engine

Stage 1.5: L0/L1/L2/L3 4-Layer Trigger Architecture

Architecture (borrowed from PDCS barrier_trigger.jl):

  L0: Global switch (barrier_enabled, check frequency)
  L1: Per-cone trigger mode (off/adaptive/conservative/always)
  L2: Runtime decision (gap filter, rho threshold, fixed slot check)
  L3: Adaptive fallback (sliding window feedback, threshold adjustment)

Decision result:
  - should_trigger: bool
  - reason: trigger_reason_t (for logging)
  - rho: boundary metric at decision point
  - mu: barrier parameter to use
================================================================================
*/

#pragma once

#include "barrier_params.h"
#include "boundary_metric.h"

#ifdef __cplusplus
extern "C"
{
#endif

typedef struct {
    bool should_trigger;
    trigger_reason_t reason;
    double rho;
    double mu;
} trigger_decision_t;

/* =============================================================================
 * Per-block context for trigger decision
 * ============================================================================= */

typedef struct {
    int iter;
    double gap;                    /* state->relative_objective_gap */
    cone_kind_t kind;
    const barrier_params_t *params;
    const barrier_state_t *state;
    bool is_fixed;                 /* Whether this block has any fixed slot */
} trigger_context_t;

/* =============================================================================
 * Main trigger decision function
 * ============================================================================= */

/*
 * decide_trigger - L0/L1/L2/L3 unified trigger decision
 *
 * Args:
 *   rho       - boundary metric Ï of the current cone block
 *   ctx       - per-block context (iter, gap, kind, params, state, fixed_slot)
 *
 * Returns: trigger_decision_t
 */
trigger_decision_t decide_trigger(double rho, const trigger_context_t *ctx);

/*
 * Compute mu based on strategy (Stage 1.5 Î¼ scheduling).
 *
 * Args:
 *   params - barrier parameters
 *   state - barrier state (for adaptive mu tracking)
 *   kind - which cone kind
 *   iter - current iteration
 *   rho - current boundary metric
 *   gap - current relative gap
 *
 * Returns: mu value to use
 */
double compute_barrier_mu(
    const barrier_params_t *params,
    barrier_state_t *state,
    cone_kind_t kind,
    int iter,
    double rho,
    double gap
);

#ifdef __cplusplus
}
#endif

#include <stdio.h>
#include <math.h>
#include <string.h>
#include "barrier_module.h"
#include "boundary_metric.h"

int main(void)
{
    int k = 5;
    double z = 10.0, nrm = 9.999999;
    double x[8] = {0};
    for (int i = 0; i < k; i++) x[i] = nrm * 0.3;
    x[k] = nrm * 0.9;
    x[k + 1] = z;

    double vsq = 0; for (int i=0;i<k;i++) vsq += x[i]*x[i];
    double inner = x[k+1]*x[k+1] - (vsq + x[k]*x[k]);
    printf("seed: ||v||^2+w^2 = %.12f, z^2 = %.6f, inner = %.6e\n", vsq + x[k]*x[k], x[k+1]*x[k+1], inner);
    printf("seed: norm=%.12f z=%.12f  norm-z = %.6e\n",
           sqrt(vsq + x[k]*x[k]), x[k+1], sqrt(vsq+x[k]*x[k]) - x[k+1]);

    boundary_metric_t b = boundary_metric_std_soc(k, x, NULL);
    printf("seed: feasible=%d rho=%.6e slack=%.6e\n", b.feasible, b.rho, b.slack);

    /* what the projection does */
    double y[8]; memcpy(y, x, sizeof(y));
    host_cone_project(CONE_STANDARD_SOC, k, y, NULL, 0.0, NULL);
    double vsq2 = 0; for (int i=0;i<k;i++) vsq2 += y[i]*y[i];
    printf("proj: inner = %.6e (exactly 0? %s)\n",
           y[k+1]*y[k+1] - (vsq2 + y[k]*y[k]),
           (y[k+1]*y[k+1] - (vsq2+y[k]*y[k])) == 0.0 ? "yes" : "no");

    barrier_params_t p; memset(&p,0,sizeof(p));
    p.barrier_max_iter=200; p.barrier_inner_max_iter=30;
    p.barrier_ls_alpha0=1.0; p.barrier_ls_beta=0.5; p.barrier_ls_c=1e-4;
    p.barrier_tol=1e-14;

    bpgrad_stats_t st = bpgrad_solve_block(CONE_STANDARD_SOC, k, x, NULL, NULL, 0.0, 1.0, 0.5, &p);
    double vsq3 = 0; for (int i=0;i<k;i++) vsq3 += x[i]*x[i];
    double inner3 = x[k+1]*x[k+1] - (vsq3 + x[k]*x[k]);
    boundary_metric_t b3 = boundary_metric_std_soc(k, x, NULL);
    printf("after: outer=%d inner=%d fallback=%d conv=%d\n",
           st.outer_iter, st.inner_iter, (int)st.fallback_used, (int)st.converged);
    printf("after: inner = %.6e  rho = %.6e\n", inner3, b3.rho);
    printf("after: z = %.6f  norm = %.6f\n", x[k+1], sqrt(vsq3 + x[k]*x[k]));
    return 0;
}
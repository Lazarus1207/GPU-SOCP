/* Standalone numerical self-test for the barrier module's StdSOC / RSOC
 * layout and BPGrad correctness.
 *
 * Build (see run_selftest.bat):
 *   nvcc -x cu -arch=sm_80 t_barrier_selftest.cu src\boundary_metric.c \
 *        src\barrier_module.c src\kernels\barrier_kernels.cu ...
 *
 * Checks:
 *   T1  StdSOC rho semantics on the PDHCG [v(k),w,z] layout
 *       - on the boundary  (||(v,w)|| == z)  -> rho == 0
 *       - on the axis      (v=0,w=0, z>0)    -> rho == 1
 *       - infeasible       (||(v,w)|| > z)    -> rho == 0, feasible == false
 *   T2  layout regression: the old (t,u) reading would have produced a
 *       different rho on the same buffer.  Guards against a silent revert.
 *   T3  host projection is idempotent on feasible input and fixes infeasible
 *   T4  BPGrad increases rho (pushes the point off the boundary) and stays
 *       feasible -- the actual scientific purpose of the barrier
 *   T5  BPGrad objective F = (1/2tau)||x-x_k||^2 + mu*phi  never increases
 *   T6  large-k cone (k = 500) is handled -- this used to hit the removed
 *       64-element stack limit and silently degrade to plain projection
 *   T7  GPU kernel and host solver agree on the same block
 */
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#include "boundary_metric.h"
#include "barrier_module.h"

extern "C" {
int launch_bpgrad_std_soc(double *x_d, int *converged_d,
                          const int *start_idx, const int *v_dim,
                          int num_blocks, double mu, double tau,
                          int max_iter, double tol,
                          double ls_alpha0, double ls_beta, int ls_max);
int launch_bpgrad_rsoc(double *x_d, int *converged_d,
                       const int *start_idx, const int *v_dim,
                       int num_blocks, double mu, double tau,
                       int max_iter, double tol,
                       double ls_alpha0, double ls_beta, int ls_max);
}

static int g_fail = 0;
static int g_pass = 0;

static void check(int cond, const char *what)
{
    if (cond) { g_pass++; printf("    [ OK ] %s\n", what); }
    else      { g_fail++; printf("    [FAIL] %s\n", what); }
}

static void check_near(double got, double want, double tol, const char *what)
{
    double d = fabs(got - want);
    if (d <= tol) { g_pass++; printf("    [ OK ] %s (got %.10g, want %.10g)\n", what, got, want); }
    else          { g_fail++; printf("    [FAIL] %s (got %.10g, want %.10g, |d|=%.3g)\n", what, got, want, d); }
}

/* Build a PDHCG StdSOC block  x = [v0..v_{k-1}, w, z]. */
static void mk_stdsoc(double *x, int k, double vmag, double w, double z)
{
    double *v = x;
    for (int i = 0; i < k; i++) v[i] = 0.0;
    if (k > 0) v[0] = vmag;
    x[k]     = w;
    x[k + 1] = z;
}

static double stdsoc_norm(const double *x, int k)
{
    double s = 0.0;
    for (int i = 0; i < k; i++) s += x[i] * x[i];
    s += x[k] * x[k];
    return sqrt(s);
}

/* ------------------------------------------------------------------------ */
static void test_stdsoc_rho(void)
{
    printf("\n[T1] StdSOC rho semantics on PDHCG [v(k),w,z] layout\n");
    const int k = 4;
    double x[8];

    /* on the boundary: ||(v,w)|| == z  ->  rho = 0 */
    mk_stdsoc(x, k, 0.0, 3.0, 5.0);
    x[0] = 3.0; x[1] = 0.0;              /* ||v|| = 3, w = 4 -> total 5 */
    x[k] = 4.0; x[k + 1] = 5.0;
    /* now norm == 5 == z exactly */
    boundary_metric_t bm = boundary_metric_std_soc(k, x, NULL);
    check(bm.feasible, "boundary point is feasible");
    check_near(bm.rho, 0.0, 1e-12, "rho == 0 on the cone boundary");

    /* on the axis: v = 0, w = 0, z > 0 -> rho = 1 */
    mk_stdsoc(x, k, 0.0, 0.0, 7.0);
    bm = boundary_metric_std_soc(k, x, NULL);
    check(bm.feasible, "axis point is feasible");
    check_near(bm.rho, 1.0, 1e-12, "rho == 1 on the cone axis");

    /* strict interior: halfway between axis and boundary -> rho = 0.5 */
    /*  z = 10, ||(v,w)|| = 5  =>  rho = sqrt(100-25)/10 = sqrt(75)/10 */
    mk_stdsoc(x, k, 0.0, 3.0, 10.0);
    x[0] = 4.0;                            /* ||v|| = 4, w = 3 -> 5 */
    bm = boundary_metric_std_soc(k, x, NULL);
    check(bm.feasible, "interior point is feasible");
    check_near(bm.rho, sqrt(75.0) / 10.0, 1e-12, "rho == sqrt(z^2-||.||^2)/z");

    /* infeasible: ||(v,w)|| > z */
    mk_stdsoc(x, k, 0.0, 0.0, 2.0);
    x[0] = 5.0;
    bm = boundary_metric_std_soc(k, x, NULL);
    check(!bm.feasible, "out-of-cone point detected as infeasible");
    check_near(bm.rho, 0.0, 1e-12, "rho == 0 when infeasible");

    /* negative z -> infeasible */
    mk_stdsoc(x, k, 0.0, 0.0, -1.0);
    bm = boundary_metric_std_soc(k, x, NULL);
    check(!bm.feasible, "negative z detected as infeasible");
}

/* ------------------------------------------------------------------------ */
static void test_layout_regression(void)
{
    printf("\n[T2] layout regression guard (old (t,u) reading would differ)\n");
    const int k = 4;
    double x[8];
    /* A block that is deep inside the cone ONLY under the [v,w,z] reading. */
    /* z = 10, w = 1, v = (1,1,1,1) -> norm = sqrt(4+1)=2.236, rho ~ 0.973 */
    mk_stdsoc(x, k, 1.0, 1.0, 10.0);
    x[1] = 1.0; x[2] = 1.0; x[3] = 1.0;

    boundary_metric_t bm = boundary_metric_std_soc(k, x, NULL);
    double expect = sqrt(100.0 - 5.0) / 10.0;
    check(bm.feasible, "block is feasible under [v,w,z]");
    check_near(bm.rho, expect, 1e-12, "rho matches the [v,w,z] formula");

    /* Under the OLD (t,u) reading this same buffer means t=1, u=(1,1,1,1),
     * which has ||u||=2 > t=1 -> INFEASIBLE.  A revert would flip this flag,
     * so assert the correct (feasible) answer explicitly. */
    check(bm.feasible,
          "reading as (t,u) would wrongly call this infeasible -- regression caught");
}

/* ------------------------------------------------------------------------ */
static void test_projection(void)
{
    printf("\n[T3] host projection on [v(k),w,z]\n");
    const int k = 4;
    double x[8];

    /* feasible input must be untouched (idempotent) */
    mk_stdsoc(x, k, 1.0, 1.0, 10.0);
    x[1] = 1.0; x[2] = 1.0; x[3] = 1.0;
    double before[8];
    memcpy(before, x, sizeof(before));
    host_cone_project(CONE_STANDARD_SOC, k, x, NULL, 0.0, NULL);
    int same = 1;
    for (int i = 0; i < k + 2; i++) if (x[i] != before[i]) same = 0;
    check(same, "feasible input is left unchanged by projection");

    /* infeasible input must become feasible */
    mk_stdsoc(x, k, 0.0, 0.0, 1.0);
    x[0] = 5.0; x[1] = 5.0; x[2] = 5.0; x[3] = 5.0; x[k] = 5.0;
    host_cone_project(CONE_STANDARD_SOC, k, x, NULL, 0.0, NULL);
    double nrm = stdsoc_norm(x, k);
    check(nrm <= x[k + 1] + 1e-12, "projection lands inside the cone");
    check(boundary_metric_std_soc(k, x, NULL).feasible,
          "projected point passes the feasibility test");
}

/* ------------------------------------------------------------------------ */
static void test_bpgrad_pushes_off_boundary(void)
{
    printf("\n[T4] BPGrad increases rho and preserves feasibility\n");
    const int k = 4;
    double mu = 1e-3, tau = 1.0;

    for (int trial = 0; trial < 3; trial++) {
        double zt = (trial == 0) ? 10.0 : (trial == 1) ? 1.0 : 100.0;
        double x[8];
        /* start essentially ON the boundary */
        double nrm = zt * 0.999999;
        mk_stdsoc(x, k, nrm * 0.6, nrm * 0.8, zt);
        for (int i = 0; i < k; i++) x[i] *= 0.6;   /* ||v|| = 0.6*nrm */
        x[k] = nrm * 0.8;
        x[k + 1] = zt;

        boundary_metric_t bm0 = boundary_metric_std_soc(k, x, NULL);
        if (!bm0.feasible) { printf("    [SKIP] trial %d: seed infeasible\n", trial); continue; }

        barrier_params_t p;
        memset(&p, 0, sizeof(p));
        p.barrier_max_iter     = 50;
        p.barrier_inner_max_iter = 20;
        p.barrier_ls_alpha0    = 1.0;
        p.barrier_ls_beta      = 0.5;
        p.barrier_ls_c         = 1e-4;
        p.barrier_tol          = 1e-12;

        bpgrad_stats_t st = bpgrad_solve_block(CONE_STANDARD_SOC, k, x,
                                                NULL, NULL, 0.0, tau, mu, &p);
        boundary_metric_t bm1 = boundary_metric_std_soc(k, x, NULL);

        char msg[160];
        snprintf(msg, sizeof(msg),
                 "trial %d (z=%g): feasible after BPGrad", trial, zt);
        check(bm1.feasible, msg);
        snprintf(msg, sizeof(msg),
                 "trial %d (z=%g): rho increased %.3e -> %.3e",
                 trial, zt, bm0.rho, bm1.rho);
        check(bm1.rho > bm0.rho, msg);
    }

    /* With a barrier weight that dominates the proximal term the step must
     * push the point a clearly visible distance off the boundary -- this is
     * the property the whole module exists for. */
    printf("    -- strong-barrier push (mu=0.5, tau=1.0) --\n");
    {
        const int k2 = 5;
        double x[8];
        /* feasible but very near the boundary: ||(v,w)|| = 0.9999 * z */
        const double z = 10.0, lat = 10.0 * 0.9999;
        double denom = sqrt((double)k2 + 81.0);
        double nrm = 0.0;
        for (int i = 0; i < k2; i++) { x[i] = lat / denom; nrm += x[i] * x[i]; }
        x[k2]     = lat * 9.0 / denom;
        x[k2 + 1] = z;

        boundary_metric_t bm0 = boundary_metric_std_soc(k2, x, NULL);
        printf("    seed: ||(v,w)|| = %.9f  z = %.4f  feasible=%d  rho=%.4e\n",
               sqrt(nrm + x[k2] * x[k2]), z, bm0.feasible, bm0.rho);
        if (!bm0.feasible) { check(0, "strong barrier: seed should be feasible"); return; }

        barrier_params_t p;
        memset(&p, 0, sizeof(p));
        p.barrier_max_iter       = 500;
        p.barrier_inner_max_iter = 40;
        p.barrier_ls_alpha0      = 1.0;
        p.barrier_ls_beta        = 0.5;
        p.barrier_ls_c           = 1e-4;
        p.barrier_tol            = 1e-16;

        bpgrad_solve_block(CONE_STANDARD_SOC, k2, x, NULL, NULL, 0.0, 1.0, 0.5, &p);
        boundary_metric_t bm1 = boundary_metric_std_soc(k2, x, NULL);
        printf("    rho %.4e -> %.4e\n", bm0.rho, bm1.rho);
        check(bm1.feasible, "strong barrier: still feasible");
        check(bm1.rho > bm0.rho + 1e-6, "strong barrier: rho rose by a visible amount");
    }

    /* A point projected EXACTLY onto the boundary is the case the barrier
     * most needs to repair: phi = -log(inner) is singular there, so the solver
     * must reseed rather than hand back a bare projection. */
    printf("    -- exactly-on-boundary recovery --\n");
    {
        const int k2 = 4;
        double x[8];
        for (int i = 0; i < k2; i++) x[i] = 3.0;
        x[k2]     = 4.0;
        x[k2 + 1] = 2.0;              /* deliberately infeasible */

        boundary_metric_t bm0 = boundary_metric_std_soc(k2, x, NULL);
        check(!bm0.feasible, "boundary-recovery seed starts infeasible");

        barrier_params_t p;
        memset(&p, 0, sizeof(p));
        p.barrier_max_iter       = 200;
        p.barrier_inner_max_iter = 30;
        p.barrier_ls_alpha0      = 1.0;
        p.barrier_ls_beta        = 0.5;
        p.barrier_ls_c           = 1e-4;
        p.barrier_tol            = 1e-16;

        bpgrad_solve_block(CONE_STANDARD_SOC, k2, x, NULL, NULL, 0.0, 1.0, 0.5, &p);
        boundary_metric_t bm1 = boundary_metric_std_soc(k2, x, NULL);
        printf("    rho after recovery = %.4e\n", bm1.rho);
        check(bm1.feasible, "boundary recovery: feasible");
        check(bm1.rho > 1e-7, "boundary recovery: ended strictly inside the cone");
    }
}

/* ------------------------------------------------------------------------ */
static void test_bpgrad_objective_monotone(void)
{
    printf("\n[T5] BPGrad never increases F = (1/2tau)||x-xk||^2 + mu*phi\n");
    const int k = 3;
    const double mu = 1e-2, tau = 2.0;

    double x[8];
    mk_stdsoc(x, k, 1.0, 2.0, 5.0);
    x[1] = 0.5; x[2] = 0.5;

    double vsq = 0.0;
    for (int i = 0; i < k; i++) vsq += x[i] * x[i];
    double inner0 = x[k + 1] * x[k + 1] - (vsq + x[k] * x[k]);
    double F0 = mu * (-log(inner0));

    barrier_params_t p;
    memset(&p, 0, sizeof(p));
    p.barrier_max_iter       = 60;
    p.barrier_inner_max_iter = 25;
    p.barrier_ls_alpha0      = 1.0;
    p.barrier_ls_beta        = 0.5;
    p.barrier_ls_c           = 1e-4;
    p.barrier_tol            = 1e-14;

    bpgrad_solve_block(CONE_STANDARD_SOC, k, x, NULL, NULL, 0.0, tau, mu, &p);

    vsq = 0.0;
    for (int i = 0; i < k; i++) vsq += x[i] * x[i];
    double inner1 = x[k + 1] * x[k + 1] - (vsq + x[k] * x[k]);
    double F1 = mu * (-log(inner1));

    printf("    F: %.10g -> %.10g\n", F0, F1);
    check(F1 <= F0 + 1e-12, "objective did not increase");
}

/* ------------------------------------------------------------------------ */
static void test_large_k(void)
{
    printf("\n[T6] large cone dimension (k=500) is handled by the host solver\n");
    const int k = 500;
    double *x = (double *)malloc((size_t)(k + 2) * sizeof(double));
    if (!x) { check(0, "malloc failed"); return; }

    for (int i = 0; i < k; i++) x[i] = 1.0;
    x[k]     = 3.0;
    x[k + 1] = 600.0;

    double vsq = 0.0;
    for (int i = 0; i < k; i++) vsq += x[i] * x[i];
    double inner0 = x[k + 1] * x[k + 1] - (vsq + x[k] * x[k]);
    check(inner0 > 0, "k=500 block starts feasible");

    barrier_params_t p;
    memset(&p, 0, sizeof(p));
    p.barrier_max_iter       = 30;
    p.barrier_inner_max_iter = 20;
    p.barrier_ls_alpha0      = 1.0;
    p.barrier_ls_beta        = 0.5;
    p.barrier_ls_c           = 1e-4;
    p.barrier_tol            = 1e-12;

    const double mu = 1e-4, tau = 1.0;
    bpgrad_stats_t st = bpgrad_solve_block(CONE_STANDARD_SOC, k, x,
                                            NULL, NULL, 0.0, tau, mu, &p);

    vsq = 0.0;
    for (int i = 0; i < k; i++) vsq += x[i] * x[i];
    double inner1 = x[k + 1] * x[k + 1] - (vsq + x[k] * x[k]);

    char msg[160];
    check(inner1 > 0, "k=500 stays feasible after BPGrad");
    /* This is the assertion the old grad[64] limit failed: a k>63 cone used
     * to be reported as fallback_used with no barrier step applied. */
    check(inner1 > inner0, "k=500 barrier actually moved the point inward");
    snprintf(msg, sizeof(msg),
             "k=500 solver reported outer_iter=%d inner_iter=%d fallback=%d",
             st.outer_iter, st.inner_iter, (int)st.fallback_used);
    printf("    %s\n", msg);

    free(x);
}

/* ------------------------------------------------------------------------ */
static void test_gpu_vs_host(void)
{
    printf("\n[T7] GPU kernel vs host solver on the same StdSOC block\n");
    const int k = 6;
    const double mu = 1e-3, tau = 1.0;
    const double tol = 1e-12;
    const int max_iter = 40;

    /* deep-interior seed so both backends have room to work */
    double seed[16];
    for (int i = 0; i < k; i++) seed[i] = 0.5 * (i + 1);
    seed[k]     = 2.0;
    seed[k + 1] = 40.0;

    /* ---- host ---- */
    double xh[16];
    memcpy(xh, seed, sizeof(seed));

    barrier_params_t p;
    memset(&p, 0, sizeof(p));
    p.barrier_max_iter       = max_iter;
    p.barrier_inner_max_iter = 20;
    p.barrier_ls_alpha0      = 1.0;
    p.barrier_ls_beta        = 0.5;
    p.barrier_ls_c           = 1e-4;
    p.barrier_tol            = tol;
    bpgrad_solve_block(CONE_STANDARD_SOC, k, xh, NULL, NULL, 0.0, tau, mu, &p);

    /* ---- device ---- */
    double *xd = NULL; int *convd = NULL, *startd = NULL, *vdimd = NULL;
    if (cudaMalloc((void **)&xd,     sizeof(seed)) != cudaSuccess) {
        check(0, "cudaMalloc x failed"); return;
    }
    if (cudaMalloc((void **)&convd,  sizeof(int))  != cudaSuccess) {
        check(0, "cudaMalloc conv failed"); free(0); return;
    }
    if (cudaMalloc((void **)&startd, sizeof(int))  != cudaSuccess) { check(0, "cudaMalloc start failed"); return; }
    if (cudaMalloc((void **)&vdimd,  sizeof(int))  != cudaSuccess) { check(0, "cudaMalloc vdim failed"); return; }

    cudaMemcpy(xd, seed, sizeof(seed), cudaMemcpyHostToDevice);
    int zero = 0, start = 0, kk = k;
    cudaMemcpy(convd, &zero,  sizeof(int), cudaMemcpyHostToDevice);
    cudaMemcpy(startd, &start, sizeof(int), cudaMemcpyHostToDevice);
    cudaMemcpy(vdimd,  &kk,   sizeof(int), cudaMemcpyHostToDevice);

    int rc = launch_bpgrad_std_soc(xd, convd, startd, vdimd, 1,
                                   mu, tau, max_iter, tol, 1.0, 0.5, 20);
    cudaDeviceSynchronize();
    check(rc == 0, "launch_bpgrad_std_soc returned success");

    int status = -1;
    cudaMemcpy(&status, convd, sizeof(int), cudaMemcpyDeviceToHost);
    printf("    gpu status = %d  (1=converged, 2=feasible-not-tol, 0=host fallback)\n", status);
    check(status == 1 || status == 2, "GPU kernel produced a barrier step (not a fallback)");

    double xg[16];
    cudaMemcpy(xg, xd, sizeof(seed), cudaMemcpyDeviceToHost);

    double diff = 0.0, mag = 0.0;
    for (int i = 0; i < k + 2; i++) {
        double d = fabs(xg[i] - xh[i]);
        if (d > diff) diff = d;
        if (fabs(xh[i]) > mag) mag = fabs(xh[i]);
    }
    printf("    max |gpu-host| = %.3e   (scale %.3e)\n", diff, mag);
    check(diff <= 1e-6 * (mag + 1.0), "GPU and host agree to 1e-6 relative");

    cudaFree(xd); cudaFree(convd); cudaFree(startd); cudaFree(vdimd);
}

/* ------------------------------------------------------------------------ */
static void test_rsoc_gpu_vs_host(void)
{
    printf("\n[T8] RSOC: GPU kernel vs host solver, and boundary-metric sanity\n");
    const int k = 5;
    const double mu = 1e-3, tau = 1.0, tol = 1e-12;
    const int max_iter = 40;

    /* deep-interior seed */
    double seed[16];
    for (int i = 0; i < k; i++) seed[i] = 0.4 * (i + 1);
    seed[k]     = 12.0;
    seed[k + 1] = 14.0;
    /* 2*s*t = 336, ||v||^2 = 0.16*(1+4+9+16+25) = 8.8 -> feasible */

    /* ---- host ---- */
    double xh[16];
    memcpy(xh, seed, sizeof(seed));

    barrier_params_t p;
    memset(&p, 0, sizeof(p));
    p.barrier_max_iter       = max_iter;
    p.barrier_inner_max_iter = 20;
    p.barrier_ls_alpha0      = 1.0;
    p.barrier_ls_beta        = 0.5;
    p.barrier_ls_c           = 1e-4;
    p.barrier_tol            = tol;
    bpgrad_solve_block(CONE_ROTATED_SOC, k, xh, NULL, NULL, 0.0, tau, mu, &p);

    /* ---- device ---- */
    double *xd = NULL; int *convd = NULL, *startd = NULL, *vdimd = NULL;
    if (cudaMalloc((void **)&xd, sizeof(seed)) != cudaSuccess) { check(0, "cudaMalloc x"); return; }
    if (cudaMalloc((void **)&convd, sizeof(int)) != cudaSuccess) { check(0, "cudaMalloc conv"); return; }
    if (cudaMalloc((void **)&startd, sizeof(int)) != cudaSuccess) { check(0, "cudaMalloc start"); return; }
    if (cudaMalloc((void **)&vdimd, sizeof(int)) != cudaSuccess) { check(0, "cudaMalloc vdim"); return; }

    cudaMemcpy(xd, seed, sizeof(seed), cudaMemcpyHostToDevice);
    int zero = 0, start = 0, kk = k;
    cudaMemcpy(convd, &zero, sizeof(int), cudaMemcpyHostToDevice);
    cudaMemcpy(startd, &start, sizeof(int), cudaMemcpyHostToDevice);
    cudaMemcpy(vdimd, &kk, sizeof(int), cudaMemcpyHostToDevice);

    int rc = launch_bpgrad_rsoc(xd, convd, startd, vdimd, 1,
                                mu, tau, max_iter, tol, 1.0, 0.5, 20);
    cudaDeviceSynchronize();
    check(rc == 0, "launch_bpgrad_rsoc returned success");

    int status = -1;
    cudaMemcpy(&status, convd, sizeof(int), cudaMemcpyDeviceToHost);
    printf("    gpu status = %d\n", status);
    check(status == 1 || status == 2, "RSOC GPU kernel produced a barrier step");

    double xg[16];
    cudaMemcpy(xg, xd, sizeof(seed), cudaMemcpyDeviceToHost);

    double diff = 0.0, mag = 0.0;
    for (int i = 0; i < k + 2; i++) {
        double d = fabs(xg[i] - xh[i]);
        if (d > diff) diff = d;
        if (fabs(xh[i]) > mag) mag = fabs(xh[i]);
    }
    printf("    max |gpu-host| = %.3e   (scale %.3e)\n", diff, mag);
    check(diff <= 1e-6 * (mag + 1.0), "RSOC GPU and host agree to 1e-6 relative");

    /* RSOC barrier must not push the point out of the cone */
    double v2 = 0.0;
    for (int i = 0; i < k; i++) v2 += xh[i] * xh[i];
    check(2.0 * xh[k] * xh[k + 1] - v2 > 0, "RSOC host result stays in the cone");

    cudaFree(xd); cudaFree(convd); cudaFree(startd); cudaFree(vdimd);
}

/* ------------------------------------------------------------------------ */
int main(void)
{
    printf("=====================================================\n");
    printf(" PDHCG-Barrier module self-test\n");
    printf("=====================================================\n");

    test_stdsoc_rho();
    test_layout_regression();
    test_projection();
    test_bpgrad_pushes_off_boundary();
    test_bpgrad_objective_monotone();
    test_large_k();
    test_gpu_vs_host();
    test_rsoc_gpu_vs_host();

    printf("\n=====================================================\n");
    printf(" passed: %d   failed: %d\n", g_pass, g_fail);
    printf("=====================================================\n");
    return g_fail ? 1 : 0;
}
#!/bin/bash
# =============================================================================
# Step-4 build & verify helper  (run ON the server, gpu-5)
#
#   bash step4_verify.sh
#
# Steps:
#   1. rebuild the solver
#   2. run the barrier numerical self-test (no benchmark instance needed)
#   3. print the summary schema check
# =============================================================================
set -uo pipefail

SRC=/DATA/disk1/zhongyingze/PDHCG-Barrier
BUILD=$SRC/build_full
EXP=/DATA/disk1/zhongyingze/exp

echo "=============================================================="
echo " Step 4 verify"
echo "=============================================================="

# ---------------------------------------------------------------- 1. build
echo ""
echo "### [1/3] rebuild ###"
if [ ! -d "$BUILD" ]; then
    echo "ERROR: build dir not found: $BUILD"
    exit 1
fi
cd "$BUILD" || exit 1
if ! make -j8 2>&1 | tail -25; then
    echo "ERROR: build failed"
    exit 1
fi
if [ ! -x "$BUILD/pdhcg" ]; then
    echo "ERROR: binary not produced at $BUILD/pdhcg"
    exit 1
fi
echo "build OK: $BUILD/pdhcg"

# ------------------------------------------------------------ 2. self-test
echo ""
echo "### [2/3] barrier numerical self-test ###"
cd "$SRC" || exit 1
nvcc -x cu -arch=sm_80 \
     Test/t_barrier_selftest.cu \
     src/boundary_metric.c \
     src/barrier_module.c \
     src/kernels/barrier_kernels.cu \
     -Iinclude -Iinternal -Isrc -DPDHCG_BARRIER_ENABLE \
     -o /tmp/step4_selftest -lcudart 2>&1 | grep -v C4819 | tail -10

if [ ! -x /tmp/step4_selftest ]; then
    echo "ERROR: self-test failed to build (see errors above)"
    exit 1
fi

CUDA_VISIBLE_DEVICES=${GPU:-4} /tmp/step4_selftest
ST=$?
if [ $ST -ne 0 ]; then
    echo "ERROR: self-test reported failures (exit $ST)"
    exit $ST
fi
echo "self-test PASS"

# --------------------------------------------------------- 3. summary keys
echo ""
echo "### [3/3] barrier counters in _summary.txt ###"
S=$(find "$EXP" -name '*_summary.txt' 2>/dev/null | head -1)
if [ -z "$S" ]; then
    echo "no summary file found yet -- run exp1_smoke.sh first"
else
    echo "checking: $S"
    MISSING=0
    for k in "Barrier Enabled" "Barrier Option" "Barrier Mu Strategy" \
             "Barrier Triggers Total" "Barrier GPU Accepted" \
             "Barrier Host Accepted" "Barrier GPU Fallbacks" \
             "Barrier Step Rejects" "Barrier NaN Rejects" \
             "Barrier Primal Res Rejects"; do
        if grep -q "^$k:" "$S"; then
            printf '  [ OK ] %s\n' "$k"
        else
            printf '  [MISS] %s\n' "$k"
            MISSING=$((MISSING + 1))
        fi
    done
    if [ $MISSING -ne 0 ]; then
        echo "ERROR: $MISSING barrier field(s) missing from _summary.txt"
        echo "       (this summary was produced by the OLD binary -- re-run exp1_smoke.sh)"
        exit 1
    fi
    echo ""
    echo "--- barrier block from $S ---"
    grep "^Barrier " "$S"
fi

echo ""
echo "=============================================================="
echo " Step 4 verify complete"
echo " Next: cd $EXP/scripts && PROBS=beam7 GPU=${GPU:-4} TIME_LIMIT=120 bash exp1_smoke.sh"
echo "=============================================================="

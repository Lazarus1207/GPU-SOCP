/*
================================================================================
test_barrier_cli.c - Host-only verification of barrier CLI parsing logic

Compile (MSVC, no CUDA needed):
  cl /I..\PDHCG-Base\include /I..\PDHCG-Barrier\PDHCG-Barrier\include ^
     /std:c99 /O2 /Fe:test_barrier_cli.exe ^
     test_barrier_cli.c ^
     ..\PDHCG-Barrier\PDHCG-Barrier\srcarrier_params.c

Or with gcc:
  gcc -I../PDHCG-Base/include -I../PDHCG-Barrier/PDHCG-Barrier/include ^
      -std=c99 -O2 -o test_barrier_cli.exe ^
      test_barrier_cli.c ../PDHCG-Barrier/PDHCG-Barrier/src/barrier_params.c

Run:
  test_barrier_cli.exe

This program verifies:
  1. create_default_barrier_params() produces correct defaults
  2. parse_barrier_cli_option() correctly parses all 25 --barrier_* flags
  3. long_options array is correctly populated by add_barrier_cli_options()
  4. print_barrier_cli_help() does not crash
================================================================================
*/

#include "barrier_cli.h"
#include "barrier_params.h"
#include "pdhcg_types.h"
#include <getopt.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Option codes (must match barrier_cli.c's internal codes 3001-3025) */
#define OPT_B_ENABLED     3001
#define OPT_B_OPTION     3002
#define OPT_B_MU_INIT   3003
#define OPT_B_MU_FINAL  3004
#define OPT_B_MU_STRAT  3005
#define OPT_B_MU_RHO    3006
#define OPT_B_SOC_RSOC_R 3007
#define OPT_B_STD_SOC_R 3008
#define OPT_B_EXP_R     3009
#define OPT_B_POWER_R   3010
#define OPT_B_MAX_ITER  3011
#define OPT_B_INNER_MAX 3012
#define OPT_B_TOL       3013
#define OPT_B_CHECK_EV  3014
#define OPT_B_GAP_THR   3015
#define OPT_B_STEP_CAP  3016
#define OPT_B_PRIM_RES  3017
#define OPT_B_ADAPTIVE  3018
#define OPT_B_VERBOSE   3019
#define OPT_B_HOM_ALPHA 3020
#define OPT_B_HOM_BETA  3021
#define OPT_B_SOC_INIT  3022
#define OPT_B_STD_INIT  3023
#define OPT_B_EXP_INIT  3024
#define OPT_B_POWER_INI 3025

static int tests_passed = 0;
static int tests_failed = 0;

#define TEST(cond, msg) do {     if (cond) {         printf("  [PASS] %s
", msg);         tests_passed++;     } else {         printf("  [FAIL] %s
", msg);         tests_failed++;     } } while(0)

/* ---- Test 1: Default values ---- */
static void test_defaults(void)
{
    printf("
[Test 1] Default values from create_default_barrier_params()
");
    barrier_params_t *bp = create_default_barrier_params();
    TEST(bp != NULL, "bp not NULL");
    TEST(bp->barrier_enabled == false, "barrier_enabled = false by default");
    TEST(bp->barrier_option == BARRIER_OPTION_1, "barrier_option = BARRIER_OPTION_1");
    TEST(bp->barrier_mu_strategy == BARRIER_MU_CONSTANT, "barrier_mu_strategy = CONSTANT");
    TEST(bp->barrier_mu_init > 0.09 && bp->barrier_mu_init < 0.11, "barrier_mu_init ~= 0.1");
    TEST(bp->barrier_mu_final > 1e-7 && bp->barrier_mu_final < 1e-5, "barrier_mu_final ~= 1e-6");
    TEST(bp->barrier_mu_rho > 0.94 && bp->barrier_mu_rho < 0.96, "barrier_mu_rho ~= 0.95");
    TEST(bp->soc_rsoc_mu_init > 0.09 && bp->soc_rsoc_mu_init < 0.11, "soc_rsoc_mu_init ~= 0.1");
    TEST(bp->exp_mu_init > 0.009 && bp->exp_mu_init < 0.011, "exp_mu_init ~= 0.01");
    TEST(bp->soc_rsoc_max_ratio > 9.0 && bp->soc_rsoc_max_ratio < 11.0, "soc_rsoc_max_ratio ~= 10.0");
    TEST(bp->barrier_max_iter == 20, "barrier_max_iter = 20");
    TEST(bp->barrier_inner_max_iter == 10, "barrier_inner_max_iter = 10");
    TEST(bp->barrier_check_every == 1, "barrier_check_every = 1");
    TEST(bp->barrier_verbose == 1, "barrier_verbose = 1");
    free_barrier_params(bp);
}

/* ---- Test 2: parse_barrier_cli_option for each flag ---- */
static void test_parse_option(void)
{
    printf("
[Test 2] parse_barrier_cli_option() for all 25 flags
");

    barrier_params_t *bp = create_default_barrier_params();

    /* 1. --barrier_enabled 1 */
    memset(bp, 0, sizeof(*bp)); set_default_barrier_params(bp);
    parse_barrier_cli_option(bp, OPT_B_ENABLED, "1");
    TEST(bp->barrier_enabled == true, "--barrier_enabled 1 â enabled");

    /* 2. --barrier_enabled 0 */
    memset(bp, 0, sizeof(*bp)); set_default_barrier_params(bp);
    parse_barrier_cli_option(bp, OPT_B_ENABLED, "0");
    TEST(bp->barrier_enabled == false, "--barrier_enabled 0 â disabled");

    /* 3. --barrier_option 2 */
    parse_barrier_cli_option(bp, OPT_B_OPTION, "2");
    TEST(bp->barrier_option == BARRIER_OPTION_2, "--barrier_option 2");

    /* 4. --barrier_option 1 */
    parse_barrier_cli_option(bp, OPT_B_OPTION, "1");
    TEST(bp->barrier_option == BARRIER_OPTION_1, "--barrier_option 1");

    /* 5. --barrier_mu_init 0.5 */
    parse_barrier_cli_option(bp, OPT_B_MU_INIT, "0.5");
    TEST(bp->barrier_mu_init > 0.49 && bp->barrier_mu_init < 0.51, "--barrier_mu_init 0.5");

    /* 6. --barrier_mu_final 1e-8 */
    parse_barrier_cli_option(bp, OPT_B_MU_FINAL, "1e-8");
    TEST(bp->barrier_mu_final > 1e-9 && bp->barrier_mu_final < 1e-7, "--barrier_mu_final 1e-8");

    /* 7-10. mu strategies */
    parse_barrier_cli_option(bp, OPT_B_MU_STRAT, "0");
    TEST(bp->barrier_mu_strategy == BARRIER_MU_CONSTANT, "--barrier_mu_strategy 0 â CONSTANT");
    parse_barrier_cli_option(bp, OPT_B_MU_STRAT, "1");
    TEST(bp->barrier_mu_strategy == BARRIER_MU_EXPONENTIAL, "--barrier_mu_strategy 1 â EXPONENTIAL");
    parse_barrier_cli_option(bp, OPT_B_MU_STRAT, "2");
    TEST(bp->barrier_mu_strategy == BARRIER_MU_ADAPTIVE, "--barrier_mu_strategy 2 â ADAPTIVE");
    parse_barrier_cli_option(bp, OPT_B_MU_STRAT, "3");
    TEST(bp->barrier_mu_strategy == BARRIER_MU_HOMOTOPY, "--barrier_mu_strategy 3 â HOMOTOPY");

    /* 11. invalid strategy clamped */
    parse_barrier_cli_option(bp, OPT_B_MU_STRAT, "99");
    TEST(bp->barrier_mu_strategy == BARRIER_MU_HOMOTOPY, "--barrier_mu_strategy 99 clamped to last valid");

    /* 12. --barrier_mu_rho */
    parse_barrier_cli_option(bp, OPT_B_MU_RHO, "0.9");
    TEST(bp->barrier_mu_rho > 0.89 && bp->barrier_mu_rho < 0.91, "--barrier_mu_rho 0.9");

    /* 13-16. per-cone max_ratio */
    parse_barrier_cli_option(bp, OPT_B_SOC_RSOC_R, "5.0");
    TEST(bp->soc_rsoc_max_ratio > 4.9 && bp->soc_rsoc_max_ratio < 5.1, "--barrier_soc_rsoc_ratio 5.0");
    parse_barrier_cli_option(bp, OPT_B_STD_SOC_R, "20.0");
    TEST(bp->std_soc_max_ratio > 19.9 && bp->std_soc_max_ratio < 20.1, "--barrier_std_soc_ratio 20.0");
    parse_barrier_cli_option(bp, OPT_B_EXP_R, "3.0");
    TEST(bp->exp_max_ratio > 2.9 && bp->exp_max_ratio < 3.1, "--barrier_exp_ratio 3.0");
    parse_barrier_cli_option(bp, OPT_B_POWER_R, "8.0");
    TEST(bp->power_max_ratio > 7.9 && bp->power_max_ratio < 8.1, "--barrier_power_ratio 8.0");

    /* 17-18. BPGrad iterations */
    parse_barrier_cli_option(bp, OPT_B_MAX_ITER, "100");
    TEST(bp->barrier_max_iter == 100, "--barrier_max_iter 100");
    parse_barrier_cli_option(bp, OPT_B_INNER_MAX, "50");
    TEST(bp->barrier_inner_max_iter == 50, "--barrier_inner_max_iter 50");

    /* 19. --barrier_tol */
    parse_barrier_cli_option(bp, OPT_B_TOL, "1e-12");
    TEST(bp->barrier_tol > 1e-13 && bp->barrier_tol < 1e-11, "--barrier_tol 1e-12");

    /* 20. --barrier_check_every */
    parse_barrier_cli_option(bp, OPT_B_CHECK_EV, "10");
    TEST(bp->barrier_check_every == 10, "--barrier_check_every 10");

    /* 21. --barrier_gap_threshold */
    parse_barrier_cli_option(bp, OPT_B_GAP_THR, "1e-2");
    TEST(bp->barrier_gap_threshold > 0.009 && bp->barrier_gap_threshold < 0.011, "--barrier_gap_threshold 1e-2");

    /* 22. --barrier_step_norm_cap */
    parse_barrier_cli_option(bp, OPT_B_STEP_CAP, "5.0");
    TEST(bp->barrier_step_norm_cap > 4.9 && bp->barrier_step_norm_cap < 5.1, "--barrier_step_norm_cap 5.0");

    /* 23. --barrier_primal_res_factor */
    parse_barrier_cli_option(bp, OPT_B_PRIM_RES, "2.0");
    TEST(bp->barrier_primal_res_factor > 1.9 && bp->barrier_primal_res_factor < 2.1, "--barrier_primal_res_factor 2.0");

    /* 24. --barrier_adaptive_threshold */
    parse_barrier_cli_option(bp, OPT_B_ADAPTIVE, "0");
    TEST(bp->barrier_adaptive_threshold == false, "--barrier_adaptive_threshold 0");
    parse_barrier_cli_option(bp, OPT_B_ADAPTIVE, "1");
    TEST(bp->barrier_adaptive_threshold == true, "--barrier_adaptive_threshold 1");

    /* 25. --barrier_verbose */
    parse_barrier_cli_option(bp, OPT_B_VERBOSE, "2");
    TEST(bp->barrier_verbose == 2, "--barrier_verbose 2");

    /* 26. --barrier_homotopy_alpha */
    parse_barrier_cli_option(bp, OPT_B_HOM_ALPHA, "0.5");
    TEST(bp->barrier_homotopy_alpha > 0.49 && bp->barrier_homotopy_alpha < 0.51, "--barrier_homotopy_alpha 0.5");

    /* 27. --barrier_homotopy_beta */
    parse_barrier_cli_option(bp, OPT_B_HOM_BETA, "1.5");
    TEST(bp->barrier_homotopy_beta > 1.49 && bp->barrier_homotopy_beta < 1.51, "--barrier_homotopy_beta 1.5");

    /* 28-31. per-cone mu_init overrides */
    parse_barrier_cli_option(bp, OPT_B_SOC_INIT, "0.5");
    TEST(bp->soc_rsoc_mu_init > 0.49 && bp->soc_rsoc_mu_init < 0.51, "--barrier_soc_rsoc_mu_init 0.5");
    parse_barrier_cli_option(bp, OPT_B_STD_INIT, "0.2");
    TEST(bp->std_soc_mu_init > 0.19 && bp->std_soc_mu_init < 0.21, "--barrier_std_soc_mu_init 0.2");
    parse_barrier_cli_option(bp, OPT_B_EXP_INIT, "0.05");
    TEST(bp->exp_mu_init > 0.049 && bp->exp_mu_init < 0.051, "--barrier_exp_mu_init 0.05");
    parse_barrier_cli_option(bp, OPT_B_POWER_INI, "0.03");
    TEST(bp->power_mu_init > 0.029 && bp->power_mu_init < 0.031, "--barrier_power_mu_init 0.03");

    /* 32. unrecognized option returns 0 */
    int ret = parse_barrier_cli_option(bp, 9999, "value");
    TEST(ret == 0, "unrecognized option returns 0");

    /* 33. NULL bp returns 0 */
    ret = parse_barrier_cli_option(NULL, OPT_B_ENABLED, "1");
    TEST(ret == 0, "NULL bp returns 0");

    free_barrier_params(bp);
}

/* ---- Test 3: add_barrier_cli_options array population ---- */
static void test_add_options(void)
{
    printf("
[Test 3] add_barrier_cli_options() array population
");
    struct option opts[30];
    memset(opts, 0, sizeof(opts));

    int n = add_barrier_cli_options(opts, 30);
    TEST(n == 25, "add_barrier_cli_options returns 25 entries");

    /* Check that long_options array has expected entries */
    int found_enabled = 0, found_option = 0, found_mu_init = 0;
    int found_max_iter = 0, found_verbose = 0, found_homotopy = 0;
    for (int i = 0; i < n; i++) {
        if (strcmp(opts[i].name, "barrier_enabled") == 0) {
            TEST(opts[i].val == OPT_B_ENABLED, "barrier_enabled code = 3001");
            TEST(opts[i].has_arg == required_argument, "barrier_enabled has_arg=required");
            found_enabled = 1;
        }
        if (strcmp(opts[i].name, "barrier_option") == 0) {
            TEST(opts[i].val == OPT_B_OPTION, "barrier_option code = 3002");
            found_option = 1;
        }
        if (strcmp(opts[i].name, "barrier_mu_init") == 0) {
            TEST(opts[i].val == OPT_B_MU_INIT, "barrier_mu_init code = 3003");
            found_mu_init = 1;
        }
        if (strcmp(opts[i].name, "barrier_max_iter") == 0) {
            TEST(opts[i].val == OPT_B_MAX_ITER, "barrier_max_iter code = 3011");
            found_max_iter = 1;
        }
        if (strcmp(opts[i].name, "barrier_verbose") == 0) {
            TEST(opts[i].val == OPT_B_VERBOSE, "barrier_verbose code = 3019");
            found_verbose = 1;
        }
        if (strcmp(opts[i].name, "barrier_homotopy_alpha") == 0) {
            TEST(opts[i].val == OPT_B_HOM_ALPHA, "barrier_homotopy_alpha code = 3020");
            found_homotopy = 1;
        }
    }
    TEST(found_enabled, "barrier_enabled in options");
    TEST(found_option, "barrier_option in options");
    TEST(found_mu_init, "barrier_mu_init in options");
    TEST(found_max_iter, "barrier_max_iter in options");
    TEST(found_verbose, "barrier_verbose in options");
    TEST(found_homotopy, "barrier_homotopy_alpha in options");

    /* Check sentinel */
    TEST(opts[n].name == NULL && opts[n].val == 0, "last entry is sentinel {0,0,0,0}");
}

/* ---- Test 4: Simulate full CLI parse cycle ---- */
static void test_cli_cycle(void)
{
    printf("
[Test 4] Simulate full CLI parse cycle (--barrier_enabled 1 --barrier_option 2 --barrier_verbose 2)
");

    barrier_params_t *bp = create_default_barrier_params();

    /* Simulate: pdhcg problem.cbf out --barrier_enabled 1 --barrier_option 2 --barrier_verbose 2 */
    parse_barrier_cli_option(bp, OPT_B_ENABLED, "1");
    parse_barrier_cli_option(bp, OPT_B_OPTION, "2");
    parse_barrier_cli_option(bp, OPT_B_VERBOSE, "2");

    TEST(bp->barrier_enabled == true, "After CLI: barrier_enabled = true");
    TEST(bp->barrier_option == BARRIER_OPTION_2, "After CLI: barrier_option = BARRIER_OPTION_2");
    TEST(bp->barrier_verbose == 2, "After CLI: barrier_verbose = 2");

    free_barrier_params(bp);
}

/* ---- Test 5: print_barrier_cli_help() does not crash ---- */
static void test_help(void)
{
    printf("
[Test 5] print_barrier_cli_help() output (first 5 lines)
");
    printf("  [output]
");
    /* Redirect stderr to capture */
    print_barrier_cli_help();
    printf("  [end output]
");
    /* If we get here without crash, pass */
    TEST(1, "print_barrier_cli_help() completed without crash");
}

int main(void)
{
    printf("=== Barrier CLI Integration Verification ===
");
    printf("Testing: barrier_cli.c / barrier_params.c / barrier_params.h
");
    printf("Compiler: %s
",
#ifdef _MSC_VER
        "MSVC"
#elif defined(__GNUC__)
        "GCC"
#else
        "Unknown"
#endif
    );

    test_defaults();
    test_parse_option();
    test_add_options();
    test_cli_cycle();
    test_help();

    printf("
========================================
");
    printf("Results: %d passed, %d failed
", tests_passed, tests_failed);
    printf("========================================
");

    return tests_failed > 0 ? 1 : 0;
}

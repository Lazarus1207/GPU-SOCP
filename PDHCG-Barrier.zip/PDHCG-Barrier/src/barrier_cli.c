/*
================================================================================
barrier_cli.c - CLI Integration for Barrier Parameters

Implements the four public entry points declared in barrier_cli.h:

    create_default_barrier_params()  - allocate + default-initialise
    free_barrier_params()             - release
    parse_barrier_cli_option()        - dispatch one --barrier_* option
    add_barrier_cli_options()         - fill a getopt_long option table
    print_barrier_cli_help()          - usage text for the main CLI

This translation unit deliberately contains NO main(): it is folded into the
pdhcg_core library, and a second main() there would collide with cli.c and
run_benchmark_main.c at link time.  The host-only self test lives in
Test/test_barrier_cli.c instead.
================================================================================
*/

#include "barrier_cli.h"
#include "barrier_params.h"
#include "pdhcg_types.h"
#include <getopt.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* =============================================================================
 * Section 1: Allocation / Release
 * ============================================================================= */

struct barrier_params_t *create_default_barrier_params(void)
{
    barrier_params_t *bp = (barrier_params_t *)calloc(1, sizeof(barrier_params_t));
    if (!bp) {
        fprintf(stderr, "[barrier_cli] ERROR: failed to allocate barrier_params_t\n");
        return NULL;
    }
    set_default_barrier_params(bp);
    return bp;
}

void free_barrier_params(struct barrier_params_t *bp)
{
    free(bp);
}

/* =============================================================================
 * Section 2: Option Parsing
 * ============================================================================= */

int parse_barrier_cli_option(struct barrier_params_t *bp, int opt, const char *optarg)
{
    if (!bp || !optarg) return 0;

    switch (opt) {
        case OPT_BARRIER_ENABLED:
            bp->barrier_enabled = (atoi(optarg) != 0);
            break;

        case OPT_BARRIER_OPTION:
        {
            int v = atoi(optarg);
            if (v < BARRIER_OPTION_DISABLED || v >= BARRIER_OPTION_MAX) {
                fprintf(stderr, "[barrier_cli] WARNING: --barrier_option %d out of range, ignored\n", v);
                return 1;
            }
            bp->barrier_option = (barrier_option_t)v;
            break;
        }

        case OPT_BARRIER_MU_INIT:
            bp->barrier_mu_init = atof(optarg);
            break;

        case OPT_BARRIER_MU_FINAL:
            bp->barrier_mu_final = atof(optarg);
            break;

        case OPT_BARRIER_MU_STRATEGY:
        {
            int s = atoi(optarg);
            if (s < 0) s = 0;
            if (s >= BARRIER_MU_NUM_STRATEGIES) s = BARRIER_MU_NUM_STRATEGIES - 1;
            bp->barrier_mu_strategy = (barrier_mu_strategy_t)s;
            break;
        }

        case OPT_BARRIER_MU_RHO:
            bp->barrier_mu_rho = atof(optarg);
            break;

        case OPT_BARRIER_SOC_RSOC_RATIO:
            bp->soc_rsoc_max_ratio = atof(optarg);
            break;

        case OPT_BARRIER_STD_SOC_RATIO:
            bp->std_soc_max_ratio = atof(optarg);
            break;

        case OPT_BARRIER_EXP_RATIO:
            bp->exp_max_ratio = atof(optarg);
            break;

        case OPT_BARRIER_POWER_RATIO:
            bp->power_max_ratio = atof(optarg);
            break;

        case OPT_BARRIER_MAX_ITER:
            bp->barrier_max_iter = atoi(optarg);
            break;

        case OPT_BARRIER_INNER_MAX_ITER:
            bp->barrier_inner_max_iter = atoi(optarg);
            break;

        case OPT_BARRIER_TOL:
            bp->barrier_tol = atof(optarg);
            break;

        case OPT_BARRIER_CHECK_EVERY:
            bp->barrier_check_every = atoi(optarg);
            break;

        case OPT_BARRIER_GAP_THRESHOLD:
            bp->barrier_gap_threshold = atof(optarg);
            break;

        case OPT_BARRIER_STEP_NORM_CAP:
            bp->barrier_step_norm_cap = atof(optarg);
            break;

        case OPT_BARRIER_PRIMAL_RES_FACTOR:
            bp->barrier_primal_res_factor = atof(optarg);
            break;

        case OPT_BARRIER_ADAPTIVE_THRESHOLD:
            bp->barrier_adaptive_threshold = (atoi(optarg) != 0);
            break;

        case OPT_BARRIER_VERBOSE:
            bp->barrier_verbose = atoi(optarg);
            break;

        case OPT_BARRIER_HOMOTOPY_ALPHA:
            bp->barrier_homotopy_alpha = atof(optarg);
            break;

        case OPT_BARRIER_HOMOTOPY_BETA:
            bp->barrier_homotopy_beta = atof(optarg);
            break;

        case OPT_BARRIER_SOC_RSOC_MU_INIT:
            bp->soc_rsoc_mu_init = atof(optarg);
            break;

        case OPT_BARRIER_STD_SOC_MU_INIT:
            bp->std_soc_mu_init = atof(optarg);
            break;

        case OPT_BARRIER_EXP_MU_INIT:
            bp->exp_mu_init = atof(optarg);
            break;

        case OPT_BARRIER_POWER_MU_INIT:
            bp->power_mu_init = atof(optarg);
            break;

        case OPT_BARRIER_USE_GPU_BPGRAD:
            bp->barrier_use_gpu_bpgrad = (atoi(optarg) != 0);
            break;

        default:
            return 0;
    }
    return 1;
}

/* =============================================================================
 * Section 3: Option Table
 * ============================================================================= */

/*
 * The long-option names are the single source of truth for the CLI surface.
 * The `val` field is the OPT_BARRIER_* code, which parse_barrier_cli_option()
 * dispatches on -- so adding a flag here automatically makes it parseable.
 *
 * NOTE: the macro parameter is called `opt_name` (not `name`) because `name`
 * is also a struct-option member; a parameter named `name` would be substituted
 * into `options[n].name` and break the assignment.
 */
#define ADD_OPT(opt_name, opt_code)                                                     \
    do {                                                                              \
        if (n < max_size) {                                                           \
            options[n].name = opt_name;                                                \
            options[n].has_arg = required_argument;                                   \
            options[n].flag = NULL;                                                   \
            options[n].val = (opt_code);                                              \
            n++;                                                                       \
        }                                                                              \
    } while (0)

int add_barrier_cli_options(struct option *options, int max_size)
{
    int n = 0;
    if (!options || max_size <= 0) return 0;

    ADD_OPT("barrier_enabled", OPT_BARRIER_ENABLED);
    ADD_OPT("barrier_option", OPT_BARRIER_OPTION);
    ADD_OPT("barrier_mu_init", OPT_BARRIER_MU_INIT);
    ADD_OPT("barrier_mu_final", OPT_BARRIER_MU_FINAL);
    ADD_OPT("barrier_mu_strategy", OPT_BARRIER_MU_STRATEGY);
    ADD_OPT("barrier_mu_rho", OPT_BARRIER_MU_RHO);
    ADD_OPT("barrier_soc_rsoc_ratio", OPT_BARRIER_SOC_RSOC_RATIO);
    ADD_OPT("barrier_std_soc_ratio", OPT_BARRIER_STD_SOC_RATIO);
    ADD_OPT("barrier_exp_ratio", OPT_BARRIER_EXP_RATIO);
    ADD_OPT("barrier_power_ratio", OPT_BARRIER_POWER_RATIO);
    ADD_OPT("barrier_max_iter", OPT_BARRIER_MAX_ITER);
    ADD_OPT("barrier_inner_max_iter", OPT_BARRIER_INNER_MAX_ITER);
    ADD_OPT("barrier_tol", OPT_BARRIER_TOL);
    ADD_OPT("barrier_check_every", OPT_BARRIER_CHECK_EVERY);
    ADD_OPT("barrier_gap_threshold", OPT_BARRIER_GAP_THRESHOLD);
    ADD_OPT("barrier_step_norm_cap", OPT_BARRIER_STEP_NORM_CAP);
    ADD_OPT("barrier_primal_res_factor", OPT_BARRIER_PRIMAL_RES_FACTOR);
    ADD_OPT("barrier_adaptive_threshold", OPT_BARRIER_ADAPTIVE_THRESHOLD);
    ADD_OPT("barrier_verbose", OPT_BARRIER_VERBOSE);
    ADD_OPT("barrier_homotopy_alpha", OPT_BARRIER_HOMOTOPY_ALPHA);
    ADD_OPT("barrier_homotopy_beta", OPT_BARRIER_HOMOTOPY_BETA);
    ADD_OPT("barrier_soc_rsoc_mu_init", OPT_BARRIER_SOC_RSOC_MU_INIT);
    ADD_OPT("barrier_std_soc_mu_init", OPT_BARRIER_STD_SOC_MU_INIT);
    ADD_OPT("barrier_exp_mu_init", OPT_BARRIER_EXP_MU_INIT);
    ADD_OPT("barrier_power_mu_init", OPT_BARRIER_POWER_MU_INIT);
    ADD_OPT("barrier_use_gpu_bpgrad", OPT_BARRIER_USE_GPU_BPGRAD);

    return n;
}

#undef ADD_OPT

/* =============================================================================
 * Section 4: Help Text
 * ============================================================================= */

void print_barrier_cli_help(void)
{
    fprintf(stderr, "\nBarrier Options (PDHCG-Barrier extension):\n");
    fprintf(stderr, "      --barrier_enabled <0|1>            Enable the barrier extension (default: 0).\n");
    fprintf(stderr, "      --barrier_option <1|2>            Insertion point: 1=after projection, 2=after Halpern.\n");
    fprintf(stderr, "      --barrier_mu_init <float>         Initial barrier parameter mu (default: 1.0).\n");
    fprintf(stderr, "      --barrier_mu_final <float>        Target mu for decaying schedules (default: 1e-6).\n");
    fprintf(stderr, "      --barrier_mu_strategy <0..3>       0=constant 1=exponential 2=adaptive 3=homotopy.\n");
    fprintf(stderr, "      --barrier_mu_rho <float>           Decay factor for the exponential schedule (default: 0.95).\n");
    fprintf(stderr, "      --barrier_soc_rsoc_ratio <float>   RSOC boundary max_ratio (default: 10.0).\n");
    fprintf(stderr, "      --barrier_std_soc_ratio <float>    StdSOC boundary max_ratio (default: 10.0).\n");
    fprintf(stderr, "      --barrier_exp_ratio <float>        Exponential cone max_ratio (default: 3.0).\n");
    fprintf(stderr, "      --barrier_power_ratio <float>      Power cone max_ratio (default: 5.0).\n");
    fprintf(stderr, "      --barrier_max_iter <int>           Max BPGrad outer iterations (default: 20).\n");
    fprintf(stderr, "      --barrier_inner_max_iter <int>     Max line-search steps per BPGrad iteration (default: 10).\n");
    fprintf(stderr, "      --barrier_tol <float>              BPGrad subproblem tolerance (default: 1e-8).\n");
    fprintf(stderr, "      --barrier_check_every <int>        Trigger check frequency (default: 1).\n");
    fprintf(stderr, "      --barrier_gap_threshold <float>    Only trigger when gap <= threshold (default: 1e-3).\n");
    fprintf(stderr, "      --barrier_step_norm_cap <float>    Max allowed ||dx|| (default: 2.0).\n");
    fprintf(stderr, "      --barrier_primal_res_factor <float> Max primal-residual degradation factor (default: 1.5).\n");
    fprintf(stderr, "      --barrier_adaptive_threshold <0|1> Enable L3 adaptive threshold (default: 1).\n");
    fprintf(stderr, "      --barrier_verbose <int>            0=silent 1=summary 2=detailed (default: 1).\n");
    fprintf(stderr, "      --barrier_homotopy_alpha <float>   Homotopy schedule alpha (default: 1.0).\n");
    fprintf(stderr, "      --barrier_homotopy_beta <float>    Homotopy schedule beta (default: 2.0).\n");
    fprintf(stderr, "      --barrier_soc_rsoc_mu_init <float> Per-cone mu override for RSOC/SOC (0 = use global).\n");
    fprintf(stderr, "      --barrier_std_soc_mu_init <float>  Per-cone mu override for StdSOC (0 = use global).\n");
    fprintf(stderr, "      --barrier_exp_mu_init <float>      Per-cone mu override for EXP (0 = use global).\n");
    fprintf(stderr, "      --barrier_power_mu_init <float>    Per-cone mu override for Power (0 = use global).\n");
    fprintf(stderr, "      --barrier_use_gpu_bpgrad <0|1>     Use the batched GPU BPGrad path (default: 1).\n");
}

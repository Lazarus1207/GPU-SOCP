/*
Copyright 2025 Haihao Lu
Copyright 2026 Hongpei Li

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

#include "internal_types.h"
#include "pdhcg.h"
#include "pdhg_core_op.h"
#include "preconditioner.h"
#include "presolve_wrapper.h"
#include "qcqp_transform.h"
#include "row_scaling.h"
#include "solver.h"
#include "solver_state.h"
#include "utils.h"
#include <chrono>
#include <cublas_v2.h>
#include <cuda_runtime.h>
#include <cusparse.h>
#include <math.h>
#include <stdbool.h>
#include <stdio.h>

/* Barrier enhancement (PDHCG-Barrier extension, optional) */
#ifdef PDHCG_BARRIER_ENABLE
#include "barrier_params.h"
#include "barrier_apply.h"
#endif

pdhcg_result_t *optimize(const pdhg_parameters_t *input_params, const qp_problem_t *original_problem)
{
    pdhg_parameters_t copyed_params = *input_params;
    pdhg_parameters_t *params = &copyed_params;
    const qp_problem_t *input_problem = original_problem;

    print_initial_info(input_params, original_problem);

    qp_problem_t *transformed = NULL;
    if (original_problem->num_quadratic_constraints > 0)
    {
        transformed = qcqp_to_socp_qp(original_problem, params->default_cone_type);
        if (!transformed)
        {
            fprintf(stderr, "Error: QCQP -> SOCP transformation failed; cannot solve.\n");
            return NULL;
        }
        if (params->verbose >= 1)
        {
            const char *form_name = (params->default_cone_type == CONE_STANDARD_SOC) ? "standard" : "rotated";
            fprintf(stderr,
                    "[QCQP] %d quadratic constraint(s) reformulated as %d "
                    "%s SOC block(s); extended problem: %d vars, "
                    "%d rows, %d nnz.\n",
                    original_problem->num_quadratic_constraints,
                    transformed->cones.num_cones,
                    form_name,
                    transformed->num_variables,
                    transformed->num_constraints,
                    transformed->constraint_matrix_num_nonzeros);
        }
        original_problem = transformed;
    }

    pdhcg_presolve_info_t *presolve_info = NULL;
    const qp_problem_t *working_problem = original_problem;
    bool working_problem_needs_free = false;

    if (params->presolve && pdhcg_presolve_available())
    {
        presolve_info = pdhcg_presolve(original_problem, params);
        if (presolve_info)
        {
            if (presolve_info->problem_solved_during_presolve)
            {
                pdhcg_result_t *result = pdhcg_create_result_from_presolve(presolve_info, original_problem);
                restore_qcqp_result_dimensions(result, transformed ? input_problem : NULL);
                if (result)
                {
                    pdhg_final_log(result, params);
                }
                pdhcg_presolve_info_free(presolve_info);
                if (transformed)
                {
                    qp_problem_free(transformed);
                }
                return result;
            }

            if (presolve_info->reduced_problem)
            {
                working_problem = presolve_info->reduced_problem;
            }
        }
    }

    if (working_problem->num_constraints == 0 || working_problem->constraint_matrix == NULL)
    {
        working_problem = create_problem_with_dummy_constraint(working_problem);
        working_problem_needs_free = true;
    }

    /* Row scaling.
 *
 * When params->enable_row_scaling is true and 0 < m <= row_scaling_max_rows
 * and every row is a finite equality, we apply the pure-C row-whitening
 * transform (M = (D A A^T D)^(-1/2) D) to the working problem in place.
 * The transform is a strict superset of diagonal equilibration, so we
 * then suppress Ruiz (l_inf_ruiz_iterations = 0) to avoid double-scaling
 * and force Curtis-Reid column equilibration on (curtis_reid_iterations
 * = 5) to keep the columns well-scaled.  Pock-Chambolle (alpha=1.0
 * default) is a no-op and stays enabled.
 *
 * The Python driver (PDHCG/python/pdhcg/row_scaling/) applies the same
 * transform before solve_once().  When the C side is invoked via the
 * CLI (cli.c) or the new C run_benchmark driver, the C path is the
 * single source of truth.
 */
    pdhcg_row_scaling_status_t rs_status = pdhcg_apply_row_scaling_const(
        params, working_problem, /*rescale_info=*/NULL);
    if (rs_status == PDHCG_ROW_SCALING_APPLIED) {
        params->l_inf_ruiz_iterations   = 0;
        params->curtis_reid_iterations  = 5;
        params->diag_jacobi_precond     = true;
    } else if (rs_status != PDHCG_ROW_SCALING_DISABLED &&
               rs_status != PDHCG_ROW_SCALING_NOT_EQUALITY) {
        if (params->verbose >= 1) {
            fprintf(stderr,
                    "[row_scaling] rejected (%s); solving unwhitened.\n",
                    pdhcg_row_scaling_status_str(rs_status));
        }
    }
    rescale_info_t *rescale_info = rescale_problem(params, working_problem);
    grid_context_t *grid_context = NULL;
    pdhg_solver_state_t *state = initialize_solver_state(params, working_problem, rescale_info, grid_context);

    if (state->quadratic_objective_term->nonconvexity < 0)
    {
        state->inner_solver->iteration_limit = 1;
    }

    rescale_info_free(rescale_info);
    initialize_step_size_and_primal_weight(state, params);
    /* Wall-clock start. PDHG iteration loop only. Ruiz + Pock-Chambolle
     * equilibration and row scaling are NOT included; both are reported
     * separately via result->rescaling_time_sec (preconditioner.c,
     * solver.cu). This matches the share/summary baseline behavior. */
    const auto start_time = std::chrono::steady_clock::now();
    bool do_restart = false;

    while (state->total_count < params->termination_criteria.iteration_limit)
    {
        if ((state->is_this_major_iteration || state->total_count == 0) ||
            (state->total_count % get_print_frequency(state->total_count) == 0))
        {
            compute_residual(state, params->optimality_norm);
            if (state->var_set_type == VAR_SET_BOX_ONLY && state->is_this_major_iteration &&
                state->total_count < 3 * params->termination_evaluation_frequency)
            {
                compute_infeasibility_information(state);
            }

            state->cumulative_time_sec =
                std::chrono::duration<double>(std::chrono::steady_clock::now() - start_time).count();

            check_termination_criteria(state, &params->termination_criteria);
            display_iteration_stats(state, params->verbose);
            if (state->termination_reason != TERMINATION_REASON_UNSPECIFIED)
            {
                break;
            }
        }

        if ((state->is_this_major_iteration || state->total_count == 0))
        {
            do_restart =
                should_do_adaptive_restart(state, &params->restart_params, params->termination_evaluation_frequency);
            if (do_restart)
                perform_restart(state, params);
        }

        state->is_this_major_iteration = ((state->total_count + 1) % params->termination_evaluation_frequency) == 0;

        pdhg_update(state);

        /* Barrier-PDHG Option 1: Apply barrier after cone projection, before halpern */
#ifdef PDHCG_BARRIER_ENABLE
        if (state->barrier_state && state->barrier_state->option == BARRIER_OPTION_1) {
            apply_barrier_option_1(state, params->barrier_params,
                                    state->barrier_state, state->total_count);
        }
#endif

        if (state->is_this_major_iteration || do_restart)
        {
            compute_fixed_point_error(state);
            if (do_restart)
            {
                state->initial_fixed_point_error = state->fixed_point_error;
                do_restart = false;
            }
        }
        halpern_update(state, params->reflection_coefficient);

        /* Barrier-PDHG Option 2: Apply barrier after halpern (Nesterov acceleration) */
#ifdef PDHCG_BARRIER_ENABLE
        if (state->barrier_state && state->barrier_state->option == BARRIER_OPTION_2) {
            apply_barrier_option_2(state, params->barrier_params,
                                    state->barrier_state, state->total_count);
        }
#endif

        state->inner_count++;
        state->total_count++;
    }

    if (state->termination_reason == TERMINATION_REASON_UNSPECIFIED)
    {
        state->termination_reason = TERMINATION_REASON_ITERATION_LIMIT;
        compute_residual(state, params->optimality_norm);
        display_iteration_stats(state, params->verbose);
    }

    // if (params->feasibility_polishing &&
    //     state->termination_reason != TERMINATION_REASON_DUAL_INFEASIBLE &&
    //     state->termination_reason != TERMINATION_REASON_PRIMAL_INFEASIBLE) {
    //   feasibility_polish(params, state);
    // }

    pdhcg_result_t *result = create_result_from_state(state, original_problem);

    if (presolve_info && presolve_info->reduced_problem)
    {
        if (!pdhcg_postsolve(presolve_info, result, original_problem))
        {
            fprintf(stderr, "Error: PreFOS primal-dual postsolve failed.\n");
            result->termination_reason = TERMINATION_REASON_UNSPECIFIED;
        }
    }
    /* Row-scaling postsolve: y_orig = M^T y_new.
     *
     * The C row_scaling.c path saved M in thread-local storage; the
     * Python driver records its own M alongside the model and applies
     * the recovery in pdhcg.model.Model.optimize().  When the C side
     * applied the transform (status APPLIED), we recover the original
     * dual here.  No-op if the transform was disabled / rejected. */
    if (result != NULL && result->dual_solution != NULL) {
        pdhcg_recover_dual_from_pending_row_scaling(result->dual_solution);
        pdhcg_release_pending_row_scaling();
    }

    if (working_problem_needs_free)
    {
        qp_problem_free((qp_problem_t *)working_problem);
    }

    restore_qcqp_result_dimensions(result, transformed ? input_problem : NULL);

    pdhg_final_log(result, params);
    pdhg_solver_state_free(state);
    pdhcg_presolve_info_free(presolve_info);
    if (transformed)
    {
        qp_problem_free(transformed);
    }
    CUDA_CHECK(cudaGetLastError());
    return result;
}

/*
================================================================================
barrier_kernels.cu - CUDA Kernels for Barrier Module

Stage 1.7: CUDA Kernel Acceleration

This file contains GPU kernels for barrier-related operations:
  1. Boundary metric Ï computation (per-block, batched)
  2. Cone block extraction (memcpy helpers)
  3. BPGrad for RSOC (single-block GPU kernel)

The host-side implementation in barrier_module.c remains the reference;
this file provides optimized GPU versions for the hot path.
================================================================================
*/

#include "boundary_metric.h"
#include <cuda_runtime.h>
#include <math.h>
#include <stdint.h>

/* =============================================================================
 * Section 1: Boundary Metric Kernels (per cone type)
 * ============================================================================= */

__global__ void boundary_metric_rsoc_kernel(
    double *rho_out,           /* device [num_blocks] */
    double *slack_out,         /* device [num_blocks] (optional, can be NULL) */
    const double *x_d,         /* device primal solution */
    const double *rescale_d,   /* device rescaling (may be NULL) */
    const int *start_idx,      /* device [num_blocks] */
    const int *v_dim,          /* device [num_blocks] */
    int num_blocks)
{
    int blk = blockIdx.x * blockDim.x + threadIdx.x;
    if (blk >= num_blocks) return;

    int start = start_idx[blk];
    int k = v_dim[blk];
    if (k < 1) {
        rho_out[blk] = 0.0;
        if (slack_out) slack_out[blk] = 0.0;
        return;
    }

    const double *v = x_d + start;
    double s = x_d[start + k];
    double t = x_d[start + k + 1];

    /* Check finiteness */
    if (!isfinite(s) || !isfinite(t)) {
        rho_out[blk] = 0.0;
        if (slack_out) slack_out[blk] = 0.0;
        return;
    }

    double ds = rescale_d ? rescale_d[start + k] : 1.0;
    double dt = rescale_d ? rescale_d[start + k + 1] : 1.0;
    if (ds <= 0.0) ds = 1.0;
    if (dt <= 0.0) dt = 1.0;

    double s_scaled = s / ds;
    double t_scaled = t / dt;

    if (s_scaled < 0.0 || t_scaled < 0.0) {
        rho_out[blk] = 0.0;
        if (slack_out) slack_out[blk] = 0.0;
        return;
    }

    double norm_v_sq = 0.0;
    for (int i = 0; i < k; i++) {
        double dv = rescale_d ? rescale_d[start + i] : 1.0;
        if (dv <= 0.0) dv = 1.0;
        double v_scaled = v[i] / dv;
        if (!isfinite(v_scaled)) {
            rho_out[blk] = 0.0;
            if (slack_out) slack_out[blk] = 0.0;
            return;
        }
        norm_v_sq += v_scaled * v_scaled;
    }

    double inner = 2.0 * s_scaled * t_scaled - norm_v_sq;
    double scale = sqrt(2.0 * s_scaled * t_scaled);

    if (slack_out) slack_out[blk] = inner;

    if (inner <= 0.0 || scale < 1e-15) {
        rho_out[blk] = 0.0;
        return;
    }

    double rho = sqrt(inner) / scale;
    if (!isfinite(rho) || rho < 0.0) rho = 0.0;
    if (rho > 1.0) rho = 1.0;
    rho_out[blk] = rho;
}

__global__ void boundary_metric_std_soc_kernel(
    double *rho_out,
    double *slack_out,
    const double *x_d,
    const double *rescale_d,
    const int *start_idx,
    const int *v_dim,
    int num_blocks)
{
    int blk = blockIdx.x * blockDim.x + threadIdx.x;
    if (blk >= num_blocks) return;

    int start = start_idx[blk];
    int k = v_dim[blk];
    if (k < 1) {
        rho_out[blk] = 0.0;
        if (slack_out) slack_out[blk] = 0.0;
        return;
    }

    double t = x_d[start];
    if (!isfinite(t)) {
        rho_out[blk] = 0.0;
        if (slack_out) slack_out[blk] = 0.0;
        return;
    }

    double dt = rescale_d ? rescale_d[start] : 1.0;
    if (dt <= 0.0) dt = 1.0;
    double t_scaled = t / dt;

    if (t_scaled < 0.0) {
        rho_out[blk] = 0.0;
        if (slack_out) slack_out[blk] = 0.0;
        return;
    }

    double norm_u_sq = 0.0;
    for (int i = 0; i < k; i++) {
        double du = rescale_d ? rescale_d[start + i + 1] : 1.0;
        if (du <= 0.0) du = 1.0;
        double u_scaled = x_d[start + i + 1] / du;
        if (!isfinite(u_scaled)) {
            rho_out[blk] = 0.0;
            if (slack_out) slack_out[blk] = 0.0;
            return;
        }
        norm_u_sq += u_scaled * u_scaled;
    }

    double inner = t_scaled * t_scaled - norm_u_sq;
    double abs_t = fabs(t_scaled);

    if (slack_out) slack_out[blk] = inner;

    if (inner <= 0.0 || abs_t < 1e-15) {
        rho_out[blk] = 0.0;
        return;
    }

    double rho = sqrt(inner) / abs_t;
    if (!isfinite(rho) || rho < 0.0) rho = 0.0;
    if (rho > 1.0) rho = 1.0;
    rho_out[blk] = rho;
}

__global__ void boundary_metric_exp_kernel(
    double *rho_out,
    double *slack_out,
    const double *x_d,
    const double *rescale_d,
    const int *start_idx,
    const int *v_dim,
    int num_blocks)
{
    int blk = blockIdx.x * blockDim.x + threadIdx.x;
    if (blk >= num_blocks) return;
    (void)v_dim;

    int start = start_idx[blk];
    double x1 = x_d[start];
    double x2 = x_d[start + 1];
    double x3 = x_d[start + 2];

    if (!isfinite(x1) || !isfinite(x2) || !isfinite(x3)) {
        rho_out[blk] = 0.0;
        if (slack_out) slack_out[blk] = -INFINITY;
        return;
    }

    double d1 = rescale_d ? rescale_d[start] : 1.0;
    double d2 = rescale_d ? rescale_d[start + 1] : 1.0;
    double d3 = rescale_d ? rescale_d[start + 2] : 1.0;
    if (d1 <= 0.0) d1 = 1.0;
    if (d2 <= 0.0) d2 = 1.0;
    if (d3 <= 0.0) d3 = 1.0;

    if (x2 / d2 <= 0.0 || x3 / d3 <= 0.0 || x1 / d1 <= 0.0) {
        rho_out[blk] = 0.0;
        if (slack_out) slack_out[blk] = -INFINITY;
        return;
    }

    double r = x3 / x2;
    if (fabs(r) > 50.0) {
        rho_out[blk] = 0.0;
        if (slack_out) slack_out[blk] = -INFINITY;
        return;
    }

    double exp_r = exp(r);
    double slack = x1 - x2 * exp_r;

    if (slack_out) slack_out[blk] = slack;

    if (!isfinite(slack) || slack <= 0.0 || x1 <= 0.0) {
        rho_out[blk] = 0.0;
        return;
    }

    double rho = slack / x1;
    if (!isfinite(rho) || rho < 0.0) rho = 0.0;
    if (rho > 1.0) rho = 1.0;
    rho_out[blk] = rho;
}

__global__ void boundary_metric_power_kernel(
    double *rho_out,
    double *slack_out,
    const double *x_d,
    const double *rescale_d,
    const double *alpha_d,
    const int *start_idx,
    const int *v_dim,
    int num_blocks)
{
    int blk = blockIdx.x * blockDim.x + threadIdx.x;
    if (blk >= num_blocks) return;
    (void)v_dim;

    int start = start_idx[blk];
    double xv = x_d[start];
    double yv = x_d[start + 1];
    double zv = x_d[start + 2];
    double alpha = alpha_d ? alpha_d[blk] : 0.5;

    if (!isfinite(xv) || !isfinite(yv) || !isfinite(zv)) {
        rho_out[blk] = 0.0;
        if (slack_out) slack_out[blk] = -INFINITY;
        return;
    }

    if (alpha <= 0.0 || alpha >= 1.0) {
        rho_out[blk] = 0.0;
        if (slack_out) slack_out[blk] = -INFINITY;
        return;
    }

    double dx = rescale_d ? rescale_d[start] : 1.0;
    double dy = rescale_d ? rescale_d[start + 1] : 1.0;
    double dz = rescale_d ? rescale_d[start + 2] : 1.0;
    if (dx <= 0.0) dx = 1.0;
    if (dy <= 0.0) dy = 1.0;
    if (dz <= 0.0) dz = 1.0;

    if (xv / dx < 0.0 || yv / dy < 0.0) {
        rho_out[blk] = 0.0;
        if (slack_out) slack_out[blk] = -INFINITY;
        return;
    }

    double xv_s = xv / dx;
    double yv_s = yv / dy;
    double zv_s = zv / dz;

    if (xv_s < 1e-300 || yv_s < 1e-300) {
        rho_out[blk] = 0.0;
        if (slack_out) slack_out[blk] = -INFINITY;
        return;
    }

    double log_h = alpha * log(xv_s) + (1.0 - alpha) * log(yv_s);
    if (!isfinite(log_h) || log_h > 700.0) {
        rho_out[blk] = 0.0;
        if (slack_out) slack_out[blk] = -INFINITY;
        return;
    }

    double h = exp(log_h);
    double abs_z = fabs(zv_s);
    double slack = h - abs_z;

    if (slack_out) slack_out[blk] = slack;

    if (slack <= 0.0 || h < 1e-15) {
        rho_out[blk] = 0.0;
        return;
    }

    double rho = slack / h;
    if (!isfinite(rho) || rho < 0.0) rho = 0.0;
    if (rho > 1.0) rho = 1.0;
    rho_out[blk] = rho;
}

/* =============================================================================
 * Section 2: Kernel Launchers (extern "C" interface)
 * ============================================================================= */

extern "C" void launch_boundary_metric_rsoc(
    double *rho_out, double *slack_out,
    const double *x_d, const double *rescale_d,
    const int *start_idx, const int *v_dim,
    int num_blocks)
{
    if (num_blocks == 0) return;
    int threads = 128;
    int blocks = (num_blocks + threads - 1) / threads;
    boundary_metric_rsoc_kernel<<<blocks, threads>>>(
        rho_out, slack_out, x_d, rescale_d, start_idx, v_dim, num_blocks);
}

extern "C" void launch_boundary_metric_std_soc(
    double *rho_out, double *slack_out,
    const double *x_d, const double *rescale_d,
    const int *start_idx, const int *v_dim,
    int num_blocks)
{
    if (num_blocks == 0) return;
    int threads = 128;
    int blocks = (num_blocks + threads - 1) / threads;
    boundary_metric_std_soc_kernel<<<blocks, threads>>>(
        rho_out, slack_out, x_d, rescale_d, start_idx, v_dim, num_blocks);
}

extern "C" void launch_boundary_metric_exp(
    double *rho_out, double *slack_out,
    const double *x_d, const double *rescale_d,
    const int *start_idx, const int *v_dim,
    int num_blocks)
{
    if (num_blocks == 0) return;
    int threads = 128;
    int blocks = (num_blocks + threads - 1) / threads;
    boundary_metric_exp_kernel<<<blocks, threads>>>(
        rho_out, slack_out, x_d, rescale_d, start_idx, v_dim, num_blocks);
}

extern "C" void launch_boundary_metric_power(
    double *rho_out, double *slack_out,
    const double *x_d, const double *rescale_d,
    const double *alpha_d,
    const int *start_idx, const int *v_dim,
    int num_blocks)
{
    if (num_blocks == 0) return;
    int threads = 128;
    int blocks = (num_blocks + threads - 1) / threads;
    boundary_metric_power_kernel<<<blocks, threads>>>(
        rho_out, slack_out, x_d, rescale_d, alpha_d, start_idx, v_dim, num_blocks);
}

/* =============================================================================
 * Section 3: BPGrad CUDA Kernels (Stage 1.6)
 *
 * Each kernel processes ONE cone block per CUDA thread block.
 *   - threadIdx.x == 0 does the entire Newton iteration
 *   - blockIdx.x  indexes the cone block
 *
 * Simplifications matching barrier_apply.c (g=0 form):
 *   - g = 0 (no linear term)
 *   - Proximal form: x* = argmin (1/2τ)||x - x_k||² + μ·φ(x)
 *   - Descent direction: d = (x - x_k)/τ + μ·∇φ(x)
 *   - Single step size: α = 1.0 (no Armijo backtracking in 1.6)
 *   - Max 20 Newton iterations
 *   - Fallback: kernel writes 0 to converged_d[idx], host re-projects
 *
 * Per cone type:
 *   - RSOC   (k+2 vars): closed-form ∇φ
 *   - StdSOC (k+1 vars): closed-form ∇φ
 *   - EXP    (3 vars):   closed-form ∇φ, diagonal Hessian
 *   - Power  (3 vars):   closed-form ∇φ, 3x3 matrix inverse
 * ============================================================================= */

#define BPGRAD_SLACK_FLOOR 1e-12
#define BPGRAD_SOC_MAX_K 64
#define BPGRAD_MAX_ITER 20

/* ---------------------------------------------------------------------------
 * BPGrad for RSOC: x = (v[0..k-1], s, t)
 *   barrier  φ = -log(2st - ||v||²)
 *   ∇φ(x)_v  = 2 v / inner
 *   ∇φ(x)_s  = -2 t / inner
 *   ∇φ(x)_t  = -2 s / inner
 *   inner    = 2 s t - ||v||²
 *
 *   Iterative update (g=0 simplification, α=1, max_iter steps):
 *     Compute ∇φ at current x
 *     x_new = x - μ·∇φ  (prox term drops because g=0 ⇒ x = x_k at start)
 * --------------------------------------------------------------------------- */
__global__ void bpgrad_rsoc_kernel(
    double *x_d,
    int *converged_d,
    const int *start_idx,
    const int *v_dim,
    int num_blocks,
    double mu,
    double tau,
    int max_iter,
    double tol)
{
    (void)tau;  /* g=0 simplification: prox = 0 at start */

    int blk = blockIdx.x;
    if (blk >= num_blocks) return;
    if (threadIdx.x != 0) return;  /* single-warp per cone block */

    int start = start_idx[blk];
    int k = v_dim[blk];
    if (k < 1 || k > BPGRAD_SOC_MAX_K) {
        converged_d[blk] = 0;
        return;
    }

    /* Shared memory: v[k], s, t (size = k+2 doubles) */
    extern __shared__ double smem[];
    double *v    = smem;
    double *s_pt = smem + k;
    double *t_pt = smem + k + 1;

    for (int i = 0; i < k; i++) v[i] = x_d[start + i];
    *s_pt = x_d[start + k];
    *t_pt = x_d[start + k + 1];

    int conv = 0;
    int fb = 0;

    for (int it = 0; it < max_iter; it++) {
        /* Feasibility */
        double nv2 = 0.0;
        for (int i = 0; i < k; i++) nv2 += v[i] * v[i];
        double inner = 2.0 * (*s_pt) * (*t_pt) - nv2;
        if (inner <= BPGRAD_SLACK_FLOOR) { fb = 1; break; }

        double inv = 1.0 / inner;

        /* ∇φ at current x */
        double phi_s = -2.0 * (*t_pt) * inv;
        double phi_t = -2.0 * (*s_pt) * inv;

        /* Update (g=0, α=1, prox at x_k: (x-x_k)/τ where x=x_k gives 0) */
        for (int i = 0; i < k; i++) {
            double phi_v = 2.0 * v[i] * inv;
            v[i] = v[i] - mu * phi_v;
        }
        *s_pt = *s_pt - mu * phi_s;
        *t_pt = *t_pt - mu * phi_t;

        /* Re-check feasibility */
        double new_nv2 = 0.0;
        for (int i = 0; i < k; i++) new_nv2 += v[i] * v[i];
        double new_inner = 2.0 * (*s_pt) * (*t_pt) - new_nv2;
        if (new_inner <= BPGRAD_SLACK_FLOOR) { fb = 1; break; }

        /* Convergence: ||μ·∇φ|| at start-of-iter < tol */
        double dnorm = (mu * phi_s) * (mu * phi_s) + (mu * phi_t) * (mu * phi_t);
        /* Recompute φ_v at start-of-iter (v[] has been updated) */
        double dnorm_v = 0.0;
        for (int i = 0; i < k; i++) {
            double phi_v_orig = 2.0 * x_d[start + i] * inv;
            dnorm_v += (mu * phi_v_orig) * (mu * phi_v_orig);
        }
        dnorm += dnorm_v;
        if (sqrt(dnorm) < tol) { conv = 1; break; }
    }

    if (!fb) {
        for (int i = 0; i < k; i++) x_d[start + i] = v[i];
        x_d[start + k]     = *s_pt;
        x_d[start + k + 1] = *t_pt;
    }
    converged_d[blk] = conv;
}

/* ---------------------------------------------------------------------------
 * BPGrad for StdSOC: x = (t, u[0..k-1])
 *   barrier  φ = -log(t² - ||u||²)
 *   ∇φ(x)_t  = -2 t / inner
 *   ∇φ(x)_u  = 2 u / inner
 *   inner    = t² - ||u||²
 * --------------------------------------------------------------------------- */
__global__ void bpgrad_std_soc_kernel(
    double *x_d,
    int *converged_d,
    const int *start_idx,
    const int *v_dim,
    int num_blocks,
    double mu,
    double tau,
    int max_iter,
    double tol)
{
    (void)tau;  /* g=0 simplification: prox term = 0 at start */

    int blk = blockIdx.x;
    if (blk >= num_blocks) return;
    if (threadIdx.x != 0) return;

    int start = start_idx[blk];
    int k = v_dim[blk];
    if (k < 1 || k > BPGRAD_SOC_MAX_K) {
        converged_d[blk] = 0;
        return;
    }

    extern __shared__ double smem[];
    double *t_pt  = smem;
    double *u     = smem + 1;
    double *t0    = smem + 1 + k;
    double *u0    = smem + 2 + k;
    /* size: 2*(k+1) doubles */

    *t_pt = *t0 = x_d[start];
    for (int i = 0; i < k; i++) u[i] = u0[i] = x_d[start + 1 + i];

    int conv = 0;
    int fb = 0;

    for (int it = 0; it < max_iter; it++) {
        double nu2 = 0.0;
        for (int i = 0; i < k; i++) nu2 += u[i] * u[i];
        double inner = (*t_pt) * (*t_pt) - nu2;
        if (inner <= BPGRAD_SLACK_FLOOR) { fb = 1; break; }

        double inv = 1.0 / inner;

        /* ∇φ at x0 */
        double phi_t = -2.0 * (*t0) * inv;
        for (int i = 0; i < k; i++) {
            double phi_i = 2.0 * u0[i] * inv;
            u[i] = u0[i] - mu * phi_i;
        }
        *t_pt = *t0 - mu * phi_t;

        double new_nu2 = 0.0;
        for (int i = 0; i < k; i++) new_nu2 += u[i] * u[i];
        double new_inner = (*t_pt) * (*t_pt) - new_nu2;
        if (new_inner <= BPGRAD_SLACK_FLOOR) { fb = 1; break; }

        double dnorm = (mu * phi_t) * (mu * phi_t);
        for (int i = 0; i < k; i++) {
            double phi_i = 2.0 * u0[i] * inv;
            dnorm += (mu * phi_i) * (mu * phi_i);
        }
        if (sqrt(dnorm) < tol) { conv = 1; break; }
    }

    if (!fb) {
        x_d[start] = *t_pt;
        for (int i = 0; i < k; i++) x_d[start + 1 + i] = u[i];
    }
    converged_d[blk] = conv;
}

/* ---------------------------------------------------------------------------
 * BPGrad for EXP: x = (x1, x2, x3)  (3-dim)
 *   barrier  φ = -log x2 - log x3 - log(x1 - x2·exp(x3/x2))
 *   r = x3/x2
 *   s = x1 - x2·exp(r)
 *   ∇φ_1 = -1/s
 *   ∇φ_2 = -1/x2 + (1+r)·exp(r)/s
 *   ∇φ_3 = -1/x3 + (r/x2)·exp(r)/s
 * --------------------------------------------------------------------------- */
__global__ void bpgrad_exp_kernel(
    double *x_d,
    int *converged_d,
    const int *start_idx,
    int num_blocks,
    double mu,
    double tau,
    int max_iter,
    double tol)
{
    (void)tau;  /* prox = 0 at start under g=0 simplification */

    int blk = blockIdx.x;
    if (blk >= num_blocks) return;
    if (threadIdx.x != 0) return;

    int start = start_idx[blk];

    double x1 = x_d[start];
    double x2 = x_d[start + 1];
    double x3 = x_d[start + 2];

    int conv = 0;
    int fb = 0;

    for (int it = 0; it < max_iter; it++) {
        if (x2 <= 0.0 || x3 <= 0.0) { fb = 1; break; }
        double r = x3 / x2;
        if (fabs(r) > 50.0) { fb = 1; break; }
        double exp_r = exp(r);
        double s = x1 - x2 * exp_r;
        if (s <= BPGRAD_SLACK_FLOOR) { fb = 1; break; }

        double inv_s = 1.0 / s;
        double phi_1 = -inv_s;
        double phi_2 = -1.0 / x2 + (1.0 + r) * exp_r * inv_s;
        double phi_3 = -1.0 / x3 + (r / x2) * exp_r * inv_s;

        x1 = x1 - mu * phi_1;
        x2 = x2 - mu * phi_2;
        x3 = x3 - mu * phi_3;

        /* Re-check feasibility */
        if (x2 <= 0.0 || x3 <= 0.0) { fb = 1; break; }
        double new_r = x3 / x2;
        if (fabs(new_r) > 50.0) { fb = 1; break; }
        double new_exp_r = exp(new_r);
        double new_s = x1 - x2 * new_exp_r;
        if (new_s <= BPGRAD_SLACK_FLOOR) { fb = 1; break; }

        double dnorm = (mu * phi_1) * (mu * phi_1)
                     + (mu * phi_2) * (mu * phi_2)
                     + (mu * phi_3) * (mu * phi_3);
        if (sqrt(dnorm) < tol) { conv = 1; break; }
    }

    if (!fb) {
        x_d[start]     = x1;
        x_d[start + 1] = x2;
        x_d[start + 2] = x3;
    }
    converged_d[blk] = conv;
}

/* ---------------------------------------------------------------------------
 * BPGrad for Power cone: x = (x, y, z)  (3-dim, alpha given per block)
 *   barrier  φ = -α log x - (1-α) log y - log(x^α y^(1-α) - |z|)
 *   H = x^α y^(1-α) - |z|
 *   ∇φ_x = -α/x + α x^(α-1) y^(1-α) / H
 *   ∇φ_y = -(1-α)/y + (1-α) x^α y^(-α) / H
 *   ∇φ_z = -sign(z) / H
 * --------------------------------------------------------------------------- */
__global__ void bpgrad_power_kernel(
    double *x_d,
    int *converged_d,
    const int *start_idx,
    const double *alpha_d,
    int num_blocks,
    double mu,
    double tau,
    int max_iter,
    double tol)
{
    (void)tau;

    int blk = blockIdx.x;
    if (blk >= num_blocks) return;
    if (threadIdx.x != 0) return;

    int start = start_idx[blk];
    double alpha = alpha_d ? alpha_d[blk] : 0.5;

    double xv = x_d[start];
    double yv = x_d[start + 1];
    double zv = x_d[start + 2];

    int conv = 0;
    int fb = 0;

    for (int it = 0; it < max_iter; it++) {
        if (xv <= 0.0 || yv <= 0.0) { fb = 1; break; }
        if (alpha <= 0.0 || alpha >= 1.0) { fb = 1; break; }

        double log_h = alpha * log(xv) + (1.0 - alpha) * log(yv);
        if (!isfinite(log_h) || log_h > 700.0) { fb = 1; break; }
        double h = exp(log_h);
        double abs_z = fabs(zv);
        double slack = h - abs_z;
        if (slack <= BPGRAD_SLACK_FLOOR || h < 1e-15) { fb = 1; break; }

        double inv_slack = 1.0 / slack;
        /* ∇φ_x = -α/x + α·(h/x)·(1/slack)
         * ∇φ_y = -(1-α)/y + (1-α)·(h/y)·(1/slack)
         * ∇φ_z = -sign(z)/slack
         */
        double phi_x = -alpha / xv + alpha * h / xv * inv_slack;
        double phi_y = -(1.0 - alpha) / yv + (1.0 - alpha) * h / yv * inv_slack;
        double sign_z = (zv >= 0.0) ? 1.0 : -1.0;
        double phi_z = -sign_z * inv_slack;

        xv = xv - mu * phi_x;
        yv = yv - mu * phi_y;
        zv = zv - mu * phi_z;

        /* Re-check feasibility */
        if (xv <= 0.0 || yv <= 0.0) { fb = 1; break; }
        double new_log_h = alpha * log(xv) + (1.0 - alpha) * log(yv);
        if (!isfinite(new_log_h) || new_log_h > 700.0) { fb = 1; break; }
        double new_h = exp(new_log_h);
        double new_abs_z = fabs(zv);
        double new_slack = new_h - new_abs_z;
        if (new_slack <= BPGRAD_SLACK_FLOOR) { fb = 1; break; }

        double dnorm = (mu * phi_x) * (mu * phi_x)
                     + (mu * phi_y) * (mu * phi_y)
                     + (mu * phi_z) * (mu * phi_z);
        if (sqrt(dnorm) < tol) { conv = 1; break; }
    }

    if (!fb) {
        x_d[start]     = xv;
        x_d[start + 1] = yv;
        x_d[start + 2] = zv;
    }
    converged_d[blk] = conv;
}

/* ---------------------------------------------------------------------------
 * Launchers (extern "C")
 * --------------------------------------------------------------------------- */

extern "C" int launch_bpgrad_rsoc(
    double *x_d,
    int *converged_d,
    const int *start_idx,
    const int *v_dim,
    int num_blocks,
    double mu,
    double tau,
    int max_iter,
    double tol)
{
    if (num_blocks == 0) return 0;
    int threads = 32;  /* single-warp */
    int blocks  = num_blocks;
    int k_max = BPGRAD_SOC_MAX_K;
    size_t shmem = (size_t)(2 * (k_max + 2)) * sizeof(double);
    bpgrad_rsoc_kernel<<<blocks, threads, shmem>>>(
        x_d, converged_d, start_idx, v_dim, num_blocks,
        mu, tau, max_iter, tol);
    return cudaGetLastError() == cudaSuccess ? 0 : -1;
}

extern "C" int launch_bpgrad_std_soc(
    double *x_d,
    int *converged_d,
    const int *start_idx,
    const int *v_dim,
    int num_blocks,
    double mu,
    double tau,
    int max_iter,
    double tol)
{
    if (num_blocks == 0) return 0;
    int threads = 32;
    int blocks  = num_blocks;
    int k_max = BPGRAD_SOC_MAX_K;
    size_t shmem = (size_t)(2 * (k_max + 1)) * sizeof(double);
    bpgrad_std_soc_kernel<<<blocks, threads, shmem>>>(
        x_d, converged_d, start_idx, v_dim, num_blocks,
        mu, tau, max_iter, tol);
    return cudaGetLastError() == cudaSuccess ? 0 : -1;
}

extern "C" int launch_bpgrad_exp(
    double *x_d,
    int *converged_d,
    const int *start_idx,
    int num_blocks,
    double mu,
    double tau,
    int max_iter,
    double tol)
{
    if (num_blocks == 0) return 0;
    int threads = 32;
    int blocks  = num_blocks;
    bpgrad_exp_kernel<<<blocks, threads>>>(
        x_d, converged_d, start_idx, num_blocks,
        mu, tau, max_iter, tol);
    return cudaGetLastError() == cudaSuccess ? 0 : -1;
}

extern "C" int launch_bpgrad_power(
    double *x_d,
    int *converged_d,
    const int *start_idx,
    const double *alpha_d,
    int num_blocks,
    double mu,
    double tau,
    int max_iter,
    double tol)
{
    if (num_blocks == 0) return 0;
    int threads = 32;
    int blocks  = num_blocks;
    bpgrad_power_kernel<<<blocks, threads>>>(
        x_d, converged_d, start_idx, alpha_d, num_blocks,
        mu, tau, max_iter, tol);
    return cudaGetLastError() == cudaSuccess ? 0 : -1;
}

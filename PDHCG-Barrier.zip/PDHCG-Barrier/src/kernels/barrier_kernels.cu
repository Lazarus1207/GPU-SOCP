/*
================================================================================
barrier_kernels.cu - CUDA Kernels for Barrier Module

Stage 1.7: CUDA Kernel Acceleration

This file contains GPU kernels for barrier-related operations:
  1. Boundary metric ρ computation (per-block, batched)
  2. Cone block extraction (memcpy helpers)
  3. BPGrad for RSOC (single-block GPU kernel)

The host-side implementation in barrier_module.c remains the reference;
this file provides optimized GPU versions for the hot path.
================================================================================
*/

#include "boundary_metric.h"
#include <cuda_runtime.h>
#include <math.h>
#include <stdint.h>

/* =============================================================================
 * Section 1: Boundary Metric Kernels (per cone type)
 * ============================================================================= */

__global__ void boundary_metric_rsoc_kernel(
    double *rho_out,           /* device [num_blocks] */
    double *slack_out,         /* device [num_blocks] (optional, can be NULL) */
    const double *x_d,         /* device primal solution */
    const double *rescale_d,   /* device rescaling (may be NULL) */
    const int *start_idx,      /* device [num_blocks] */
    const int *v_dim,          /* device [num_blocks] */
    int num_blocks)
{
    int blk = blockIdx.x * blockDim.x + threadIdx.x;
    if (blk >= num_blocks) return;

    int start = start_idx[blk];
    int k = v_dim[blk];
    if (k < 1) {
        rho_out[blk] = 0.0;
        if (slack_out) slack_out[blk] = 0.0;
        return;
    }

    const double *v = x_d + start;
    double s = x_d[start + k];
    double t = x_d[start + k + 1];

    /* Check finiteness */
    if (!isfinite(s) || !isfinite(t)) {
        rho_out[blk] = 0.0;
        if (slack_out) slack_out[blk] = 0.0;
        return;
    }

    double ds = rescale_d ? rescale_d[start + k] : 1.0;
    double dt = rescale_d ? rescale_d[start + k + 1] : 1.0;
    if (ds <= 0.0) ds = 1.0;
    if (dt <= 0.0) dt = 1.0;

    double s_scaled = s / ds;
    double t_scaled = t / dt;

    if (s_scaled < 0.0 || t_scaled < 0.0) {
        rho_out[blk] = 0.0;
        if (slack_out) slack_out[blk] = 0.0;
        return;
    }

    double norm_v_sq = 0.0;
    for (int i = 0; i < k; i++) {
        double dv = rescale_d ? rescale_d[start + i] : 1.0;
        if (dv <= 0.0) dv = 1.0;
        double v_scaled = v[i] / dv;
        if (!isfinite(v_scaled)) {
            rho_out[blk] = 0.0;
            if (slack_out) slack_out[blk] = 0.0;
            return;
        }
        norm_v_sq += v_scaled * v_scaled;
    }

    double inner = 2.0 * s_scaled * t_scaled - norm_v_sq;
    double scale = sqrt(2.0 * s_scaled * t_scaled);

    if (slack_out) slack_out[blk] = inner;

    if (inner <= 0.0 || scale < 1e-15) {
        rho_out[blk] = 0.0;
        return;
    }

    double rho = sqrt(inner) / scale;
    if (!isfinite(rho) || rho < 0.0) rho = 0.0;
    if (rho > 1.0) rho = 1.0;
    rho_out[blk] = rho;
}

__global__ void boundary_metric_std_soc_kernel(
    double *rho_out,
    double *slack_out,
    const double *x_d,
    const double *rescale_d,
    const int *start_idx,
    const int *v_dim,
    int num_blocks)
{
    int blk = blockIdx.x * blockDim.x + threadIdx.x;
    if (blk >= num_blocks) return;

    int start = start_idx[blk];
    int k = v_dim[blk];
    if (k < 1) {
        rho_out[blk] = 0.0;
        if (slack_out) slack_out[blk] = 0.0;
        return;
    }

    /* PDHCG internal layout: x = [v0..v_{k-1}, w, z]  (total size k + 2).
     * Cone: Q = {(w, z, v) : ||(v, w)|| <= z }, z >= 0.
     * Matches boundary_metric_std_soc() on the host and the PDHCG projection
     * kernel; there is no leading-scalar (t, u) grouping here. */
    double w = x_d[start + k];
    double z = x_d[start + k + 1];
    if (!isfinite(w) || !isfinite(z)) {
        rho_out[blk] = 0.0;
        if (slack_out) slack_out[blk] = 0.0;
        return;
    }

    /* Same rescaling convention as project_standard_soc_kernel:
     * d_z = d[k+1], dhat_w = d[k]/d_z, dh_m = d[m]/d_z, and the cone test
     * happens in the logical space (v/dh, w/dhat_w, z). */
    double d_z = rescale_d ? rescale_d[start + k + 1] : 1.0;
    if (!(d_z > 0.0)) d_z = 1.0;
    double d_w = rescale_d ? rescale_d[start + k] : 1.0;
    if (!(d_w > 0.0)) d_w = 1.0;
    double dhat_w = d_w / d_z;

    if (z < 0.0) {
        rho_out[blk] = 0.0;
        if (slack_out) slack_out[blk] = 0.0;
        return;
    }

    double norm_sq = (w / dhat_w) * (w / dhat_w);
    for (int i = 0; i < k; i++) {
        double dv = rescale_d ? rescale_d[start + i] : 1.0;
        double dh = dv / d_z;
        if (!(dh > 0.0)) dh = 1.0;
        double vs = x_d[start + i] / dh;
        if (!isfinite(vs)) {
            rho_out[blk] = 0.0;
            if (slack_out) slack_out[blk] = 0.0;
            return;
        }
        norm_sq += vs * vs;
    }

    double inner = z * z - norm_sq;
    if (slack_out) slack_out[blk] = inner;

    if (inner <= 0.0 || z < 1e-15) {
        rho_out[blk] = 0.0;
        return;
    }

    double rho = sqrt(inner) / z;
    if (!isfinite(rho) || rho < 0.0) rho = 0.0;
    if (rho > 1.0) rho = 1.0;
    rho_out[blk] = rho;
}

__global__ void boundary_metric_exp_kernel(
    double *rho_out,
    double *slack_out,
    const double *x_d,
    const double *rescale_d,
    const int *start_idx,
    const int *v_dim,
    int num_blocks)
{
    int blk = blockIdx.x * blockDim.x + threadIdx.x;
    if (blk >= num_blocks) return;
    (void)v_dim;

    int start = start_idx[blk];
    double x1 = x_d[start];
    double x2 = x_d[start + 1];
    double x3 = x_d[start + 2];

    if (!isfinite(x1) || !isfinite(x2) || !isfinite(x3)) {
        rho_out[blk] = 0.0;
        if (slack_out) slack_out[blk] = -INFINITY;
        return;
    }

    double d1 = rescale_d ? rescale_d[start] : 1.0;
    double d2 = rescale_d ? rescale_d[start + 1] : 1.0;
    double d3 = rescale_d ? rescale_d[start + 2] : 1.0;
    if (d1 <= 0.0) d1 = 1.0;
    if (d2 <= 0.0) d2 = 1.0;
    if (d3 <= 0.0) d3 = 1.0;

    if (x2 / d2 <= 0.0 || x3 / d3 <= 0.0 || x1 / d1 <= 0.0) {
        rho_out[blk] = 0.0;
        if (slack_out) slack_out[blk] = -INFINITY;
        return;
    }

    double r = x3 / x2;
    if (fabs(r) > 50.0) {
        rho_out[blk] = 0.0;
        if (slack_out) slack_out[blk] = -INFINITY;
        return;
    }

    double exp_r = exp(r);
    double slack = x1 - x2 * exp_r;

    if (slack_out) slack_out[blk] = slack;

    if (!isfinite(slack) || slack <= 0.0 || x1 <= 0.0) {
        rho_out[blk] = 0.0;
        return;
    }

    double rho = slack / x1;
    if (!isfinite(rho) || rho < 0.0) rho = 0.0;
    if (rho > 1.0) rho = 1.0;
    rho_out[blk] = rho;
}

__global__ void boundary_metric_power_kernel(
    double *rho_out,
    double *slack_out,
    const double *x_d,
    const double *rescale_d,
    const double *alpha_d,
    const int *start_idx,
    const int *v_dim,
    int num_blocks)
{
    int blk = blockIdx.x * blockDim.x + threadIdx.x;
    if (blk >= num_blocks) return;
    (void)v_dim;

    int start = start_idx[blk];
    double xv = x_d[start];
    double yv = x_d[start + 1];
    double zv = x_d[start + 2];
    double alpha = alpha_d ? alpha_d[blk] : 0.5;

    if (!isfinite(xv) || !isfinite(yv) || !isfinite(zv)) {
        rho_out[blk] = 0.0;
        if (slack_out) slack_out[blk] = -INFINITY;
        return;
    }

    if (alpha <= 0.0 || alpha >= 1.0) {
        rho_out[blk] = 0.0;
        if (slack_out) slack_out[blk] = -INFINITY;
        return;
    }

    double dx = rescale_d ? rescale_d[start] : 1.0;
    double dy = rescale_d ? rescale_d[start + 1] : 1.0;
    double dz = rescale_d ? rescale_d[start + 2] : 1.0;
    if (dx <= 0.0) dx = 1.0;
    if (dy <= 0.0) dy = 1.0;
    if (dz <= 0.0) dz = 1.0;

    if (xv / dx < 0.0 || yv / dy < 0.0) {
        rho_out[blk] = 0.0;
        if (slack_out) slack_out[blk] = -INFINITY;
        return;
    }

    double xv_s = xv / dx;
    double yv_s = yv / dy;
    double zv_s = zv / dz;

    if (xv_s < 1e-300 || yv_s < 1e-300) {
        rho_out[blk] = 0.0;
        if (slack_out) slack_out[blk] = -INFINITY;
        return;
    }

    double log_h = alpha * log(xv_s) + (1.0 - alpha) * log(yv_s);
    if (!isfinite(log_h) || log_h > 700.0) {
        rho_out[blk] = 0.0;
        if (slack_out) slack_out[blk] = -INFINITY;
        return;
    }

    double h = exp(log_h);
    double abs_z = fabs(zv_s);
    double slack = h - abs_z;

    if (slack_out) slack_out[blk] = slack;

    if (slack <= 0.0 || h < 1e-15) {
        rho_out[blk] = 0.0;
        return;
    }

    double rho = slack / h;
    if (!isfinite(rho) || rho < 0.0) rho = 0.0;
    if (rho > 1.0) rho = 1.0;
    rho_out[blk] = rho;
}

/* =============================================================================
 * Section 2: Kernel Launchers (extern "C" interface)
 * ============================================================================= */

extern "C" void launch_boundary_metric_rsoc(
    double *rho_out, double *slack_out,
    const double *x_d, const double *rescale_d,
    const int *start_idx, const int *v_dim,
    int num_blocks)
{
    if (num_blocks == 0) return;
    int threads = 128;
    int blocks = (num_blocks + threads - 1) / threads;
    boundary_metric_rsoc_kernel<<<blocks, threads>>>(
        rho_out, slack_out, x_d, rescale_d, start_idx, v_dim, num_blocks);
}

extern "C" void launch_boundary_metric_std_soc(
    double *rho_out, double *slack_out,
    const double *x_d, const double *rescale_d,
    const int *start_idx, const int *v_dim,
    int num_blocks)
{
    if (num_blocks == 0) return;
    int threads = 128;
    int blocks = (num_blocks + threads - 1) / threads;
    boundary_metric_std_soc_kernel<<<blocks, threads>>>(
        rho_out, slack_out, x_d, rescale_d, start_idx, v_dim, num_blocks);
}

extern "C" void launch_boundary_metric_exp(
    double *rho_out, double *slack_out,
    const double *x_d, const double *rescale_d,
    const int *start_idx, const int *v_dim,
    int num_blocks)
{
    if (num_blocks == 0) return;
    int threads = 128;
    int blocks = (num_blocks + threads - 1) / threads;
    boundary_metric_exp_kernel<<<blocks, threads>>>(
        rho_out, slack_out, x_d, rescale_d, start_idx, v_dim, num_blocks);
}

extern "C" void launch_boundary_metric_power(
    double *rho_out, double *slack_out,
    const double *x_d, const double *rescale_d,
    const double *alpha_d,
    const int *start_idx, const int *v_dim,
    int num_blocks)
{
    if (num_blocks == 0) return;
    int threads = 128;
    int blocks = (num_blocks + threads - 1) / threads;
    boundary_metric_power_kernel<<<blocks, threads>>>(
        rho_out, slack_out, x_d, rescale_d, alpha_d, start_idx, v_dim, num_blocks);
}

/* =============================================================================
 * Section 3: BPGrad CUDA Kernels (Stage 1.6)
 *
 * Each kernel processes ONE cone block per CUDA thread block.
 *   - threadIdx.x == 0 does the entire Newton iteration
 *   - blockIdx.x  indexes the cone block
 *
 * Simplifications matching barrier_apply.c (g=0 form):
 *   - g = 0 (no linear term)
 *   - Proximal form: x* = argmin (1/2τ)||x - x_k||² + μ·φ(x)
 *   - Descent direction: d = (x - x_k)/τ + μ·∇φ(x)
 *   - Single step size: α = 1.0 (no Armijo backtracking in 1.6)
 *   - Max 20 Newton iterations
 *   - Fallback: kernel writes 0 to converged_d[idx], host re-projects
 *
 * Per cone type:
 *   - RSOC   (k+2 vars): closed-form ∇φ
 *   - StdSOC (k+1 vars): closed-form ∇φ
 *   - EXP    (3 vars):   closed-form ∇φ, diagonal Hessian
 *   - Power  (3 vars):   closed-form ∇φ, 3x3 matrix inverse
 * ============================================================================= */

#define BPGRAD_SLACK_FLOOR 1e-12
#define BPGRAD_MAX_K_CAP 1024
#define BPGRAD_MAX_ITER 20

/* BPGrad for RSOC: PDHCG layout x = (v[0..k-1], s, t), total size k + 2
   *
   * Barrier  φ = -log(2st - ||v||²),  inner = 2 s t - ||v||²
   * ∇φ_v = 2 v / inner,  ∇φ_s = -2 t / inner,  ∇φ_t = -2 s / inner
   *
   * The subproblem solved is the g = 0 barrier-proximal form
   *     x* = argmin { (1/2τ)||x - x_k||² + μ φ(x) }
   * evaluated by a damped quasi-Newton (gradient) iteration with an Armijo
   * backtracking line search and a cone projection of every trial point --
   * exactly mirroring the reference host solver bpgrad_solve_rsoc().
   *
   * status_d codes:
   *   1 = solved and converged below tol   (barrier step fully applied)
   *   2 = solved, feasible, tol not met   (barrier step applied, keep going)
   *   0 = kernel could not handle it       (host must redo with real BPGrad)
   */
__global__ void bpgrad_rsoc_kernel(
    double *x_d,
    int *converged_d,
    const int *start_idx,
    const int *v_dim,
    int num_blocks,
    double mu,
    double tau,
    int max_iter,
    double tol,
    int k_max,
    double ls_alpha0,
    double ls_beta,
    int ls_max)
{
    int blk = blockIdx.x;
    if (blk >= num_blocks) return;
if (threadIdx.x != 0) return;  /* single-warp per cone block */

    int start = start_idx[blk];
    int k = v_dim[blk];
    /* Dynamic shared memory: 3*(k+2) doubles (current, x_k, trial) + grad(k+2)
     * The launcher sizes the request from the *actual* maximum k in this
     * launch, so k_max is a genuine capability bound, not a hard-coded 64. */
    if (k < 1 || k > k_max || k > BPGRAD_MAX_K_CAP) {
        converged_d[blk] = 0;   /* host must solve with the real BPGrad solver */
        return;
    }

    int n = k + 2;
    extern __shared__ double smem[];
    double *x    = smem;               /* n */
    double *xk   = smem + n;           /* n  (proximal centre) */
    double *tr   = smem + 2 * n;       /* n  (line-search trial) */
    double *grad = smem + 3 * n;       /* n  (descent direction) */
    double *s_pt = x + k;
    double *t_pt = x + k + 1;

    for (int i = 0; i < n; i++) {
        x[i]  = x_d[start + i];
        xk[i] = x[i];
    }

    double tau_inv = 1.0 / tau;
    if (!(tau_inv > 0.0) || !isfinite(tau_inv)) tau_inv = 1.0;

    int status = 0;
    int any_accepted = 0;

    for (int it = 0; it < max_iter; it++) {
        double nv2 = 0.0;
        for (int i = 0; i < k; i++) nv2 += x[i] * x[i];
        double inner = 2.0 * (*s_pt) * (*t_pt) - nv2;
        if (!(inner > 0.0)) {
            /* On the boundary the barrier gradient is singular.  Shrink the
             * lateral part by sqrt(1-delta) so inner -> delta * 2 s t > 0,
             * mirroring host rsoc_reseed_interior().  s and t stay put. */
            const double beta = 0.99999999995;
            for (int i = 0; i < k; i++) x[i] *= beta;
            for (int i = 0; i < k; i++) nv2 += x[i] * x[i];
            inner = 2.0 * x[k] * x[k + 1] - nv2;
            if (!(inner > 0.0)) { status = 0; break; }
        }

        double inv = 1.0 / inner;

        /* grad F = (x - x_k)/tau + mu * grad(phi);  g = 0 */
        for (int i = 0; i < k; i++) {
            grad[i] = (x[i] - xk[i]) * tau_inv + mu * (2.0 * x[i] * inv);
        }
        grad[k]     = (x[k]     - xk[k])     * tau_inv + mu * (-2.0 * x[k + 1] * inv);
        grad[k + 1] = (x[k + 1] - xk[k + 1]) * tau_inv + mu * (-2.0 * x[k]     * inv);

        double gnorm = 0.0;
        for (int i = 0; i < n; i++) gnorm += grad[i] * grad[i];
        gnorm = sqrt(gnorm);

        if (gnorm < 1e-12) { status = 1; break; }

        /* F(x) = (1/2tau)||x - x_k||^2 + mu*phi(x) */
        double dx2 = 0.0;
        for (int i = 0; i < n; i++) {
            double d = x[i] - xk[i];
            dx2 += d * d;
        }
        double F_x = 0.5 * tau_inv * dx2 + mu * (-log(inner));

        /* Armijo backtracking with cone projection of the trial point */
        double alpha = ls_alpha0;
        bool ls_ok = false;
        for (int ls = 0; ls < ls_max; ls++) {
            for (int i = 0; i < n; i++) tr[i] = x[i] - alpha * grad[i];

            /* In-cone RSOC projection (uniform-scaling form, matches
             * project_rotated_soc_kernel's fast path for the rescaled case). */
            {
                double w = (tr[k] - tr[k + 1]) * 0.7071067811865475;
                double z = (tr[k] + tr[k + 1]) * 0.7071067811865475;
                double sumsq = w * w;
                for (int i = 0; i < k; i++) sumsq += tr[i] * tr[i];
                double r = sqrt(sumsq);
                if (r > z) {
                    if (r <= -z) {
                        for (int i = 0; i < k; i++) tr[i] = 0.0;
                        tr[k] = 0.0;
                        tr[k + 1] = 0.0;
                    } else {
                        double sc = (z + r) / (2.0 * r);
                        for (int i = 0; i < k; i++) tr[i] *= sc;
                        double wn = sc * w, zn = sc * r;
                        tr[k]     = (zn + wn) * 0.7071067811865475;
                        tr[k + 1] = (zn - wn) * 0.7071067811865475;
                    }
                }
            }

            double tv2 = 0.0;
            for (int i = 0; i < k; i++) tv2 += tr[i] * tr[i];
            double t_inner = 2.0 * tr[k] * tr[k + 1] - tv2;
            if (!(t_inner > BPGRAD_SLACK_FLOOR)) { alpha *= ls_beta; continue; }

            double tdx2 = 0.0;
            for (int i = 0; i < n; i++) {
                double d = tr[i] - xk[i];
                tdx2 += d * d;
            }
            double F_tr = 0.5 * tau_inv * tdx2 + mu * (-log(t_inner));

            double gdd = 0.0;
            for (int i = 0; i < n; i++) gdd += grad[i] * (tr[i] - x[i]);
            if (F_tr <= F_x + 1e-4 * alpha * gdd) {
                for (int i = 0; i < n; i++) x[i] = tr[i];
                ls_ok = true;
                break;
            }
            alpha *= ls_beta;
        }

        if (!ls_ok) { status = 0; break; }

        any_accepted = 1;

        /* Convergence must be judged on the gradient AT THE NEW POINT, not the
         * one we stepped away from.  The old kernel compared a norm built from
         * the pre-update gradient and then reported success, so "converged"
         * really meant "we moved", which is why nothing downstream could tell a
         * real solve from a discarded one. */
        double nvsq2 = 0.0;
        for (int i = 0; i < k; i++) nvsq2 += x[i] * x[i];
        double new_inner = 2.0 * x[k] * x[k + 1] - nvsq2;
        if (!(new_inner > 0.0)) {
            /* Step landed on the boundary: shrink laterally and retry. */
            const double beta = 0.99999999995;
            for (int i = 0; i < k; i++) x[i] *= beta;
            continue;
        }

        double new_inv = 1.0 / new_inner;
        double rnorm = 0.0;
        for (int i = 0; i < k; i++) {
            double gr = (x[i] - xk[i]) * tau_inv + mu * (2.0 * x[i] * new_inv);
            rnorm += gr * gr;
        }
        {
            double gr = (x[k] - xk[k]) * tau_inv + mu * (-2.0 * x[k + 1] * new_inv);
            rnorm += gr * gr;
            gr = (x[k + 1] - xk[k + 1]) * tau_inv + mu * (-2.0 * x[k] * new_inv);
            rnorm += gr * gr;
        }
        rnorm = sqrt(rnorm);

        /* A feasible, monotonically-improving barrier step is already a
         * *result*.  Requiring full convergence to tol before keeping it made
         * the kernel discard most steps and reduced the barrier to a no-op. */
        status = (rnorm < tol) ? 1 : 2;
        if (status == 1) break;
    }

    if (status != 0 && any_accepted) {
        for (int i = 0; i < n; i++) x_d[start + i] = x[i];
        converged_d[blk] = status;
    } else {
        /* Never wrote anything: leave the device block untouched. */
        converged_d[blk] = 0;
    }
}

/* ---------------------------------------------------------------------------
 * BPGrad for StdSOC: PDHCG layout x = (v[0..k-1], w, z), total size k + 2
   *   Cone Q = {(w, z, v) : ||(v, w)|| <= z }, z >= 0
   *   Barrier  φ = -log(z² - (||v||² + w²)),  inner = z² - (||v||² + w²)
   *   ∇φ_v = 2 v / inner,  ∇φ_w = 2 w / inner,  ∇φ_z = -2 z / inner
   * --------------------------------------------------------------------------- */
__global__ void bpgrad_std_soc_kernel(
    double *x_d,
    int *converged_d,
    const int *start_idx,
    const int *v_dim,
    int num_blocks,
    double mu,
    double tau,
    int max_iter,
    double tol,
    int k_max,
    double ls_alpha0,
    double ls_beta,
    int ls_max)
{
    int blk = blockIdx.x;
    if (blk >= num_blocks) return;
    if (threadIdx.x != 0) return;

    int start = start_idx[blk];
    int k = v_dim[blk];
    if (k < 1 || k > k_max || k > BPGRAD_MAX_K_CAP) {
        converged_d[blk] = 0;
        return;
    }

    int n = k + 2;
    extern __shared__ double smem[];
    double *x    = smem;            /* n: [v(k), w, z] */
    double *xk   = smem + n;        /* n: proximal centre */
    double *tr   = smem + 2 * n;    /* n: line-search trial */
    double *grad = smem + 3 * n;    /* n: descent direction */

    for (int i = 0; i < n; i++) {
        x[i]  = x_d[start + i];
        xk[i] = x[i];
    }

    double tau_inv = 1.0 / tau;
    if (!(tau_inv > 0.0) || !isfinite(tau_inv)) tau_inv = 1.0;

    int status = 0;
    int any_accepted = 0;

    for (int it = 0; it < max_iter; it++) {
        double vsq = 0.0;
        for (int i = 0; i < k; i++) vsq += x[i] * x[i];
        double wv = x[k], zv = x[k + 1];
        double inner = zv * zv - (vsq + wv * wv);
        if (!(inner > 0.0)) {
            /* Boundary => singular barrier gradient.  Shrink (v, w) by
             * sqrt(1-delta) so inner -> delta * z^2 > 0; z stays put.
             * Mirrors host stdsoc_reseed_interior(). */
            const double beta = 0.99999999995;
            for (int i = 0; i < k; i++) x[i] *= beta;
            x[k] *= beta;
            vsq = 0.0;
            for (int i = 0; i < k; i++) vsq += x[i] * x[i];
            inner = x[k + 1] * x[k + 1] - (vsq + x[k] * x[k]);
            if (!(inner > 0.0)) { status = 0; break; }
        }

        double inv = 1.0 / inner;

        /* grad F = (x - x_k)/tau + mu * grad(phi) */
        for (int i = 0; i < k; i++) {
            grad[i] = (x[i] - xk[i]) * tau_inv + mu * (2.0 * x[i] * inv);
        }
        grad[k]     = (x[k]     - xk[k])     * tau_inv + mu * (2.0 * x[k]     * inv);
        grad[k + 1] = (x[k + 1] - xk[k + 1]) * tau_inv + mu * (-2.0 * x[k + 1] * inv);

        double gnorm = 0.0;
        for (int i = 0; i < n; i++) gnorm += grad[i] * grad[i];
        gnorm = sqrt(gnorm);

        if (gnorm < 1e-12) { status = 1; break; }

        double dx2 = 0.0;
        for (int i = 0; i < n; i++) {
            double d = x[i] - xk[i];
            dx2 += d * d;
        }
        double F_x = 0.5 * tau_inv * dx2 + mu * (-log(inner));

        double alpha = ls_alpha0;
        bool ls_ok = false;
        for (int ls = 0; ls < ls_max; ls++) {
            for (int i = 0; i < n; i++) tr[i] = x[i] - alpha * grad[i];

            /* Project onto Q = {(w,z,v) : ||(v,w)|| <= z} (d = 1 case) */
            {
                double t_v2 = 0.0;
                for (int i = 0; i < k; i++) t_v2 += tr[i] * tr[i];
                double t_w = tr[k], t_z = tr[k + 1];
                double nrm = sqrt(t_v2 + t_w * t_w);
                if (!(t_z >= 0.0)) {
                    for (int i = 0; i < k; i++) tr[i] = 0.0;
                    tr[k] = 0.0;
                    tr[k + 1] = 0.0;
                } else if (nrm > t_z) {
                    if (nrm <= -t_z) {
                        for (int i = 0; i < k; i++) tr[i] = 0.0;
                        tr[k] = 0.0;
                        tr[k + 1] = 0.0;
                    } else {
                        double sc = (t_z + nrm) / (2.0 * nrm);
                        for (int i = 0; i < k; i++) tr[i] *= sc;
                        tr[k]     = t_w * sc;
                        tr[k + 1] = t_z * sc;
                    }
                }
            }

            double tv2 = 0.0;
            for (int i = 0; i < k; i++) tv2 += tr[i] * tr[i];
            double t_inner = tr[k + 1] * tr[k + 1] - (tv2 + tr[k] * tr[k]);
            if (!(t_inner > BPGRAD_SLACK_FLOOR)) { alpha *= ls_beta; continue; }

            double tdx2 = 0.0;
            for (int i = 0; i < n; i++) {
                double d = tr[i] - xk[i];
                tdx2 += d * d;
            }
            double F_tr = 0.5 * tau_inv * tdx2 + mu * (-log(t_inner));

            double gdd = 0.0;
            for (int i = 0; i < n; i++) gdd += grad[i] * (tr[i] - x[i]);
            if (F_tr <= F_x + 1e-4 * alpha * gdd) {
                for (int i = 0; i < n; i++) x[i] = tr[i];
                ls_ok = true;
                break;
            }
            alpha *= ls_beta;
        }

        if (!ls_ok) { status = 0; break; }

        any_accepted = 1;

        /* Judge convergence on the gradient at the NEW point (see the RSOC
         * kernel for the reasoning). */
        double nvsq = 0.0;
        for (int i = 0; i < k; i++) nvsq += x[i] * x[i];
        double new_inner = x[k + 1] * x[k + 1] - (nvsq + x[k] * x[k]);
        if (!(new_inner > 0.0)) {
            /* Step landed on the boundary: shrink (v, w) and retry. */
            const double beta = 0.99999999995;
            for (int i = 0; i < k; i++) x[i] *= beta;
            x[k] *= beta;
            continue;
        }

        double new_inv = 1.0 / new_inner;
        double rnorm = 0.0;
        for (int i = 0; i < k; i++) {
            double gr = (x[i] - xk[i]) * tau_inv + mu * (2.0 * x[i] * new_inv);
            rnorm += gr * gr;
        }
        {
            double gr = (x[k] - xk[k]) * tau_inv + mu * (2.0 * x[k] * new_inv);
            rnorm += gr * gr;
            gr = (x[k + 1] - xk[k + 1]) * tau_inv + mu * (-2.0 * x[k + 1] * new_inv);
            rnorm += gr * gr;
        }
        rnorm = sqrt(rnorm);

        status = (rnorm < tol) ? 1 : 2;
        if (status == 1) break;
    }

    if (status != 0 && any_accepted) {
        for (int i = 0; i < n; i++) x_d[start + i] = x[i];
        converged_d[blk] = status;
    } else {
        converged_d[blk] = 0;
    }
}

/* ---------------------------------------------------------------------------
 * BPGrad for EXP: x = (x1, x2, x3)  (3-dim)
 *   barrier  φ = -log x2 - log x3 - log(x1 - x2·exp(x3/x2))
 *   r = x3/x2
 *   s = x1 - x2·exp(r)
 *   ∇φ_1 = -1/s
 *   ∇φ_2 = -1/x2 + (1+r)·exp(r)/s
 *   ∇φ_3 = -1/x3 + (r/x2)·exp(r)/s
 * --------------------------------------------------------------------------- */
__global__ void bpgrad_exp_kernel(
    double *x_d,
    int *converged_d,
    const int *start_idx,
    int num_blocks,
    double mu,
    double tau,
    int max_iter,
    double tol)
{
    (void)tau;  /* prox = 0 at start under g=0 simplification */

    int blk = blockIdx.x;
    if (blk >= num_blocks) return;
    if (threadIdx.x != 0) return;

    int start = start_idx[blk];

    double x1 = x_d[start];
    double x2 = x_d[start + 1];
    double x3 = x_d[start + 2];

    int conv = 0;
    int fb = 0;

    for (int it = 0; it < max_iter; it++) {
        if (x2 <= 0.0 || x3 <= 0.0) { fb = 1; break; }
        double r = x3 / x2;
        if (fabs(r) > 50.0) { fb = 1; break; }
        double exp_r = exp(r);
        double s = x1 - x2 * exp_r;
        if (s <= BPGRAD_SLACK_FLOOR) { fb = 1; break; }

        double inv_s = 1.0 / s;
        double phi_1 = -inv_s;
        double phi_2 = -1.0 / x2 + (1.0 + r) * exp_r * inv_s;
        double phi_3 = -1.0 / x3 + (r / x2) * exp_r * inv_s;

        x1 = x1 - mu * phi_1;
        x2 = x2 - mu * phi_2;
        x3 = x3 - mu * phi_3;

        /* Re-check feasibility */
        if (x2 <= 0.0 || x3 <= 0.0) { fb = 1; break; }
        double new_r = x3 / x2;
        if (fabs(new_r) > 50.0) { fb = 1; break; }
        double new_exp_r = exp(new_r);
        double new_s = x1 - x2 * new_exp_r;
        if (new_s <= BPGRAD_SLACK_FLOOR) { fb = 1; break; }

        double dnorm = (mu * phi_1) * (mu * phi_1)
                     + (mu * phi_2) * (mu * phi_2)
                     + (mu * phi_3) * (mu * phi_3);
        if (sqrt(dnorm) < tol) { conv = 1; break; }
    }

    if (!fb) {
        x_d[start]     = x1;
        x_d[start + 1] = x2;
        x_d[start + 2] = x3;
    }
    converged_d[blk] = conv;
}

/* ---------------------------------------------------------------------------
 * BPGrad for Power cone: x = (x, y, z)  (3-dim, alpha given per block)
 *   barrier  φ = -α log x - (1-α) log y - log(x^α y^(1-α) - |z|)
 *   H = x^α y^(1-α) - |z|
 *   ∇φ_x = -α/x + α x^(α-1) y^(1-α) / H
 *   ∇φ_y = -(1-α)/y + (1-α) x^α y^(-α) / H
 *   ∇φ_z = -sign(z) / H
 * --------------------------------------------------------------------------- */
__global__ void bpgrad_power_kernel(
    double *x_d,
    int *converged_d,
    const int *start_idx,
    const double *alpha_d,
    int num_blocks,
    double mu,
    double tau,
    int max_iter,
    double tol)
{
    (void)tau;

    int blk = blockIdx.x;
    if (blk >= num_blocks) return;
    if (threadIdx.x != 0) return;

    int start = start_idx[blk];
    double alpha = alpha_d ? alpha_d[blk] : 0.5;

    double xv = x_d[start];
    double yv = x_d[start + 1];
    double zv = x_d[start + 2];

    int conv = 0;
    int fb = 0;

    for (int it = 0; it < max_iter; it++) {
        if (xv <= 0.0 || yv <= 0.0) { fb = 1; break; }
        if (alpha <= 0.0 || alpha >= 1.0) { fb = 1; break; }

        double log_h = alpha * log(xv) + (1.0 - alpha) * log(yv);
        if (!isfinite(log_h) || log_h > 700.0) { fb = 1; break; }
        double h = exp(log_h);
        double abs_z = fabs(zv);
        double slack = h - abs_z;
        if (slack <= BPGRAD_SLACK_FLOOR || h < 1e-15) { fb = 1; break; }

        double inv_slack = 1.0 / slack;
        /* ∇φ_x = -α/x + α·(h/x)·(1/slack)
         * ∇φ_y = -(1-α)/y + (1-α)·(h/y)·(1/slack)
         * ∇φ_z = -sign(z)/slack
         */
        double phi_x = -alpha / xv + alpha * h / xv * inv_slack;
        double phi_y = -(1.0 - alpha) / yv + (1.0 - alpha) * h / yv * inv_slack;
        double sign_z = (zv >= 0.0) ? 1.0 : -1.0;
        double phi_z = -sign_z * inv_slack;

        xv = xv - mu * phi_x;
        yv = yv - mu * phi_y;
        zv = zv - mu * phi_z;

        /* Re-check feasibility */
        if (xv <= 0.0 || yv <= 0.0) { fb = 1; break; }
        double new_log_h = alpha * log(xv) + (1.0 - alpha) * log(yv);
        if (!isfinite(new_log_h) || new_log_h > 700.0) { fb = 1; break; }
        double new_h = exp(new_log_h);
        double new_abs_z = fabs(zv);
        double new_slack = new_h - new_abs_z;
        if (new_slack <= BPGRAD_SLACK_FLOOR) { fb = 1; break; }

        double dnorm = (mu * phi_x) * (mu * phi_x)
                     + (mu * phi_y) * (mu * phi_y)
                     + (mu * phi_z) * (mu * phi_z);
        if (sqrt(dnorm) < tol) { conv = 1; break; }
    }

    if (!fb) {
        x_d[start]     = xv;
        x_d[start + 1] = yv;
        x_d[start + 2] = zv;
    }
    converged_d[blk] = conv;
}

/* ---------------------------------------------------------------------------
 * Launchers (extern "C")
 * --------------------------------------------------------------------------- */

/* ---------------------------------------------------------------------------
 * Shared helper: resolve the largest k present in this launch, then pick a
 * shared-memory size that fits the real data instead of a hard-coded bound.
 *
 * We request dynamic shared memory for 4*(k_max+2) doubles (current, x_k,
 * trial, grad).  If that exceeds the device limit we shrink k_max until it
 * fits; blocks with a larger k are reported as status 0 and re-solved on the
 * host with the real BPGrad solver -- never silently downgraded to a plain
 * projection.
 * --------------------------------------------------------------------------- */
extern "C" int bpgrad_resolve_soc_launch(
    const int *v_dim,
    int num_blocks,
    int *out_k_max,
    size_t *out_shmem)
{
    if (!v_dim || num_blocks <= 0) return -1;

    /* Copy the k vector to the host: it is already small (one int per cone
     * block) and this keeps the launcher free of extra allocations. */
    int h_v[4096];
    int chunk = 4096;
    int *v_h = h_v;
    int *v_heap = NULL;
    if (num_blocks > chunk) {
        v_heap = (int *)malloc((size_t)num_blocks * sizeof(int));
        if (!v_heap) return -1;
        v_h = v_heap;
    }
    cudaError_t cerr = cudaMemcpy(v_h, v_dim, (size_t)num_blocks * sizeof(int),
                                  cudaMemcpyDeviceToHost);
    if (cerr != cudaSuccess) { free(v_heap); return -1; }

    int k_max = 0;
    for (int i = 0; i < num_blocks; i++) {
        if (v_h[i] > k_max) k_max = v_h[i];
    }
    free(v_heap);

    if (k_max < 1) k_max = 1;
    if (k_max > BPGRAD_MAX_K_CAP) k_max = BPGRAD_MAX_K_CAP;

    /* Largest k we can actually service with dynamic shared memory. */
    int dev = 0;
    int max_shmem = 48 * 1024;  /* conservative: every supported arch has this */
    if (cudaGetDevice(&dev) == cudaSuccess) {
        cudaDeviceGetAttribute(&max_shmem, cudaDevAttrMaxSharedMemoryPerBlock, dev);
    }
    if (max_shmem <= 0) max_shmem = 48 * 1024;

    /* 4 arrays of (k+2) doubles, plus a little slack */
    size_t per_k = 4 * sizeof(double);
    int k_fit = (int)((size_t)(max_shmem - 1024) / (per_k * 1)) - 2;
    if (k_fit < 1) k_fit = 1;
    if (k_fit < k_max) k_max = k_fit;

    *out_k_max = k_max;
    *out_shmem = (size_t)(4 * (k_max + 2)) * sizeof(double);
    return 0;
}

extern "C" int launch_bpgrad_rsoc(
    double *x_d,
    int *converged_d,
    const int *start_idx,
    const int *v_dim,
    int num_blocks,
    double mu,
    double tau,
    int max_iter,
    double tol,
    double ls_alpha0,
    double ls_beta,
    int ls_max)
{
    if (num_blocks == 0) return 0;
    int k_max = 1;
    size_t shmem = 0;
    if (bpgrad_resolve_soc_launch(v_dim, num_blocks, &k_max, &shmem) != 0) {
        return -1;
    }

    bpgrad_rsoc_kernel<<<num_blocks, 32, shmem, 0>>>(
        x_d, converged_d, start_idx, v_dim, num_blocks,
        mu, tau, max_iter, tol, k_max, ls_alpha0, ls_beta, ls_max);
    return cudaGetLastError() == cudaSuccess ? 0 : -1;
}

extern "C" int launch_bpgrad_std_soc(
    double *x_d,
    int *converged_d,
    const int *start_idx,
    const int *v_dim,
    int num_blocks,
    double mu,
    double tau,
    int max_iter,
    double tol,
    double ls_alpha0,
    double ls_beta,
    int ls_max)
{
    if (num_blocks == 0) return 0;
    int k_max = 1;
    size_t shmem = 0;
    if (bpgrad_resolve_soc_launch(v_dim, num_blocks, &k_max, &shmem) != 0) {
        return -1;
    }

    bpgrad_std_soc_kernel<<<num_blocks, 32, shmem, 0>>>(
        x_d, converged_d, start_idx, v_dim, num_blocks,
        mu, tau, max_iter, tol, k_max, ls_alpha0, ls_beta, ls_max);
    return cudaGetLastError() == cudaSuccess ? 0 : -1;
}

extern "C" int launch_bpgrad_exp(
    double *x_d,
    int *converged_d,
    const int *start_idx,
    int num_blocks,
    double mu,
    double tau,
    int max_iter,
    double tol)
{
    if (num_blocks == 0) return 0;
    int threads = 32;
    int blocks  = num_blocks;
    bpgrad_exp_kernel<<<blocks, threads>>>(
        x_d, converged_d, start_idx, num_blocks,
        mu, tau, max_iter, tol);
    return cudaGetLastError() == cudaSuccess ? 0 : -1;
}

extern "C" int launch_bpgrad_power(
    double *x_d,
    int *converged_d,
    const int *start_idx,
    const double *alpha_d,
    int num_blocks,
    double mu,
    double tau,
    int max_iter,
    double tol)
{
    if (num_blocks == 0) return 0;
    int threads = 32;
    int blocks  = num_blocks;
    bpgrad_power_kernel<<<blocks, threads>>>(
        x_d, converged_d, start_idx, alpha_d, num_blocks,
        mu, tau, max_iter, tol);
    return cudaGetLastError() == cudaSuccess ? 0 : -1;
}

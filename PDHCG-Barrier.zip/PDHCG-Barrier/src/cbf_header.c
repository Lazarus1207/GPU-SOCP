/* cbf_header.c -- minimal CBF geometry reader.
 *
 * Scans the top of a CBF (or CBF.gz) file just enough to extract
 * VAR, CON, FCOORD nnz, CONES, and the per-cone-type counts.  The
 * scanner treats anything from '#' to end-of-line as a comment, and
 * splits each non-comment line into a sequence of whitespace-separated
 * tokens.  The first token is the keyword; subsequent tokens are
 * either integer counts or, for cone-type lines, a list of variable
 * indices whose length is not material here.
 *
 * The scanner is intentionally permissive: on any unrecognised token
 * or zlib error it sets `parse_failed=true` and returns whatever
 * fields it managed to fill.  The driver treats that as a signal to
 * fall back to the C defaults (alpha=1.0, restart=default) for the
 * geometry-based config classifier.
 */
#include "cbf_header.h"

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <zlib.h>

#define LINE_BUF_SIZE 8192

/* A small line reader.  Returns 0 on EOF, 1 on a non-empty line read
 * (with the trailing newline stripped), -1 on error.  Comments
 * starting with '#' are skipped.  The output buffer is null-
 * terminated.  When `path` ends in ".gz", a gzip stream is opened;
 * otherwise the file is read directly. */
static int read_line(FILE *fp, gzFile gz, char *buf, size_t bufsz) {
    for (;;) {
        const char *raw;
        if (gz != NULL) {
            if (gzgets(gz, buf, (int)bufsz) == NULL) {
                return (gzeof(gz)) ? 0 : -1;
            }
            raw = buf;
        } else {
            if (fgets(buf, (int)bufsz, fp) == NULL) {
                return feof(fp) ? 0 : -1;
            }
            raw = buf;
        }
        /* Strip trailing CR/LF. */
        size_t n = strlen(raw);
        while (n > 0 && (raw[n - 1] == '\n' || raw[n - 1] == '\r')) {
            buf[--n] = '\0';
        }
        /* Skip blank lines and full-line comments. */
        const char *p = raw;
        while (*p && isspace((unsigned char)*p)) ++p;
        if (*p == '\0' || *p == '#') continue;
        return 1;
    }
}

/* Returns 1 if `tok` matches any of the cone-type keywords
 * (Q, QR, EXP, F, L=, L+, L-).  These are "content" lines and the
 * scanner must not abort on them; it just records the type and moves
 * on without trying to parse the variable list. */
static int is_cone_keyword(const char *tok) {
    return (strcmp(tok, "Q")   == 0 ||
            strcmp(tok, "QR")  == 0 ||
            strcmp(tok, "EXP") == 0 ||
            strcmp(tok, "F")   == 0 ||
            strcmp(tok, "L=")  == 0 ||
            strcmp(tok, "L+")  == 0 ||
            strcmp(tok, "L-")  == 0);
}

/* Returns 1 if `tok` is a header keyword that introduces a data
 * block which the scanner should still inspect (e.g. FCOORD, ACOORD,
 * BCOORD, OBJSENSE, OBJACOORD, OBJBCOORD, BOUND).  We tolerate but
 * do not parse these -- we just keep reading lines. */
static int is_skip_keyword(const char *tok) {
    /* FCOORD/ACOORD/BCOORD/OBJACOORD/OBJBCOORD are followed by an
     * integer nnz which we want to read; for the rest we just keep
     * scanning.  This function is reserved for future use; the
     * current scanner reads FCOORD explicitly. */
    (void)tok;
    return 0;
}

void pdhcg_cbf_read_geometry(const char *path, pdhcg_cbf_geometry_t *g) {
    if (g == NULL) return;
    memset(g, 0, sizeof(*g));
    if (path == NULL || path[0] == '\0') {
        g->parse_failed = true;
        snprintf(g->errmsg, sizeof(g->errmsg), "null path");
        return;
    }

    /* Decide whether to use a gzip reader.  CBF files in the
     * Mittelmann benchmark are always gzipped (*.cbf.gz). */
    const char *dot = strrchr(path, '.');
    int use_gz = (dot != NULL && strcmp(dot, ".gz") == 0);

    FILE *fp = NULL;
    gzFile gz = NULL;
    if (use_gz) {
        gz = gzopen(path, "rb");
        if (gz == NULL) {
            g->parse_failed = true;
            snprintf(g->errmsg, sizeof(g->errmsg),
                     "gzopen failed: %s", path);
            return;
        }
    } else {
        fp = fopen(path, "r");
        if (fp == NULL) {
            g->parse_failed = true;
            snprintf(g->errmsg, sizeof(g->errmsg),
                     "fopen failed: %s", path);
            return;
        }
    }

    char line[LINE_BUF_SIZE];
    int lineno = 0;
    int seen_var = 0, seen_con = 0, seen_fcoord = 0, seen_cones = 0;
    for (;;) {
        int r = read_line(fp, gz, line, sizeof(line));
        if (r == 0) break;        /* EOF */
        if (r < 0) {
            g->parse_failed = true;
            snprintf(g->errmsg, sizeof(g->errmsg),
                     "read error at line %d", lineno);
            break;
        }
        ++lineno;

        /* Tokenize the line.  Tokens are whitespace-separated. */
        char *save = NULL;
        char *tok = strtok_r(line, " \t", &save);
        if (tok == NULL) continue;

        if (strcmp(tok, "VER") == 0) {
            /* version line:  VER <major>.<minor>  -- ignored. */
            continue;
        }
        if (strcmp(tok, "OBJSENSE") == 0) {
            /* OBJSENSE MIN | MAX  -- ignored. */
            continue;
        }
        if (strcmp(tok, "VAR") == 0) {
            char *n_str = strtok_r(NULL, " \t", &save);
            if (n_str != NULL) {
                g->num_variables = (int)strtol(n_str, NULL, 10);
                seen_var = 1;
            }
            continue;
        }
        if (strcmp(tok, "CON") == 0) {
            char *m_str = strtok_r(NULL, " \t", &save);
            if (m_str != NULL) {
                g->num_constraints = (int)strtol(m_str, NULL, 10);
                seen_con = 1;
            }
            continue;
        }
        if (strcmp(tok, "INT") == 0) {
            /* Integer variables -- chainsing has none, but we tolerate. */
            continue;
        }
        if (strcmp(tok, "FCOORD") == 0 || strcmp(tok, "ACOORD") == 0) {
            /* FCOORD <nnz>  then nnz lines of "row col val".  We only
             * need the nnz, which is the first integer. */
            char *nnz_str = strtok_r(NULL, " \t", &save);
            if (nnz_str != NULL) {
                g->num_nonzeros = (int)strtol(nnz_str, NULL, 10);
                seen_fcoord = 1;
            }
            /* Skip past the nnz coordinate lines so we don't mistake
             * their first integer for a header. */
            int to_skip = g->num_nonzeros;
            while (to_skip-- > 0) {
                if (read_line(fp, gz, line, sizeof(line)) <= 0) break;
            }
            continue;
        }
        if (strcmp(tok, "BCOORD") == 0) {
            /* BCOORD <m>  then m lines.  Skip. */
            char *m_str = strtok_r(NULL, " \t", &save);
            int to_skip = (m_str != NULL) ? (int)strtol(m_str, NULL, 10) : 0;
            while (to_skip-- > 0) {
                if (read_line(fp, gz, line, sizeof(line)) <= 0) break;
            }
            continue;
        }
        if (strcmp(tok, "OBJACOORD") == 0) {
            char *nnz_str = strtok_r(NULL, " \t", &save);
            int to_skip = (nnz_str != NULL) ? (int)strtol(nnz_str, NULL, 10) : 0;
            while (to_skip-- > 0) {
                if (read_line(fp, gz, line, sizeof(line)) <= 0) break;
            }
            continue;
        }
        if (strcmp(tok, "OBJBCOORD") == 0) {
            char *one_str = strtok_r(NULL, " \t", &save);
            (void)one_str;
            if (read_line(fp, gz, line, sizeof(line)) <= 0) break;
            continue;
        }
        if (strcmp(tok, "BOUND") == 0) {
            /* BOUND <2n+1> ...  skip 2n lines. */
            char *nnz_str = strtok_r(NULL, " \t", &save);
            int to_skip = (nnz_str != NULL) ? (int)strtol(nnz_str, NULL, 10) : 0;
            while (to_skip-- > 0) {
                if (read_line(fp, gz, line, sizeof(line)) <= 0) break;
            }
            continue;
        }
        if (strcmp(tok, "CONES") == 0) {
            char *c_str = strtok_r(NULL, " \t", &save);
            if (c_str != NULL) {
                g->num_cones = (int)strtol(c_str, NULL, 10);
                seen_cones = 1;
            }
            continue;
        }
        if (is_cone_keyword(tok)) {
            if (strcmp(tok, "Q")   == 0) g->num_soc_cones++;
            if (strcmp(tok, "QR")  == 0) g->num_rsoc_cones++;
            if (strcmp(tok, "EXP") == 0) g->num_exp_cones++;
            /* Cone lines are followed by a list of variable indices;
             * we just consume the rest of the line and move on. */
            continue;
        }
        if (is_skip_keyword(tok)) {
            continue;
        }
        /* Unrecognised keyword -- assume we've moved past the header. */
        if (seen_var && seen_con && seen_fcoord && seen_cones) {
            break;
        }
        /* Otherwise, keep going.  Some files interleave non-cone
         * tokens in unusual ways; we just try to keep collecting. */
    }

    if (fp) fclose(fp);
    if (gz) gzclose(gz);

    if (!seen_var || !seen_con) {
        g->parse_failed = true;
        if (g->errmsg[0] == '\0') {
            snprintf(g->errmsg, sizeof(g->errmsg),
                     "missing VAR/CON header (seen_var=%d seen_con=%d)",
                     seen_var, seen_con);
        }
    }
}

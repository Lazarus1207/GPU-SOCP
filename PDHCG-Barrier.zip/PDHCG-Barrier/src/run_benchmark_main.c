/* run_benchmark_main.c -- thin entry point for the C-side benchmark
 * driver.  Parses command-line args, then hands off to
 * pdhcg_run_benchmark().
 */
#include "run_benchmark.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

int main(int argc, char **argv) {
    /* Defaults mirror the Python run_benchmark.py. */
    const char *pdhcg_cli   = "pdhcg";
    const char *in_dir      = NULL;
    const char *out_dir     = NULL;
    const char *only        = NULL;
    const char *spmv        = "new";
    double time_limit = 3600.0;
    int iter_limit    = 99999999;
    double eps_opt    = 1e-6;
    double eps_feas   = 1e-6;
    int verbose       = 2;
    int row_scaling_max_rows = 2000;
    int fea_polish    = 0;
    int presolve      = 0;
    int curtis_reid   = 0;
    int ruiz          = -1;       /* -1 = leave at C default (10) */
    int diag_jacobi   = 1;
    int gpu_id        = -1;
    int apply_config  = 1;

    for (int i = 1; i < argc; ++i) {
        const char *a = argv[i];
        const char *v = (i + 1 < argc) ? argv[i + 1] : "";
        if (strcmp(a, "--cli") == 0)               { pdhcg_cli = v; ++i; continue; }
        if (strcmp(a, "--in-dir") == 0)            { in_dir = v; ++i; continue; }
        if (strcmp(a, "--out-dir") == 0)           { out_dir = v; ++i; continue; }
        if (strcmp(a, "--only") == 0)              { only = v; ++i; continue; }
        if (strcmp(a, "--time-limit") == 0)        { time_limit = atof(v); ++i; continue; }
        if (strcmp(a, "--iter-limit") == 0)        { iter_limit = atoi(v); ++i; continue; }
        if (strcmp(a, "--eps") == 0)               { eps_opt = eps_feas = atof(v); ++i; continue; }
        if (strcmp(a, "--eps-opt") == 0)           { eps_opt = atof(v); ++i; continue; }
        if (strcmp(a, "--eps-feas") == 0)          { eps_feas = atof(v); ++i; continue; }
        if (strcmp(a, "--verbose") == 0)           { verbose = atoi(v); ++i; continue; }
        if (strcmp(a, "--row-scaling-max-rows") == 0) { row_scaling_max_rows = atoi(v); ++i; continue; }
        if (strcmp(a, "--row-scaling-enabled") == 0)  { row_scaling_max_rows = atoi(v) ? 2000 : 0; ++i; continue; }
        if (strcmp(a, "--fea-polish") == 0)        { fea_polish = atoi(v); ++i; continue; }
        if (strcmp(a, "--presolve") == 0)          { presolve = atoi(v); ++i; continue; }
        if (strcmp(a, "--curtis-reid-iter") == 0)  { curtis_reid = atoi(v); ++i; continue; }
        if (strcmp(a, "--l-inf-ruiz-iter") == 0)   { ruiz = atoi(v); ++i; continue; }
        if (strcmp(a, "--diag-jacobi") == 0)       { diag_jacobi = atoi(v); ++i; continue; }
        if (strcmp(a, "--spmv-backend") == 0)      { spmv = v; ++i; continue; }
        if (strcmp(a, "--gpu") == 0)               { gpu_id = atoi(v); ++i; continue; }
        if (strcmp(a, "--apply-config") == 0)      { apply_config = atoi(v); ++i; continue; }
        if (strcmp(a, "--no-apply-config") == 0)   { apply_config = 0; continue; }
        if (strcmp(a, "-h") == 0 || strcmp(a, "--help") == 0) {
            fprintf(stderr,
                    "Usage: %s [options]\n"
                    "  --cli <path>            path to PDHCG_cli binary (default: 'pdhcg')\n"
                    "  --in-dir <dir>          directory with .cbf.gz problems (required)\n"
                    "  --out-dir <dir>         output dir (default: <in-dir>/results_<ts>)\n"
                    "  --only <name>           run only this instance\n"
                    "  --time-limit <sec>      per-case time limit (default: 3600)\n"
                    "  --iter-limit <int>      per-case iter limit (default: 99999999)\n"
                    "  --eps <float>           set both eps_opt and eps_feas (default: 1e-6)\n"
                    "  --eps-opt <float>       relative optimality tolerance (default: 1e-6)\n"
                    "  --eps-feas <float>      relative feasibility tolerance (default: 1e-6)\n"
                    "  --verbose <int>         forward to CLI (default: 2)\n"
                    "  --row-scaling-max-rows  cap for row_scaling (default: 2000)\n"
                    "  --row-scaling-enabled 0 disable row scaling entirely\n"
                    "  --fea-polish 0|1        feasibility polishing (default: 0)\n"
                    "  --presolve 0|1          presolve (default: 0)\n"
                    "  --curtis-reid-iter <n>  Curtis-Reid iters when RS activates (default: 0)\n"
                    "  --l-inf-ruiz-iter <n>   Ruiz iters when RS activates (default: -1=C default)\n"
                    "  --diag-jacobi 0|1       diag-Jacobi (default: 1 when RS activates)\n"
                    "  --spmv-backend new|cusparse  (default: new)\n"
                    "  --gpu <int>             CUDA device ordinal (default: -1, env untouched)\n"
                    "  --apply-config 0|1      let C config select (alpha,restart) (default: 1)\n"
                    "  --no-apply-config       alias for --apply-config 0\n",
                    argv[0]);
            return 0;
        }
        fprintf(stderr, "[run_benchmark_main] unknown arg: %s\n", a);
    }
    if (in_dir == NULL) {
        fprintf(stderr, "[run_benchmark_main] --in-dir is required\n");
        return 1;
    }
    if (out_dir == NULL) {
        char ts[32];
        time_t now = time(NULL);
        struct tm *tm = localtime(&now);
        strftime(ts, sizeof(ts), "%Y%m%d_%H%M%S", tm);
        static char default_out[1024];
        snprintf(default_out, sizeof(default_out), "%s/results_%s", in_dir, ts);
        out_dir = default_out;
    }
    return pdhcg_run_benchmark(
        pdhcg_cli, in_dir, out_dir, only,
        time_limit, iter_limit, eps_opt, eps_feas, verbose,
        row_scaling_max_rows, fea_polish, presolve,
        curtis_reid, ruiz, diag_jacobi, spmv, gpu_id, apply_config);
}

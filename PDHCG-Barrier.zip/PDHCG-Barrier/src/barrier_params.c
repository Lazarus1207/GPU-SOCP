/*
================================================================================
barrier_params.c - Barrier Parameters Implementation

Provides default values, utility functions, and state management for the
Barrier-PDHG enhancement.
================================================================================
*/

#include "barrier_params.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <cuda_runtime.h>

/* =============================================================================
 * Section 1: Default Parameter Initialization
 * ============================================================================= */

void set_default_barrier_params(barrier_params_t *params)
{
    if (!params) return;

    memset(params, 0, sizeof(barrier_params_t));

    /* Global switch: disabled by default */
    params->barrier_enabled = false;

    /* Option: 1 = pre-Halpern (primary), 2 = post-Halpern (secondary) */
    params->barrier_option = BARRIER_OPTION_1;

    /* Mu scheduling */
    params->barrier_mu_strategy = BARRIER_MU_CONSTANT;
    params->barrier_mu_init = 1.0;
    params->barrier_mu_final = 1e-6;
    params->barrier_mu_rho = 0.95;

    /* Per-cone max_ratio thresholds (PDCS exp-3.4 v5 experience) */
    params->soc_rsoc_max_ratio = 10.0;   /* SOC/RSOC: rho â 0.316 */
    params->std_soc_max_ratio = 10.0;    /* StdSOC: rho â 0.316 */
    params->exp_max_ratio = 3.0;          /* EXP: rho â 0.577 */
    params->power_max_ratio = 5.0;        /* Power: rho â 0.447 */

    /* BPGrad inner solver */
    params->barrier_max_iter = 20;
    params->barrier_inner_max_iter = 10;
    params->barrier_tol = 1e-8;
    params->barrier_ls_alpha0 = 1.0;
    params->barrier_ls_beta = 0.5;
    params->barrier_ls_c = 1e-4;

    /* 5-layer protection */
    params->barrier_step_norm_cap = 2.0;
    params->barrier_primal_res_factor = 1.5;
    params->barrier_check_every = 1;     /* Check every iteration */
    params->barrier_gap_threshold = 1e-3; /* Gap filter threshold */

    /* Adaptive threshold */
    params->barrier_adaptive_threshold = true;
    params->barrier_fallback_high = 0.3;
    params->barrier_fallback_low = 0.05;
    params->barrier_window_size = 100;

    /* Per-cone trigger mode (default: 1 = adaptive for SOC, 2 = conservative for EXP/Power)
     * 0 = off, 1 = adaptive, 2 = conservative, 3 = always */
    for (int i = 0; i < CONE_KIND_NUM_KINDS; i++) {
        if (i == CONE_KIND_RSOC_PRIMAL || i == CONE_KIND_RSOC_DUAL ||
            i == CONE_KIND_STD_SOC_PRIMAL || i == CONE_KIND_STD_SOC_DUAL) {
            params->cone_trigger_mode[i] = 1; /* adaptive */
        } else {
            params->cone_trigger_mode[i] = 2; /* conservative */
        }
    }

    /* Verbosity */
    params->barrier_verbose = 1;

    /* GPU BPGrad acceleration (Stage 1.6) */
    params->barrier_use_gpu_bpgrad = true;
}

/* =============================================================================
 * Section 2: rho Threshold Conversion (PDCS Stage 3)
 * ============================================================================= */

/*
 * Convert max_ratio to rho_threshold.
 *
 * For SOC/RSOC: rho = sqrt(inner) / t = sqrt(1 - ||u||Â²/tÂ²)
 *   - Old trigger: inner < 1/max_ratio  =>  tÂ² - ||u||Â² < 1/max_ratio
 *   - Assume t ~ 1: 1 - ||u||Â² < 1/max_ratio  =>  ||u||Â² > 1 - 1/max_ratio
 *   - rhoÂ² = 1 - ||u||Â²  =>  rhoÂ² < 1/max_ratio  =>  rho < 1/sqrt(max_ratio)
 *
 * For EXP/Power: rho = slack / x1
 *   - Old trigger: slack < 1/max_ratio  =>  slack/x1 < 1/(max_ratio * x1)
 *   - If x1 ~ 1: rho < 1/max_ratio
 *
 * We use: rho_threshold = 1 / sqrt(max_ratio) for SOC/RSOC/StdSOC
 *         rho_threshold = 1 / max_ratio for EXP/Power
 */
double barrier_rho_threshold(cone_kind_t kind, const barrier_params_t *params)
{
    double max_ratio;

    switch (kind) {
        case CONE_KIND_RSOC_PRIMAL:
        case CONE_KIND_RSOC_DUAL:
            max_ratio = params->soc_rsoc_max_ratio;
            break;
        case CONE_KIND_STD_SOC_PRIMAL:
        case CONE_KIND_STD_SOC_DUAL:
            max_ratio = params->std_soc_max_ratio;
            break;
        case CONE_KIND_EXP_PRIMAL:
        case CONE_KIND_EXP_DUAL:
            max_ratio = params->exp_max_ratio;
            break;
        case CONE_KIND_POWER_PRIMAL:
        case CONE_KIND_POWER_DUAL:
            max_ratio = params->power_max_ratio;
            break;
        default:
            return 1.0;
    }

    if (max_ratio <= 1.0) return 1.0;

    /* SOC/RSOC/StdSOC: sqrt formula, EXP/Power: linear formula */
    if (kind == CONE_KIND_RSOC_PRIMAL || kind == CONE_KIND_RSOC_DUAL ||
        kind == CONE_KIND_STD_SOC_PRIMAL || kind == CONE_KIND_STD_SOC_DUAL) {
        return 1.0 / sqrt(max_ratio);
    } else {
        return 1.0 / max_ratio;
    }
}

/* =============================================================================
 * Section 3: State Management
 * ============================================================================= */

barrier_state_t *create_barrier_state(const barrier_params_t *params, int max_v_dim)
{
    if (!params) return NULL;

    barrier_state_t *state = (barrier_state_t *)calloc(1, sizeof(barrier_state_t));
    if (!state) {
        fprintf(stderr, "[barrier_params] ERROR: failed to allocate barrier_state_t
");
        return NULL;
    }

    /* Quick-access copies from params */
    state->enabled = params->barrier_enabled;
    state->option = params->barrier_option;
    state->verbose = params->barrier_verbose;

    /* Pre-allocate host buffers (max_v_dim + 2 for RSOC: v + s + t) */
    state->max_cone_v_dim = max_v_dim;
    size_t buf_size = (size_t)(max_v_dim + 2) * sizeof(double);
    state->host_cone_block = (double *)malloc(buf_size);
    state->host_cone_grad = (double *)malloc(buf_size);
    state->host_cone_dir = (double *)malloc(buf_size);

    if (!state->host_cone_block || !state->host_cone_grad || !state->host_cone_dir) {
        fprintf(stderr, "[barrier_params] ERROR: failed to allocate host buffers
");
        free(state->host_cone_block);
        free(state->host_cone_grad);
        free(state->host_cone_dir);
        free(state);
        return NULL;
    }

    /* Initialize rho thresholds from params */
    for (int i = 0; i < CONE_KIND_NUM_KINDS; i++) {
        state->rho_threshold[i] = barrier_rho_threshold((cone_kind_t)i, params);
        state->mu_current[i] = params->barrier_mu_init;
    }

    /* Initialize fallback window */
    state->window_size = params->barrier_window_size;
    state->window_pos = 0;
    size_t window_size = (size_t)params->barrier_window_size * CONE_KIND_NUM_KINDS * sizeof(double);
    state->fallback_window = (double *)calloc(params->barrier_window_size * CONE_KIND_NUM_KINDS, sizeof(double));
    if (!state->fallback_window) {
        fprintf(stderr, "[barrier_params] WARNING: failed to allocate fallback window
");
    }

    /* GPU buffers not allocated yet */
    state->gpu_buffers_allocated = false;

    return state;
}

void free_barrier_state(barrier_state_t *state)
{
    if (!state) return;

    free(state->host_cone_block);
    free(state->host_cone_grad);
    free(state->host_cone_dir);
    free(state->fallback_window);

    if (state->gpu_buffers_allocated) {
        free_barrier_gpu_buffers(state);
    }

    free(state);
}

void reset_barrier_state(barrier_state_t *state, const barrier_params_t *params)
{
    if (!state || !params) return;

    state->enabled = params->barrier_enabled;
    state->option = params->barrier_option;
    state->verbose = params->barrier_verbose;

    state->trigger_count_total = 0;
    state->fallback_count_total = 0;
    state->nan_reject_count = 0;
    state->step_norm_reject_count = 0;
    state->primal_res_reject_count = 0;

    for (int i = 0; i < CONE_KIND_NUM_KINDS; i++) {
        state->trigger_count[i] = 0;
        state->mu_current[i] = params->barrier_mu_init;
        state->stagnation_count[i] = 0;
        state->rho_threshold[i] = barrier_rho_threshold((cone_kind_t)i, params);
    }

    state->window_pos = 0;
    if (state->fallback_window) {
        memset(state->fallback_window, 0,
               (size_t)state->window_size * CONE_KIND_NUM_KINDS * sizeof(double));
    }
}

void barrier_state_add_fallback(barrier_state_t *state, cone_kind_t kind, int accepted)
{
    if (!state || !state->fallback_window) return;

    int idx = kind * state->window_size + state->window_pos;
    state->fallback_window[idx] = accepted ? 0.0 : 1.0; /* 1 = fallback, 0 = accept */

    state->window_pos = (state->window_pos + 1) % state->window_size;
}

double barrier_state_fallback_rate(barrier_state_t *state, cone_kind_t kind)
{
    if (!state || !state->fallback_window || state->window_size == 0) return 0.0;

    int start = kind * state->window_size;
    int count = 0;
    int fallbacks = 0;

    for (int i = 0; i < state->window_size; i++) {
        double val = state->fallback_window[start + i];
        if (val != 0.0 || i < state->window_pos) {  /* Valid entry */
            count++;
            if (val > 0.5) fallbacks++;
        }
    }

    if (count == 0) return 0.0;
    return (double)fallbacks / (double)count;
}

/*
 * L3 Adaptive Threshold Adjustment (PDCS Stage 5)
 *
 * If fallback_rate > high: relax threshold (barrier too aggressive)
 * If fallback_rate < low: tighten threshold (barrier too conservative)
 */
void barrier_state_adapt_threshold(barrier_state_t *state, barrier_params_t *params, cone_kind_t kind)
{
    if (!state || !params || !params->barrier_adaptive_threshold) return;

    double fallback_rate = barrier_state_fallback_rate(state, kind);
    double *rho = &state->rho_threshold[kind];

    if (fallback_rate > params->barrier_fallback_high) {
        /* Too many fallbacks: relax threshold */
        double factor = 1.5;
        double new_rho = (*rho) * factor;
        /* Cap at 1.0 */
        if (new_rho > 1.0) new_rho = 1.0;
        *rho = new_rho;
        if (state->verbose >= 2) {
            fprintf(stderr, "[barrier] L3: kind=%s, fallback_rate=%.3f > %.3f, relax rho to %.4f
",
                    cone_kind_to_string(kind), fallback_rate,
                    params->barrier_fallback_high, *rho);
        }
    } else if (fallback_rate < params->barrier_fallback_low) {
        /* Too few fallbacks: tighten threshold */
        double factor = 0.67;
        double new_rho = (*rho) * factor;
        /* Minimum at 0.01 */
        if (new_rho < 0.01) new_rho = 0.01;
        *rho = new_rho;
        if (state->verbose >= 2) {
            fprintf(stderr, "[barrier] L3: kind=%s, fallback_rate=%.3f < %.3f, tighten rho to %.4f
",
                    cone_kind_to_string(kind), fallback_rate,
                    params->barrier_fallback_low, *rho);
        }
    }
}

/* =============================================================================
 * Section 4: Utility Functions
 * ============================================================================= */

const char *cone_kind_to_string(cone_kind_t kind)
{
    switch (kind) {
        case CONE_KIND_RSOC_PRIMAL:    return "RSOC_primal";
        case CONE_KIND_RSOC_DUAL:       return "RSOC_dual";
        case CONE_KIND_STD_SOC_PRIMAL: return "StdSOC_primal";
        case CONE_KIND_STD_SOC_DUAL:   return "StdSOC_dual";
        case CONE_KIND_EXP_PRIMAL:     return "EXP_primal";
        case CONE_KIND_EXP_DUAL:       return "EXP_dual";
        case CONE_KIND_POWER_PRIMAL:   return "Power_primal";
        case CONE_KIND_POWER_DUAL:     return "Power_dual";
        default:                       return "UNKNOWN";
    }
}

const char *trigger_reason_to_string(trigger_reason_t reason)
{
    switch (reason) {
        case TRIGGER_OFF:          return "OFF";
        case TRIGGER_ALWAYS:       return "ALWAYS";
        case TRIGGER_GAP:           return "GAP";
        case TRIGGER_BOUNDARY:      return "BOUNDARY";
        case TRIGGER_FIXED_SLOT:   return "FIXED_SLOT";
        case TRIGGER_NUMERIC:       return "NUMERIC";
        case TRIGGER_SAFETY:        return "SAFETY";
        case TRIGGER_CHECK_SKIP:    return "CHECK_SKIP";
        default:                    return "UNKNOWN";
    }
}

/*
 * Map pdhcg_types.h cone_type_t to our cone_kind_t.
 * PDHCG has no explicit dual cone concept in the types, but since all
 * cones are self-dual (SOC, EXP, Power), we treat primal and dual as
 * identical for barrier purposes. The distinction is only for bookkeeping.
 */
cone_kind_t cone_type_to_cone_kind(cone_type_t type, bool is_dual)
{
    switch (type) {
        case CONE_ROTATED_SOC:
            return is_dual ? CONE_KIND_RSOC_DUAL : CONE_KIND_RSOC_PRIMAL;
        case CONE_STANDARD_SOC:
            return is_dual ? CONE_KIND_STD_SOC_DUAL : CONE_KIND_STD_SOC_PRIMAL;
        case CONE_EXPONENTIAL:
            return is_dual ? CONE_KIND_EXP_DUAL : CONE_KIND_EXP_PRIMAL;
        case CONE_POWER:
            return is_dual ? CONE_KIND_POWER_DUAL : CONE_KIND_POWER_PRIMAL;
        default:
            return CONE_KIND_RSOC_PRIMAL; /* Should not happen */
    }
}

/* =============================================================================
 * Section 5: Parameter Printing
 * ============================================================================= */

void print_barrier_params(const barrier_params_t *params)
{
    if (!params) return;

    printf("  [Barrier Parameters]
");
    printf("    barrier_enabled         : %s
", params->barrier_enabled ? "true" : "false");
    printf("    barrier_option         : %d (%s)
", params->barrier_option,
           params->barrier_option == BARRIER_OPTION_1 ? "pre-Halpern" : "post-Halpern");
    printf("    barrier_mu_strategy    : %d
", params->barrier_mu_strategy);
    printf("    barrier_mu_init        : %.1e
", params->barrier_mu_init);
    printf("    barrier_mu_final       : %.1e
", params->barrier_mu_final);
    printf("    barrier_mu_rho         : %.4f
", params->barrier_mu_rho);
    printf("    soc_rsoc_max_ratio     : %.1f (rho_thresh=%.4f)
",
           params->soc_rsoc_max_ratio,
           1.0 / sqrt(params->soc_rsoc_max_ratio));
    printf("    std_soc_max_ratio      : %.1f (rho_thresh=%.4f)
",
           params->std_soc_max_ratio,
           1.0 / sqrt(params->std_soc_max_ratio));
    printf("    exp_max_ratio          : %.1f (rho_thresh=%.4f)
",
           params->exp_max_ratio, 1.0 / params->exp_max_ratio);
    printf("    power_max_ratio       : %.1f (rho_thresh=%.4f)
",
           params->power_max_ratio, 1.0 / params->power_max_ratio);
    printf("    barrier_max_iter       : %d
", params->barrier_max_iter);
    printf("    barrier_inner_max_iter : %d
", params->barrier_inner_max_iter);
    printf("    barrier_tol            : %.1e
", params->barrier_tol);
    printf("    barrier_check_every    : %d
", params->barrier_check_every);
    printf("    barrier_gap_threshold  : %.1e
", params->barrier_gap_threshold);
    printf("    barrier_adaptive       : %s
", params->barrier_adaptive_threshold ? "true" : "false");
    printf("    barrier_verbose        : %d
", params->barrier_verbose);
}

/* =============================================================================
 * allocate_barrier_gpu_buffers - Allocate device-side buffers for GPU BPGrad path
 * ============================================================================= */
int allocate_barrier_gpu_buffers(barrier_state_t *state, int max_blocks_per_bucket)
{
    if (!state) return -1;
    if (state->gpu_buffers_allocated) {
        if (max_blocks_per_bucket <= state->max_cone_blocks_per_bucket) return 0;
        free_barrier_gpu_buffers(state);
    }

    if (max_blocks_per_bucket < 1) max_blocks_per_bucket = 4096;
    state->max_cone_blocks_per_bucket = max_blocks_per_bucket;

    size_t sz_d = (size_t)max_blocks_per_bucket * sizeof(double);
    size_t sz_i = (size_t)max_blocks_per_bucket * sizeof(int);

    cudaError_t err;
    err = cudaMalloc((void **)&state->dev_rho_out, sz_d);
    if (err != cudaSuccess) goto fail;
    err = cudaMalloc((void **)&state->dev_start_idx_held, sz_i);
    if (err != cudaSuccess) goto fail;
    err = cudaMalloc((void **)&state->dev_v_dim_held, sz_i);
    if (err != cudaSuccess) goto fail;
    err = cudaMalloc((void **)&state->dev_alpha_held, sz_d);
    if (err != cudaSuccess) goto fail;
    err = cudaMalloc((void **)&state->dev_converged, sz_i);
    if (err != cudaSuccess) goto fail;
    err = cudaMalloc((void **)&state->dev_cone_block, sz_d);
    if (err != cudaSuccess) goto fail;
    err = cudaMalloc((void **)&state->dev_cone_grad, sz_d);
    if (err != cudaSuccess) goto fail;

    state->gpu_buffers_allocated = true;
    return 0;

fail:
    fprintf(stderr, "[barrier_params] cudaMalloc failed: %s\n",
            cudaGetErrorString(err));
    free_barrier_gpu_buffers(state);
    return -1;
}

void free_barrier_gpu_buffers(barrier_state_t *state)
{
    if (!state) return;
    if (state->dev_rho_out)        { cudaFree(state->dev_rho_out);        state->dev_rho_out = NULL; }
    if (state->dev_start_idx_held) { cudaFree(state->dev_start_idx_held); state->dev_start_idx_held = NULL; }
    if (state->dev_v_dim_held)     { cudaFree(state->dev_v_dim_held);     state->dev_v_dim_held = NULL; }
    if (state->dev_alpha_held)     { cudaFree(state->dev_alpha_held);     state->dev_alpha_held = NULL; }
    if (state->dev_converged)      { cudaFree(state->dev_converged);      state->dev_converged = NULL; }
    if (state->dev_cone_block)    { cudaFree(state->dev_cone_block);    state->dev_cone_block = NULL; }
    if (state->dev_cone_grad)     { cudaFree(state->dev_cone_grad);     state->dev_cone_grad = NULL; }
    state->gpu_buffers_allocated = false;
}

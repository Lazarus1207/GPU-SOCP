/*
================================================================================
barrier_module.c - BPGrad Subproblem Solver Implementation (4 Cones)
================================================================================
*/

#include "barrier_module.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* =============================================================================
 * Section 1: Host-Side Euclidean Projection (4 Cones)
 *
 * These mirror the GPU kernels in pdhcg_conic_kernels.cu but run on CPU.
 * We use the same algorithms to ensure correctness consistency.
 * ============================================================================= */

/* RSOC: x = (v[0..k-1], s, t) */
static void host_project_rsoc(
    int k,
    double *x,
    const double *d,
    double *warm_start)
{
    const double INV_SQRT2 = 0.7071067811865475;

    if (k < 1) return;

    double *v = x;
    double *sptr = x + k;
    double *tptr = x + k + 1;
    double s = *sptr;
    double t = *tptr;

    double d_s = d ? d[k] : 1.0;
    double d_t = d ? d[k + 1] : 1.0;
    if (d_s <= 0.0) d_s = 1.0;
    if (d_t <= 0.0) d_t = 1.0;
    double d_st = sqrt(d_s * d_t);

    /* Transform to (w, z) = ((s-t)/∈2, (s+t)/∈2) */
    double w = (s - t) * INV_SQRT2;
    double z = (s + t) * INV_SQRT2;

    /* Check diag uniformity */
    bool diag_uniform = true;
    for (int m = 0; m < k && diag_uniform; m++) {
        double dm = d ? d[m] : 1.0;
        if (dm != d_st) diag_uniform = false;
    }

    if (diag_uniform) {
        double sumsq = w * w;
        for (int m = 0; m < k; m++) sumsq += v[m] * v[m];
        double r = sqrt(sumsq);
        if (r <= z) return;  /* already in cone */
        if (r <= -z) {
            for (int m = 0; m < k; m++) v[m] = 0.0;
            *sptr = 0.0;
            *tptr = 0.0;
            return;
        }
        double scale = (z + r) / (2.0 * r);
        for (int m = 0; m < k; m++) v[m] *= scale;
        double w_new = scale * w;
        double z_new = scale * r;
        *sptr = (z_new + w_new) * INV_SQRT2;
        *tptr = (z_new - w_new) * INV_SQRT2;
        return;
    }

    /* Non-uniform case: use bisection (simplified version of GPU kernel) */
    /* Use warm-start if available */
    double warm_lam = warm_start ? *warm_start : 0.0;
    (void)warm_lam;

    /* For simplicity in fallback path: just clamp to feasible region */
    /* and run a few bisection iterations */

    /* Compute r_pos and r_inv */
    double r_inv_sq = w * w;
    double r_pos_sq = w * w;
    for (int m = 0; m < k; m++) {
        double dh = (d ? d[m] : 1.0) / d_st;
        double v_m = v[m];
        r_inv_sq += (v_m / dh) * (v_m / dh);
        r_pos_sq += (v_m * dh) * (v_m * dh);
    }
    double r_inv = sqrt(r_inv_sq);
    if (r_inv <= z) return;

    double r_pos = sqrt(r_pos_sq);
    if (r_pos <= -z) {
        for (int m = 0; m < k; m++) v[m] = 0.0;
        *sptr = 0.0;
        *tptr = 0.0;
        return;
    }

    /* Bisection on lambda in (0, 1) */
    double lo = 0.0, hi = 0.5;
    bool z_pos = (z > 0.0);
    if (!z_pos) {
        lo = 0.5 + 1e-14;
        hi = 1.0;
    }

    for (int it = 0; it < 60; it++) {
        double lam = 0.5 * (lo + hi);
        double sum = 0.0;
        for (int m = 0; m < k; m++) {
            double dh = (d ? d[m] : 1.0) / d_st;
            double dh2 = dh * dh;
            double tt = v[m] * dh / (dh2 + 2.0 * lam);
            sum += tt * tt;
        }
        double tw = w / (1.0 + 2.0 * lam);
        sum += tw * tw;
        double zt = z / (1.0 - 2.0 * lam);
        double f = sum - zt * zt;
        if (fabs(f) < 1e-12) {
            double w_new = w / (1.0 + 2.0 * lam);
            double z_new = z / (1.0 - 2.0 * lam);
            for (int m = 0; m < k; m++) {
                double dh = (d ? d[m] : 1.0) / d_st;
                double dh2 = dh * dh;
                v[m] = v[m] * dh2 / (dh2 + 2.0 * lam);
            }
            *sptr = (z_new + w_new) * INV_SQRT2;
            *tptr = (z_new - w_new) * INV_SQRT2;
            if (warm_start) *warm_start = lam;
            return;
        }
        if (z_pos) {
            if (f > 0.0) lo = lam; else hi = lam;
        } else {
            if (f > 0.0) hi = lam; else lo = lam;
        }
    }

    /* Use final midpoint as best estimate */
    double lam = 0.5 * (lo + hi);
    double w_new = w / (1.0 + 2.0 * lam);
    double z_new = z / (1.0 - 2.0 * lam);
    for (int m = 0; m < k; m++) {
        double dh = (d ? d[m] : 1.0) / d_st;
        double dh2 = dh * dh;
        v[m] = v[m] * dh2 / (dh2 + 2.0 * lam);
    }
    *sptr = (z_new + w_new) * INV_SQRT2;
    *tptr = (z_new - w_new) * INV_SQRT2;
    if (warm_start) *warm_start = lam;
}

/* StdSOC: PDHCG internal layout x = [v0..v_{k-1}, w, z], total size = k + 2.
 *
 * Cone: Q = {(w, z, v) : ||(v, w)|| <= z }, z >= 0.
 *
 * This mirrors project_standard_soc_kernel() in pdhcg_conic_kernels.cu.
 * With uniform rescaling (the case the barrier module actually runs in --
 * d == NULL, or all scaling factors equal), the Euclidean projection is the
 * well-known radial one:
 *      r = ||(v, w)||,   scale = (z + r) / (2 r)
 *      (v, w, z)  <-  (scale*v, scale*w, scale*r)
 * Note the new z is scale*r == (z + r)/2, i.e. the new RADIUS.  Writing
 * scale*z instead leaves the point outside the cone.
 *
 * For non-uniform scaling PDHCG bisects a Lagrangian multiplier; we do the
 * same so the host and device paths agree.
 */
static void host_project_std_soc(int k, double *x, const double *d)
{
    if (k < 1) return;

    double *v = x;            /* v[0..k-1] */
    double *wptr = x + k;
    double *zptr = x + k + 1;

    const double d_z = (d && d[k + 1] > 0.0) ? d[k + 1] : 1.0;
    const double d_w = (d && d[k]     > 0.0) ? d[k]     : 1.0;
    const double dhat_w = d_w / d_z;
    const double dhat_w2 = dhat_w * dhat_w;

    double w = *wptr;
    double z = *zptr;

    /* ---- uniform fast path (also the d == NULL path) ---- */
    bool uniform = (dhat_w == 1.0);
    for (int m = 0; m < k && uniform; m++) {
        double dm = d ? d[m] : 1.0;
        if (!(dm > 0.0) || dm != d_z) uniform = false;
    }

    if (uniform) {
        double sumsq = w * w;
        for (int m = 0; m < k; m++) sumsq += v[m] * v[m];
        double r = sqrt(sumsq);
        if (r <= z) return;                       /* already in the cone */
        if (r <= -z) {                            /* z < 0 -> apex */
            for (int m = 0; m < k; m++) v[m] = 0.0;
            *wptr = 0.0;
            *zptr = 0.0;
            return;
        }
        double sc = (z + r) / (2.0 * r);
        for (int m = 0; m < k; m++) v[m] *= sc;
        *wptr = sc * w;
        *zptr = sc * r;                            /* new radius (z + r)/2 */
        return;
    }

    /* ---- general rescaled path: PDHCG's bisection in lambda ---- */
    /* Constraint in logical coords (V=v/h, W=w/dhat_w, Z=z):
     *     sum_m V_m^2 + W^2 <= Z^2
     * Solve   sum_m (v_m*h_m/(h_m^2+2l))^2 + (w*dhat_w/(dhat_w2+2l))^2
     *             - (z/(1-2l))^2 = 0                                */
    double r_inv_sq = (w / dhat_w) * (w / dhat_w);
    for (int m = 0; m < k; m++) {
        double h = d ? d[m] : 1.0;
        h = (h > 0.0 ? h : 1.0) / d_z;
        double y = v[m] / h;
        r_inv_sq += y * y;
    }
    if (sqrt(r_inv_sq) <= z) return;               /* feasible, nothing to do */

    double lo, hi;
    if (z > 0.0) {
        lo = 0.0;
        hi = 0.5 - 1e-14;
    } else {
        lo = 0.5 + 1e-14;
        hi = 1.0;
        for (int it = 0; it < 60; it++) {
            double s = 0.0;
            for (int m = 0; m < k; m++) {
                double h = d ? d[m] : 1.0;
                h = (h > 0.0 ? h : 1.0) / d_z;
                double t = v[m] * h / (h * h + 2.0 * hi);
                s += t * t;
            }
            double tw = w * dhat_w / (dhat_w2 + 2.0 * hi);
            s += tw * tw;
            double zt = z / (1.0 - 2.0 * hi);
            if (s - zt * zt > 0.0) break;
            lo = hi;
            hi *= 2.0;
        }
    }

    for (int it = 0; it < 60; it++) {
        double lam = 0.5 * (lo + hi);
        double s = 0.0;
        for (int m = 0; m < k; m++) {
            double h = d ? d[m] : 1.0;
            h = (h > 0.0 ? h : 1.0) / d_z;
            double h2 = h * h;
            double t = v[m] * h / (h2 + 2.0 * lam);
            s += t * t;
        }
        double tw = w * dhat_w / (dhat_w2 + 2.0 * lam);
        s += tw * tw;
        double zt = z / (1.0 - 2.0 * lam);
        double f = s - zt * zt;
        if (z > 0.0) { if (f > 0.0) lo = lam; else hi = lam; }
        else         { if (f > 0.0) hi = lam; else lo = lam; }
        if ((hi - lo) / (1.0 + hi + lo) < 1e-13) break;
    }

    double lam = 0.5 * (lo + hi);
    *zptr = z / (1.0 - 2.0 * lam);
    *wptr = w * dhat_w2 / (dhat_w2 + 2.0 * lam);
    for (int m = 0; m < k; m++) {
        double h = d ? d[m] : 1.0;
        h = (h > 0.0 ? h : 1.0) / d_z;
        v[m] *= (h * h) / (h * h + 2.0 * lam);
    }
}

/* EXP: x = (x1, x2, x3) */
/* This is a simplified port of project_exp_cone_point from pdhcg_conic_kernels.cu */
static void host_project_exp(double *x, const double *d)
{
    double d1 = d ? d[0] : 1.0;
    double d2 = d ? d[1] : 1.0;
    double d3 = d ? d[2] : 1.0;
    if (d1 <= 0.0) d1 = 1.0;
    if (d2 <= 0.0) d2 = 1.0;
    if (d3 <= 0.0) d3 = 1.0;

    double r1 = x[0] / d1;
    double r2 = x[1] / d2;
    double r3 = x[2] / d3;

    /* Check if already in cone */
    bool in_cone = (r2 > 1e-14 && r3 > 1e-14);
    if (in_cone) {
        double exp_r3r2 = (r3 / r2 > 50.0) ? INFINITY : exp(r3 / r2);
        if (isfinite(exp_r3r2) && r1 >= r2 * exp_r3r2) {
            /* Already in cone */
            return;
        }
    }

    /* Fixed y = r2: project (r1, r3) onto the 2D exp curve */
    if (r2 <= 1e-14) {
        /* y near 0: x1 <= 0 and x3 >= 0 */
        x[0] = (r1 < 0.0 ? r1 : 0.0) * d1;
        x[1] = 1e-14 * d2;
        x[2] = (r3 > 0.0 ? r3 : 0.0) * d3;
        return;
    }

    /* General case: project (r1, r3) onto the 2D exp curve
     *   r1 = r2 * exp(s),  r3 = r2 * s
     * Solve for s via Newton's method, then reconstruct.
     */
    double s = r3 / r2;
    double target = r1 / r2;

    /* Initial guess: exp(s) = target and s = r3/r2 are inconsistent in
     * general, so combine both in log space. */
    double new_s;
    if (target > 0.0 && s > 0.0) {
        new_s = log(target) - log(s + 1e-300);
    } else if (target > 0.0) {
        new_s = log(target);
    } else {
        new_s = 0.0;
    }

    /* Newton refinement */
    for (int iter = 0; iter < 50; iter++) {
        double exp_new_s = (new_s > 50.0) ? INFINITY :
                          ((new_s < -50.0) ? 0.0 : exp(new_s));
        if (!isfinite(exp_new_s)) break;

        /* f(s) = r2 * exp(s) - r3 * s - r1 */
        double f = r2 * exp_new_s - r3 * new_s - r1;
        /* f'(s) = r2 * exp(s) - r3 */
        double df = r2 * exp_new_s - r3;
        if (fabs(df) < 1e-30) break;
        double delta = f / df;
        new_s -= delta;
        if (fabs(delta) < 1e-12) break;
    }

    /* Clamp new_s to ensure feasibility */
    if (!isfinite(new_s)) new_s = s;
    if (new_s < 0.0) new_s = 0.0;

    /* Reconstruct: x1 = x2 * exp(s), x3 = x2 * s */
    double exp_ns = (new_s > 50.0) ? INFINITY :
                    ((new_s < -50.0) ? 0.0 : exp(new_s));
    if (!isfinite(exp_ns)) exp_ns = INFINITY;

    x[0] = r2 * exp_ns * d1;
    x[1] = r2 * d2;
    x[2] = r2 * new_s * d3;

    /* Final feasibility check: x1 must be finite */
    if (!isfinite(x[0])) {
        x[0] = (r1 > 0.0 ? r1 : 1.0) * d1;
        x[1] = 1.0 * d2;
        x[2] = 0.0 * d3;
    }
}

/* Power: x = (x, y, z) */
/* Simplified projection: just clamp to feasible region */
static void host_project_power(double *x, const double *d, double alpha)
{
    double dx = d ? d[0] : 1.0;
    double dy = d ? d[1] : 1.0;
    double dz = d ? d[2] : 1.0;
    if (dx <= 0.0) dx = 1.0;
    if (dy <= 0.0) dy = 1.0;
    if (dz <= 0.0) dz = 1.0;

    double xv = x[0] / dx;
    double yv = x[1] / dy;
    double zv = x[2] / dz;

    /* Clamp x, y to non-negative */
    if (xv < 0.0) xv = 0.0;
    if (yv < 0.0) yv = 0.0;

    /* Compute h = x^alpha * y^(1-alpha) */
    double h;
    if (xv < 1e-300 || yv < 1e-300) {
        h = 0.0;
    } else {
        double log_h = alpha * log(xv) + (1.0 - alpha) * log(yv);
        if (log_h > 700.0) {
            h = INFINITY;
        } else if (log_h < -700.0) {
            h = 0.0;
        } else {
            h = exp(log_h);
        }
    }

    /* If |z| > h, need to clamp */
    double abs_z = fabs(zv);
    if (abs_z > h) {
        /* Simple approach: scale down z */
        double scale = h / abs_z;
        zv *= scale;
    }

    x[0] = xv * dx;
    x[1] = yv * dy;
    x[2] = zv * dz;
}

void host_cone_project(
    cone_type_t cone_type,
    int v_dim,
    double *x,
    const double *d,
    double alpha,
    double *warm_start)
{
    switch (cone_type) {
        case CONE_ROTATED_SOC:
            host_project_rsoc(v_dim, x, d, warm_start);
            break;
        case CONE_STANDARD_SOC:
            host_project_std_soc(v_dim, x, d);
            break;
        case CONE_EXPONENTIAL:
            host_project_exp(x, d);
            break;
        case CONE_POWER:
            host_project_power(x, d, alpha);
            break;
        default:
            break;
    }
}

/* =============================================================================
 * Interior re-seeding (controlled margin)
 * =============================================================================
 *
 * If a point arrives exactly ON the cone boundary, phi = -log(inner) has a
 * singular gradient and every solver degenerates to a bare projection.  That
 * is precisely the situation the barrier exists to repair, so we must not
 * give up here.
 *
 * A multiplicative nudge cannot fix it: after projecting an infeasible point
 * the slack is already at machine zero, so scaling by (1+eps) leaves it at
 * machine zero.  Instead we shrink the *lateral* part of the block by
 * beta = sqrt(1 - delta), which opens a deterministic margin:
 *
 *     StdSOC:  inner = z^2 - ||(v,w)||^2  ->  z^2 - beta^2 ||(v,w)||^2
 *              = delta * z^2          on the boundary
 *     RSOC:    inner = 2 s t - ||v||^2  ->  2 s t - beta^2 ||v||^2
 *              = delta * 2 s t        on the boundary
 *
 * The resulting point is strictly feasible with rho = sqrt(delta), and the
 * relative displacement is only beta = 1 - delta/2, so PDHCG's iterate is
 * perturbed far below solver tolerance while the barrier gradient becomes
 * finite and the inward push can do its work from there.
 */
#define BARRIER_RESEED_DELTA 1e-10

static void stdsoc_reseed_interior(int k, double *x, const double *d)
{
    const double beta = sqrt(1.0 - BARRIER_RESEED_DELTA);

    /* shrink laterally in logical coordinates, keep z */
    double d_z = d ? d[k + 1] : 1.0;
    if (!(d_z > 0.0)) d_z = 1.0;
    double d_w = d ? d[k] : 1.0;
    if (!(d_w > 0.0)) d_w = 1.0;
    double dhat_w = d_w / d_z;

    for (int m = 0; m < k; m++) {
        double dm = d ? d[m] : 1.0;
        if (!(dm > 0.0)) dm = 1.0;
        x[m] *= beta * (dm / d_z);
    }
    x[k] *= beta * dhat_w;
    /* z is left untouched -- it defines the margin */
}

static void rsoc_reseed_interior(int k, double *x, const double *d)
{
    const double beta = sqrt(1.0 - BARRIER_RESEED_DELTA);
    for (int m = 0; m < k; m++) {
        double dm = d ? d[m] : 1.0;
        if (!(dm > 0.0)) dm = 1.0;
        x[m] *= beta * dm;
    }
    /* s and t stay put: they carry the 2 s t term that opens the margin */
}

/* =============================================================================
 * Section 2: Cone-specific feasibility / projection check
 * ============================================================================= */

boundary_metric_t check_cone_feasibility(
    cone_type_t cone_type,
    int v_dim,
    const double *x,
    const double *d,
    double alpha)
{
    return boundary_metric_generic(cone_type, v_dim, x, d, alpha, false);
}

/* =============================================================================
 * Section 3: RSOC BPGrad
 *
 * RSOC: x = (v, s, t), τ(x) = -log(2st - ||v||²)
 * ∇τ(x) = [2v/(2st-||v||²), -2t/(...), -2s/(...)]
 * ============================================================================= */

bpgrad_stats_t bpgrad_solve_rsoc(
    int k,
    double *x,
    const double *g,
    const double *d,
    double tau,
    double mu,
    const barrier_params_t *params)
{
    bpgrad_stats_t stats = {0, 0, false, false, INFINITY, mu, 0.0, 0.0};

    int n = k + 2;
    double *v = x;
    double *sptr = x + k;
    double *tptr = x + k + 1;

    /* Save the starting point as the proximal centre x_k.  The BPGrad step is
     *     x* = argmin { (1/2tau)||x - x_k||^2 + <g,x> + mu*phi(x) }
     * so x_k must be kept separate from the iterate x[]. */
    double *x_k = (double *)malloc((size_t)n * sizeof(double));
    if (!x_k) {
        host_project_rsoc(k, x, d, NULL);
        stats.fallback_used = true;
        return stats;
    }
    memcpy(x_k, x, (size_t)n * sizeof(double));

    /* Compute initial ρ */
    boundary_metric_t bm = boundary_metric_rsoc(k, x, d);
    stats.rho_initial = bm.rho;

    if (!bm.feasible) {
        /* Project to cone first */
        host_project_rsoc(k, x, d, NULL);
        memcpy(x_k, x, (size_t)n * sizeof(double));
        bm = boundary_metric_rsoc(k, x, d);
        if (!bm.feasible) {
            stats.fallback_used = true;
            free(x_k);
            return stats;
        }
    }

    double tau_inv = 1.0 / tau;
    if (!(tau_inv > 0.0) || !isfinite(tau_inv)) tau_inv = 1.0;

    for (int outer = 0; outer < params->barrier_max_iter; outer++) {
        stats.outer_iter = outer + 1;

        double s = *sptr;
        double t = *tptr;
        double norm_v_sq = 0.0;
        for (int i = 0; i < k; i++) norm_v_sq += v[i] * v[i];
        double inner = 2.0 * s * t - norm_v_sq;

        if (inner <= 1e-12) {
            /* Sitting on the RSOC boundary makes grad(phi) singular; move
             * strictly inside rather than degrading to a projection. */
            rsoc_reseed_interior(k, x, d);
            free(x_k);
            return stats;
        }

        /* Compute the gradient of
         *     F(x) = (1/2*tau)*||x - x_k||^2 + <g,x> + mu*phi(x)
         * i.e.  grad F = (x - x_k)/tau + g + mu*grad(phi),  with
         *     grad(phi) = [ 2v/inner, -2t/inner, -2s/inner ].
         *
         * x_k is the *original* iterate held in x_k[]; x[] is the current
         * iterate.  On the first outer iteration x == x_k, so the proximal
         * term is zero there, but it becomes non-zero afterwards and MUST be
         * kept -- otherwise the solve silently degenerates into a pure
         * barrier-gradient flow that can drift far from the starting point. */
        double inv_inner = 1.0 / inner;
        double *grad = (double *)malloc(n * sizeof(double));
        if (!grad) {
            stats.fallback_used = true;
            host_project_rsoc(k, x, d, NULL);
            free(x_k);
            return stats;
        }

        for (int i = 0; i < k; i++) {
            grad[i] = (x[i] - x_k[i]) * tau_inv + g[i] + mu * (2.0 * v[i] * inv_inner);
        }
        grad[k]     = (x[k]     - x_k[k])     * tau_inv + g[k]     + mu * (-2.0 * t * inv_inner);
        grad[k + 1] = (x[k + 1] - x_k[k + 1]) * tau_inv + g[k + 1] + mu * (-2.0 * s * inv_inner);

        double grad_norm = 0.0;
        for (int i = 0; i < n; i++) grad_norm += grad[i] * grad[i];
        grad_norm = sqrt(grad_norm);
        stats.final_residual = grad_norm;

        if (grad_norm < 1e-12) {
            stats.converged = true;
            free(grad);
            break;
        }

        /* F(x) = (1/2*tau)*||x - x_k||^2 + <g,x> + mu*phi(x) */
        double dx_sq = 0.0;
        for (int i = 0; i < n; i++) {
            double dx = x[i] - x_k[i];
            dx_sq += dx * dx;
        }
        double F_x = 0.5 * tau_inv * dx_sq + mu * (-log(inner));

        double alpha_ls = params->barrier_ls_alpha0;
        bool ls_success = false;

        double *x_trial = (double *)malloc(n * sizeof(double));
        if (!x_trial) {
            free(grad);
            stats.fallback_used = true;
            host_project_rsoc(k, x, d, NULL);
            free(x_k);
            return stats;
        }

        for (int ls = 0; ls < params->barrier_inner_max_iter; ls++) {
            stats.inner_iter++;

            /* Trial point: x_trial = x - alpha * grad, projected to cone */
            for (int i = 0; i < n; i++) x_trial[i] = x[i] - alpha_ls * grad[i];
            host_project_rsoc(k, x_trial, d, NULL);

            /* Check feasibility of trial */
            double trial_inner = 2.0 * x_trial[k] * x_trial[k + 1];
            for (int i = 0; i < k; i++) trial_inner -= x_trial[i] * x_trial[i];

            if (trial_inner <= 1e-12) {
                alpha_ls *= params->barrier_ls_beta;
                continue;
            }

            /* Armijo condition on the full objective (prox term included). */
            double trial_dx_sq = 0.0;
            for (int i = 0; i < n; i++) {
                double dx = x_trial[i] - x_k[i];
                trial_dx_sq += dx * dx;
            }
            double F_trial = 0.5 * tau_inv * trial_dx_sq + mu * (-log(trial_inner));

            double grad_dot_dir = 0.0;
            for (int i = 0; i < n; i++) {
                grad_dot_dir += grad[i] * (x_trial[i] - x[i]);
            }
            double armijo_rhs = params->barrier_ls_c * alpha_ls * grad_dot_dir;

            if (F_trial <= F_x + armijo_rhs) {
                /* Line search succeeded */
                for (int i = 0; i < n; i++) x[i] = x_trial[i];
                ls_success = true;
                break;
            }

            alpha_ls *= params->barrier_ls_beta;
        }

        free(x_trial);
        free(grad);

        if (!ls_success) {
            stats.fallback_used = true;
            host_project_rsoc(k, x, d, NULL);
            free(x_k);
            return stats;
        }

        /* Convergence is judged on the gradient AT THE NEW POINT, matching the
         * CUDA kernel so both backends produce the same iterate. */
        double nv2n = 0.0;
        for (int i = 0; i < k; i++) nv2n += x[i] * x[i];
        double new_inner = 2.0 * x[k] * x[k + 1] - nv2n;
        if (!(new_inner > 1e-12)) {
            rsoc_reseed_interior(k, x, d);
            free(x_k);
            return stats;
        }
        {
            double ninv = 1.0 / new_inner;
            double rnorm = 0.0;
            for (int i = 0; i < k; i++) {
                double gr = (x[i] - x_k[i]) * tau_inv + mu * (2.0 * x[i] * ninv);
                rnorm += gr * gr;
            }
            double gr = (x[k] - x_k[k]) * tau_inv + mu * (-2.0 * x[k + 1] * ninv);
            rnorm += gr * gr;
            gr = (x[k + 1] - x_k[k + 1]) * tau_inv + mu * (-2.0 * x[k] * ninv);
            rnorm += gr * gr;
            rnorm = sqrt(rnorm);
            stats.final_residual = rnorm;

            if (rnorm < params->barrier_tol) {
                stats.converged = true;
                break;
            }
        }
    }

    /* Final ρ */
    bm = boundary_metric_rsoc(k, x, d);
    stats.rho_final = bm.rho;
    free(x_k);
    return stats;
}

/* =============================================================================
 * Section 4: StdSOC BPGrad
 *
 * PDHCG internal layout: x = [v0..v_{k-1}, w, z]  (total size k + 2)
 * Cone: Q = {(w, z, v) : ||(v, w)|| <= z }, z >= 0
 *
 * Barrier  φ = -log(z² - (||v||² + w²))
 * ∇φ_v = 2 v / inner,  ∇φ_w = 2 w / inner,  ∇φ_z = -2 z / inner
 * ============================================================================= */

bpgrad_stats_t bpgrad_solve_std_soc(
    int k,
    double *x,
    const double *g,
    const double *d,
    double tau,
    double mu,
    const barrier_params_t *params)
{
    bpgrad_stats_t stats = {0, 0, false, false, INFINITY, mu, 0.0, 0.0};

    /* PDHCG internal layout: x = [v0..v_{k-1}, w, z], total size n = k + 2.
     * Cone: Q = {(w, z, v) : ||(v, w)|| <= z }, z >= 0.
     * Everything below therefore works on the (w, z, v) grouping, never on a
     * leading-scalar (t, u) layout. */
    int n = k + 2;
    const double *w_slot = x + k;
    const double *z_slot = x + k + 1;

    boundary_metric_t bm = boundary_metric_std_soc(k, x, d);
    stats.rho_initial = bm.rho;

    if (!(bm.feasible)) {
        host_project_std_soc(k, x, d);
        bm = boundary_metric_std_soc(k, x, d);
        if (!bm.feasible) {
            stats.fallback_used = true;
            return stats;
        }
    }

    /* tau is unused in this quasi-Newton variant (the (x - x_k)/tau term is
     * identically zero because the centering point is the current iterate). */
    (void)tau;

    /* g is likewise intentionally absent.  The quasi-Newton stationarity for
     *   min_x  φ(x) + (1/(2τ))·||x - x_k - τ·g||²
     * expands to  g + (x - x_k - τ·g)/τ + μ·∇φ(x) = 0,  and the τ·g terms
     * cancel exactly, leaving  (x - x_k)/τ + μ·∇φ(x).  So `g` genuinely does
     * not appear in the gradient built below -- this is algebra, not an
     * oversight, and is mirrored exactly in the CUDA kernel. */
    (void)g;

    /* Work buffers sized from k, so arbitrarily large cones are supported.
     * x_k is the proximal centre (the point we were called with); keeping it
     * separate is what makes (x - x_k)/tau non-zero after the first step and
     * what lets this solver reproduce the CUDA kernel's iterates exactly. */
    double *x_k = (double *)malloc((size_t)n * sizeof(double));
    double *grad    = (double *)malloc((size_t)n * sizeof(double));
    double *x_trial = (double *)malloc((size_t)n * sizeof(double));
    if (!x_k || !grad || !x_trial) {
        free(x_k);
        free(grad);
        free(x_trial);
        /* Out of memory: leave x projected & feasible, flag as fallback. */
        stats.fallback_used = true;
        host_project_std_soc(k, x, d);
        return stats;
    }
    memcpy(x_k, x, (size_t)n * sizeof(double));

    double tau_inv = 1.0 / tau;
    if (!(tau_inv > 0.0) || !isfinite(tau_inv)) tau_inv = 1.0;

    /* Index layout inside grad/x_trial: [0..k-1] = v, [k] = w, [k+1] = z. */
    for (int outer = 0; outer < params->barrier_max_iter; outer++) {
        stats.outer_iter = outer + 1;

        /* inner = z^2 - (||v||^2 + w^2) */
        double vsq = 0.0;
        for (int i = 0; i < k; i++) vsq += x[i] * x[i];
        double wv = x[k];
        double zv = x[k + 1];
        double inner = zv * zv - (vsq + wv * wv);

        if (!(inner > 1e-12)) {
            /* On (or numerically at) the boundary: the barrier gradient is
             * singular, so nudge strictly inside and keep solving instead of
             * handing back a plain projection. */
            stdsoc_reseed_interior(k, x, d);
            vsq = 0.0;
            for (int i = 0; i < k; i++) vsq += x[i] * x[i];
            wv = x[k];
            zv = x[k + 1];
            inner = zv * zv - (vsq + wv * wv);
            if (!(inner > 0.0)) {
                stats.fallback_used = true;
                host_project_std_soc(k, x, d);
                free(x_k);
                free(grad);
                free(x_trial);
                return stats;
            }
        }

        /* Gradient of the barrier phi = -log(z^2 - ||(v,w)||^2):
         *   dphi/dz = -2z / inner
         *   dphi/dv_i = 2 v_i / inner
         *   dphi/dw  = 2 w   / inner
         * plus the proximal term (x - x_k)/tau  (g = 0 here). */
        double inv_inner = 1.0 / inner;
        for (int i = 0; i < k; i++) grad[i] = (x[i] - x_k[i]) * tau_inv + mu * (2.0 * x[i] * inv_inner);
        grad[k]     = (x[k]     - x_k[k])     * tau_inv + mu * (2.0 * wv * inv_inner);
        grad[k + 1] = (x[k + 1] - x_k[k + 1]) * tau_inv + mu * (-2.0 * zv * inv_inner);

        double grad_norm = 0.0;
        for (int i = 0; i < n; i++) grad_norm += grad[i] * grad[i];
        grad_norm = sqrt(grad_norm);
        stats.final_residual = grad_norm;

        if (grad_norm < 1e-12) {
            stats.converged = true;
            break;
        }

        /* F(x) = (1/2tau)||x - x_k||^2 + mu*phi(x) */
        double dx2 = 0.0;
        for (int i = 0; i < n; i++) {
            double d = x[i] - x_k[i];
            dx2 += d * d;
        }
        double F_x = 0.5 * tau_inv * dx2 + mu * (-log(inner));

        double alpha_ls = params->barrier_ls_alpha0;
        bool ls_success = false;

        for (int ls = 0; ls < params->barrier_inner_max_iter; ls++) {
            stats.inner_iter++;

            for (int i = 0; i < n; i++) x_trial[i] = x[i] - alpha_ls * grad[i];
            host_project_std_soc(k, x_trial, d);

            /* Trial point is projected, so it is feasible by construction; we
             * still recompute the objective to drive the Armijo test. */
            double t_vs = 0.0;
            for (int i = 0; i < k; i++) t_vs += x_trial[i] * x_trial[i];
            double t_w = x_trial[k];
            double t_z = x_trial[k + 1];
            double trial_inner = t_z * t_z - (t_vs + t_w * t_w);

            if (!(trial_inner > 1e-12)) {
                alpha_ls *= params->barrier_ls_beta;
                continue;
            }

            double F_trial = 0.0;
            {
                double tdx2 = 0.0;
                for (int i = 0; i < n; i++) {
                    double d = x_trial[i] - x_k[i];
                    tdx2 += d * d;
                }
                F_trial = 0.5 * tau_inv * tdx2 + mu * (-log(trial_inner));
            }

            double grad_dot_dir = 0.0;
            for (int i = 0; i < n; i++) grad_dot_dir += grad[i] * (x_trial[i] - x[i]);
            double armijo_rhs = params->barrier_ls_c * alpha_ls * grad_dot_dir;

            if (F_trial <= F_x + armijo_rhs) {
                for (int i = 0; i < n; i++) x[i] = x_trial[i];
                ls_success = true;
                break;
            }

            alpha_ls *= params->barrier_ls_beta;
        }

        if (!ls_success) {
            stats.fallback_used = true;
            host_project_std_soc(k, x, d);
            free(x_k);
            free(grad);
            free(x_trial);
            return stats;
        }

        /* Convergence is judged on the gradient AT THE NEW POINT, matching the
         * CUDA kernel.  Judging it on the gradient we stepped away from makes
         * the two backends stop at different iterates for the same block. */
        double nvsq = 0.0;
        for (int i = 0; i < k; i++) nvsq += x[i] * x[i];
        double new_inner = x[k + 1] * x[k + 1] - (nvsq + x[k] * x[k]);
        if (!(new_inner > 1e-12)) {
            /* The step landed on the boundary: nudge inside and continue. */
            stdsoc_reseed_interior(k, x, d);
            stats.final_residual = INFINITY;
            continue;
        }
        double ninv = 1.0 / new_inner;
        double rnorm = 0.0;
        for (int i = 0; i < k; i++) {
            double gr = (x[i] - x_k[i]) * tau_inv + mu * (2.0 * x[i] * ninv);
            rnorm += gr * gr;
        }
        {
            double gr = (x[k] - x_k[k]) * tau_inv + mu * (2.0 * x[k] * ninv);
            rnorm += gr * gr;
            gr = (x[k + 1] - x_k[k + 1]) * tau_inv + mu * (-2.0 * x[k + 1] * ninv);
            rnorm += gr * gr;
        }
        rnorm = sqrt(rnorm);
        stats.final_residual = rnorm;

        if (rnorm < params->barrier_tol) {
            stats.converged = true;
            break;
        }
    }

    bm = boundary_metric_std_soc(k, x, d);
    stats.rho_final = bm.rho;
    (void)w_slot;
    (void)z_slot;
    free(x_k);
    free(grad);
    free(x_trial);
    return stats;
}

/* =============================================================================
 * Section 5: EXP BPGrad
 *
 * EXP: x = (x1, x2, x3), τ(x) = -log(x2) - log(x3) - log(slack)
 * where slack = x1 - x2 * exp(x3/x2)
 *
 * Hessian is diagonal (PDCS exp_proj analysis), so Newton step is direct.
 * ============================================================================= */

bpgrad_stats_t bpgrad_solve_exp(
    double *x,
    const double *g,
    const double *d,
    double tau,
    double mu,
    const barrier_params_t *params)
{
    bpgrad_stats_t stats = {0, 0, false, false, INFINITY, mu, 0.0, 0.0};

    boundary_metric_t bm = boundary_metric_exp(x, d);
    stats.rho_initial = bm.rho;

    if (!bm.feasible) {
        host_project_exp(x, d);
        bm = boundary_metric_exp(x, d);
        if (!bm.feasible) {
            stats.fallback_used = true;
            return stats;
        }
    }

    /* tau is unused in this quasi-Newton variant (see bpgrad_solve_std_soc). */
    (void)tau;

    for (int outer = 0; outer < params->barrier_max_iter; outer++) {
        stats.outer_iter = outer + 1;

        double x1 = x[0], x2 = x[1], x3 = x[2];
        double r = x3 / x2;
        if (fabs(r) > 50.0) {
            stats.fallback_used = true;
            host_project_exp(x, d);
            return stats;
        }

        double exp_r = exp(r);
        double s = x1 - x2 * exp_r;

        if (x2 <= 1e-12 || x3 <= 1e-12 || s <= 1e-12) {
            stats.fallback_used = true;
            host_project_exp(x, d);
            return stats;
        }

        /* Gradient of barrier: grad(phi) = [-1/s, -1/x2 + exp(r)*(1+r)/s, -1/x3 + exp(r)*r/(x2*s)]
         * Descent direction: d = (x - x_k)/tau + g + mu * grad(phi)
         * For first iteration: x = x_k so first term is 0.
         */
        double inv_s = 1.0 / s;
        double inv_x2 = 1.0 / x2;
        double inv_x3 = 1.0 / x3;

        double grad[3];
        grad[0] = g[0] + mu * (-inv_s);
        grad[1] = g[1] + mu * (-inv_x2 + exp_r * (1.0 + r) * inv_s);
        grad[2] = g[2] + mu * (-inv_x3 + exp_r * r / (x2 * s));

        double grad_norm = sqrt(grad[0]*grad[0] + grad[1]*grad[1] + grad[2]*grad[2]);
        stats.final_residual = grad_norm;

        if (grad_norm < 1e-12) {
            stats.converged = true;
            break;
        }

        /* For EXP, take Newton step with diagonal Hessian approximation */
        /* Hessian diag: H_ii = mu * d²(phi)/dx_i²
         *   d²(phi)/dx1² = 1/s²
         *   d²(phi)/dx2² ∈ 1/x2² + exp(r)²(1+r)²/s² + higher order
         *   d²(phi)/dx3² ∈ 1/x3² + exp(r)²r²/(x2²s²) + higher order
         * For simplicity, use small step + projection
         */

        double alpha_ls = params->barrier_ls_alpha0;
        bool ls_success = false;

        /* F(x) = <g,x> + mu * (-log(x2) - log(x3) - log(s)) */
        double F_x = g[0]*x1 + g[1]*x2 + g[2]*x3;
        F_x += mu * (-log(x2) - log(x3) - log(s));

        for (int ls = 0; ls < params->barrier_inner_max_iter; ls++) {
            stats.inner_iter++;

            double x_trial[3];
            x_trial[0] = x1 - alpha_ls * grad[0];
            x_trial[1] = x2 - alpha_ls * grad[1];
            x_trial[2] = x3 - alpha_ls * grad[2];

            /* Ensure strictly positive before projection */
            if (x_trial[1] < 1e-14) x_trial[1] = 1e-14;
            if (x_trial[2] < 1e-14) x_trial[2] = 1e-14;

            host_project_exp(x_trial, d);

            double tx1 = x_trial[0], tx2 = x_trial[1], tx3 = x_trial[2];
            double tr = tx3 / tx2;
            if (fabs(tr) > 50.0) {
                alpha_ls *= params->barrier_ls_beta;
                continue;
            }
            double t_exp_r = exp(tr);
            double ts = tx1 - tx2 * t_exp_r;

            if (ts <= 1e-12 || tx2 <= 1e-12 || tx3 <= 1e-12) {
                alpha_ls *= params->barrier_ls_beta;
                continue;
            }

            double F_trial = g[0]*tx1 + g[1]*tx2 + g[2]*tx3;
            F_trial += mu * (-log(tx2) - log(tx3) - log(ts));

            double grad_dot_dir = grad[0]*(x_trial[0]-x1) + grad[1]*(x_trial[1]-x2) + grad[2]*(x_trial[2]-x3);
            double armijo_rhs = params->barrier_ls_c * alpha_ls * grad_dot_dir;

            if (F_trial <= F_x + armijo_rhs) {
                x[0] = tx1; x[1] = tx2; x[2] = tx3;
                ls_success = true;
                break;
            }

            alpha_ls *= params->barrier_ls_beta;
        }

        if (!ls_success) {
            stats.fallback_used = true;
            host_project_exp(x, d);
            return stats;
        }

        bm = boundary_metric_exp(x, d);
        if (bm.feasible && fabs(stats.final_residual) < params->barrier_tol) {
            stats.converged = true;
            break;
        }
    }

    bm = boundary_metric_exp(x, d);
    stats.rho_final = bm.rho;
    return stats;
}

/* =============================================================================
 * Section 6: Power BPGrad
 *
 * Power: x = (x, y, z), τ(x) = -α·log(x) - (1-α)·log(y) - log(slack)
 * where slack = x^α * y^(1-α) - |z|
 *
 * Hessian is 3x3 (not diagonal), but we use a quasi-Newton approach
 * for simplicity in the host implementation.
 * ============================================================================= */

bpgrad_stats_t bpgrad_solve_power(
    double *x,
    const double *g,
    const double *d,
    double alpha,
    double tau,
    double mu,
    const barrier_params_t *params)
{
    bpgrad_stats_t stats = {0, 0, false, false, INFINITY, mu, 0.0, 0.0};

    boundary_metric_t bm = boundary_metric_power(x, alpha, d);
    stats.rho_initial = bm.rho;

    if (!bm.feasible) {
        host_project_power(x, d, alpha);
        bm = boundary_metric_power(x, alpha, d);
        if (!bm.feasible) {
            stats.fallback_used = true;
            return stats;
        }
    }

    /* tau is unused in this quasi-Newton variant (see bpgrad_solve_std_soc). */
    (void)tau;

    for (int outer = 0; outer < params->barrier_max_iter; outer++) {
        stats.outer_iter = outer + 1;

        double xv = x[0], yv = x[1], zv = x[2];

        if (xv <= 1e-12 || yv <= 1e-12) {
            stats.fallback_used = true;
            host_project_power(x, d, alpha);
            return stats;
        }

        /* Compute h = x^α * y^(1-α), slack = h - |z| */
        double log_h = alpha * log(xv) + (1.0 - alpha) * log(yv);
        if (!isfinite(log_h)) {
            stats.fallback_used = true;
            host_project_power(x, d, alpha);
            return stats;
        }
        double h = exp(log_h);
        double abs_z = fabs(zv);
        double slack = h - abs_z;

        if (slack <= 1e-12) {
            stats.fallback_used = true;
            host_project_power(x, d, alpha);
            return stats;
        }

        /* Gradient of barrier: grad(phi) for power cone */
        /* phi = -α·log(x) - (1-α)·log(y) - log(slack)
         *   d(phi)/dx = -α/x + α·x^(α-1)·y^(1-α)/slack
         *              = -α/x + α·h/(x·slack)
         *   d(phi)/dy = -(1-α)/y + (1-α)·x^α·y^(-α)/slack
         *              = -(1-α)/y + (1-α)·h/(y·slack)
         *   d(phi)/dz = -sign(z)/slack
         */
        double inv_x = 1.0 / xv;
        double inv_y = 1.0 / yv;
        double inv_slack = 1.0 / slack;

        double grad[3];
        grad[0] = g[0] + mu * (-alpha * inv_x + alpha * h * inv_x * inv_slack);
        grad[1] = g[1] + mu * (-(1.0 - alpha) * inv_y + (1.0 - alpha) * h * inv_y * inv_slack);
        grad[2] = g[2] + mu * (-(zv >= 0.0 ? 1.0 : -1.0) * inv_slack);

        double grad_norm = sqrt(grad[0]*grad[0] + grad[1]*grad[1] + grad[2]*grad[2]);
        stats.final_residual = grad_norm;

        if (grad_norm < 1e-12) {
            stats.converged = true;
            break;
        }

        /* F(x) = <g,x> + mu * phi */
        double F_x = g[0]*xv + g[1]*yv + g[2]*zv;
        F_x += mu * (-alpha * log(xv) - (1.0 - alpha) * log(yv) - log(slack));

        double alpha_ls = params->barrier_ls_alpha0;
        bool ls_success = false;

        for (int ls = 0; ls < params->barrier_inner_max_iter; ls++) {
            stats.inner_iter++;

            double x_trial[3];
            x_trial[0] = xv - alpha_ls * grad[0];
            x_trial[1] = yv - alpha_ls * grad[1];
            x_trial[2] = zv - alpha_ls * grad[2];

            /* Ensure strictly positive */
            if (x_trial[0] < 1e-14) x_trial[0] = 1e-14;
            if (x_trial[1] < 1e-14) x_trial[1] = 1e-14;

            host_project_power(x_trial, d, alpha);

            double txv = x_trial[0], tyv = x_trial[1], tzv = x_trial[2];
            double t_log_h = alpha * log(txv) + (1.0 - alpha) * log(tyv);
            if (!isfinite(t_log_h)) {
                alpha_ls *= params->barrier_ls_beta;
                continue;
            }
            double t_h = exp(t_log_h);
            double t_abs_z = fabs(tzv);
            double t_slack = t_h - t_abs_z;

            if (t_slack <= 1e-12 || txv <= 1e-12 || tyv <= 1e-12) {
                alpha_ls *= params->barrier_ls_beta;
                continue;
            }

            double F_trial = g[0]*txv + g[1]*tyv + g[2]*tzv;
            F_trial += mu * (-alpha * log(txv) - (1.0 - alpha) * log(tyv) - log(t_slack));

            double grad_dot_dir = grad[0]*(txv-xv) + grad[1]*(tyv-yv) + grad[2]*(tzv-zv);
            double armijo_rhs = params->barrier_ls_c * alpha_ls * grad_dot_dir;

            if (F_trial <= F_x + armijo_rhs) {
                x[0] = txv; x[1] = tyv; x[2] = tzv;
                ls_success = true;
                break;
            }

            alpha_ls *= params->barrier_ls_beta;
        }

        if (!ls_success) {
            stats.fallback_used = true;
            host_project_power(x, d, alpha);
            return stats;
        }

        bm = boundary_metric_power(x, alpha, d);
        if (bm.feasible && fabs(stats.final_residual) < params->barrier_tol) {
            stats.converged = true;
            break;
        }
    }

    bm = boundary_metric_power(x, alpha, d);
    stats.rho_final = bm.rho;
    return stats;
}

/* =============================================================================
 * Section 7: Generic Dispatcher
 * ============================================================================= */

bpgrad_stats_t bpgrad_solve(
    cone_type_t cone_type,
    int v_dim,
    double *x_block,
    const double *g_block,
    const double *d_block,
    double alpha,
    double tau,
    double mu,
    const barrier_params_t *params)
{
    switch (cone_type) {
        case CONE_ROTATED_SOC:
            return bpgrad_solve_rsoc(v_dim, x_block, g_block, d_block, tau, mu, params);
        case CONE_STANDARD_SOC:
            return bpgrad_solve_std_soc(v_dim, x_block, g_block, d_block, tau, mu, params);
        case CONE_EXPONENTIAL:
            return bpgrad_solve_exp(x_block, g_block, d_block, tau, mu, params);
        case CONE_POWER:
            return bpgrad_solve_power(x_block, g_block, d_block, alpha, tau, mu, params);
        default:
            {
                bpgrad_stats_t err_stats = {0, 0, true, false, INFINITY, mu, 0.0, 0.0};
                return err_stats;
            }
    }
}

/* =============================================================================
 * Section 8: Cone-size aware wrapper (used by BOTH the pure host path and the
 *             GPU path's fallback)
 * =============================================================================
 *
 * bpgrad_solve() is the raw dispatcher.  bpgrad_solve_block() adds the one
 * piece of policy the caller must not have to repeat: sizing the block and
 * guaranteeing a feasible result for *any* v_dim the problem may contain.
 *
 * In particular, callers must NOT treat "k is large" as a reason to skip the
 * barrier and project instead -- that silently turns the barrier into a no-op
 * while still paying for it.  Every cone dimension is solvable on the CPU.
 */
bpgrad_stats_t bpgrad_solve_block(
    cone_type_t cone_type,
    int v_dim,
    double *x_block,
    const double *g_block,
    const double *d_block,
    double alpha,
    double tau,
    double mu,
    const barrier_params_t *params)
{
    bpgrad_stats_t stats = {0, 0, false, false, INFINITY, mu, 0.0, 0.0};

    if (!x_block || !params) {
        stats.fallback_used = true;
        return stats;
    }

    /* g = 0 is the barrier-only form used by this module; make it explicit so
     * callers may pass NULL. */
    const double *g = g_block;
    double *g_zero = NULL;
    int block_size = 0;
    switch (cone_type) {
        case CONE_ROTATED_SOC:
            block_size = v_dim + 2;
            break;
        case CONE_STANDARD_SOC:
            block_size = v_dim + 2;   /* [v(k), w, z] — see boundary_metric.h */
            break;
        case CONE_EXPONENTIAL:
        case CONE_POWER:
            block_size = 3;
            break;
        default:
            stats.fallback_used = true;
            return stats;
    }

    if (v_dim < 1 && (cone_type == CONE_ROTATED_SOC || cone_type == CONE_STANDARD_SOC)) {
        /* Degenerate SOC dimension: nothing to do beyond feasibility. */
        host_cone_project(cone_type, v_dim, x_block, d_block, alpha, NULL);
        stats.fallback_used = true;
        return stats;
    }

    if (!g) {
        g_zero = (double *)calloc((size_t)block_size, sizeof(double));
        if (!g_zero) {
            host_cone_project(cone_type, v_dim, x_block, d_block, alpha, NULL);
            stats.fallback_used = true;
            return stats;
        }
        g = g_zero;
    }

    stats = bpgrad_solve(cone_type, v_dim, x_block, g, d_block,
                         alpha, tau, mu, params);

    free(g_zero);

    /* Last-resort feasibility guarantee: whatever BPGrad did, the point we
     * hand back must satisfy the cone membership test that PDHCG itself uses.
     * Only an infeasible result triggers the projection repair -- a successful
     * barrier step is left untouched. */
    boundary_metric_t bm = boundary_metric_generic(cone_type, v_dim, x_block,
                                                   d_block, alpha, false);
    if (!bm.feasible) {
        host_cone_project(cone_type, v_dim, x_block, d_block, alpha, NULL);
        stats.fallback_used = true;
        stats.converged = false;
    }

    return stats;
}

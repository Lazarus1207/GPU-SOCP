/*
Copyright 2025 Haihao Lu
Copyright 2026 Hongpei Li

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limit under the License.
*/

/* popen()/pclose() are POSIX, not pure C99.  Enable POSIX feature
 * test macro before any system header is pulled in. */
#ifndef _POSIX_C_SOURCE
#define _POSIX_C_SOURCE 200809L
#endif

#include "cbf_parser.h"
#include "mps_parser.h"
#include "pdhcg.h"
#include "presolve_wrapper.h"
#include "solver.h"
#include "spmv_backend.h"
#include "utils.h"
#include <cuda_runtime.h>
#include <getopt.h>
#include <libgen.h>
#include <signal.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef PDHCG_COMPILE_DISTRIBUTED
#include "distributed_solver.h"
#include <mpi.h>
#endif

/* Cancellation flag (defined in pdhcg.c). CLI does not link pdhcg.c directly
 * so the symbol must be supplied by pdhcg_core.lib �?ensure it is built. */
extern volatile sig_atomic_t g_pdhcg_cancel_request;

char *get_output_path(const char *output_dir, const char *instance_name, const char *suffix)
{
    size_t path_len = strlen(output_dir) + strlen(instance_name) + strlen(suffix) + 2;
    char *full_path = safe_malloc(path_len * sizeof(char));
    snprintf(full_path, path_len, "%s/%s%s", output_dir, instance_name, suffix);
    return full_path;
}

/* Dispatch on file extension: .cbf(.gz) -> CBF parser, else MPS parser. */
static qp_problem_t *read_problem_file(const char *filename)
{
    size_t n = strlen(filename);
    const char *tail = filename;
    if (n > 3 && strcmp(filename + n - 3, ".gz") == 0)
        n -= 3;
    if (n > 4 && strncmp(tail + n - 4, ".cbf", 4) == 0)
        return read_cbf_file(filename);
    return read_mps_file(filename);
}

char *extract_instance_name(const char *filename)
{
    char *filename_copy = strdup(filename);
    if (filename_copy == NULL)
    {
        perror("Memory allocation failed");
        return NULL;
    }

    char *base = basename(filename_copy);
    char *dot = strchr(base, '.');
    if (dot)
    {
        *dot = '\0';
    }

    char *instance_name = strdup(base);
    free(filename_copy);
    return instance_name;
}

void save_solution(const double *data, int size, const char *output_dir, const char *instance_name, const char *suffix)
{
    char *file_path = get_output_path(output_dir, instance_name, suffix);
    if (file_path == NULL || data == NULL)
    {
        return;
    }

    FILE *outfile = fopen(file_path, "w");
    if (outfile == NULL)
    {
        perror("Error opening solution file");
        free(file_path);
        return;
    }

    for (int i = 0; i < size; ++i)
    {
        fprintf(outfile, "%.10g\n", data[i]);
    }

    fclose(outfile);
    free(file_path);
}

void save_solver_summary(const pdhcg_result_t *result, const char *output_dir, const char *instance_name)
{
    char *file_path = get_output_path(output_dir, instance_name, "_summary.txt");
    if (file_path == NULL)
    {
        return;
    }

    FILE *outfile = fopen(file_path, "w");
    if (outfile == NULL)
    {
        perror("Error opening summary file");
        free(file_path);
        return;
    }
    fprintf(outfile, "Termination Reason: %s\n", termination_reason_to_string(result->termination_reason));
    fprintf(outfile, "Runtime (sec): %e\n", result->cumulative_time_sec);
    fprintf(outfile, "Iterations Count: %d\n", result->total_count);
    if (result->total_inner_count > 0)
    {
        fprintf(outfile, "Inner Iterations Count: %d\n", result->total_inner_count);
    }
    fprintf(outfile, "Primal Objective Value: %e\n", result->primal_objective_value);
    fprintf(outfile, "Dual Objective Value: %e\n", result->dual_objective_value);
    fprintf(outfile, "Absolute Primal Residual: %e\n", result->absolute_primal_residual);
    fprintf(outfile, "Absolute Dual Residual: %e\n", result->absolute_dual_residual);
    fprintf(outfile, "Relative Primal Residual: %e\n", result->relative_primal_residual);
    fprintf(outfile, "Relative Dual Residual: %e\n", result->relative_dual_residual);
    fprintf(outfile, "Absolute Objective Gap: %e\n", result->objective_gap);
    fprintf(outfile, "Relative Objective Gap: %e\n", result->relative_objective_gap);
    fprintf(outfile, "Rows: %d\n", result->num_constraints);
    fprintf(outfile, "Columns: %d\n", result->num_variables);
    fprintf(outfile, "Nonzeros: %d\n", result->num_nonzeros);

    if (result->presolve_time > 0.0)
    {
        fprintf(outfile, "Presolve Status: %s\n", pdhcg_get_presolve_status_str(result->presolve_status));
        fprintf(outfile, "Presolve Time (sec): %e\n", result->presolve_time);
        fprintf(outfile, "Reduced Rows: %d\n", result->num_reduced_constraints);
        fprintf(outfile, "Reduced Columns: %d\n", result->num_reduced_variables);
        fprintf(outfile, "Reduced Nonzeros: %d\n", result->num_reduced_nonzeros);
    }

    if (result->feasibility_polishing_time > 0.0)
    {
        fprintf(outfile, "Feasibility Polishing Time (sec): %e\n", result->feasibility_polishing_time);
        fprintf(outfile, "Feasibility Polishing Iteration Count: %d\n", result->feasibility_iteration);
    }
    /* Row equilibration (row scaling) wall-clock. Always emitted (0.0 when
     * disabled or auto-skipped) so the bash runner can parse it uniformly. */
    fprintf(outfile, "Rescaling Time (sec): %e\n", result->rescaling_time_sec);
    fclose(outfile);
    free(file_path);
}

void print_usage(const char *prog_name)
{
    fprintf(stderr, "Usage: %s [OPTIONS] <problem_file> <output_dir>\n\n", prog_name);

    fprintf(stderr, "Arguments:\n");
    fprintf(stderr, "  <problem_file>           Input problem: .mps, .qps, .cbf, and gzip-compressed variants.\n");
    fprintf(stderr, "  <output_dir>             Directory where output files will be saved. It will contain:\n");
    fprintf(stderr, "                             - <basename>_summary.txt\n");
    fprintf(stderr, "                             - <basename>_primal_solution.txt\n");
    fprintf(stderr, "                             - <basename>_dual_solution.txt\n\n");

    fprintf(stderr, "Options:\n");
    fprintf(stderr, "  -h, --help               Display this help message.\n");
    fprintf(stderr, "  -v, --verbose <int>      Verbosity level: 0=silent, 1=summary, 2=detailed (default: 1).\n");
    fprintf(stderr, "      --time_limit <sec>   Time limit in seconds (default: 3600.0).\n");
    fprintf(stderr, "      --iter_limit <int>   Iteration limit (default: %d).\n", INT32_MAX);
    fprintf(stderr, "      --eps_opt <float>    Relative optimality tolerance (default: 1e-4).\n");
    fprintf(stderr, "      --eps_feas <float>   Relative feasibility tolerance (default: 1e-4).\n");
    fprintf(stderr, "      --eps_infeas_detect  Infeasibility detection tolerance (default: 1e-12).\n");
    fprintf(stderr, "      --curtis_reid_iter   Iterations for Curtis-Reid scaling (default: 0, disabled).\n");
    fprintf(stderr, "      --l_inf_ruiz_iter    Iterations for L-inf Ruiz rescaling (default: 10).\n");
    fprintf(stderr, "      --enable_row_scaling Apply row equilibration (default: on, auto-skipped when m > 2000).\n");
    fprintf(stderr, "      --row_scaling_max_rows Max m for row scaling (default: 2000).\n");
    fprintf(stderr, "      --no_row_scaling  Disable C row_scaling (sets --row_scaling_max_rows 0).\n");
    fprintf(stderr, "      --row_scaling_c_only <0|1> 1 = force C row_scaling on even when m>max_rows (default 0).\n");
    fprintf(stderr, "      --no_pock_chambolle  Disable Pock-Chambolle rescaling (default: enabled).\n");
    fprintf(stderr, "      --pock_chambolle_alpha Value for Pock-Chambolle alpha (default: 1.0).\n");
    fprintf(stderr, "      --no_bound_obj_rescaling Disable bound objective rescaling.\n");
    fprintf(stderr, "      --heterogeneous_cone_scaling Keep per-element cone scales (default: uniform per cone).\n");
    fprintf(stderr, "      --eval_freq <int>    Termination evaluation frequency (default: 200).\n");
    fprintf(stderr, "      --artificial_restart_threshold Artificial restart threshold (default: 0.36).\n");
    fprintf(stderr,
            "      --sufficient_reduction_for_restart Sufficient reduction factor for restart (default: 0.2).\n");
    fprintf(stderr, "      --necessary_reduction_for_restart Necessary reduction factor for restart (default: 0.8).\n");
    fprintf(stderr, "      --sv_max_iter <int>  Max iterations for singular value estimation (default: 5000).\n");
    fprintf(stderr, "      --sv_tol <float>     Tolerance for singular value estimation (default: 1e-4).\n");
    fprintf(stderr, "      --opt_norm <type>    Norm for optimality criteria: l2 or linf (default: linf).\n");
    fprintf(stderr, "      --inner_iter_limit   Max iterations for the inner solver (default: 1000).\n");
    fprintf(stderr, "      --inner_init_tol     Initial tolerance for the inner solver (default: 1e-3).\n");
    fprintf(stderr, "      --inner_min_tol      Minimum tolerance for the inner solver (default: 1e-9).\n");
    fprintf(
        stderr,
        "      --no_diag_precond    Disable Jacobi diagonal preconditioner for inner subproblem (default: enabled).\n");
    fprintf(stderr, "      --soc_form <form>    QCQP cone formulation: 'rotated' or 'standard' (default: rotated).\n");
    fprintf(stderr, "      --spmv_backend <type>  SpMV backend: 'cusparse' or 'new' (default: new, requires new build).\n");

#ifdef PDHCG_BARRIER_ENABLE
    print_barrier_cli_help();
#endif

#ifdef PDHCG_COMPILE_DISTRIBUTED
    fprintf(stderr, "\nDistributed Options (MPI & NCCL):\n");
    fprintf(stderr, "      --grid_size r,c      Explicitly set the 2D grid dimensions (e.g., 2,4).\n");
    fprintf(stderr, "      --partition_method   'uniform' or 'nnz' (default: nnz).\n");
    fprintf(stderr, "      --permute_method     'none', 'random', or 'block' (default: block).\n");
    fprintf(stderr, "      --permute_block_size Block size for block permutation (default: 256).\n");
#endif
}

int run_pdhcg(int argc, char *argv[])
{
    cudaFree(0);
    pdhg_parameters_t params;
    set_default_parameters(&params);

    static struct option long_options[] = {{"help", no_argument, 0, 'h'},
                                           {"verbose", required_argument, 0, 'v'},
                                           {"time_limit", required_argument, 0, 1001},
                                           {"iter_limit", required_argument, 0, 1002},
                                           {"eps_opt", required_argument, 0, 1003},
                                           {"eps_feas", required_argument, 0, 1004},
                                           {"eps_infeas_detect", required_argument, 0, 1005},
                                           {"eps_feas_polish", required_argument, 0, 1006},
                                           {"feasibility_polishing", no_argument, 0, 'f'},
                                           {"l_inf_ruiz_iter", required_argument, 0, 1007},
                                           {"pock_chambolle_alpha", required_argument, 0, 1008},
                                           {"no_pock_chambolle", no_argument, 0, 1009},
                                           {"no_bound_obj_rescaling", no_argument, 0, 1010},
                                           {"sv_max_iter", required_argument, 0, 1011},
                                           {"sv_tol", required_argument, 0, 1012},
                                           {"eval_freq", required_argument, 0, 1013},
                                           {"opt_norm", required_argument, 0, 1014},
                                           {"inner_iter_limit", required_argument, 0, 1015},
                                           {"inner_init_tol", required_argument, 0, 1016},
                                           {"inner_min_tol", required_argument, 0, 1017},
                                           {"presolve", required_argument, 0, 1018},
                                           {"no_diag_precond", no_argument, 0, 1019},
                                           {"soc_form", required_argument, 0, 1020},
                                           {"heterogeneous_cone_scaling", no_argument, 0, 1021},
                                           {"artificial_restart_threshold", required_argument, 0, 1022},
                                           {"sufficient_reduction_for_restart", required_argument, 0, 1023},
                                           {"necessary_reduction_for_restart", required_argument, 0, 1024},
                                           {"curtis_reid_iter", required_argument, 0, 1025},
                                           {"spmv_backend", required_argument, 0, 1026},
                                           {"enable_row_scaling", no_argument, 0, 1028},
                                           {"row_scaling_max_rows", required_argument, 0, 1029},
                                           {"row_scaling_c_only", required_argument, 0, 1030},
                                           {"python_row_scaling", required_argument, 0, 1031},
                                           {"no_row_scaling", no_argument, 0, 1032},
                                           {0, 0, 0, 0}};

    int opt;
    optind = 1;
    while ((opt = getopt_long(argc, argv, "hv:fp", long_options, NULL)) != -1)
    {
        switch (opt)
        {
            case 'h':
                print_usage(argv[0]);
                return 0;
            case 'v':
                params.verbose = atoi(optarg);
                break;
            case 1001:
                params.termination_criteria.time_sec_limit = atof(optarg);
                break;
            case 1002:
                params.termination_criteria.iteration_limit = atoi(optarg);
                break;
            case 1003:
                params.termination_criteria.eps_optimal_relative = atof(optarg);
                break;
            case 1004:
                params.termination_criteria.eps_feasible_relative = atof(optarg);
                break;
            case 1005:
                params.termination_criteria.eps_infeasible = atof(optarg);
                break;
            case 1006:
                params.termination_criteria.eps_feas_polish_relative = atof(optarg);
                break;
            case 'f':
                params.feasibility_polishing = true;
                break;
            case 1007:
                params.l_inf_ruiz_iterations = atoi(optarg);
                break;
            case 1008:
                params.pock_chambolle_alpha = atof(optarg);
                break;
            case 1009:
                params.has_pock_chambolle_alpha = false;
                break;
            case 1010:
                params.bound_objective_rescaling = false;
                break;
            case 1011:
                params.sv_max_iter = atoi(optarg);
                break;
            case 1012:
                params.sv_tol = atof(optarg);
                break;
            case 1013:
                params.termination_evaluation_frequency = atoi(optarg);
                break;
            case 1014:
                if (strcmp(optarg, "l2") == 0)
                    params.optimality_norm = NORM_TYPE_L2;
                else if (strcmp(optarg, "linf") == 0)
                    params.optimality_norm = NORM_TYPE_L_INF;
                else
                {
                    fprintf(stderr, "Error: opt_norm must be 'l2' or 'linf'\n");
                    return 1;
                }
                break;
            case 1015:
                params.inner_solver_parameters.iteration_limit = atoi(optarg);
                break;
            case 1016:
                params.inner_solver_parameters.initial_tolerance = atof(optarg);
                break;
            case 1017:
                params.inner_solver_parameters.min_tolerance = atof(optarg);
                break;
            case 1018:
                params.presolve = (atoi(optarg) != 0);
                break;
            case 1019:
                params.diag_jacobi_precond = false;
                break;
            case 1020:
                if (strcmp(optarg, "rotated") == 0)
                    params.default_cone_type = CONE_ROTATED_SOC;
                else if (strcmp(optarg, "standard") == 0)
                    params.default_cone_type = CONE_STANDARD_SOC;
                else
                {
                    fprintf(stderr, "Error: soc_form must be 'rotated' or 'standard'\n");
                    return 1;
                }
                break;
            case 1021:
                params.heterogeneous_cone_scaling = true;
                break;
            case 1022:
                params.restart_params.artificial_restart_threshold = atof(optarg);
                break;
            case 1023:
                params.restart_params.sufficient_reduction_for_restart = atof(optarg);
                break;
            case 1024:
                params.restart_params.necessary_reduction_for_restart = atof(optarg);
                break;
            case 1025:
                params.curtis_reid_iterations = atoi(optarg);
                break;
            case 1026: // --spmv_backend cusparse|new
                if (strcmp(optarg, "cusparse") == 0 || strcmp(optarg, "cusparse_spmvop") == 0)
                {
                    pdhcg_set_spmv_backend(0);
                }
                else if (strcmp(optarg, "new") == 0 || strcmp(optarg, "new_spmv") == 0)
                {
                    pdhcg_set_spmv_backend(1);
                }
                else
                {
                    fprintf(stderr, "Error: spmv_backend must be 'cusparse' or 'new'\n");
                    return 1;
                }
                break;
            case 1028:
                params.enable_row_scaling = true;
                break;
            case 1029:
                params.row_scaling_max_rows = atoi(optarg);
                break;
            case 1030: /* --row_scaling_c_only 0|1 */
                params.enable_row_scaling = (atoi(optarg) != 0);
                if (params.enable_row_scaling) {
                    /* Cap at a value where the cuSOLVER dsyevd call still
                     * fits in <1 GB of host/GPU memory:  m*m * 8 bytes.
                     * 5000*5000*8 = 200 MB which is comfortable. */
                    if (params.row_scaling_max_rows < 5000) {
                        params.row_scaling_max_rows = 5000;
                    }
                }
                break;
            case 1031: /* --python_row_scaling 0|1 (legacy hook) */
                /* No-op in the new C-only build; kept for ABI compat. */
                break;
            case 1032: /* --no_row_scaling */
                params.enable_row_scaling = false;
                params.row_scaling_max_rows = 0;
                break;
#ifdef PDHCG_BARRIER_ENABLE
            /* Barrier dispatch (codes 3001-3026). */
            case 3001:
                ((barrier_params_t *)params.barrier_params)->barrier_enabled = (atoi(optarg) != 0);
                break;
            case 3002:
                ((barrier_params_t *)params.barrier_params)->barrier_option = (barrier_option_t)atoi(optarg);
                break;
            case 3003:
                ((barrier_params_t *)params.barrier_params)->barrier_mu_init = atof(optarg);
                break;
            case 3004:
                ((barrier_params_t *)params.barrier_params)->barrier_mu_final = atof(optarg);
                break;
            case 3005:
            {
                int s = atoi(optarg);
                if (s >= 0 && s < BARRIER_MU_NUM_STRATEGIES)
                    ((barrier_params_t *)params.barrier_params)->barrier_mu_strategy = (barrier_mu_strategy_t)s;
                break;
            }
            case 3006:
                ((barrier_params_t *)params.barrier_params)->barrier_mu_rho = atof(optarg);
                break;
            case 3007:
                ((barrier_params_t *)params.barrier_params)->soc_rsoc_max_ratio = atof(optarg);
                break;
            case 3008:
                ((barrier_params_t *)params.barrier_params)->std_soc_max_ratio = atof(optarg);
                break;
            case 3009:
                ((barrier_params_t *)params.barrier_params)->exp_max_ratio = atof(optarg);
                break;
            case 3010:
                ((barrier_params_t *)params.barrier_params)->power_max_ratio = atof(optarg);
                break;
            case 3011:
                ((barrier_params_t *)params.barrier_params)->barrier_max_iter = atoi(optarg);
                break;
            case 3012:
                ((barrier_params_t *)params.barrier_params)->barrier_inner_max_iter = atoi(optarg);
                break;
            case 3013:
                ((barrier_params_t *)params.barrier_params)->barrier_tol = atof(optarg);
                break;
            case 3014:
                ((barrier_params_t *)params.barrier_params)->barrier_check_every = atoi(optarg);
                break;
            case 3015:
                ((barrier_params_t *)params.barrier_params)->barrier_gap_threshold = atof(optarg);
                break;
            case 3016:
                ((barrier_params_t *)params.barrier_params)->barrier_step_norm_cap = atof(optarg);
                break;
            case 3017:
                ((barrier_params_t *)params.barrier_params)->barrier_primal_res_factor = atof(optarg);
                break;
            case 3018:
                ((barrier_params_t *)params.barrier_params)->barrier_adaptive_threshold = (atoi(optarg) != 0);
                break;
            case 3019:
                ((barrier_params_t *)params.barrier_params)->barrier_verbose = atoi(optarg);
                break;
            case 3020:
                ((barrier_params_t *)params.barrier_params)->barrier_homotopy_alpha = atof(optarg);
                break;
            case 3021:
                ((barrier_params_t *)params.barrier_params)->barrier_homotopy_beta = atof(optarg);
                break;
            case 3022:
                ((barrier_params_t *)params.barrier_params)->soc_rsoc_mu_init = atof(optarg);
                break;
            case 3023:
                ((barrier_params_t *)params.barrier_params)->std_soc_mu_init = atof(optarg);
                break;
            case 3024:
                ((barrier_params_t *)params.barrier_params)->exp_mu_init = atof(optarg);
                break;
            case 3025:
                ((barrier_params_t *)params.barrier_params)->power_mu_init = atof(optarg);
                break;
            case 3026:
                ((barrier_params_t *)params.barrier_params)->barrier_use_gpu_bpgrad = (atoi(optarg) != 0);
                break;
#endif            case '?':
                return 1;
        }
    }

    if (argc - optind != 2)
    {
        fprintf(stderr, "Error: You must specify an input file and an output directory.\n\n");
        print_usage(argv[0]);
        return 1;
    }

    const char *filename = argv[optind];
    const char *output_dir = argv[optind + 1];

    char *instance_name = extract_instance_name(filename);
    if (instance_name == NULL)
        return 1;

    qp_problem_t *problem = read_problem_file(filename);
    if (problem == NULL)
    {
        fprintf(stderr, "Failed to read or parse the file.\n");
        free(instance_name);
        return 1;
    }

    /* ------------------------------------------------------------
     * Row-scaling dispatch.
     *
     * The C-side row_scaling.c path (PDHCG/src/row_scaling.c, invoked
     * from solver.cu via pdhcg_apply_row_scaling) is now the single
     * source of truth.  The previous Python popen hook that delegated
     * m <= max_rows problems to PDHCG/python/pdhcg/row_scaling/ has
     * been removed: the C and Python paths compute the same M, but
     * the C path avoids a fork+exec and a re-parse of the problem on
     * every small-instance solve.
     *
     * For m > row_scaling_max_rows, no row scaling is applied; the
     * C core still runs Ruiz + Pock-Chambolle + (optionally)
     * Curtis-Reid on the original problem.
     * ------------------------------------------------------------ */
    if (params.enable_row_scaling &&
        params.row_scaling_max_rows > 0 &&
        problem->num_constraints > 0 &&
        problem->num_constraints <= params.row_scaling_max_rows)
    {
        fprintf(stderr,
                "[row_scaling] using C path for m=%d (max_rows=%d).\n",
                problem->num_constraints, params.row_scaling_max_rows);
    }

    pdhcg_result_t *result = optimize(&params, problem);

    if (result == NULL)
    {
        fprintf(stderr, "Solver failed.\n");
    }
    else
    {
        save_solver_summary(result, output_dir, instance_name);
        save_solution(
            result->primal_solution, problem->num_variables, output_dir, instance_name, "_primal_solution.txt");
        save_solution(result->dual_solution, problem->num_constraints, output_dir, instance_name, "_dual_solution.txt");
        pdhcg_result_free(result);
    }

    qp_problem_free(problem);
    free(instance_name);

#ifdef PDHCG_BARRIER_ENABLE
    free_barrier_params(params.barrier_params);
    params.barrier_params = NULL;
#endif

    return 0;
}

#ifdef PDHCG_COMPILE_DISTRIBUTED
int run_d_pdhcg(int argc, char *argv[])
{
    int mpi_initialized = 0;
    MPI_Initialized(&mpi_initialized);
    if (!mpi_initialized)
    {
        MPI_Init(&argc, &argv);
    }

    int rank_global, world_size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank_global);
    MPI_Comm_size(MPI_COMM_WORLD, &world_size);

    pdhg_parameters_t params;
    set_default_parameters(&params);

    params.grid_size.row_dims = 0;
    params.grid_size.col_dims = 0;
    params.grid_size.decided = false;
    params.permute_block_size = 256;

    static struct option long_options[] = {{"help", no_argument, 0, 'h'},
                                           {"verbose", required_argument, 0, 'v'},
                                           {"time_limit", required_argument, 0, 1001},
                                           {"iter_limit", required_argument, 0, 1002},
                                           {"eps_opt", required_argument, 0, 1003},
                                           {"eps_feas", required_argument, 0, 1004},
                                           {"eps_infeas_detect", required_argument, 0, 1005},
                                           {"eps_feas_polish", required_argument, 0, 1006},
                                           {"feasibility_polishing", no_argument, 0, 'f'},
                                           {"l_inf_ruiz_iter", required_argument, 0, 1007},
                                           {"pock_chambolle_alpha", required_argument, 0, 1008},
                                           {"no_pock_chambolle", no_argument, 0, 1009},
                                           {"no_bound_obj_rescaling", no_argument, 0, 1010},
                                           {"sv_max_iter", required_argument, 0, 1011},
                                           {"sv_tol", required_argument, 0, 1012},
                                           {"eval_freq", required_argument, 0, 1013},
                                           {"opt_norm", required_argument, 0, 1014},
                                           {"inner_iter_limit", required_argument, 0, 1015},
                                           {"inner_init_tol", required_argument, 0, 1016},
                                           {"inner_min_tol", required_argument, 0, 1017},
                                           {"presolve", required_argument, 0, 1018},
                                           {"no_diag_precond", no_argument, 0, 1019},
                                           {"heterogeneous_cone_scaling", no_argument, 0, 1021},
                                           {"artificial_restart_threshold", required_argument, 0, 1022},
                                           {"sufficient_reduction_for_restart", required_argument, 0, 1023},
                                           {"necessary_reduction_for_restart", required_argument, 0, 1024},
                                           {"curtis_reid_iter", required_argument, 0, 1025},
                                           {"enable_row_scaling", no_argument, 0, 1028},
                                           {"row_scaling_max_rows", required_argument, 0, 1029},
                                           {"row_scaling_c_only", required_argument, 0, 1030},
                                           {"python_row_scaling", required_argument, 0, 1031},
                                           {"no_row_scaling", no_argument, 0, 1032},
#ifdef PDHCG_BARRIER_ENABLE
                                           /* Barrier option codes (range 3001-3026). */
                                           {"barrier_enabled", required_argument, 0, 3001},
                                           {"barrier_option", required_argument, 0, 3002},
                                           {"barrier_mu_init", required_argument, 0, 3003},
                                           {"barrier_mu_final", required_argument, 0, 3004},
                                           {"barrier_mu_strategy", required_argument, 0, 3005},
                                           {"barrier_mu_rho", required_argument, 0, 3006},
                                           {"barrier_soc_rsoc_ratio", required_argument, 0, 3007},
                                           {"barrier_std_soc_ratio", required_argument, 0, 3008},
                                           {"barrier_exp_ratio", required_argument, 0, 3009},
                                           {"barrier_power_ratio", required_argument, 0, 3010},
                                           {"barrier_max_iter", required_argument, 0, 3011},
                                           {"barrier_inner_max_iter", required_argument, 0, 3012},
                                           {"barrier_tol", required_argument, 0, 3013},
                                           {"barrier_check_every", required_argument, 0, 3014},
                                           {"barrier_gap_threshold", required_argument, 0, 3015},
                                           {"barrier_step_norm_cap", required_argument, 0, 3016},
                                           {"barrier_primal_res_factor", required_argument, 0, 3017},
                                           {"barrier_adaptive_threshold", required_argument, 0, 3018},
                                           {"barrier_verbose", required_argument, 0, 3019},
                                           {"barrier_homotopy_alpha", required_argument, 0, 3020},
                                           {"barrier_homotopy_beta", required_argument, 0, 3021},
                                           {"barrier_soc_rsoc_mu_init", required_argument, 0, 3022},
                                           {"barrier_std_soc_mu_init", required_argument, 0, 3023},
                                           {"barrier_exp_mu_init", required_argument, 0, 3024},
                                           {"barrier_power_mu_init", required_argument, 0, 3025},
                                           {"barrier_use_gpu_bpgrad", required_argument, 0, 3026},
#endif
                                           {"grid_size", required_argument, 0, 2001},
                                           {"partition_method", required_argument, 0, 2002},
                                           {"permute_method", required_argument, 0, 2003},
                                           {"permute_block_size", required_argument, 0, 2004},
                                           {0, 0, 0, 0}};

    int opt;
    optind = 1;
    while ((opt = getopt_long(argc, argv, "hv:fp", long_options, NULL)) != -1)
    {
        switch (opt)
        {
            case 'h':
                if (rank_global == 0)
                    print_usage(argv[0]);
                MPI_Finalize();
                return 0;
            case 'v':
                params.verbose = atoi(optarg);
                break;
            case 1001:
                params.termination_criteria.time_sec_limit = atof(optarg);
                break;
            case 1002:
                params.termination_criteria.iteration_limit = atoi(optarg);
                break;
            case 1003:
                params.termination_criteria.eps_optimal_relative = atof(optarg);
                break;
            case 1004:
                params.termination_criteria.eps_feasible_relative = atof(optarg);
                break;
            case 1005:
                params.termination_criteria.eps_infeasible = atof(optarg);
                break;
            case 1006:
                params.termination_criteria.eps_feas_polish_relative = atof(optarg);
                break;
            case 'f':
                params.feasibility_polishing = true;
                break;
            case 1007:
                params.l_inf_ruiz_iterations = atoi(optarg);
                break;
            case 1008:
                params.pock_chambolle_alpha = atof(optarg);
                break;
            case 1009:
                params.has_pock_chambolle_alpha = false;
                break;
            case 1010:
                params.bound_objective_rescaling = false;
                break;
            case 1011:
                params.sv_max_iter = atoi(optarg);
                break;
            case 1012:
                params.sv_tol = atof(optarg);
                break;
            case 1013:
                params.termination_evaluation_frequency = atoi(optarg);
                break;
            case 1014:
                if (strcmp(optarg, "l2") == 0)
                    params.optimality_norm = NORM_TYPE_L2;
                else if (strcmp(optarg, "linf") == 0)
                    params.optimality_norm = NORM_TYPE_L_INF;
                else
                {
                    if (rank_global == 0)
                        fprintf(stderr, "Error: opt_norm must be 'l2' or 'linf'\n");
                    MPI_Abort(MPI_COMM_WORLD, EXIT_FAILURE);
                }
                break;
            case 1015:
                params.inner_solver_parameters.iteration_limit = atoi(optarg);
                break;
            case 1016:
                params.inner_solver_parameters.initial_tolerance = atof(optarg);
                break;
            case 1017:
                params.inner_solver_parameters.min_tolerance = atof(optarg);
                break;
            case 1018:
                params.presolve = (atoi(optarg) != 0);
                break;
            case 1019:
                params.diag_jacobi_precond = false;
                break;
            case 1021:
                params.heterogeneous_cone_scaling = true;
                break;
            case 1022:
                params.restart_params.artificial_restart_threshold = atof(optarg);
                break;
            case 1023:
                params.restart_params.sufficient_reduction_for_restart = atof(optarg);
                break;
            case 1024:
                params.restart_params.necessary_reduction_for_restart = atof(optarg);
                break;
            case 1025:
                params.curtis_reid_iterations = atoi(optarg);
                break;
            case 1028:
                params.enable_row_scaling = true;
                break;
            case 1029:
                params.row_scaling_max_rows = atoi(optarg);
                break;
            case 1030: /* --row_scaling_c_only 0|1 */
                params.enable_row_scaling = (atoi(optarg) != 0);
                if (params.enable_row_scaling &&
                    params.row_scaling_max_rows < 5000) {
                    params.row_scaling_max_rows = 5000;
                }
                break;
            case 1031: /* --python_row_scaling 0|1 (legacy hook, no-op) */
                break;
            case 1032: /* --no_row_scaling */
                params.enable_row_scaling = false;
                params.row_scaling_max_rows = 0;
                break;
            case 2001: // --grid_size r,c
            {
                int r, c;
                if (sscanf(optarg, "%d,%d", &r, &c) == 2 && r > 0 && c > 0)
                {
                    if (r * c != world_size)
                    {
                        if (rank_global == 0)
                        {
                            fprintf(stderr, "\n[FATAL ERROR] MPI Grid Configuration Mismatch\n");
                            fprintf(stderr, "Command line input : --grid_size %s (Total: %d)\n", optarg, r * c);
                            fprintf(stderr, "MPI Runtime size   : -n %d\n", world_size);
                        }
                        MPI_Abort(MPI_COMM_WORLD, EXIT_FAILURE);
                    }
                    params.grid_size.row_dims = r;
                    params.grid_size.col_dims = c;
                    params.grid_size.decided = true;
                }
                else
                {
                    if (rank_global == 0)
                        fprintf(stderr, "Error: Invalid grid_size format. Use r,c\n");
                    MPI_Abort(MPI_COMM_WORLD, EXIT_FAILURE);
                }
                break;
            }
            case 2002: // --partition_method
            {
                if (strcmp(optarg, "uniform") == 0)
                    params.partition_method = UNIFORM_PARTITION;
                else if (strcmp(optarg, "nnz") == 0 || strcmp(optarg, "nnz_balance") == 0)
                    params.partition_method = NNZ_BALANCE_PARTITION;
                else
                {
                    if (rank_global == 0)
                        fprintf(stderr, "Error: partition_method must be 'uniform' or 'nnz'\n");
                    MPI_Abort(MPI_COMM_WORLD, EXIT_FAILURE);
                }
                break;
            }
            case 2003: // --permute_method
            {
                if (strcmp(optarg, "none") == 0 || strcmp(optarg, "no") == 0)
                    params.permute_method = NO_PERMUTATION;
                else if (strcmp(optarg, "random") == 0 || strcmp(optarg, "full") == 0)
                    params.permute_method = FULL_RANDOM_PERMUTATION;
                else if (strcmp(optarg, "block") == 0)
                    params.permute_method = BLOCK_RANDOM_PERMUTATION;
                else
                {
                    if (rank_global == 0)
                        fprintf(stderr, "Error: permute_method must be 'none', 'random', or 'block'\n");
                    MPI_Abort(MPI_COMM_WORLD, EXIT_FAILURE);
                }
                break;
            }
            case 2004: // --permute_block_size
            {
                params.permute_block_size = atoi(optarg);
                if (params.permute_block_size <= 0)
                {
                    if (rank_global == 0)
                        fprintf(stderr, "Error: permute_block_size must be positive.\n");
                    MPI_Abort(MPI_COMM_WORLD, EXIT_FAILURE);
                }
                break;
            }
#ifdef PDHCG_BARRIER_ENABLE
            /* Barrier dispatch (codes 3001-3026). */
            case 3001:
                ((barrier_params_t *)params.barrier_params)->barrier_enabled = (atoi(optarg) != 0);
                break;
            case 3002:
                ((barrier_params_t *)params.barrier_params)->barrier_option = (barrier_option_t)atoi(optarg);
                break;
            case 3003:
                ((barrier_params_t *)params.barrier_params)->barrier_mu_init = atof(optarg);
                break;
            case 3004:
                ((barrier_params_t *)params.barrier_params)->barrier_mu_final = atof(optarg);
                break;
            case 3005:
            {
                int s = atoi(optarg);
                if (s >= 0 && s < BARRIER_MU_NUM_STRATEGIES)
                    ((barrier_params_t *)params.barrier_params)->barrier_mu_strategy = (barrier_mu_strategy_t)s;
                break;
            }
            case 3006:
                ((barrier_params_t *)params.barrier_params)->barrier_mu_rho = atof(optarg);
                break;
            case 3007:
                ((barrier_params_t *)params.barrier_params)->soc_rsoc_max_ratio = atof(optarg);
                break;
            case 3008:
                ((barrier_params_t *)params.barrier_params)->std_soc_max_ratio = atof(optarg);
                break;
            case 3009:
                ((barrier_params_t *)params.barrier_params)->exp_max_ratio = atof(optarg);
                break;
            case 3010:
                ((barrier_params_t *)params.barrier_params)->power_max_ratio = atof(optarg);
                break;
            case 3011:
                ((barrier_params_t *)params.barrier_params)->barrier_max_iter = atoi(optarg);
                break;
            case 3012:
                ((barrier_params_t *)params.barrier_params)->barrier_inner_max_iter = atoi(optarg);
                break;
            case 3013:
                ((barrier_params_t *)params.barrier_params)->barrier_tol = atof(optarg);
                break;
            case 3014:
                ((barrier_params_t *)params.barrier_params)->barrier_check_every = atoi(optarg);
                break;
            case 3015:
                ((barrier_params_t *)params.barrier_params)->barrier_gap_threshold = atof(optarg);
                break;
            case 3016:
                ((barrier_params_t *)params.barrier_params)->barrier_step_norm_cap = atof(optarg);
                break;
            case 3017:
                ((barrier_params_t *)params.barrier_params)->barrier_primal_res_factor = atof(optarg);
                break;
            case 3018:
                ((barrier_params_t *)params.barrier_params)->barrier_adaptive_threshold = (atoi(optarg) != 0);
                break;
            case 3019:
                ((barrier_params_t *)params.barrier_params)->barrier_verbose = atoi(optarg);
                break;
            case 3020:
                ((barrier_params_t *)params.barrier_params)->barrier_homotopy_alpha = atof(optarg);
                break;
            case 3021:
                ((barrier_params_t *)params.barrier_params)->barrier_homotopy_beta = atof(optarg);
                break;
            case 3022:
                ((barrier_params_t *)params.barrier_params)->soc_rsoc_mu_init = atof(optarg);
                break;
            case 3023:
                ((barrier_params_t *)params.barrier_params)->std_soc_mu_init = atof(optarg);
                break;
            case 3024:
                ((barrier_params_t *)params.barrier_params)->exp_mu_init = atof(optarg);
                break;
            case 3025:
                ((barrier_params_t *)params.barrier_params)->power_mu_init = atof(optarg);
                break;
            case 3026:
                ((barrier_params_t *)params.barrier_params)->barrier_use_gpu_bpgrad = (atoi(optarg) != 0);
                break;
#endif            case '?':
                MPI_Abort(MPI_COMM_WORLD, EXIT_FAILURE);
                return 1;
        }
    }

    if (argc - optind != 2)
    {
        if (rank_global == 0)
        {
            fprintf(stderr, "Error: You must specify an input file and an output directory.\n");
            print_usage(argv[0]);
        }
        MPI_Finalize();
        return 1;
    }

    const char *filename = argv[optind];
    const char *output_dir = argv[optind + 1];

    char *instance_name = extract_instance_name(filename);
    if (instance_name == NULL)
    {
        if (rank_global == 0)
            fprintf(stderr, "Error: Could not extract instance name from filename.\n");
        MPI_Abort(MPI_COMM_WORLD, EXIT_FAILURE);
        return 1;
    }

    qp_problem_t *problem = NULL;

    if (rank_global == 0)
    {
        if (params.verbose)
            printf("Rank 0: Loading problem file '%s'...\n", filename);
        problem = read_problem_file(filename);

        if (problem == NULL)
        {
            fprintf(stderr, "Rank 0: Failed to read or parse the file.\n");
            MPI_Abort(MPI_COMM_WORLD, EXIT_FAILURE);
            return 1;
        }
    }

    pdhcg_result_t *result = distributed_optimize(&params, problem);

    if (rank_global == 0)
    {
        if (result == NULL)
        {
            fprintf(stderr, "Solver failed (returned NULL result).\n");
        }
        else
        {
            save_solver_summary(result, output_dir, instance_name);
            save_solution(
                result->primal_solution, result->num_variables, output_dir, instance_name, "_primal_solution.txt");
            save_solution(
                result->dual_solution, result->num_constraints, output_dir, instance_name, "_dual_solution.txt");
            pdhcg_result_free(result);
        }
        if (problem)
            qp_problem_free(problem);
    }
    else
    {
        if (result)
            pdhcg_result_free(result);
    }

    free(instance_name);
    MPI_Finalize();
    return 0;
}
#endif // PDHCG_COMPILE_DISTRIBUTED

int main(int argc, char *argv[])
{
#ifdef PDHCG_COMPILE_DISTRIBUTED
    int mpi_initialized = 0;
    MPI_Initialized(&mpi_initialized);
    if (!mpi_initialized)
    {
        MPI_Init(&argc, &argv);
    }

    int world_size;
    MPI_Comm_size(MPI_COMM_WORLD, &world_size);

    if (world_size > 1)
    {
        return run_d_pdhcg(argc, argv);
    }
    else
    {
        int ret = run_pdhcg(argc, argv);
        MPI_Finalize();
        return ret;
    }
#else
    return run_pdhcg(argc, argv);
#endif
}

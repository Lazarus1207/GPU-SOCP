/*
================================================================================
boundary_metric.c - Boundary Metric (ρ) Implementation for 4 Cone Types
================================================================================
*/

#include "boundary_metric.h"
#include <math.h>
#include <string.h>

/* =============================================================================
 * Section 1: Helper - Clamp ρ to [0, 1]
 * ============================================================================= */

static inline double clamp_rho(double rho)
{
    if (!isfinite(rho)) return 0.0;
    if (rho < 0.0) return 0.0;
    if (rho > 1.0) return 1.0;
    return rho;
}

/* =============================================================================
 * Section 2: RSOC Boundary Metric
 * ============================================================================= */

boundary_metric_t boundary_metric_rsoc(int k, const double *x, const double *d)
{
    boundary_metric_t result = {0.0, 0.0, false};

    if (!x || k < 1) return result;

    /* x layout: [v0, ..., v_{k-1}, s, t] */
    const double *v = x;
    double s = x[k];
    double t = x[k + 1];

    /* Check finiteness */
    if (!isfinite(s) || !isfinite(t)) return result;
    for (int i = 0; i < k; i++) {
        if (!isfinite(x[i])) return result;
    }

    /* Apply rescaling if provided */
    double ds = d ? d[k] : 1.0;
    double dt = d ? d[k + 1] : 1.0;
    if (ds <= 0.0) ds = 1.0;
    if (dt <= 0.0) dt = 1.0;

    /* In rescaled space, the cone is: 2*(s/ds)*(t/dt) >= ||v_i/d_v_i||² */
    double s_scaled = s / ds;
    double t_scaled = t / dt;

    /* Boundary feasibility requires s >= 0, t >= 0, 2st >= ||v||² */
    if (s_scaled < 0.0 || t_scaled < 0.0) {
        return result;  /* infeasible */
    }

    double norm_v_sq = 0.0;
    for (int i = 0; i < k; i++) {
        double dv = d ? d[i] : 1.0;
        if (dv <= 0.0) dv = 1.0;
        double v_scaled = x[i] / dv;
        norm_v_sq += v_scaled * v_scaled;
    }

    double inner = 2.0 * s_scaled * t_scaled - norm_v_sq;
    double scale = sqrt(2.0 * s_scaled * t_scaled);

    result.slack = inner;
    result.feasible = (inner >= 0.0 && s >= 0.0 && t >= 0.0);

    if (!result.feasible || scale < 1e-15 || inner <= 0.0) {
        result.rho = 0.0;
        return result;
    }

    result.rho = clamp_rho(sqrt(inner) / scale);
    return result;
}

/* =============================================================================
 * Section 3: StdSOC Boundary Metric
 * ============================================================================= */

boundary_metric_t boundary_metric_std_soc(int k, const double *x, const double *d)
{
    boundary_metric_t result = {0.0, 0.0, false};

    if (!x || k < 1) return result;

    /* x layout: [t, u0, ..., u_{k-1}] */
    double t = x[0];
    const double *u = x + 1;

    /* Check finiteness */
    if (!isfinite(t)) return result;
    for (int i = 0; i < k; i++) {
        if (!isfinite(u[i])) return result;
    }

    /* Apply rescaling */
    double dt = d ? d[0] : 1.0;
    if (dt <= 0.0) dt = 1.0;
    double t_scaled = t / dt;

    if (t_scaled < 0.0) {
        return result;  /* infeasible */
    }

    double norm_u_sq = 0.0;
    for (int i = 0; i < k; i++) {
        double du = d ? d[i + 1] : 1.0;
        if (du <= 0.0) du = 1.0;
        double u_scaled = u[i] / du;
        norm_u_sq += u_scaled * u_scaled;
    }

    double inner = t_scaled * t_scaled - norm_u_sq;
    double abs_t_scaled = fabs(t_scaled);

    result.slack = inner;
    result.feasible = (inner >= 0.0 && t >= 0.0);

    if (!result.feasible || abs_t_scaled < 1e-15 || inner <= 0.0) {
        result.rho = 0.0;
        return result;
    }

    result.rho = clamp_rho(sqrt(inner) / abs_t_scaled);
    return result;
}

/* =============================================================================
 * Section 4: EXP Boundary Metric
 * ============================================================================= */

boundary_metric_t boundary_metric_exp(const double *x, const double *d)
{
    boundary_metric_t result = {0.0, -INFINITY, false};

    if (!x) return result;

    /* x layout: [x1, x2, x3] */
    double x1 = x[0], x2 = x[1], x3 = x[2];

    if (!isfinite(x1) || !isfinite(x2) || !isfinite(x3)) {
        return result;
    }

    /* Apply rescaling */
    double d1 = d ? d[0] : 1.0;
    double d2 = d ? d[1] : 1.0;
    double d3 = d ? d[2] : 1.0;
    if (d1 <= 0.0) d1 = 1.0;
    if (d2 <= 0.0) d2 = 1.0;
    if (d3 <= 0.0) d3 = 1.0;

    /* Check feasibility: x2 > 0, x3 > 0 in rescaled space */
    if (x2 / d2 <= 0.0 || x3 / d3 <= 0.0 || x1 / d1 <= 0.0) {
        return result;
    }

    /* r = x3/x2, slack = x1 - x2 * exp(r) */
    double r = x3 / x2;
    if (fabs(r) > 50.0) {
        return result;  /* r too large, exponential overflow */
    }

    double exp_r = exp(r);
    double slack = x1 - x2 * exp_r;

    result.slack = slack;
    result.feasible = (slack >= 0.0);

    if (!isfinite(slack) || slack <= 0.0 || x1 <= 0.0) {
        result.rho = 0.0;
        return result;
    }

    /* ρ = slack / x1 */
    result.rho = clamp_rho(slack / x1);
    return result;
}

/* =============================================================================
 * Section 5: Power Boundary Metric
 * ============================================================================= */

boundary_metric_t boundary_metric_power(const double *x, double alpha, const double *d)
{
    boundary_metric_t result = {0.0, -INFINITY, false};

    if (!x) return result;
    if (alpha <= 0.0 || alpha >= 1.0) {
        /* Invalid alpha; treat as at boundary */
        return result;
    }

    /* x layout: [x, y, z] */
    double xv = x[0], yv = x[1], zv = x[2];

    if (!isfinite(xv) || !isfinite(yv) || !isfinite(zv)) {
        return result;
    }

    /* Apply rescaling */
    double dx = d ? d[0] : 1.0;
    double dy = d ? d[1] : 1.0;
    double dz = d ? d[2] : 1.0;
    if (dx <= 0.0) dx = 1.0;
    if (dy <= 0.0) dy = 1.0;
    if (dz <= 0.0) dz = 1.0;

    /* Check feasibility: x >= 0, y >= 0 in rescaled space */
    if (xv / dx < 0.0 || yv / dy < 0.0) {
        return result;
    }

    /* Compute slack = x^α * y^(1-α) - |z| */
    double x_scaled = xv / dx;
    double y_scaled = yv / dy;
    double z_scaled = zv / dz;

    /* Use stable computation: x^α * y^(1-α) = exp(α*log(x) + (1-α)*log(y)) */
    if (x_scaled < 1e-300 || y_scaled < 1e-300) {
        return result;  /* log overflow */
    }

    double log_h = alpha * log(x_scaled) + (1.0 - alpha) * log(y_scaled);
    if (!isfinite(log_h) || log_h > 700.0) {
        return result;
    }
    double h = exp(log_h);
    double abs_z = fabs(z_scaled);
    double slack = h - abs_z;

    result.slack = slack;
    result.feasible = (slack >= 0.0 && xv >= 0.0 && yv >= 0.0);

    if (!result.feasible || !isfinite(slack) || slack <= 0.0 || h < 1e-15) {
        result.rho = 0.0;
        return result;
    }

    result.rho = clamp_rho(slack / h);
    return result;
}

/* =============================================================================
 * Section 6: Generic Dispatcher
 * ============================================================================= */

boundary_metric_t boundary_metric_generic(
    cone_type_t cone_type,
    int v_dim,
    const double *x,
    const double *d,
    double alpha,
    bool is_dual
)
{
    (void)is_dual;  /* All PDHCG cones are self-dual; is_dual is for bookkeeping */

    switch (cone_type) {
        case CONE_ROTATED_SOC:
            /* RSOC: x = (v[0..k-1], s, t), total size = k + 2 */
            return boundary_metric_rsoc(v_dim, x, d);

        case CONE_STANDARD_SOC:
            /* StdSOC: x = (t, u[0..k-1]), total size = k + 1 */
            return boundary_metric_std_soc(v_dim, x, d);

        case CONE_EXPONENTIAL:
            /* EXP: x = (x1, x2, x3), v_dim is not used */
            (void)v_dim;
            return boundary_metric_exp(x, d);

        case CONE_POWER:
            /* Power: x = (x, y, z), v_dim is not used */
            (void)v_dim;
            return boundary_metric_power(x, alpha, d);

        default:
            return (boundary_metric_t){0.0, 0.0, false};
    }
}

/* =============================================================================
 * Section 7: Trigger Decision
 * ============================================================================= */

bool should_trigger_by_rho(double rho, double rho_threshold, cone_kind_t cone_kind)
{
    (void)cone_kind;  /* Available for future logging */

    /* Trigger when close to boundary: small rho means close to boundary */
    if (rho <= 0.0) return false;  /* At boundary or infeasible: skip (let fallback handle) */
    if (rho > rho_threshold) return false;  /* Too far from boundary */
    return true;
}

/* =============================================================================
 * Section 8: Max-ratio to rho threshold conversion
 * ============================================================================= */

double max_ratio_to_rho_threshold(double max_ratio, cone_type_t cone_type)
{
    if (max_ratio <= 1.0) return 1.0;

    /* SOC/RSOC: sqrt formula
     *   inner < 1/max_ratio  =>  rho < 1/sqrt(max_ratio)
     */
    if (cone_type == CONE_ROTATED_SOC || cone_type == CONE_STANDARD_SOC) {
        return 1.0 / sqrt(max_ratio);
    }

    /* EXP/Power: linear formula
     *   slack < 1/max_ratio, rho = slack/x1, x1 ~ 1  =>  rho < 1/max_ratio
     */
    return 1.0 / max_ratio;
}

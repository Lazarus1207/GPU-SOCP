/*
================================================================================
barrier_trigger.c - Trigger Decision Engine Implementation
================================================================================
*/

#include "barrier_trigger.h"
#include <math.h>
#include <stdio.h>

/* =============================================================================
 * Section 1: μ Scheduling (PDCS Stage 1 + Stage 2)
 * ============================================================================= */

double compute_barrier_mu(
    const barrier_params_t *params,
    barrier_state_t *state,
    cone_kind_t kind,
    int iter,
    double rho,
    double gap)
{
    if (!params || !state) return 1.0;

    /* Select per-cone mu_init (PDCS-aligned)
     * If a per-cone override is non-zero, use it; otherwise fall back to global.
     */
    double mu_init;
    switch (kind) {
        case CONE_KIND_RSOC_PRIMAL:
        case CONE_KIND_RSOC_DUAL:
            mu_init = (params->soc_rsoc_mu_init > 0.0)
                      ? params->soc_rsoc_mu_init : params->barrier_mu_init;
            break;
        case CONE_KIND_STD_SOC_PRIMAL:
        case CONE_KIND_STD_SOC_DUAL:
            mu_init = (params->std_soc_mu_init > 0.0)
                      ? params->std_soc_mu_init : params->barrier_mu_init;
            break;
        case CONE_KIND_EXP_PRIMAL:
        case CONE_KIND_EXP_DUAL:
            mu_init = (params->exp_mu_init > 0.0)
                      ? params->exp_mu_init : params->barrier_mu_init;
            break;
        case CONE_KIND_POWER_PRIMAL:
        case CONE_KIND_POWER_DUAL:
            mu_init = (params->power_mu_init > 0.0)
                      ? params->power_mu_init : params->barrier_mu_init;
            break;
        default:
            mu_init = params->barrier_mu_init;
    }

    double mu = state->mu_current[kind];
    double mu_final = params->barrier_mu_final;
    double rho_thresh = state->rho_threshold[kind];

    switch (params->barrier_mu_strategy) {
        case BARRIER_MU_CONSTANT:
            /* PDCS :constant default: fixed mu throughout */
            state->mu_current[kind] = mu_init;
            return mu_init;

        case BARRIER_MU_EXPONENTIAL:
            /* PDCS :exponential
             *   mu_k = mu_init * mu_decay^k
             *   This is a homotopy-like schedule that lets mu → mu_final.
             *   Standard IPM would use mu_k = mu_init * decay^(2k)
             *   (factor 2 because PDHG iterates primal+dual per "step").
             */
            mu = mu_init * pow(params->barrier_mu_rho, (double)iter);
            if (mu < mu_final) mu = mu_final;
            state->mu_current[kind] = mu;
            return mu;

        case BARRIER_MU_ADAPTIVE: {
            /* PDCS :adaptive
             *   - If very close to boundary (rho < thresh/2): increase mu (×2, capped at mu_init)
             *   - If gap is small: decrease mu (×0.5, floored at mu_final)
             *   - Stagnation counter: if rho small for >=5 iter, boost mu
             */
            if (rho > 0.0 && rho < rho_thresh * 0.5) {
                mu = mu * 2.0;
                if (mu > mu_init) mu = mu_init;
                state->stagnation_count[kind]++;
            } else {
                state->stagnation_count[kind] = 0;
            }

            /* Decrease mu if gap is small (close to solution) */
            if (isfinite(gap) && gap < params->barrier_gap_threshold) {
                mu = mu * 0.5;
                if (mu < mu_final) mu = mu_final;
            }

            /* Boost mu if stagnant for many iterations */
            if (state->stagnation_count[kind] >= 5) {
                mu = mu * 2.0;
                if (mu > mu_init) mu = mu_init;
                state->stagnation_count[kind] = 0;
            }

            state->mu_current[kind] = mu;
            return mu;
        }

        case BARRIER_MU_HOMOTOPY: {
            /* NEW: Standard interior-point method homotopy
             *
             * mu_k = mu_init / (1 + alpha * iter)^beta
             *
             * This is the textbook IPM mu schedule (mu decreases as a power
             * of iter), converging to 0. User has indicated this will be
             * needed for future full-IPM integration.
             *
             * - alpha (barrier_homotopy_alpha): controls decay rate
             *   Default: 1.0
             * - beta (barrier_homotopy_beta): controls polynomial order
             *   Default: 2.0 → mu ~ 1/iter^2 (quadratic decay, fast but risky)
             *   For safety, use 1.0 → mu ~ 1/iter (linear decay)
             *
             * Note: This will be added as a separate parameter; see
             * barrier_homotopy_alpha and barrier_homotopy_beta below.
             */
            double alpha = params->barrier_homotopy_alpha;
            double beta = params->barrier_homotopy_beta;
            if (alpha <= 0.0) alpha = 1.0;
            if (beta <= 0.0) beta = 2.0;
            double denom = pow(1.0 + alpha * (double)iter, beta);
            mu = mu_init / denom;
            if (mu < mu_final) mu = mu_final;
            state->mu_current[kind] = mu;
            return mu;
        }

        default:
            state->mu_current[kind] = mu_init;
            return mu_init;
    }
}

/* =============================================================================
 * Section 2: L0/L1/L2/L3 Trigger Decision
 * ============================================================================= */

trigger_decision_t decide_trigger(double rho, const trigger_context_t *ctx)
{
    trigger_decision_t dec = {false, TRIGGER_OFF, rho, 1.0};

    if (!ctx || !ctx->params || !ctx->state) return dec;

    const barrier_params_t *params = ctx->params;
    const barrier_state_t *state = ctx->state;
    cone_kind_t kind = ctx->kind;

    /* --- L0: Global switch --- */
    if (!params->barrier_enabled) {
        dec.reason = TRIGGER_OFF;
        return dec;
    }
    if (!state->enabled) {
        dec.reason = TRIGGER_OFF;
        return dec;
    }

    /* --- L0: Check frequency (skip if iter % check_every != 0) --- */
    if (params->barrier_check_every > 1 && ctx->iter > 0) {
        if (ctx->iter % params->barrier_check_every != 0) {
            dec.reason = TRIGGER_CHECK_SKIP;
            return dec;
        }
    }

    /* --- L1: Per-cone trigger mode --- */
    int mode = params->cone_trigger_mode[kind];
    if (mode == 0) {  /* off */
        dec.reason = TRIGGER_OFF;
        return dec;
    }

    /* --- L2: Gap filter (avoid early convergence disruption) --- */
    if (isfinite(ctx->gap) && ctx->gap > params->barrier_gap_threshold) {
        dec.reason = TRIGGER_GAP;
        return dec;
    }

    /* --- L2: Fixed slot check --- */
    if (ctx->is_fixed) {
        dec.reason = TRIGGER_FIXED_SLOT;
        return dec;
    }

    /* --- L2: Numeric check (rho must be finite and non-negative) --- */
    if (!isfinite(rho) || rho < 0.0) {
        dec.reason = TRIGGER_NUMERIC;
        return dec;
    }

    /* --- L2: Mode-specific decision --- */
    double rho_thresh = state->rho_threshold[kind];

    if (mode == 3) {  /* always */
        dec.should_trigger = true;
        dec.reason = TRIGGER_ALWAYS;
        dec.mu = compute_barrier_mu(params, (barrier_state_t *)state, kind,
                                     ctx->iter, rho, ctx->gap);
        return dec;
    }

    /* mode 1 (adaptive) or mode 2 (conservative) */
    if (rho <= rho_thresh && rho > 0.0) {
        dec.should_trigger = true;
        dec.reason = TRIGGER_BOUNDARY;
        dec.mu = compute_barrier_mu(params, (barrier_state_t *)state, kind,
                                     ctx->iter, rho, ctx->gap);
    } else {
        dec.reason = TRIGGER_BOUNDARY;  /* Not triggered, but boundary metric OK */
    }

    return dec;
}

#pragma once

#include <cusparse.h>

// cusparseSpMVOp_bufferSize was introduced in cuSPARSE 12.7.3 (CUDA 13.1 Update 1).
// CUSPARSE_VERSION encoding: major*1000 + minor*100 + patch.
#if defined(CUSPARSE_VERSION) && CUSPARSE_VERSION >= 12703
#define PDHCG_USE_SPMVOP 1
#else
#define PDHCG_USE_SPMVOP 0
#endif

#if !PDHCG_USE_SPMVOP
// The SpMVOp types were added to cusparse.h before the functions
// (e.g. CUDA 13.1 base has the types but not the functions).
// Only provide fallback typedefs for cuSPARSE versions that lack them entirely.
#if !defined(CUSPARSE_VERSION) || CUSPARSE_VERSION < 12700
typedef void *cusparseSpMVOpDescr_t;
typedef void *cusparseSpMVOpPlan_t;
#endif
#endif

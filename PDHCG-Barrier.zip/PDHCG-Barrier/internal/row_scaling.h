/* row_scaling.h -- public C-side row-whitening transform.
 *
 * This is the C-side mirror of the in-package pure-Python
 * PDHCG/python/pdhcg/row_scaling/row_scaling.py whiten_equalities()
 * routine.  See the long comment at the top of row_scaling.c for the
 * transform and the data flow.
 *
 * The public entry point is pdhcg_apply_row_scaling(), which the CLI
 * (cli.c) and the C-side driver (run_benchmark.c) call when:
 *
 *   - params->enable_row_scaling is true,
 *   - 0 < num_constraints <= params->row_scaling_max_rows,
 *   - num_constraints <= num_variables (full row rank required), and
 *   - every constraint row is a finite equality (l == u, finite).
 *
 * On success the transform rewrites the constraint matrix in place,
 * replaces the constraint bounds with the new M @ b vector, and
 * optionally transforms a dual_start vector.  The row map M is
 * retained in thread-local storage so that, after the optimizer
 * returns, the original-space dual can be recovered via
 * pdhcg_recover_dual_from_pending_row_scaling().
 */
#ifndef PDHCG_INTERNAL_ROW_SCALING_H
#define PDHCG_INTERNAL_ROW_SCALING_H

#include "internal_types.h"
#include "pdhcg_types.h"

#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Status enum for pdhcg_apply_row_scaling.  Mirrors the in-Python
 * status values that pdhcg.model.Model.optimize() records in
 * info["RowScalingStatus"]. */
typedef enum {
    PDHCG_ROW_SCALING_APPLIED = 0,
    PDHCG_ROW_SCALING_DISABLED = 1,
    PDHCG_ROW_SCALING_NOT_EQUALITY = 2,
    PDHCG_ROW_SCALING_RANK_DEFICIENT = 3,
    PDHCG_ROW_SCALING_ERROR = 4,
} pdhcg_row_scaling_status_t;

/* Apply the row-whitening transform to `problem` IN PLACE.
 *
 * Pre-conditions (checked internally):
 *   - params->enable_row_scaling must be true
 *   - num_constraints must be in (0, params->row_scaling_max_rows]
 *   - num_constraints <= num_variables
 *   - every row of A must be a finite equality (l == u, finite)
 *
 * On success returns PDHCG_ROW_SCALING_APPLIED and:
 *   - problem->constraint_matrix (CsrComponent) is rewritten in CSR
 *   - problem->constraint_lower_bound and constraint_upper_bound
 *     are both replaced by M @ b
 *   - problem->dual_start (if non-NULL and length m) is replaced
 *     by M^{-T} @ y_old
 *   - the row map M is stashed in thread-local storage for
 *     postsolve.
 *
 * On any failure the input problem is left UNCHANGED and the
 * returned status describes the reason.
 */
pdhcg_row_scaling_status_t pdhcg_apply_row_scaling(
    const pdhg_parameters_t *params,
    qp_problem_t *problem,
    rescale_info_t *rescale_info);

/* Const-cast wrapper (the algorithm needs to rewrite the matrix in
 * place; solver.cu already treats `problem` as a working copy). */
pdhcg_row_scaling_status_t pdhcg_apply_row_scaling_const(
    const pdhg_parameters_t *params,
    const qp_problem_t *problem,
    rescale_info_t *rescale_info);

/* Free the thread-local M buffer, if any.  Safe to call multiple
 * times; subsequent calls are no-ops. */
void pdhcg_release_pending_row_scaling(void);

/* Apply the saved row map's transpose to `dual_solution` in place.
 * `dual_solution` must be a length-m vector; y_orig[i] = sum_j
 * M[j,i] * y_new[j].  Used by solver.cu to recover the original
 * dual after the C core has solved the whitened problem. */
void pdhcg_recover_dual_from_pending_row_scaling(double *dual_solution);

/* Legacy entry point kept for ABI compatibility.  Routes through the
 * thread-local handle. */
void pdhcg_recover_dual_from_row_scaling(
    rescale_info_t *info,
    double *dual_solution);

/* Drop a stale row_scaling handle when rescale_info is freed.  No-op
 * if no handle is set. */
void pdhcg_row_scaling_info_clear(rescale_info_t *info);

/* Human-readable status string ("applied" / "disabled" / ...). */
const char *pdhcg_row_scaling_status_str(pdhcg_row_scaling_status_t s);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* PDHCG_INTERNAL_ROW_SCALING_H */

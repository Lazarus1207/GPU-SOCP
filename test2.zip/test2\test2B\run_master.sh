#!/usr/bin/env bash
# run_master.sh — test2B 全流程 master
# 依次运行 4 个配置: baseline / no_halpern / no_reflection / both_off
# 每次切换 binary 前自动备份，跑完后恢复 baseline。
#
# 用法:
#   ./run_master.sh               # 交互确认
#   ./run_master.sh --confirm    # 直接跑
#   ./run_master.sh --gpu 4      # 指定 GPU
#   ./run_master.sh --step patch  # 只打补丁 + 编译
#   ./run_master.sh --step run   # 只跑实验（不重新 patch）

set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PDHCG_HOME="${PDHCG_HOME:-$HOME/PDHCG}"
BUILD_DIR="${PDHCG_HOME}/build"
BACKUP_TAG="backup_test2B"

# ── 默认参数 ──
CONFIRM="no"
GPU="${GPU:-4}"
TIME_LIMIT="${TIME_LIMIT:-300}"
ITER_LIMIT="${ITER_LIMIT:-100000}"
EPS_OPT="${EPS_OPT:-1e-4}"
EPS_FEAS="${EPS_FEAS:-1e-4}"
STEP="all"

# ── 4 个消融配置 ──
CONFIGS=("baseline" "no_halpern" "no_reflection" "both_off")

# ── 参数解析 ──
while [[ $# -gt 0 ]]; do
    case "$1" in
        --confirm)       CONFIRM="yes"; shift ;;
        --gpu)           GPU="$2"; shift 2 ;;
        --time-limit)    TIME_LIMIT="$2"; shift 2 ;;
        --iter-limit)    ITER_LIMIT="$2"; shift 2 ;;
        --eps-opt)       EPS_OPT="$2"; shift 2 ;;
        --eps-feas)      EPS_FEAS="$2"; shift 2 ;;
        --step)          STEP="$2"; shift 2 ;;
        --help|-h)
            echo "用法: $0 [OPTIONS]"
            echo "  --confirm         直接运行（不确认）"
            echo "  --gpu N           GPU 卡号 (默认 4)"
            echo "  --time-limit SEC  单题时间限制 (默认 300)"
            echo "  --iter-limit N    单题迭代限制 (默认 100000)"
            echo "  --step all|patch|run  all=patch+run, patch=只打补丁编译, run=只跑实验"
            exit 0 ;;
        *) echo "[err] 未知参数: $1" >&2; exit 1 ;;
    esac
done

# ── 检查 ──
if [[ ! -d "${PDHCG_HOME}" ]]; then
    echo "[err] PDHCG_HOME 不存在: ${PDHCG_HOME}" >&2
    exit 1
fi

echo "══════════════════════════════════════════════════════════"
echo "  test2B — Halpern × Reflection 消融实验"
echo "══════════════════════════════════════════════════════════"
echo "  PDHCG_HOME : ${PDHCG_HOME}"
echo "  BUILD_DIR  : ${BUILD_DIR}"
echo "  GPU        : ${GPU}"
echo "  TIME_LIMIT : ${TIME_LIMIT}s"
echo "  配置       : ${CONFIGS[*]}"
echo "  步骤       : ${STEP}"
echo "══════════════════════════════════════════════════════════"

if [[ "${CONFIRM}" != "yes" ]]; then
    echo "按 Enter 开始，或 Ctrl+C 取消..."
    read -r
fi

export CUDA_VISIBLE_DEVICES="${GPU}"

# ── 备份 ──
BACKUP="${BUILD_DIR}/pdhcg.${BACKUP_TAG}"
if [[ ! -f "${BACKUP}" ]]; then
    if [[ -f "${BUILD_DIR}/pdhcg" ]]; then
        cp "${BUILD_DIR}/pdhcg" "${BACKUP}"
        echo "[OK] 原 binary 备份到: ${BACKUP}"
    else
        echo "[WARN] 未找到 ${BUILD_DIR}/pdhcg，跳过备份"
    fi
else
    echo "[OK] 已有备份: ${BACKUP}"
fi

# ── Step: patch ──
if [[ "${STEP}" == "all" || "${STEP}" == "patch" ]]; then
    echo ""
    echo "══════════════════════════════════════════════════════════"
    echo "  阶段 1: 打补丁 + 编译 (4 个配置)"
    echo "══════════════════════════════════════════════════════════"

    for CONFIG in "${CONFIGS[@]}"; do
        echo ""
        echo "┌──────────────────────────────────────────────┐"
        echo "│  patch + compile: ${CONFIG}"
        echo "└──────────────────────────────────────────────┘"

        python3 "${SCRIPT_DIR}/patch_pdhcg.py" \
            --config "${CONFIG}" \
            --src-dir "${PDHCG_HOME}" \
            --build-dir "${BUILD_DIR}"

        if [[ $? -ne 0 ]]; then
            echo "[ERR] patch_pdhcg.py 失败，配置=${CONFIG}" >&2
            continue
        fi

        # 验证 flag
        if "${BUILD_DIR}/pdhcg" --help 2>&1 | grep -q "no_halpern\|no_reflection"; then
            echo "[OK] binary flag 验证通过"
        else
            echo "[WARN] 新 binary 缺少 expected flag"
        fi
    done
fi

# ── Step: run ──
if [[ "${STEP}" == "all" || "${STEP}" == "run" ]]; then
    echo ""
    echo "══════════════════════════════════════════════════════════"
    echo "  阶段 2: 跑实验 (4 配置 × 20 题)"
    echo "══════════════════════════════════════════════════════════"

    for CONFIG in "${CONFIGS[@]}"; do
        echo ""
        echo "┌──────────────────────────────────────────────┐"
        echo "│  实验配置: ${CONFIG}"
        echo "└──────────────────────────────────────────────┘"

        # 切换到该配置的 binary
        if [[ -f "${BUILD_DIR}/pdhcg_${CONFIG}" ]]; then
            cp "${BUILD_DIR}/pdhcg_${CONFIG}" "${BUILD_DIR}/pdhcg"
            echo "[OK] 已切换 pdhcg -> pdhcg_${CONFIG}"
        else
            echo "[WARN] pdhcg_${CONFIG} 不存在，跳过"
            continue
        fi

        # 跑批量
        "${SCRIPT_DIR}/run_all.sh" \
            --gpu "${GPU}" \
            --time-limit "${TIME_LIMIT}" \
            --iter-limit "${ITER_LIMIT}" \
            --eps-opt "${EPS_OPT}" \
            --eps-feas "${EPS_FEAS}" \
            --current-config "${CONFIG}"

        echo "[OK] 配置 ${CONFIG} 完成"
    done

    # 全局汇总
    echo ""
    echo "══════════════════════════════════════════════════════════"
    echo "  阶段 3: 全局汇总"
    echo "══════════════════════════════════════════════════════════"

    RUN_DIR=$(ls -t "$HOME/test2/test2B/results"/run_* 2>/dev/null | head -1)
    if [[ -n "${RUN_DIR}" && -f "${SCRIPT_DIR}/aggregate.py" ]]; then
        python3 "${SCRIPT_DIR}/aggregate.py" "${RUN_DIR}" \
            && echo "[OK] 汇总 -> ${RUN_DIR}/summary.csv + summary.md"
    fi
fi

# ── 恢复 baseline ──
echo ""
echo "══════════════════════════════════════════════════════════"
echo "  恢复 baseline 二进制"
echo "══════════════════════════════════════════════════════════"
if [[ -f "${BACKUP}" ]]; then
    cp "${BACKUP}" "${BUILD_DIR}/pdhcg"
    echo "[OK] 已恢复: ${BUILD_DIR}/pdhcg (来自 ${BACKUP})"
else
    echo "[WARN] 备份不存在，无法恢复。请手动:"
    echo "       cp ${BUILD_DIR}/pdhcg.${BACKUP_TAG} ${BUILD_DIR}/pdhcg"
fi

echo ""
echo "══════════════════════════════════════════════════════════"
echo "  ✅ test2B 完成!"
echo "══════════════════════════════════════════════════════════"
RUN_DIR=$(ls -t "$HOME/test2/test2B/results"/run_* 2>/dev/null | head -1)
if [[ -n "${RUN_DIR}" ]]; then
    echo "结果: ${RUN_DIR}/"
    echo "查看汇总: cat ${RUN_DIR}/summary.md"
fi

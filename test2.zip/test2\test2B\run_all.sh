#!/usr/bin/env bash
# run_all.sh — test2B 批量 runner
# 通过 --current-config 只跑一个配置，或跑全部。
#
# 用法:
#   ./run_all.sh                          # 跑全部 4 配置 × 20 题（一般不用）
#   ./run_all.sh --current-config no_halpern   # 只跑 no_halpern（master 脚本调用）

set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

DATA_DIR="${CBLIB_DATA_DIR:-$HOME/CBLIB/represent_data}"
OUT_ROOT="${OUT_DIR:-$HOME/test2/test2B/results}"
TIME_LIMIT="${TIME_LIMIT:-300}"
ITER_LIMIT="${ITER_LIMIT:-100000}"
EPS_OPT="${EPS_OPT:-1e-4}"
EPS_FEAS="${EPS_FEAS:-1e-4}"
PDHCG_BIN="${PDHCG_BIN:-$HOME/PDHCG/build/pdhcg}"
GPU="${PDHCG_GPU:-4}"

CONFIGS=("baseline" "no_halpern" "no_reflection" "both_off")
PROBLEMS=(
    "bss1" "estein4_A" "pp-n10-d10" "slay04h" "gams01"
    "classical_200_0" "robust_100_0" "shortfall_100_0" "100_0_1_w"
    "achtziger_stolpe06-6.1flowc" "b1bigflowc" "stolpe07-8.1flowc"
    "uflquad-psc-10-100" "du-opt" "tls12" "jha88"
    "LogExpCR-n100-m1200" "gp_dave_1" "sssd-strong-15-4" "fac3"
)

CURRENT_CONFIG=""

while [[ $# -gt 0 ]]; do
    case "$1" in
        --gpu)           GPU="$2"; shift 2 ;;
        --time-limit)    TIME_LIMIT="$2"; shift 2 ;;
        --iter-limit)    ITER_LIMIT="$2"; shift 2 ;;
        --eps-opt)       EPS_OPT="$2"; shift 2 ;;
        --eps-feas)      EPS_FEAS="$2"; shift 2 ;;
        --out-dir)       OUT_ROOT="$2"; shift 2 ;;
        --pdhcg-bin)     PDHCG_BIN="$2"; shift 2 ;;
        --data-dir)      DATA_DIR="$2"; shift 2 ;;
        --current-config) CURRENT_CONFIG="$2"; shift 2 ;;
        --help|-h)
            echo "用法: $0 [OPTIONS]"
            echo "  --current-config C   只跑这一个配置"
            exit 0 ;;
        *) echo "[err] 未知参数: $1" >&2; exit 1 ;;
    esac
done

# 只跑一个配置
if [[ -n "${CURRENT_CONFIG}" ]]; then
    valid=0
    for c in "${CONFIGS[@]}"; do [[ "${c}" == "${CURRENT_CONFIG}" ]] && valid=1 && break; done
    if [[ "${valid}" == "0" ]]; then
        echo "[err] --current-config '${CURRENT_CONFIG}' 不合法" >&2
        exit 1
    fi
    CONFIGS=("${CURRENT_CONFIG}")
fi

export CUDA_VISIBLE_DEVICES="${GPU}"

RUN_DIR="${OUT_ROOT}/run_$(date +%Y%m%d_%H%M%S)"
mkdir -p "${RUN_DIR}"
echo "[run] 结果目录: ${RUN_DIR}"
echo "[run] 配置数: ${#CONFIGS[@]}, 问题数: ${#PROBLEMS[@]}, 总运行: $((${#CONFIGS[@]} * ${#PROBLEMS[@]}))"

TOTAL=$((${#CONFIGS[@]} * ${#PROBLEMS[@]}))
CURRENT=0; SUCCESS=0; FAILED=0

for CONFIG in "${CONFIGS[@]}"; do
    for PROB in "${PROBLEMS[@]}"; do
        CURRENT=$((CURRENT + 1))
        INPUT="${DATA_DIR}/${PROB}.cbf.gz"
        OUT_DIR="${RUN_DIR}/${CONFIG}/${PROB}"

        echo ""
        echo "════════════════════════════════════════════════════════"
        echo "[${CURRENT}/${TOTAL}] config=${CONFIG}  problem=${PROB}"

        if [[ ! -f "${INPUT}" ]]; then
            echo "    -> SKIP (input not found)"
            ((FAILED++))
            continue
        fi

        "${SCRIPT_DIR}/run_one.sh" \
            --config "${CONFIG}" \
            --gpu "${GPU}" \
            "${INPUT}" "${OUT_DIR}" \
            "${TIME_LIMIT}" "${ITER_LIMIT}" "${EPS_OPT}" "${EPS_FEAS}"
        RC=$?

        if [[ -f "${OUT_DIR}/${PROB}.json" ]]; then
            echo "    -> OK  rc=${RC}"
            ((SUCCESS++))
        else
            echo "    -> FAILED  rc=${RC}"
            ((FAILED++))
        fi

        echo "[$(date -Iseconds)] config=${CONFIG} prob=${PROB} rc=${RC}" >> "${RUN_DIR}/run.log"
    done
done

echo ""
echo "════════════════════════════════════════════════════════"
echo "[run] 全部完成 -> ${RUN_DIR}"
echo "[run] 统计: 成功=${SUCCESS}  失败=${FAILED}  总计=${TOTAL}"

if [[ -f "${SCRIPT_DIR}/aggregate.py" ]]; then
    python3 "${SCRIPT_DIR}/aggregate.py" "${RUN_DIR}" \
        && echo "[ok] 汇总 -> ${RUN_DIR}/summary.csv + summary.md"
fi

echo "[run] DONE"

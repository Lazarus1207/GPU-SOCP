#!/usr/bin/env python3
"""
patch_pdhcg.py — 自动修改 PDHCG 源码并重新编译，生成带指定消融配置的二进制。

使用前请阅读 test2B/README.md

配置:
    baseline       不改源码，使用 ~/PDHCG/build/pdhcg 原版
    no_halpern    关闭 Halpern 锚定（weight=1.0，回退到纯 PDHG step）
    no_reflection 关闭 reflected cone projection
    both_off      同时关闭 Halpern + reflection

用法:
    python3 patch_pdhcg.py --config CONFIG [--src-dir DIR] [--build-dir DIR]
    python3 patch_pdhcg.py --list
"""

import os
import sys
import re
import shutil
import subprocess
import argparse
from pathlib import Path


PDHCG_HOME = Path.home() / "PDHCG"
DEFAULT_BUILD = PDHCG_HOME / "build"

PARAMS_NEW_FIELDS = """    // Ablation: Halpern / Reflection toggle
    bool use_halpern;
    bool use_reflection;"""

SET_DEFAULTS_INSERT = """    params->use_halpern = true;
    params->use_reflection = true;"""

CLI_OPTION_ENTRY = """    {"no_halpern",    no_argument, 0, 1026},
    {"no_reflection", no_argument, 0, 1027},"""

CLI_CASE_BODY = """        case 1026:
            params->use_halpern = false;
            break;
        case 1027:
            params->use_reflection = false;
            break;"""

HALPERN_GUARD_ENTER = """void halpern_update(pdhg_solver_state_t *state, double reflection_coefficient)
{
    // Ablation: 如果关闭了 Halpern，直接跳过，用原始 PDHG step
    if (state != NULL && state->params != NULL && !state->params->use_halpern) {
        return;
    }"""

REFLECTION_CALL_OLD = """    recompute_cone_reflection(state);"""
REFLECTION_CALL_NEW = """    // Ablation: 如果关闭了 reflection，跳过 reflected cone projection
    if (state != NULL && state->params != NULL && state->params->use_reflection) {
        recompute_cone_reflection(state);
    }"""


def patch_file(path: Path, old: str, new: str, description: str):
    if not path.exists():
        print(f"[ERR] 文件不存在: {path}", file=sys.stderr)
        return False
    content = path.read_text(encoding="utf-8")
    if old not in content:
        if "use_halpern" in content:
            print(f"[INFO] {description}: {path.name} 已有 use_halpern 字段，跳过")
            return True
        print(f"[WARN] 在 {path.name} 中未找到补丁目标，跳过")
        return False
    new_content = content.replace(old, new, 1)
    path.write_text(new_content, encoding="utf-8")
    print(f"[OK]  {description}: {path.name}")
    return True


def apply_patches(src_dir: Path, config: str):
    types_h = src_dir / "include" / "pdhcg_types.h"
    cli_c   = src_dir / "src" / "cli.c"
    core_cu = src_dir / "src" / "pdhg_core_op.cu"
    changes = []

    if config == "baseline":
        return changes

    # types: 加字段
    marker_types = 'bool diag_jacobi_precond;'
    if patch_file(types_h, marker_types,
                  marker_types + "\n" + PARAMS_NEW_FIELDS,
                  "pdhg_parameters_t 加字段"):
        changes.append("types")

    # types: set_default_parameters
    marker_setdef = 'params->diag_jacobi_precond = true;'
    if patch_file(types_h, marker_setdef,
                  marker_setdef + "\n" + SET_DEFAULTS_INSERT,
                  "set_default_parameters 设默认值"):
        changes.append("set_defaults")

    # cli: long_options
    marker_opts = '{0, 0, 0, 0}};'
    if patch_file(cli_c, marker_opts,
                  CLI_OPTION_ENTRY + "\n" + marker_opts,
                  "cli.c long_options 加条目"):
        changes.append("cli_options")

    # cli: switch
    marker_case = '    case \'?\':\n        return 1;\n    }'
    if patch_file(cli_c, marker_case,
                  CLI_CASE_BODY + "\n" + marker_case,
                  "cli.c switch 加 case"):
        changes.append("cli_switch")

    # halpern_update: 加守卫
    if config in ("no_halpern", "both_off"):
        content = core_cu.read_text(encoding="utf-8")
        old_func = """void halpern_update(pdhg_solver_state_t *state, double reflection_coefficient)
{
    double weight"""
        if old_func in content:
            if patch_file(core_cu, old_func,
                          HALPERN_GUARD_ENTER + "\n" + old_func,
                          "halpern_update 加守卫"):
                changes.append("halpern_guard")
        else:
            pattern = r'(void halpern_update\([^)]+\)\s*\{[^}]*double weight)'
            m = re.search(pattern, content)
            if m:
                old_sig = m.group(1)
                if patch_file(core_cu, old_sig,
                              HALPERN_GUARD_ENTER + "\n" + old_sig,
                              "halpern_update 加守卫(宽松匹配)"):
                    changes.append("halpern_guard")
            else:
                print(f"[WARN] 无法匹配 halpern_update 函数，请手动确认 {core_cu}")

    # recompute_cone_reflection: 加守卫
    if config in ("no_reflection", "both_off"):
        content = core_cu.read_text(encoding="utf-8")
        for cand in ["    recompute_cone_reflection(state);\n",
                     "recompute_cone_reflection(state);\n",
                     "    recompute_cone_reflection(state);"]:
            if cand in content:
                new_cand = "    " + REFLECTION_CALL_NEW.strip()
                if patch_file(core_cu, cand, new_cand,
                              "recompute_cone_reflection 调用加守卫"):
                    changes.append("reflection_guard")
                break
        else:
            print(f"[WARN] 无法匹配 recompute_cone_reflection 调用，请手动确认 {core_cu}")

    return changes


def compile(src_dir: Path, build_dir: Path, config: str, verbose: bool = True):
    cmake_cmd = [
        "cmake", "-S", str(src_dir), "-B", str(build_dir),
        "-DCMAKE_BUILD_TYPE=Release",
    ]
    if verbose:
        print(f"[build] cmake 配置...")
    r = subprocess.run(cmake_cmd, capture_output=True, text=True)
    if r.returncode != 0:
        print(f"[ERR] cmake 失败:\n{r.stderr[-1500:]}", file=sys.stderr)
        return False

    if verbose:
        print(f"[build] make -j4...")
    r = subprocess.run(
        ["cmake", "--build", str(build_dir), "--", "-j4"],
        capture_output=True, text=True
    )
    if r.returncode != 0:
        print(f"[ERR] 编译失败:\n{r.stderr[-1500:]}", file=sys.stderr)
        return False
    if verbose:
        print(f"[build] 编译成功!")
    return True


def main():
    parser = argparse.ArgumentParser(description="PDHCG 源码消融补丁")
    parser.add_argument("--config", "-c",
                        choices=["baseline","no_halpern","no_reflection","both_off"],
                        default=None, help="消融配置")
    parser.add_argument("--src-dir",  default=str(PDHCG_HOME))
    parser.add_argument("--build-dir", default=str(DEFAULT_BUILD))
    parser.add_argument("--list", "-l", action="store_true")
    parser.add_argument("--no-compile", action="store_true")
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()

    if args.list:
        print("可用配置:")
        for c, d in [("baseline","不改源码，使用原版"),
                      ("no_halpern","关闭 Halpern 锚定（weight=1）"),
                      ("no_reflection","关闭 reflected cone projection"),
                      ("both_off","同时关闭两者")]:
            print(f"  {c:20s}  {d}")
        return

    if args.config is None:
        parser.print_help()
        return

    config    = args.config
    src_dir   = Path(args.src_dir)
    build_dir = Path(args.build_dir)

    # 仅检查关键文件
    critical = [src_dir/"include/pdhcg_types.h", src_dir/"src/cli.c"]
    missing = [f for f in critical if not f.exists()]
    if missing:
        for f in missing:
            print(f"[ERR] 源码文件不存在: {f}", file=sys.stderr)
        sys.exit(1)

    print(f"[patch_pdhcg] 配置: {config}")
    print(f"[patch_pdhcg] 源码: {src_dir}")

    if config == "baseline":
        print("[OK] baseline: 不改源码")
        return

    types_h = src_dir / "include" / "pdhcg_types.h"
    already = "use_halpern" in types_h.read_text(encoding="utf-8")
    if already and not args.force:
        print("[INFO] 检测到源码已被修改，使用 --force 强制重新打补丁")
        sys.exit(0)

    changes = apply_patches(src_dir, config)
    print(f"[patch] 已修改: {', '.join(changes) if changes else '无'}")

    if args.no_compile:
        print("[skip] --no-compile，跳过编译")
        return

    ok = compile(src_dir, build_dir, config)
    if not ok:
        sys.exit(1)

    named_bin = build_dir / f"pdhcg_{config}"
    src_bin   = build_dir / "pdhcg"
    shutil.copy2(src_bin, named_bin)
    print(f"[OK] 命名二进制: {named_bin}")
    print(f"[OK] 默认 pdhcg 已更新")


if __name__ == "__main__":
    main()

# PDHCG 消融实验 — Test2

## 概述

Test2 分为两个独立的部分：

| 部分 | 名称 | 对比维度 | 是否改源码 |
|------|------|---------|-----------|
| **Part A** | `test2A/` | Diagonal Rescaling（开 / 关） | 否 |
| **Part B** | `test2B/` | Halpern × Reflection 组合（4 配置） | 是 |

---

## Part A: Diagonal Rescaling 对比

**目标**: 评估 Jacobi 对角预条件（diagonal rescaling）对收敛速度的影响。

**配置**:

| 配置 | 命令行参数 |
|------|-----------|
| baseline | 默认（全开） |
| no_diag_precond | `--no_diag_precond` |

**流程**:

```bash
# 1. 上传到服务器（~/test2/test2A/）

# 2. 先验证 1 题
./run_one.sh --config baseline \
    ~/CBLIB/represent_data/bss1.cbf.gz \
    /tmp/test2a_trial 300 100000 1e-4 1e-4

# 3. 批量跑全部
./run_all.sh --gpu 4
```

**输出**:

```
~/test2/test2A/results/run_<timestamp>/
├── baseline/
│   ├── bss1/bss1.json
│   └── ...
├── no_diag_precond/
│   ├── bss1/bss1.json
│   └── ...
├── summary.csv
└── summary.md
```

---

## Part B: Halpern × Reflection 对比

**目标**: 评估 reflected Halpern scheme 中 Halpern 锚定和 reflection cone projection 的各自贡献。

**配置**:

| 配置 | 参数组合 | 含义 |
|------|---------|------|
| baseline | (默认) | 全开 |
| no_halpern | `--no_halpern` | 关闭 Halpern 锚定，weight=1 |
| no_reflection | `--no_reflection` | 关闭 reflected cone projection |
| both_off | `--no_halpern --no_reflection` | 同时关闭两者 |

**完整流程**:

```bash
# 1. 上传到服务器（~/test2/test2B/）

# 2. 验证 patch_pdhcg.py 可运行
python3 patch_pdhcg.py --list

# 3. 一次性跑完全部（自动备份、patch、编译、跑实验、恢复 baseline）
./run_master.sh --gpu 4 --confirm
```

`run_master.sh` 执行顺序：
1. 备份 `~/PDHCG/build/pdhcg` → `pdhcg.backup_test2B`
2. 依次 patch + 编译 + 跑实验：baseline → no_halpern → no_reflection → both_off
3. 恢复 baseline 二进制
4. 全局汇总（4 配置一起）

**如需单独步骤**:

```bash
# 只打补丁 + 编译（不跑实验）
./run_master.sh --step patch --confirm

# 只跑实验（假设补丁已打好）
./run_master.sh --step run --confirm

# 恢复 baseline 二进制（万一流程中断）
cp ~/PDHCG/build/pdhcg.backup_test2B ~/PDHCG/build/pdhcg
```

**输出**:

```
~/test2/test2B/results/run_<timestamp>/
├── baseline/bss1/bss1.json
├── no_halpern/bss1/bss1.json
├── no_reflection/bss1/bss1.json
├── both_off/bss1/bss1.json
├── summary.csv
└── summary.md
```

---

## 共通信息

**数据集**: `~/CBLIB/represent_data/*.cbf.gz`（20 题，按类型平衡）

**20 题列表**:
```
bss1, estein4_A, pp-n10-d10, slay04h, gams01,
classical_200_0, robust_100_0, shortfall_100_0, 100_0_1_w,
achtziger_stolpe06-6.1flowc, b1bigflowc, stolpe07-8.1flowc,
uflquad-psc-10-100, du-opt, tls12, jha88,
LogExpCR-n100-m1200, gp_dave_1, sssd-strong-15-4, fac3
```

**通用参数**（两部分相同）:

| 参数 | 值 | 说明 |
|------|----|------|
| `--time_limit` | 300 s | 单题上限 |
| `--iter_limit` | 100,000 | 迭代上限 |
| `--eps_opt` | 1e-4 | 最优性容差 |
| `--eps_feas` | 1e-4 | 可行性容差 |

**GPU**: 建议选 nvidia-smi 中最闲的那张卡。

---

## 文件清单

```
test2/
├── README.md                    ← 本文件
├── test2A/                      ← Part A: Diagonal Rescaling
│   ├── run_one.sh              单题 runner
│   ├── run_all.sh              批量 runner
│   └── aggregate.py            汇总脚本
└── test2B/                     ← Part B: Halpern × Reflection
    ├── README.md               详细说明
    ├── patch_pdhcg.py          源码补丁 + 编译
    ├── run_one.sh              单题 runner
    ├── run_all.sh              批量 runner（单配置版）
    ├── run_master.sh           全流程 master
    └── aggregate.py            汇总脚本
```

---

## 注意事项

1. **test2A 不改源码，test2B 会改源码** — 两者可独立运行，不会互相影响
2. Part B 完成后会自动恢复 baseline 二进制；如果中途 Ctrl+C，需手动恢复：
   ```bash
   cp ~/PDHCG/build/pdhcg.backup_test2B ~/PDHCG/build/pdhcg
   ```
3. 所有结果都在 `~/test2/test2A/results/` 和 `~/test2/test2B/results/`，不会覆盖
4. `aggregate.py` 生成的 `summary.md` 可直接粘回实验报告

---

*整理: 钟颍泽 | 2026-08-14*

#!/usr/bin/env bash
# run_all.sh — test2A 批量 runner
# 同时跑 baseline 和 no_diag_precond，输出到同一目录。
#
# 用法:
#   ./run_all.sh                # 默认参数
#   ./run_all.sh --gpu 4
#   ./run_all.sh --time-limit 300

set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

DATA_DIR="${CBLIB_DATA_DIR:-$HOME/CBLIB/represent_data}"
OUT_ROOT="${OUT_DIR:-$HOME/test2/test2A/results}"
TIME_LIMIT="${TIME_LIMIT:-300}"
ITER_LIMIT="${ITER_LIMIT:-100000}"
EPS_OPT="${EPS_OPT:-1e-4}"
EPS_FEAS="${EPS_FEAS:-1e-4}"
PDHCG_BIN="${PDHCG_BIN:-$HOME/PDHCG/build/pdhcg}"
GPU="${PDHCG_GPU:-4}"

CONFIGS=("baseline" "no_diag_precond")
PROBLEMS=(
    "bss1" "estein4_A" "pp-n10-d10" "slay04h" "gams01"
    "classical_200_0" "robust_100_0" "shortfall_100_0" "100_0_1_w"
    "achtziger_stolpe06-6.1flowc" "b1bigflowc" "stolpe07-8.1flowc"
    "uflquad-psc-10-100" "du-opt" "tls12" "jha88"
    "LogExpCR-n100-m1200" "gp_dave_1" "sssd-strong-15-4" "fac3"
)

while [[ $# -gt 0 ]]; do
    case "$1" in
        --gpu)          GPU="$2"; shift 2 ;;
        --time-limit)   TIME_LIMIT="$2"; shift 2 ;;
        --iter-limit)   ITER_LIMIT="$2"; shift 2 ;;
        --eps-opt)      EPS_OPT="$2"; shift 2 ;;
        --eps-feas)     EPS_FEAS="$2"; shift 2 ;;
        --out-dir)      OUT_ROOT="$2"; shift 2 ;;
        --pdhcg-bin)    PDHCG_BIN="$2"; shift 2 ;;
        --data-dir)     DATA_DIR="$2"; shift 2 ;;
        --help|-h)
            echo "用法: $0 [OPTIONS]"
            exit 0 ;;
        *) echo "[err] 未知参数: $1" >&2; exit 1 ;;
    esac
done

export CUDA_VISIBLE_DEVICES="${GPU}"

RUN_DIR="${OUT_ROOT}/run_$(date +%Y%m%d_%H%M%S)"
mkdir -p "${RUN_DIR}"
echo "[run] 结果目录: ${RUN_DIR}"
echo "[run] 配置: ${CONFIGS[*]}"
echo "[run] 问题数: ${#PROBLEMS[@]}  总运行: $((${#CONFIGS[@]} * ${#PROBLEMS[@]}))"

TOTAL=$((${#CONFIGS[@]} * ${#PROBLEMS[@]}))
CURRENT=0; SUCCESS=0; FAILED=0

for CONFIG in "${CONFIGS[@]}"; do
    for PROB in "${PROBLEMS[@]}"; do
        CURRENT=$((CURRENT + 1))
        INPUT="${DATA_DIR}/${PROB}.cbf.gz"
        OUT_DIR="${RUN_DIR}/${CONFIG}/${PROB}"

        echo ""
        echo "════════════════════════════════════════════════════════"
        echo "[${CURRENT}/${TOTAL}] config=${CONFIG}  problem=${PROB}"

        if [[ ! -f "${INPUT}" ]]; then
            echo "    -> SKIP (input not found: ${INPUT})"
            ((FAILED++))
            continue
        fi

        "${SCRIPT_DIR}/run_one.sh" \
            --config "${CONFIG}" \
            --gpu "${GPU}" \
            "${INPUT}" "${OUT_DIR}" \
            "${TIME_LIMIT}" "${ITER_LIMIT}" "${EPS_OPT}" "${EPS_FEAS}"
        RC=$?

        if [[ -f "${OUT_DIR}/${PROB}.json" ]]; then
            echo "    -> OK  rc=${RC}"
            ((SUCCESS++))
        else
            echo "    -> FAILED  rc=${RC}"
            ((FAILED++))
        fi

        echo "[$(date -Iseconds)] config=${CONFIG} prob=${PROB} rc=${RC}" >> "${RUN_DIR}/run.log"
    done
done

echo ""
echo "════════════════════════════════════════════════════════"
echo "[run] 全部完成 -> ${RUN_DIR}"
echo "[run] 统计: 成功=${SUCCESS}  失败=${FAILED}  总计=${TOTAL}"

if [[ -f "${SCRIPT_DIR}/aggregate.py" ]]; then
    python3 "${SCRIPT_DIR}/aggregate.py" "${RUN_DIR}" \
        && echo "[ok] 汇总 -> ${RUN_DIR}/summary.csv + summary.md"
fi

echo "[run] DONE"

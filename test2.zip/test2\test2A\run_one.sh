#!/usr/bin/env bash
# run_one.sh — test2A 单题 runner
# 配置: baseline | no_diag_precond
#
# 用法:
#   ./run_one.sh --config CONFIG INPUT PROBLEM_DIR TIME_LIMIT ITER_LIMIT EPS_OPT EPS_FEAS
# 示例:
#   ./run_one.sh --config baseline ~/CBLIB/represent_data/bss1.cbf.gz /tmp/out 300 100000 1e-4 1e-4

set -uo pipefail

CONFIG="baseline"
GPU="${PDHCG_GPU:-4}"
PDHCG_BIN="${PDHCG_BIN:-$HOME/PDHCG/build/pdhcg}"

while [[ $# -gt 0 ]]; do
    case "$1" in
        --config) CONFIG="$2"; shift 2 ;;
        --gpu)    GPU="$2"; shift 2 ;;
        *)        break ;;
    esac
done

INPUT="$1"; shift || { echo "[err] 缺少 INPUT" >&2; exit 1; }
PROBLEM_DIR="${1:-.}"; shift
TIME_LIMIT="${1:-300}"; shift
ITER_LIMIT="${1:-100000}"; shift
EPS_OPT="${1:-1e-4}"; shift
EPS_FEAS="${1:-1e-4}"

case "${CONFIG}" in
    baseline)         CONFIG_FLAGS="" ;;
    no_diag_precond)  CONFIG_FLAGS="--no_diag_precond" ;;
    *)
        echo "[err] 未知 config: ${CONFIG}" >&2
        echo "       可用: baseline | no_diag_precond" >&2
        exit 1 ;;
esac

if [[ ! -x "${PDHCG_BIN}" ]]; then
    echo "[err] 找不到 PDHCG 二进制: ${PDHCG_BIN}" >&2
    exit 1
fi

mkdir -p "${PROBLEM_DIR}"
NAME="$(basename "${INPUT}" .cbf.gz)"
LOG="${PROBLEM_DIR}/log.txt"
JSON_OUT="${PROBLEM_DIR}/${NAME}.json"

export CUDA_VISIBLE_DEVICES="${GPU}"

echo "[test2A] config=${CONFIG}  problem=${NAME}"
echo "  binary: ${PDHCG_BIN}"
echo "  flags:  ${CONFIG_FLAGS:-(none)}"

START=$(date +%s.%N)
START_ISO=$(date -Iseconds)

set +e
"${PDHCG_BIN}" \
    -v 2 \
    --time_limit "${TIME_LIMIT}" \
    --iter_limit "${ITER_LIMIT}" \
    --eps_opt "${EPS_OPT}" \
    --eps_feas "${EPS_FEAS}" \
    ${CONFIG_FLAGS} \
    "${INPUT}" "${PROBLEM_DIR}" \
    > "${LOG}" 2>&1
RC=$?
set -e

END=$(date +%s.%N)
WALL=$(echo "${END} - ${START}" | bc 2>/dev/null || echo "0")

SUMMARY_TXT="${PROBLEM_DIR}/${NAME}_summary.txt"
STATUS="UNKNOWN"; ITER="-1"; RT="-1"
P_OBJ=""; D_OBJ=""; GAP=""; P_FEAS=""; D_FEAS=""

if [[ -f "${SUMMARY_TXT}" ]]; then
    STATUS=$(grep -i "optimal\|incomplete\|time.limit\|error" "${SUMMARY_TXT}" | head -1 | xargs)
    ITER=$(grep "iterations" "${SUMMARY_TXT}" 2>/dev/null | awk '{print $NF}')
    RT=$(grep "runtime" "${SUMMARY_TXT}" 2>/dev/null | awk '{print $NF}')
    P_OBJ=$(grep "primal_objective" "${SUMMARY_TXT}" 2>/dev/null | awk '{print $NF}')
    D_OBJ=$(grep "dual_objective" "${SUMMARY_TXT}" 2>/dev/null | awk '{print $NF}')
    GAP=$(grep "relative_gap" "${SUMMARY_TXT}" 2>/dev/null | awk '{print $NF}')
    P_FEAS=$(grep "primal_feasibility" "${SUMMARY_TXT}" 2>/dev/null | awk '{print $NF}')
    D_FEAS=$(grep "dual_feasibility" "${SUMMARY_TXT}" 2>/dev/null | awk '{print $NF}')
fi

cat > "${JSON_OUT}" <<EOF
{
  "problem": "${NAME}",
  "ablation_config": "${CONFIG}",
  "config_flags": "${CONFIG_FLAGS}",
  "status": "${STATUS}",
  "exit_code": ${RC},
  "iterations": ${ITER},
  "runtime_sec": ${RT},
  "wall_sec": ${WALL},
  "primal_obj": ${P_OBJ:-null},
  "dual_obj": ${D_OBJ:-null},
  "rel_gap": ${GAP:-null},
  "primal_feas": ${P_FEAS:-null},
  "dual_feas": ${D_FEAS:-null},
  "timestamp_start": "${START_ISO}",
  "timestamp_end": "$(date -Iseconds)",
  "log_file": "${LOG}"
}
EOF

echo "  status=${STATUS}  iter=${ITER}  rt=${RT}s"
exit ${RC}

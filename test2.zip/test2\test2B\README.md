# test2B — Halpern × Reflection 消融实验

## 目标

评估 PDHCG-II 的 Reflected Halpern scheme 中两个核心技巧的各自贡献：

| 配置 | 命令行参数 | 含义 |
|------|-----------|------|
| baseline | (默认) | 全开：Halpern 锚定（weight=(k+1)/(k+2)）+ reflected cone projection（ρ=1） |
| no_halpern | `--no_halpern` | 关闭 Halpern 锚定，weight 固定为 1，回退到纯 PDHG step |
| no_reflection | `--no_reflection` | 关闭 reflected cone projection，跳过 `recompute_cone_reflection()` 调用 |
| both_off | `--no_halpern --no_reflection` | 同时关闭两者 |

## 工作原理

### 源码改动

通过 `patch_pdhcg.py` 在 PDHCG 源码的 3 个关键位置自动注入代码：

**`include/pdhcg_types.h`** — `pdhg_parameters_t` 结构体：

```c
// 在 "bool diag_jacobi_precond;" 后加：
    bool use_halpern;
    bool use_reflection;
```

**`src/cli.c`** — CLI 选项：

```c
// getopt_long 表：
{"no_halpern",    no_argument, 0, 1026},
{"no_reflection", no_argument, 0, 1027},

// switch:
case 1026: params->use_halpern = false; break;
case 1027: params->use_reflection = false; break;
```

**`src/pdhhg_core_op.cu`** — 逻辑守卫：

```c
// halpern_update() 函数开头：
if (!params->use_halpern) { return; }

// recompute_cone_reflection() 调用点：
if (params->use_reflection) {
    recompute_cone_reflection(state);
}
```

每次运行 `patch_pdhcg.py` 生成一个命名二进制 `~/PDHCG/build/pdhcg_<CONFIG>`，默认 `pdhcg` 指向最近一次 patch 的版本。

## 用法

### 推荐：一次性跑完

```bash
# 上传到服务器 ~/test2/test2B/
# 验证脚本
python3 patch_pdhcg.py --list

# 一次性跑完（自动备份、patch、compile、run、restore）
./run_master.sh --gpu 4 --confirm
```

`run_master.sh` 执行流程：

```
1. 备份 ~/PDHCG/build/pdhcg → pdhcg.backup_test2B
2. patch + compile: baseline
3. patch + compile: no_halpern
4. patch + compile: no_reflection
5. patch + compile: both_off
6. 依次切 binary、跑实验（4 × 20 题）
7. 全局汇总 → summary.csv + summary.md
8. 恢复 baseline 二进制（来自 backup）
```

### 分步骤运行

```bash
# 只打补丁 + 编译（不跑实验）
./run_master.sh --step patch --confirm

# 只跑实验（假设补丁已打好）
./run_master.sh --step run --confirm

# 手动恢复 baseline（如流程中断）
cp ~/PDHCG/build/pdhcg.backup_test2B ~/PDHCG/build/pdhcg
```

### 手动单题验证

```bash
# 先切到对应 binary
cp ~/PDHCG/build/pdhcg_no_halpern ~/PDHCG/build/pdhcg

# 单题
./run_one.sh --config no_halpern --gpu 4 \
    ~/CBLIB/represent_data/bss1.cbf.gz \
    /tmp/test2b_trial 300 100000 1e-4 1e-4

# 验证 JSON
cat /tmp/test2b_trial/bss1.json | python3 -m json.tool
```

## 输出

```
~/test2/test2B/results/run_<timestamp>/
├── baseline/bss1/bss1.json
├── baseline/estein4_A/estein4_A.json
├── ...
├── no_halpern/bss1/bss1.json
├── ...
├── no_reflection/...
├── both_off/...
├── summary.csv          ← 长表（可导入 Excel）
└── summary.md          ← Markdown 对比表
```

## 查看汇总

```bash
RUN=$(ls -t ~/test2/test2B/results/run_* | head -1)
cat $RUN/summary.md
```

## 注意事项

1. **必须用 `--confirm`** 才能跳过交互确认，否则会一直等待按 Enter
2. **不要中途 Ctrl+C** — 如果中断了，先恢复 baseline 再重跑：
   ```bash
   cp ~/PDHCG/build/pdhcg.backup_test2B ~/PDHCG/build/pdhcg
   ```
3. 每次 patch 会覆盖默认 `pdhcg`，用 `pdhcg_<CONFIG>` 做命名快照
4. `--force` 参数可强制重新打补丁（会丢失之前补丁、保留备份）

## 预估时间

| 阶段 | 耗时 |
|------|------|
| 编译（4 个配置） | ~10-20 分钟 |
| 实验（4 × 20 题） | 实际基于 Test1 数据：~1-2 小时（最坏 ~6 小时） |
| 汇总 | < 1 秒 |

---

*整理: 钟颍泽 | 2026-08-14*

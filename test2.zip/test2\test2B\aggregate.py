#!/usr/bin/env python3
"""
aggregate.py — test2B 汇总: 读取 run_root 下的 JSON，输出 summary.csv + summary.md

输入: run_root 目录（含 <config>/<problem>/<problem>.json）
输出: summary.csv, summary.md
"""

import sys, json, csv, math
from pathlib import Path

PROBLEM_TYPES = {
    "bss1": "LP",          "estein4_A": "LP",
    "pp-n10-d10": "LP",    "slay04h": "LP-MINLP",
    "gams01": "LP-MINLP",
    "classical_200_0": "SOC-portfolio", "robust_100_0": "SOC-portfolio",
    "shortfall_100_0": "SOC-portfolio", "100_0_1_w": "SOC-portfolio",
    "achtziger_stolpe06-6.1flowc": "SOC-structural",
    "b1bigflowc": "SOC-structural",    "stolpe07-8.1flowc": "SOC-structural",
    "uflquad-psc-10-100": "SOC-QP",   "du-opt": "SOC-QP",
    "tls12": "SOC-mixed",              "jha88": "SOC-mixed",
    "LogExpCR-n100-m1200": "EXP",      "gp_dave_1": "EXP-GP",
    "sssd-strong-15-4": "QP",          "fac3": "LP-MINLP",
}
TYPE_GROUP = {
    "LP": "LP", "LP-MINLP": "LP",
    "SOC-portfolio": "SOC", "SOC-structural": "SOC",
    "SOC-QP": "SOC", "SOC-mixed": "SOC",
    "EXP": "EXP", "EXP-GP": "EXP", "QP": "QP",
}


def load_json(path):
    try:
        with open(path) as f:
            return json.load(f)
    except Exception:
        return None


def sf(x):
    try:
        v = float(x)
        return None if (math.isnan(v) or math.isinf(v)) else v
    except Exception:
        return None


def fmt(x, sci=False):
    if x is None: return "—"
    if isinstance(x, str): return x
    try:
        v = float(x)
        if math.isnan(v) or math.isinf(v): return "—"
        if sci: return f"{v:.2e}"
        if v >= 1000: return f"{v:,.1f}"
        return f"{v:.3f}"
    except Exception:
        return str(x)


def main():
    if len(sys.argv) < 2:
        print("[err] 用法: aggregate.py <run_root>")
        sys.exit(1)

    run_root = Path(sys.argv[1])
    if not run_root.exists():
        print(f"[err] run_root 不存在: {run_root}")
        sys.exit(1)

    # glob: <config>/<problem>/<problem>.json
    records = []
    for jp in sorted(run_root.glob("*/*/*.json")):
        rec = load_json(jp)
        if rec is None:
            print(f"[warn] 跳过: {jp}")
            continue
        parts = jp.parts
        if len(parts) >= 2:
            rec.setdefault("ablation_config", parts[-3])
            rec.setdefault("problem", parts[-2])
        records.append(rec)

    if not records:
        print("[warn] 没找到任何 JSON")
        return

    # CSV
    fields = ["problem","ablation_config","config_flags","status","exit_code",
              "runtime_sec","iterations","primal_obj","dual_obj","rel_gap",
              "primal_feas","dual_feas","wall_sec","timestamp_start"]
    csv_path = run_root / "summary.csv"
    with open(csv_path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        w.writerows(records)
    print(f"[ok] CSV -> {csv_path}")

    # MD
    md_path = run_root / "summary.md"
    write_md(md_path, records)
    print(f"[ok] MD  -> {md_path}")


def write_md(path, records):
    configs = sorted({r.get("ablation_config","?") for r in records})
    problems = sorted({r.get("problem","?") for r in records})
    if "baseline" in configs:
        configs.remove("baseline")
        configs = ["baseline"] + configs

    rec_idx = {(r.get("problem",""), r.get("ablation_config","")): r for r in records}

    with open(path, "w") as f:
        f.write("# PDHCG 消融实验汇总 (test2B)\n\n")
        f.write(f"- 记录: {len(records)} | 配置: {len(configs)} | 问题: {len(problems)}\n\n")

        # 表A: 逐题 pivot
        f.write("## 各配置逐题结果\n\n")
        f.write("| problem | type |")
        for cfg in configs:
            f.write(f" {cfg} rt | {cfg} iter | {cfg} status |")
        f.write(" Δrt% |\n")
        f.write("|---|---" + " --- | --- | --- |" * len(configs) + " --- |\n")
        for prob in problems:
            typ = PROBLEM_TYPES.get(prob, "?")
            row = f"| {prob} | {typ} |"
            base_r = rec_idx.get((prob,"baseline"))
            base_rt = sf(base_r.get("runtime_sec")) if base_r else None
            for cfg in configs:
                r = rec_idx.get((prob, cfg))
                if r is None:
                    row += " — | — | MISSING |"
                else:
                    rt = sf(r.get("runtime_sec"))
                    it = sf(r.get("iterations"))
                    st = r.get("status","-")
                    row += f" {fmt(rt)} | {fmt(it)} | {st} |"
            if base_rt and configs:
                last_r = rec_idx.get((prob, configs[-1]))
                last_rt = sf(last_r.get("runtime_sec")) if last_r else None
                if last_rt and base_rt > 0:
                    d = (last_rt - base_rt) / base_rt * 100
                    row += f" {d:+.1f}% |"
                else:
                    row += " — |"
            else:
                row += " — |"
            f.write(row + "\n")

        # 表B: 整体小计
        f.write("\n## 整体小计 (OPTIMAL 记录，几何平均)\n\n")
        f.write("| config | gm_rt (s) | gm_iter | success |\n")
        f.write("|---|---|---|---|\n")
        for cfg in configs:
            rts, its, opt_n, tot_n = [], [], 0, 0
            for prob in problems:
                r = rec_idx.get((prob, cfg))
                if r is None: continue
                tot_n += 1
                if r.get("status") == "OPTIMAL":
                    opt_n += 1
                    rt = sf(r.get("runtime_sec"))
                    it = sf(r.get("iterations"))
                    if rt: rts.append(rt)
                    if it: its.append(it)
            gm_rt = math.exp(sum(math.log(x) for x in rts) / len(rts)) if rts else None
            gm_it = math.exp(sum(math.log(x) for x in its) / len(its)) if its else None
            f.write(f"| {cfg} | {fmt(gm_rt)} | {fmt(gm_it)} | {opt_n}/{tot_n} |\n")

        # 表C: 类型分组
        f.write("\n## 类型分组小计\n\n")
        for grp in sorted(set(TYPE_GROUP.values())):
            probs = [p for p in problems if TYPE_GROUP.get(PROBLEM_TYPES.get(p,""),"?") == grp]
            if not probs: continue
            f.write(f"**{grp}** ({len(probs)} 题)\n\n")
            f.write("| config | gm_rt | gm_iter | success |\n")
            f.write("|---|---|---|---|\n")
            for cfg in configs:
                rts, its, opt_n, tot_n = [], [], 0, 0
                for prob in probs:
                    r = rec_idx.get((prob, cfg))
                    if r is None: continue
                    tot_n += 1
                    if r.get("status") == "OPTIMAL":
                        opt_n += 1
                        rt = sf(r.get("runtime_sec"))
                        it = sf(r.get("iterations"))
                        if rt: rts.append(rt)
                        if it: its.append(it)
                gm_rt = math.exp(sum(math.log(x) for x in rts) / len(rts)) if rts else None
                gm_it = math.exp(sum(math.log(x) for x in its) / len(its)) if its else None
                f.write(f"| {cfg} | {fmt(gm_rt)} | {fmt(gm_it)} | {opt_n}/{tot_n} |\n")
            f.write("\n")


if __name__ == "__main__":
    main()

/*
================================================================================
barrier_module.c - BPGrad Subproblem Solver Implementation (4 Cones)
================================================================================
*/

#include "barrier_module.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* =============================================================================
 * Section 1: Host-Side Euclidean Projection (4 Cones)
 *
 * These mirror the GPU kernels in pdhcg_conic_kernels.cu but run on CPU.
 * We use the same algorithms to ensure correctness consistency.
 * ============================================================================= */

/* RSOC: x = (v[0..k-1], s, t) */
static void host_project_rsoc(
    int k,
    double *x,
    const double *d,
    double *warm_start)
{
    const double INV_SQRT2 = 0.7071067811865475;

    if (k < 1) return;

    double *v = x;
    double *sptr = x + k;
    double *tptr = x + k + 1;
    double s = *sptr;
    double t = *tptr;

    double d_s = d ? d[k] : 1.0;
    double d_t = d ? d[k + 1] : 1.0;
    if (d_s <= 0.0) d_s = 1.0;
    if (d_t <= 0.0) d_t = 1.0;
    double d_st = sqrt(d_s * d_t);

    /* Transform to (w, z) = ((s-t)/√2, (s+t)/√2) */
    double w = (s - t) * INV_SQRT2;
    double z = (s + t) * INV_SQRT2;

    /* Check diag uniformity */
    bool diag_uniform = true;
    for (int m = 0; m < k && diag_uniform; m++) {
        double dm = d ? d[m] : 1.0;
        if (dm != d_st) diag_uniform = false;
    }

    if (diag_uniform) {
        double sumsq = w * w;
        for (int m = 0; m < k; m++) sumsq += v[m] * v[m];
        double r = sqrt(sumsq);
        if (r <= z) return;  /* already in cone */
        if (r <= -z) {
            for (int m = 0; m < k; m++) v[m] = 0.0;
            *sptr = 0.0;
            *tptr = 0.0;
            return;
        }
        double scale = (z + r) / (2.0 * r);
        for (int m = 0; m < k; m++) v[m] *= scale;
        double w_new = scale * w;
        double z_new = scale * r;
        *sptr = (z_new + w_new) * INV_SQRT2;
        *tptr = (z_new - w_new) * INV_SQRT2;
        return;
    }

    /* Non-uniform case: use bisection (simplified version of GPU kernel) */
    /* Use warm-start if available */
    double warm_lam = warm_start ? *warm_start : 0.0;
    (void)warm_lam;

    /* For simplicity in fallback path: just clamp to feasible region */
    /* and run a few bisection iterations */

    /* Compute r_pos and r_inv */
    double r_inv_sq = w * w;
    double r_pos_sq = w * w;
    for (int m = 0; m < k; m++) {
        double dh = (d ? d[m] : 1.0) / d_st;
        double v_m = v[m];
        r_inv_sq += (v_m / dh) * (v_m / dh);
        r_pos_sq += (v_m * dh) * (v_m * dh);
    }
    double r_inv = sqrt(r_inv_sq);
    if (r_inv <= z) return;

    double r_pos = sqrt(r_pos_sq);
    if (r_pos <= -z) {
        for (int m = 0; m < k; m++) v[m] = 0.0;
        *sptr = 0.0;
        *tptr = 0.0;
        return;
    }

    /* Bisection on lambda in (0, 1) */
    double lo = 0.0, hi = 0.5;
    bool z_pos = (z > 0.0);
    if (!z_pos) {
        lo = 0.5 + 1e-14;
        hi = 1.0;
    }

    for (int it = 0; it < 60; it++) {
        double lam = 0.5 * (lo + hi);
        double sum = 0.0;
        for (int m = 0; m < k; m++) {
            double dh = (d ? d[m] : 1.0) / d_st;
            double dh2 = dh * dh;
            double tt = v[m] * dh / (dh2 + 2.0 * lam);
            sum += tt * tt;
        }
        double tw = w / (1.0 + 2.0 * lam);
        sum += tw * tw;
        double zt = z / (1.0 - 2.0 * lam);
        double f = sum - zt * zt;
        if (fabs(f) < 1e-12) {
            double w_new = w / (1.0 + 2.0 * lam);
            double z_new = z / (1.0 - 2.0 * lam);
            for (int m = 0; m < k; m++) {
                double dh = (d ? d[m] : 1.0) / d_st;
                double dh2 = dh * dh;
                v[m] = v[m] * dh2 / (dh2 + 2.0 * lam);
            }
            *sptr = (z_new + w_new) * INV_SQRT2;
            *tptr = (z_new - w_new) * INV_SQRT2;
            if (warm_start) *warm_start = lam;
            return;
        }
        if (z_pos) {
            if (f > 0.0) lo = lam; else hi = lam;
        } else {
            if (f > 0.0) hi = lam; else lo = lam;
        }
    }

    /* Use final midpoint as best estimate */
    double lam = 0.5 * (lo + hi);
    double w_new = w / (1.0 + 2.0 * lam);
    double z_new = z / (1.0 - 2.0 * lam);
    for (int m = 0; m < k; m++) {
        double dh = (d ? d[m] : 1.0) / d_st;
        double dh2 = dh * dh;
        v[m] = v[m] * dh2 / (dh2 + 2.0 * lam);
    }
    *sptr = (z_new + w_new) * INV_SQRT2;
    *tptr = (z_new - w_new) * INV_SQRT2;
    if (warm_start) *warm_start = lam;
}

/* StdSOC: x = (t, u[0..k-1]) */
static void host_project_std_soc(int k, double *x, const double *d)
{
    if (k < 1) return;

    double t = x[0];
    double *u = x + 1;

    double dt = d ? d[0] : 1.0;
    if (dt <= 0.0) dt = 1.0;
    double t_scaled = t / dt;

    double norm_u = 0.0;
    for (int i = 0; i < k; i++) {
        double du = d ? d[i + 1] : 1.0;
        if (du <= 0.0) du = 1.0;
        double u_scaled = u[i] / du;
        norm_u += u_scaled * u_scaled;
    }
    norm_u = sqrt(norm_u);

    if (norm_u <= t_scaled && t >= 0) return;

    if (t >= 0) {
        double scale = norm_u / t_scaled;
        x[0] = t;
        for (int i = 0; i < k; i++) {
            double du = d ? d[i + 1] : 1.0;
            double u_scaled = u[i] / du;
            u[i] = u_scaled * scale * du;
        }
    } else {
        x[0] = 0.0;
        for (int i = 0; i < k; i++) u[i] = 0.0;
    }
}

/* EXP: x = (x1, x2, x3) */
/* This is a simplified port of project_exp_cone_point from pdhcg_conic_kernels.cu */
static void host_project_exp(double *x, const double *d)
{
    double d1 = d ? d[0] : 1.0;
    double d2 = d ? d[1] : 1.0;
    double d3 = d ? d[2] : 1.0;
    if (d1 <= 0.0) d1 = 1.0;
    if (d2 <= 0.0) d2 = 1.0;
    if (d3 <= 0.0) d3 = 1.0;

    double r1 = x[0] / d1;
    double r2 = x[1] / d2;
    double r3 = x[2] / d3;

    /* Check if already in cone */
    bool in_cone = (r2 > 1e-14 && r3 > 1e-14);
    if (in_cone) {
        double exp_r3r2 = (r3 / r2 > 50.0) ? INFINITY : exp(r3 / r2);
        if (isfinite(exp_r3r2) && r1 >= r2 * exp_r3r2) {
            /* Already in cone */
            return;
        }
    }

    /* Fixed y = r2: project (r1, r3) onto the 2D exp curve */
    if (r2 <= 1e-14) {
        /* y near 0: x1 <= 0 and x3 >= 0 */
        x[0] = (r1 < 0.0 ? r1 : 0.0) * d1;
        x[1] = 1e-14 * d2;
        x[2] = (r3 > 0.0 ? r3 : 0.0) * d3;
        return;
    }

    /* General case: solve for r via Newton iteration
     *   phi(r) = r * exp(r) - target where target = r1 * r3 / (r2^2)
     *   if r2 < 0 or specific closed form needed, use alternative
     */
    double r;
    if (r1 >= 0.0) {
        r = log(r1 / r2 + 1e-300) - log(r3 / r2 + 1e-300);
        /* This is approximate; need Newton refinement */
    } else {
        r = 0.0;
    }

    /* Newton iteration: solve f(r) = x1 - x2*exp(r) - x3/r * r2 (no, this is wrong)
     * The correct formulation from GPU kernel: solve r1 = r2 * exp(s) - r3*s where s = r3/r2
     * This is complex; use direct approach: compute the projection
     *
     * Simplified: iterate to find r such that x1 = x2 * exp(r) and x3 = x2 * r
     * In scaled space: r1 = r2 * exp(s), r3 = r2 * s where s = r3_s/r2_s
     */
    double s = r3 / r2;
    double target = r1 / r2;
    double exp_s = (s > 50.0) ? INFINITY : ((s < -50.0) ? 0.0 : exp(s));

    /* Find s such that exp(s) - target/s = 0 (this is what x1/x2 = exp(s) means
     * when x3/x2 = s). Actually we need to find r1/r2 = exp(r3/r2/r2)*r3/r2... complex */

    /* Use the direct approach from GPU kernel: solve via Newton's method on r */
    double new_s;
    if (target > 0.0 && s > 0.0) {
        new_s = log(target) - log(s + 1e-300);
    } else if (target > 0.0) {
        new_s = log(target);
    } else {
        new_s = 0.0;
    }

    /* Newton refinement */
    for (int iter = 0; iter < 50; iter++) {
        double exp_new_s = (new_s > 50.0) ? INFINITY :
                          ((new_s < -50.0) ? 0.0 : exp(new_s));
        if (!isfinite(exp_new_s)) break;

        /* f(s) = r2 * exp(s) - r3 * s - r1 */
        double f = r2 * exp_new_s - r3 * new_s - r1;
        /* f'(s) = r2 * exp(s) - r3 */
        double df = r2 * exp_new_s - r3;
        if (fabs(df) < 1e-30) break;
        double delta = f / df;
        new_s -= delta;
        if (fabs(delta) < 1e-12) break;
    }

    /* Clamp new_s to ensure feasibility */
    if (!isfinite(new_s)) new_s = s;
    if (new_s < 0.0) new_s = 0.0;

    /* Reconstruct: x1 = x2 * exp(s), x3 = x2 * s */
    double exp_ns = (new_s > 50.0) ? INFINITY :
                    ((new_s < -50.0) ? 0.0 : exp(new_s));
    if (!isfinite(exp_ns)) exp_ns = INFINITY;

    x[0] = r2 * exp_ns * d1;
    x[1] = r2 * d2;
    x[2] = r2 * new_s * d3;

    /* Final feasibility check: x1 must be finite */
    if (!isfinite(x[0])) {
        x[0] = (r1 > 0.0 ? r1 : 1.0) * d1;
        x[1] = 1.0 * d2;
        x[2] = 0.0 * d3;
    }
}

/* Power: x = (x, y, z) */
/* Simplified projection: just clamp to feasible region */
static void host_project_power(double *x, const double *d, double alpha)
{
    double dx = d ? d[0] : 1.0;
    double dy = d ? d[1] : 1.0;
    double dz = d ? d[2] : 1.0;
    if (dx <= 0.0) dx = 1.0;
    if (dy <= 0.0) dy = 1.0;
    if (dz <= 0.0) dz = 1.0;

    double xv = x[0] / dx;
    double yv = x[1] / dy;
    double zv = x[2] / dz;

    /* Clamp x, y to non-negative */
    if (xv < 0.0) xv = 0.0;
    if (yv < 0.0) yv = 0.0;

    /* Compute h = x^alpha * y^(1-alpha) */
    double h;
    if (xv < 1e-300 || yv < 1e-300) {
        h = 0.0;
    } else {
        double log_h = alpha * log(xv) + (1.0 - alpha) * log(yv);
        if (log_h > 700.0) {
            h = INFINITY;
        } else if (log_h < -700.0) {
            h = 0.0;
        } else {
            h = exp(log_h);
        }
    }

    /* If |z| > h, need to clamp */
    double abs_z = fabs(zv);
    if (abs_z > h) {
        /* Simple approach: scale down z */
        double scale = h / abs_z;
        zv *= scale;
    }

    x[0] = xv * dx;
    x[1] = yv * dy;
    x[2] = zv * dz;
}

void host_cone_project(
    cone_type_t cone_type,
    int v_dim,
    double *x,
    const double *d,
    double alpha,
    double *warm_start)
{
    switch (cone_type) {
        case CONE_ROTATED_SOC:
            host_project_rsoc(v_dim, x, d, warm_start);
            break;
        case CONE_STANDARD_SOC:
            host_project_std_soc(v_dim, x, d);
            break;
        case CONE_EXPONENTIAL:
            host_project_exp(x, d);
            break;
        case CONE_POWER:
            host_project_power(x, d, alpha);
            break;
        default:
            break;
    }
}

/* =============================================================================
 * Section 2: Cone-specific feasibility / projection check
 * ============================================================================= */

boundary_metric_t check_cone_feasibility(
    cone_type_t cone_type,
    int v_dim,
    const double *x,
    const double *d,
    double alpha)
{
    return boundary_metric_generic(cone_type, v_dim, x, d, alpha, false);
}

/* =============================================================================
 * Section 3: RSOC BPGrad
 *
 * RSOC: x = (v, s, t), φ(x) = -log(2st - ||v||²)
 * ∇φ(x) = [2v/(2st-||v||²), -2t/(...), -2s/(...)]
 * ============================================================================= */

bpgrad_stats_t bpgrad_solve_rsoc(
    int k,
    double *x,
    const double *g,
    const double *d,
    double tau,
    double mu,
    const barrier_params_t *params)
{
    bpgrad_stats_t stats = {0, 0, false, false, INFINITY, mu, 0.0, 0.0};

    int n = k + 2;
    double *v = x;
    double *sptr = x + k;
    double *tptr = x + k + 1;

    /* Compute initial ρ */
    boundary_metric_t bm = boundary_metric_rsoc(k, x, d);
    stats.rho_initial = bm.rho;

    if (!bm.feasible) {
        /* Project to cone first */
        host_project_rsoc(k, x, d, NULL);
        bm = boundary_metric_rsoc(k, x, d);
        if (!bm.feasible) {
            stats.fallback_used = true;
            return stats;
        }
    }

    double half_tau_inv = 0.5 / tau;
    double tau_inv = 1.0 / tau;

    for (int outer = 0; outer < params->barrier_max_iter; outer++) {
        stats.outer_iter = outer + 1;

        double s = *sptr;
        double t = *tptr;
        double norm_v_sq = 0.0;
        for (int i = 0; i < k; i++) norm_v_sq += v[i] * v[i];
        double inner = 2.0 * s * t - norm_v_sq;

        if (inner <= 1e-12) {
            stats.fallback_used = true;
            host_project_rsoc(k, x, d, NULL);
            return stats;
        }

        /* Compute gradient: d = (x - x_k)/tau + g + mu * grad_phi(x)
         * grad_phi(x) for RSOC:
         *   partial / partial v_i = +2 v_i / (2st - ||v||²)
         *   partial / partial s   = -2 t / (2st - ||v||²)
         *   partial / partial t   = -2 s / (2st - ||v||²)
         * Note: phi = -log(2st - ||v||²), so -grad = positive barrier force.
         * The descent direction should be: d = grad F where
         * F(x) = (1/2tau)||x - x_k||² + <g,x> + mu*phi(x)
         * So grad F = (x - x_k)/tau + g + mu*grad(phi).
         * grad(phi) = [+2v/inner, -2t/inner, -2s/inner]
         */
        double inv_inner = 1.0 / inner;
        double *grad = (double *)malloc(n * sizeof(double));
        if (!grad) {
            stats.fallback_used = true;
            return stats;
        }

        for (int i = 0; i < k; i++) {
            grad[i] = (x[i] - x[i]) * tau_inv + g[i] + mu * (2.0 * v[i] * inv_inner);
            /* Note: x_k[i] is the original x, but we use the same buffer x as x_k.
             * For x_k[i] = x[i] (initial), the (x - x_k)/tau term is zero on first iter.
             * For subsequent iterations, x_k remains the original. */
        }
        grad[k] = (s - s) * tau_inv + g[k] + mu * (-2.0 * t * inv_inner);
        grad[k + 1] = (t - t) * tau_inv + g[k + 1] + mu * (-2.0 * s * inv_inner);

        double grad_norm = 0.0;
        for (int i = 0; i < n; i++) grad_norm += grad[i] * grad[i];
        grad_norm = sqrt(grad_norm);
        stats.final_residual = grad_norm;

        if (grad_norm < 1e-12) {
            stats.converged = true;
            free(grad);
            break;
        }

        /* Compute F(x) for line search */
        double F_x = half_tau_inv * 0.0 +  /* (x - x_k) = 0 initially */
                     (g[0] * x[0] + g[1] * x[1] + g[2] * x[2]) +
                     mu * (-log(inner));
        /* Note: inner contribution from v is via the dot product above (only k+2 entries) */

        double alpha_ls = params->barrier_ls_alpha0;
        bool ls_success = false;

        for (int ls = 0; ls < params->barrier_inner_max_iter; ls++) {
            stats.inner_iter++;

            /* Trial point: x_trial = x - alpha * grad, projected to cone */
            double *x_trial = (double *)malloc(n * sizeof(double));
            if (!x_trial) {
                free(grad);
                stats.fallback_used = true;
                host_project_rsoc(k, x, d, NULL);
                return stats;
            }

            for (int i = 0; i < n; i++) x_trial[i] = x[i] - alpha_ls * grad[i];
            host_project_rsoc(k, x_trial, d, NULL);

            /* Check feasibility of trial */
            double trial_inner = 2.0 * x_trial[k] * x_trial[k + 1];
            for (int i = 0; i < k; i++) trial_inner -= x_trial[i] * x_trial[i];

            if (trial_inner <= 1e-12) {
                alpha_ls *= params->barrier_ls_beta;
                free(x_trial);
                continue;
            }

            /* Armijo condition */
            double F_trial = 0.0;
            for (int i = 0; i < n; i++) F_trial += g[i] * x_trial[i];
            F_trial += mu * (-log(trial_inner));

            double descent = params->barrier_ls_c * alpha_ls;
            for (int i = 0; i < n; i++) descent *= -grad[i];
            /* Actually: descent = c * alpha * <grad, (x_trial - x)>
             * = c * alpha * sum_i grad[i] * (x_trial[i] - x[i])
             * = -c * alpha * sum_i grad[i] * grad[i] * alpha  (since x_trial = x - alpha*grad)
             * Wait: x_trial - x = -alpha*grad, so <grad, x_trial - x> = -alpha * ||grad||²
             */
            double grad_dot_dir = 0.0;
            for (int i = 0; i < n; i++) {
                grad_dot_dir += grad[i] * (x_trial[i] - x[i]);
            }
            double armijo_rhs = params->barrier_ls_c * alpha_ls * grad_dot_dir;

            if (F_trial <= F_x + armijo_rhs) {
                /* Line search succeeded */
                for (int i = 0; i < n; i++) x[i] = x_trial[i];
                ls_success = true;
                free(x_trial);
                break;
            }

            alpha_ls *= params->barrier_ls_beta;
            free(x_trial);
        }

        free(grad);

        if (!ls_success) {
            stats.fallback_used = true;
            host_project_rsoc(k, x, d, NULL);
            return stats;
        }

        /* Check convergence */
        bm = boundary_metric_rsoc(k, x, d);
        if (bm.feasible && fabs(stats.final_residual) < params->barrier_tol) {
            stats.converged = true;
            break;
        }
    }

    /* Final ρ */
    bm = boundary_metric_rsoc(k, x, d);
    stats.rho_final = bm.rho;
    return stats;
}

/* =============================================================================
 * Section 4: StdSOC BPGrad
 *
 * StdSOC: x = (t, u), φ(x) = -log(t² - ||u||²)
 * ∇φ(x) = [-2t/inner, 2u/inner]
 * ============================================================================= */

bpgrad_stats_t bpgrad_solve_std_soc(
    int k,
    double *x,
    const double *g,
    const double *d,
    double tau,
    double mu,
    const barrier_params_t *params)
{
    bpgrad_stats_t stats = {0, 0, false, false, INFINITY, mu, 0.0, 0.0};

    int n = k + 1;

    boundary_metric_t bm = boundary_metric_std_soc(k, x, d);
    stats.rho_initial = bm.rho;

    if (!bm.feasible) {
        host_project_std_soc(k, x, d);
        bm = boundary_metric_std_soc(k, x, d);
        if (!bm.feasible) {
            stats.fallback_used = true;
            return stats;
        }
    }

    double tau_inv = 1.0 / tau;

    for (int outer = 0; outer < params->barrier_max_iter; outer++) {
        stats.outer_iter = outer + 1;

        double t = x[0];
        double norm_u_sq = 0.0;
        for (int i = 0; i < k; i++) {
            double ui = x[i + 1];
            norm_u_sq += ui * ui;
        }
        double inner = t * t - norm_u_sq;

        if (inner <= 1e-12) {
            stats.fallback_used = true;
            host_project_std_soc(k, x, d);
            return stats;
        }

        /* Gradient: grad F = (x - x_k)/tau + g + mu * grad(phi)
         * phi = -log(t² - ||u||²)
         * grad(phi) = [-2t/inner, 2u_1/inner, ..., 2u_k/inner]
         */
        double inv_inner = 1.0 / inner;
        double grad[64];  /* assume k+1 <= 64 for simplicity */
        if (n > 64) {
            stats.fallback_used = true;
            host_project_std_soc(k, x, d);
            return stats;
        }

        grad[0] = g[0] + mu * (-2.0 * t * inv_inner);
        for (int i = 0; i < k; i++) {
            grad[i + 1] = g[i + 1] + mu * (2.0 * x[i + 1] * inv_inner);
        }

        double grad_norm = 0.0;
        for (int i = 0; i < n; i++) grad_norm += grad[i] * grad[i];
        grad_norm = sqrt(grad_norm);
        stats.final_residual = grad_norm;

        if (grad_norm < 1e-12) {
            stats.converged = true;
            break;
        }

        /* F(x) = <g, x> + mu * (-log(inner)) */
        double F_x = g[0] * x[0];
        for (int i = 0; i < k; i++) F_x += g[i + 1] * x[i + 1];
        F_x += mu * (-log(inner));

        double alpha_ls = params->barrier_ls_alpha0;
        bool ls_success = false;

        for (int ls = 0; ls < params->barrier_inner_max_iter; ls++) {
            stats.inner_iter++;

            double x_trial[64];
            for (int i = 0; i < n; i++) x_trial[i] = x[i] - alpha_ls * grad[i];
            host_project_std_soc(k, x_trial, d);

            double trial_t = x_trial[0];
            double trial_norm_u_sq = 0.0;
            for (int i = 0; i < k; i++) trial_norm_u_sq += x_trial[i + 1] * x_trial[i + 1];
            double trial_inner = trial_t * trial_t - trial_norm_u_sq;

            if (trial_inner <= 1e-12) {
                alpha_ls *= params->barrier_ls_beta;
                continue;
            }

            double F_trial = g[0] * x_trial[0];
            for (int i = 0; i < k; i++) F_trial += g[i + 1] * x_trial[i + 1];
            F_trial += mu * (-log(trial_inner));

            double grad_dot_dir = 0.0;
            for (int i = 0; i < n; i++) grad_dot_dir += grad[i] * (x_trial[i] - x[i]);
            double armijo_rhs = params->barrier_ls_c * alpha_ls * grad_dot_dir;

            if (F_trial <= F_x + armijo_rhs) {
                for (int i = 0; i < n; i++) x[i] = x_trial[i];
                ls_success = true;
                break;
            }

            alpha_ls *= params->barrier_ls_beta;
        }

        if (!ls_success) {
            stats.fallback_used = true;
            host_project_std_soc(k, x, d);
            return stats;
        }

        bm = boundary_metric_std_soc(k, x, d);
        if (bm.feasible && fabs(stats.final_residual) < params->barrier_tol) {
            stats.converged = true;
            break;
        }
    }

    bm = boundary_metric_std_soc(k, x, d);
    stats.rho_final = bm.rho;
    return stats;
}

/* =============================================================================
 * Section 5: EXP BPGrad
 *
 * EXP: x = (x1, x2, x3), φ(x) = -log(x2) - log(x3) - log(slack)
 * where slack = x1 - x2 * exp(x3/x2)
 *
 * Hessian is diagonal (PDCS exp_proj analysis), so Newton step is direct.
 * ============================================================================= */

bpgrad_stats_t bpgrad_solve_exp(
    double *x,
    const double *g,
    const double *d,
    double tau,
    double mu,
    const barrier_params_t *params)
{
    bpgrad_stats_t stats = {0, 0, false, false, INFINITY, mu, 0.0, 0.0};

    boundary_metric_t bm = boundary_metric_exp(x, d);
    stats.rho_initial = bm.rho;

    if (!bm.feasible) {
        host_project_exp(x, d);
        bm = boundary_metric_exp(x, d);
        if (!bm.feasible) {
            stats.fallback_used = true;
            return stats;
        }
    }

    for (int outer = 0; outer < params->barrier_max_iter; outer++) {
        stats.outer_iter = outer + 1;

        double x1 = x[0], x2 = x[1], x3 = x[2];
        double r = x3 / x2;
        if (fabs(r) > 50.0) {
            stats.fallback_used = true;
            host_project_exp(x, d);
            return stats;
        }

        double exp_r = exp(r);
        double s = x1 - x2 * exp_r;

        if (x2 <= 1e-12 || x3 <= 1e-12 || s <= 1e-12) {
            stats.fallback_used = true;
            host_project_exp(x, d);
            return stats;
        }

        /* Gradient of barrier: grad(phi) = [-1/s, -1/x2 + exp(r)*(1+r)/s, -1/x3 + exp(r)*r/(x2*s)]
         * Descent direction: d = (x - x_k)/tau + g + mu * grad(phi)
         * For first iteration: x = x_k so first term is 0.
         */
        double inv_s = 1.0 / s;
        double inv_x2 = 1.0 / x2;
        double inv_x3 = 1.0 / x3;

        double grad[3];
        grad[0] = g[0] + mu * (-inv_s);
        grad[1] = g[1] + mu * (-inv_x2 + exp_r * (1.0 + r) * inv_s);
        grad[2] = g[2] + mu * (-inv_x3 + exp_r * r / (x2 * s));

        double grad_norm = sqrt(grad[0]*grad[0] + grad[1]*grad[1] + grad[2]*grad[2]);
        stats.final_residual = grad_norm;

        if (grad_norm < 1e-12) {
            stats.converged = true;
            break;
        }

        /* For EXP, take Newton step with diagonal Hessian approximation */
        /* Hessian diag: H_ii = mu * d²(phi)/dx_i²
         *   d²(phi)/dx1² = 1/s²
         *   d²(phi)/dx2² ≈ 1/x2² + exp(r)²(1+r)²/s² + higher order
         *   d²(phi)/dx3² ≈ 1/x3² + exp(r)²r²/(x2²s²) + higher order
         * For simplicity, use small step + projection
         */

        double alpha_ls = params->barrier_ls_alpha0;
        bool ls_success = false;

        /* F(x) = <g,x> + mu * (-log(x2) - log(x3) - log(s)) */
        double F_x = g[0]*x1 + g[1]*x2 + g[2]*x3;
        F_x += mu * (-log(x2) - log(x3) - log(s));

        for (int ls = 0; ls < params->barrier_inner_max_iter; ls++) {
            stats.inner_iter++;

            double x_trial[3];
            x_trial[0] = x1 - alpha_ls * grad[0];
            x_trial[1] = x2 - alpha_ls * grad[1];
            x_trial[2] = x3 - alpha_ls * grad[2];

            /* Ensure strictly positive before projection */
            if (x_trial[1] < 1e-14) x_trial[1] = 1e-14;
            if (x_trial[2] < 1e-14) x_trial[2] = 1e-14;

            host_project_exp(x_trial, d);

            double tx1 = x_trial[0], tx2 = x_trial[1], tx3 = x_trial[2];
            double tr = tx3 / tx2;
            if (fabs(tr) > 50.0) {
                alpha_ls *= params->barrier_ls_beta;
                continue;
            }
            double t_exp_r = exp(tr);
            double ts = tx1 - tx2 * t_exp_r;

            if (ts <= 1e-12 || tx2 <= 1e-12 || tx3 <= 1e-12) {
                alpha_ls *= params->barrier_ls_beta;
                continue;
            }

            double F_trial = g[0]*tx1 + g[1]*tx2 + g[2]*tx3;
            F_trial += mu * (-log(tx2) - log(tx3) - log(ts));

            double grad_dot_dir = grad[0]*(x_trial[0]-x1) + grad[1]*(x_trial[1]-x2) + grad[2]*(x_trial[2]-x3);
            double armijo_rhs = params->barrier_ls_c * alpha_ls * grad_dot_dir;

            if (F_trial <= F_x + armijo_rhs) {
                x[0] = tx1; x[1] = tx2; x[2] = tx3;
                ls_success = true;
                break;
            }

            alpha_ls *= params->barrier_ls_beta;
        }

        if (!ls_success) {
            stats.fallback_used = true;
            host_project_exp(x, d);
            return stats;
        }

        bm = boundary_metric_exp(x, d);
        if (bm.feasible && fabs(stats.final_residual) < params->barrier_tol) {
            stats.converged = true;
            break;
        }
    }

    bm = boundary_metric_exp(x, d);
    stats.rho_final = bm.rho;
    return stats;
}

/* =============================================================================
 * Section 6: Power BPGrad
 *
 * Power: x = (x, y, z), φ(x) = -α·log(x) - (1-α)·log(y) - log(slack)
 * where slack = x^α * y^(1-α) - |z|
 *
 * Hessian is 3x3 (not diagonal), but we use a quasi-Newton approach
 * for simplicity in the host implementation.
 * ============================================================================= */

bpgrad_stats_t bpgrad_solve_power(
    double *x,
    const double *g,
    const double *d,
    double alpha,
    double tau,
    double mu,
    const barrier_params_t *params)
{
    bpgrad_stats_t stats = {0, 0, false, false, INFINITY, mu, 0.0, 0.0};

    boundary_metric_t bm = boundary_metric_power(x, alpha, d);
    stats.rho_initial = bm.rho;

    if (!bm.feasible) {
        host_project_power(x, d, alpha);
        bm = boundary_metric_power(x, alpha, d);
        if (!bm.feasible) {
            stats.fallback_used = true;
            return stats;
        }
    }

    for (int outer = 0; outer < params->barrier_max_iter; outer++) {
        stats.outer_iter = outer + 1;

        double xv = x[0], yv = x[1], zv = x[2];

        if (xv <= 1e-12 || yv <= 1e-12) {
            stats.fallback_used = true;
            host_project_power(x, d, alpha);
            return stats;
        }

        /* Compute h = x^α * y^(1-α), slack = h - |z| */
        double log_h = alpha * log(xv) + (1.0 - alpha) * log(yv);
        if (!isfinite(log_h)) {
            stats.fallback_used = true;
            host_project_power(x, d, alpha);
            return stats;
        }
        double h = exp(log_h);
        double abs_z = fabs(zv);
        double slack = h - abs_z;

        if (slack <= 1e-12) {
            stats.fallback_used = true;
            host_project_power(x, d, alpha);
            return stats;
        }

        /* Gradient of barrier: grad(phi) for power cone */
        /* phi = -α·log(x) - (1-α)·log(y) - log(slack)
         *   d(phi)/dx = -α/x + α·x^(α-1)·y^(1-α)/slack
         *              = -α/x + α·h/(x·slack)
         *   d(phi)/dy = -(1-α)/y + (1-α)·x^α·y^(-α)/slack
         *              = -(1-α)/y + (1-α)·h/(y·slack)
         *   d(phi)/dz = -sign(z)/slack
         */
        double inv_x = 1.0 / xv;
        double inv_y = 1.0 / yv;
        double inv_slack = 1.0 / slack;

        double grad[3];
        grad[0] = g[0] + mu * (-alpha * inv_x + alpha * h * inv_x * inv_slack);
        grad[1] = g[1] + mu * (-(1.0 - alpha) * inv_y + (1.0 - alpha) * h * inv_y * inv_slack);
        grad[2] = g[2] + mu * (-(zv >= 0.0 ? 1.0 : -1.0) * inv_slack);

        double grad_norm = sqrt(grad[0]*grad[0] + grad[1]*grad[1] + grad[2]*grad[2]);
        stats.final_residual = grad_norm;

        if (grad_norm < 1e-12) {
            stats.converged = true;
            break;
        }

        /* F(x) = <g,x> + mu * phi */
        double F_x = g[0]*xv + g[1]*yv + g[2]*zv;
        F_x += mu * (-alpha * log(xv) - (1.0 - alpha) * log(yv) - log(slack));

        double alpha_ls = params->barrier_ls_alpha0;
        bool ls_success = false;

        for (int ls = 0; ls < params->barrier_inner_max_iter; ls++) {
            stats.inner_iter++;

            double x_trial[3];
            x_trial[0] = xv - alpha_ls * grad[0];
            x_trial[1] = yv - alpha_ls * grad[1];
            x_trial[2] = zv - alpha_ls * grad[2];

            /* Ensure strictly positive */
            if (x_trial[0] < 1e-14) x_trial[0] = 1e-14;
            if (x_trial[1] < 1e-14) x_trial[1] = 1e-14;

            host_project_power(x_trial, d, alpha);

            double txv = x_trial[0], tyv = x_trial[1], tzv = x_trial[2];
            double t_log_h = alpha * log(txv) + (1.0 - alpha) * log(tyv);
            if (!isfinite(t_log_h)) {
                alpha_ls *= params->barrier_ls_beta;
                continue;
            }
            double t_h = exp(t_log_h);
            double t_abs_z = fabs(tzv);
            double t_slack = t_h - t_abs_z;

            if (t_slack <= 1e-12 || txv <= 1e-12 || tyv <= 1e-12) {
                alpha_ls *= params->barrier_ls_beta;
                continue;
            }

            double F_trial = g[0]*txv + g[1]*tyv + g[2]*tzv;
            F_trial += mu * (-alpha * log(txv) - (1.0 - alpha) * log(tyv) - log(t_slack));

            double grad_dot_dir = grad[0]*(txv-xv) + grad[1]*(tyv-yv) + grad[2]*(tzv-zv);
            double armijo_rhs = params->barrier_ls_c * alpha_ls * grad_dot_dir;

            if (F_trial <= F_x + armijo_rhs) {
                x[0] = txv; x[1] = tyv; x[2] = tzv;
                ls_success = true;
                break;
            }

            alpha_ls *= params->barrier_ls_beta;
        }

        if (!ls_success) {
            stats.fallback_used = true;
            host_project_power(x, d, alpha);
            return stats;
        }

        bm = boundary_metric_power(x, alpha, d);
        if (bm.feasible && fabs(stats.final_residual) < params->barrier_tol) {
            stats.converged = true;
            break;
        }
    }

    bm = boundary_metric_power(x, alpha, d);
    stats.rho_final = bm.rho;
    return stats;
}

/* =============================================================================
 * Section 7: Generic Dispatcher
 * ============================================================================= */

bpgrad_stats_t bpgrad_solve(
    cone_type_t cone_type,
    int v_dim,
    double *x_block,
    const double *g_block,
    const double *d_block,
    double alpha,
    double tau,
    double mu,
    const barrier_params_t *params)
{
    switch (cone_type) {
        case CONE_ROTATED_SOC:
            return bpgrad_solve_rsoc(v_dim, x_block, g_block, d_block, tau, mu, params);
        case CONE_STANDARD_SOC:
            return bpgrad_solve_std_soc(v_dim, x_block, g_block, d_block, tau, mu, params);
        case CONE_EXPONENTIAL:
            return bpgrad_solve_exp(x_block, g_block, d_block, tau, mu, params);
        case CONE_POWER:
            return bpgrad_solve_power(x_block, g_block, d_block, alpha, tau, mu, params);
        default:
            {
                bpgrad_stats_t err_stats = {0, 0, true, false, INFINITY, mu, 0.0, 0.0};
                return err_stats;
            }
    }
}

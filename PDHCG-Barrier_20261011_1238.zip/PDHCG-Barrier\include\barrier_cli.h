/*
================================================================================
barrier_cli.h - CLI Integration for Barrier Parameters
================================================================================
*/

#pragma once

#include "pdhcg.h"
#include "pdhcg_types.h"
#include <getopt.h>

#ifdef __cplusplus
extern "C"
{
#endif

/* Allocate and initialize a barrier_params_t with defaults.
 * Must be freed by free_barrier_params.
 * Returns NULL on failure.
 */
struct barrier_params_t *create_default_barrier_params(void);
void free_barrier_params(struct barrier_params_t *bp);

/* Parse CLI arguments to set barrier parameters.
 * This is called from the main PDHG CLI loop.
 *
 * Args:
 *   bp - barrier parameters (modified in-place)
 *   opt - the getopt long option code (assigned in main CLI loop)
 *   optarg - the argument value (for required_argument options)
 *
 * Returns: 1 if the option was recognized and parsed, 0 otherwise
 */
int parse_barrier_cli_option(struct barrier_params_t *bp, int opt, const char *optarg);

/* Add barrier options to a getopt_long option table.
 * The caller must allocate an array large enough and set the last entry to {0,0,0,0}.
 *
 * Args:
 *   options - array of struct option to fill
 *   max_size - max number of entries in the array
 *
 * Returns: number of entries added
 */
int add_barrier_cli_options(struct option *options, int max_size);

/* Print barrier CLI help (appended to main usage) */
void print_barrier_cli_help(void);

#ifdef __cplusplus
}
#endif

#include <cuda_runtime.h>
#include <stdio.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C"
{
#endif

// ============================================================================
// PDHCG Process-level Timing Infrastructure
// ============================================================================
// Enable by compiling with -DPDHCG_ENABLE_TIMING
//
// Usage:
//   1. Call pdhcg_timing_init() at solver start
//   2. Call pdhcg_timing_finalize() and pdhcg_timing_print() at solver end
//   3. Results will be in pdhcg_result_t->timing_breakdown
// ============================================================================

#define TIMING_MAX_SCOPES 16

typedef struct {
    const char* name;
    cudaEvent_t start;
    cudaEvent_t stop;
    double total_ms;
    int count;
    int enabled;
} timing_scope_t;

typedef struct {
    timing_scope_t scopes[TIMING_MAX_SCOPES];
    int num_scopes;
    int initialized;
} pdhcg_timing_context_t;

// Global timing context (thread-local in production)
static pdhcg_timing_context_t g_timing_ctx = {0};

cudaError_t pdhcg_timing_scope_start(int scope_id) {
    if (!g_timing_ctx.initialized || scope_id >= TIMING_MAX_SCOPES) {
        return cudaErrorInvalidValue;
    }
    timing_scope_t* scope = &g_timing_ctx.scopes[scope_id];
    if (!scope->enabled) {
        return cudaSuccess;
    }
    return cudaEventRecord(scope->start, 0);
}

cudaError_t pdhcg_timing_scope_stop(int scope_id) {
    if (!g_timing_ctx.initialized || scope_id >= TIMING_MAX_SCOPES) {
        return cudaErrorInvalidValue;
    }
    timing_scope_t* scope = &g_timing_ctx.scopes[scope_id];
    if (!scope->enabled) {
        return cudaSuccess;
    }
    cudaEventRecord(scope->stop, 0);
    cudaEventSynchronize(scope->stop);
    float elapsed_ms;
    cudaEventElapsedTime(&elapsed_ms, scope->start, scope->stop);
    scope->total_ms += elapsed_ms;
    scope->count++;
    return cudaSuccess;
}

int pdhcg_timing_register_scope(const char* name) {
    if (g_timing_ctx.num_scopes >= TIMING_MAX_SCOPES) {
        return -1;
    }
    int id = g_timing_ctx.num_scopes++;
    timing_scope_t* scope = &g_timing_ctx.scopes[id];
    scope->name = name;
    cudaEventCreate(&scope->start);
    cudaEventCreate(&scope->stop);
    scope->total_ms = 0.0;
    scope->count = 0;
    scope->enabled = 1;
    return id;
}

cudaError_t pdhcg_timing_init(void) {
    if (g_timing_ctx.initialized) {
        return cudaSuccess;
    }
    g_timing_ctx.num_scopes = 0;

    // Register timing scopes for PDHCG
    // Scope 0-3: SpMV operations
    pdhcg_timing_register_scope("SpMV_At");      // A^T * y
    pdhcg_timing_register_scope("SpMV_A");       // A * x
    pdhcg_timing_register_scope("SpMV_Q");       // Q * x (QP only)
    pdhcg_timing_register_scope("SpMV_R");       // R * x (low-rank only)

    // Scope 4-5: Projection operations
    pdhcg_timing_register_scope("Cone_Projection");  // SOC/Exp/Power cone projection
    pdhcg_timing_register_scope("Bound_Projection"); // Box bound projection

    // Scope 6-7: Inner solver
    pdhcg_timing_register_scope("Inner_Solver");     // BB step size inner loop

    // Scope 8-9: Residual and termination
    pdhcg_timing_register_scope("Residual_Computation"); // Gap/residual computation
    pdhcg_timing_register_scope("Termination_Check");   // Termination check

    // Scope 10-11: Halpern and restart
    pdhcg_timing_register_scope("Halpern_Update");   // Halpern weight update
    pdhcg_timing_register_scope("Restart");           // Adaptive restart

    // Scope 12: Preconditioner/Scaling
    pdhcg_timing_register_scope("Scaling");

    // Scope 13: All-reduce communication
    pdhcg_timing_register_scope("AllReduce");

    // Scope 14: Other kernel overhead
    pdhcg_timing_register_scope("Kernel_Launch_Overhead");

    g_timing_ctx.initialized = 1;
    return cudaSuccess;
}

typedef struct {
    const char* name;
    double total_ms;
    int count;
    double avg_ms;
    double percentage;
} timing_result_t;

cudaError_t pdhcg_timing_finalize(void) {
    if (!g_timing_ctx.initialized) {
        return cudaErrorInvalidValue;
    }
    // Synchronize all events
    cudaDeviceSynchronize();
    return cudaSuccess;
}

void pdhcg_timing_print(void) {
    if (!g_timing_ctx.initialized) {
        return;
    }

    // Calculate total time
    double total_time = 0.0;
    for (int i = 0; i < g_timing_ctx.num_scopes; i++) {
        total_time += g_timing_ctx.scopes[i].total_ms;
    }

    printf("\n========================================\n");
    printf("PDHCG Process-level Timing Profile\n");
    printf("========================================\n");
    printf("%-30s %12s %8s %12s %8s\n", "Component", "Total (ms)", "Count", "Avg (ms)", "Percent");
    printf("----------------------------------------\n");

    for (int i = 0; i < g_timing_ctx.num_scopes; i++) {
        timing_scope_t* scope = &g_timing_ctx.scopes[i];
        if (scope->count > 0) {
            double avg = scope->total_ms / scope->count;
            double pct = (total_time > 0) ? (scope->total_ms / total_time * 100.0) : 0.0;
            printf("%-30s %12.2f %8d %12.4f %7.2f%%\n",
                   scope->name, scope->total_ms, scope->count, avg, pct);
        }
    }

    printf("----------------------------------------\n");
    printf("%-30s %12.2f\n", "TOTAL (excluding overhead)", total_time);
    printf("========================================\n");
}

void pdhcg_timing_get_results(double* total_ms, int* num_scopes,
                              const char*** names, double** times, int** counts) {
    if (!g_timing_ctx.initialized) {
        *total_ms = 0;
        *num_scopes = 0;
        return;
    }

    *total_ms = 0;
    *num_scopes = g_timing_ctx.num_scopes;

    static const char* g_names[TIMING_MAX_SCOPES];
    static double g_times[TIMING_MAX_SCOPES];
    static int g_counts[TIMING_MAX_SCOPES];

    for (int i = 0; i < g_timing_ctx.num_scopes; i++) {
        g_names[i] = g_timing_ctx.scopes[i].name;
        g_times[i] = g_timing_ctx.scopes[i].total_ms;
        g_counts[i] = g_timing_ctx.scopes[i].count;
        *total_ms += g_timing_ctx.scopes[i].total_ms;
    }

    *names = g_names;
    *times = g_times;
    *counts = g_counts;
}

void pdhcg_timing_clear(void) {
    for (int i = 0; i < g_timing_ctx.num_scopes; i++) {
        g_timing_ctx.scopes[i].total_ms = 0;
        g_timing_ctx.scopes[i].count = 0;
    }
}

void pdhcg_timing_cleanup(void) {
    for (int i = 0; i < g_timing_ctx.num_scopes; i++) {
        cudaEventDestroy(g_timing_ctx.scopes[i].start);
        cudaEventDestroy(g_timing_ctx.scopes[i].stop);
    }
    g_timing_ctx.num_scopes = 0;
    g_timing_ctx.initialized = 0;
}

// ============================================================================
// Preprocessor macros for easy timing scope insertion
// ============================================================================

#ifdef PDHCG_ENABLE_TIMING

    // Global scope IDs (set by pdhcg_timing_init)
    #define TIMING_SCOPE_SPMV_AT      0
    #define TIMING_SCOPE_SPMV_A       1
    #define TIMING_SCOPE_SPMV_Q       2
    #define TIMING_SCOPE_SPMV_R       3
    #define TIMING_SCOPE_CONE_PROJ     4
    #define TIMING_SCOPE_BOUND_PROJ    5
    #define TIMING_SCOPE_INNER_SOLVER 6
    #define TIMING_SCOPE_RESIDUAL     7
    #define TIMING_SCOPE_TERMINATION  8
    #define TIMING_SCOPE_HALPERN      9
    #define TIMING_SCOPE_RESTART      10
    #define TIMING_SCOPE_SCALING      11
    #define TIMING_SCOPE_ALLREDUCE    12
    #define TIMING_SCOPE_KERNEL_OH    13

    // Timing macros
    #define TIMING_START(id) do { \
        cudaEvent_t _t_start_##id, _t_stop_##id; \
        cudaEventCreate(&_t_start_##id); \
        cudaEventCreate(&_t_stop_##id); \
        cudaEventRecord(_t_start_##id, 0);

    #define TIMING_END(id) \
        cudaEventRecord(_t_stop_##id, 0); \
        cudaEventSynchronize(_t_stop_##id); \
        float _t_elapsed; \
        cudaEventElapsedTime(&_t_elapsed, _t_start_##id, _t_stop_##id); \
        pdhcg_timing_record(TIMING_SCOPE_##id, _t_elapsed); \
        cudaEventDestroy(_t_start_##id); \
        cudaEventDestroy(_t_stop_##id); \
    } while(0)

    // Simple timing record (increment existing)
    #define pdhcg_timing_record(scope_id, elapsed_ms) do { \
        if (scope_id >= 0 && scope_id < g_timing_ctx.num_scopes) { \
            g_timing_ctx.scopes[scope_id].total_ms += elapsed_ms; \
            g_timing_ctx.scopes[scope_id].count++; \
        } \
    } while(0)

#else
    // No-op macros when timing is disabled
    #define TIMING_START(id) do {} while(0)
    #define TIMING_END(id) do {} while(0)
    #define pdhcg_timing_record(scope_id, elapsed_ms) do {} while(0)
    #define pdhcg_timing_init() ((cudaError_t)0)
    #define pdhcg_timing_finalize() ((cudaError_t)0)
    #define pdhcg_timing_print() do {} while(0)
    #define pdhcg_timing_cleanup() do {} while(0)
    #define pdhcg_timing_scope_start(id) ((cudaError_t)0)
    #define pdhcg_timing_scope_stop(id) ((cudaError_t)0)
#endif

#ifdef __cplusplus
}
#endif

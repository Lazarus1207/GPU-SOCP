include(CMakeFindDependencyMacro)
find_dependency(CUDAToolkit 12.4)
if(NOT TARGET spmv::spmv)
  get_filename_component(_spmv_root "${CMAKE_CURRENT_LIST_DIR}/../../.." ABSOLUTE)
  add_library(spmv::spmv STATIC IMPORTED)
  set_target_properties(spmv::spmv PROPERTIES
    IMPORTED_LOCATION "${_spmv_root}/lib/libspmv.a"
    INTERFACE_INCLUDE_DIRECTORIES "${_spmv_root}/include"
    INTERFACE_LINK_LIBRARIES "CUDA::cudart"
    INTERFACE_COMPILE_FEATURES "cxx_std_17")
  unset(_spmv_root)
endif()

#!/bin/bash
#===============================================================================
# Patch: 缁?PDHCG CLI 娣诲姞 --spmv_backend 鍙傛暟
#===============================================================================
# 鐢ㄦ硶锛歝d ~/PDHCG && bash apply_cli_patch.sh
# 鍥炴粴锛歮v src/cli.c.bak src/cli.c
#===============================================================================

set -e

cd "$(dirname "${BASH_SOURCE[0]}")/../PDHCG-exp" || cd "$(pwd)"

echo "[cli-patch] 褰撳墠鐩綍: $(pwd)"

CLI_C="src/cli.c"

# ---- 澶囦唤 ----
[ -f "${CLI_C}.bak" ] || cp "$CLI_C" "${CLI_C}.bak"
echo "[cli-patch] 宸插浠?$CLI_C"

# =============================================================================
# Step 1: 娣诲姞 #include "spmv_backend.h"
# =============================================================================
# 鐢?awk 鍦ㄧ涓€涓?#include "solver.h" 涔嬪悗杩藉姞
TMP=$(mktemp)
awk '
    /^#include "solver.h"$/ && !done {
        print
        print "#include \"spmv_backend.h\""
        done = 1
        next
    }
    { print }
' "$CLI_C" > "$TMP" && mv "$TMP" "$CLI_C"
echo "[cli-patch] 娣诲姞 #include"

# =============================================================================
# Step 2: 鍦?help 鏂囨湰涓拷鍔?--spmv_backend
# =============================================================================
# 鎴戜滑鐢ㄤ竴涓畝鍗?sed 鍗曡鏇挎崲锛氬湪鍖呭惈 'soc_form' 鐨勯偅涓€琛屾湯灏捐拷鍔犲府鍔┿€?
# 娉ㄦ剰锛氭墍鏈?\n 鍦?sed 閲岀敤鍙嶆枩鏉犵画琛屽睍寮€涓烘崲琛屻€?
TMP=$(mktemp)
awk '
    /QCQP cone formulation/ && !done {
        # 鍦ㄨ琛屽悗闈㈡彃鍏ヤ竴琛?help 鏂囨湰
        print
        print "      --spmv_backend <type>  SpMV backend: cusparse or new (default: cusparse)."
        done = 1
        next
    }
    { print }
' "$CLI_C" > "$TMP" && mv "$TMP" "$CLI_C"
echo "[cli-patch] 娣诲姞 help 鏂囨湰"

# =============================================================================
# Step 3: 鍦?long_options 鏁扮粍閲屽姞涓€椤?
# =============================================================================
# 閿氱偣锛歝urtis_reid_iter 閭ｄ竴琛屽悗闈㈣拷鍔?
TMP=$(mktemp)
awk '
    /"curtis_reid_iter", required_argument, 0, 1025/ && !done {
        print
        print "                                           {\"spmv_backend\", required_argument, 0, 1026},"
        done = 1
        next
    }
    { print }
' "$CLI_C" > "$TMP" && mv "$TMP" "$CLI_C"
echo "[cli-patch] 娣诲姞 long_options 椤?

# =============================================================================
# Step 4: 鍦?switch 鐨?case 1025 涔嬪悗鍔?case 1026
# =============================================================================
# 鍦?"break;" 绱ц窡鍦?case 1025 鍧楁湯灏剧殑浣嶇疆鍓嶄竴琛屽姞 case 1026 娈?
TMP=$(mktemp)
awk '
    BEGIN { in_1025 = 0 }
    /^            case 1025:$/ { in_1025 = 1 }
    in_1025 && /^                break;$/ {
        # 杩欐槸 case 1025 鐨?break锛屽厛鎵撳嵃鏂?case 1026锛屽啀鎵撳嵃鍘?break
        print "            case 1026:"
        print "                if (strcmp(optarg, \"cusparse\") == 0)"
        print "                {"
        print "                    pdhcg_set_spmv_backend(0);"
        print "                }"
        print "                else if (strcmp(optarg, \"new\") == 0)"
        print "                {"
        print "                    pdhcg_set_spmv_backend(1);"
        print "                }"
        print "                else"
        print "                {"
        print "                    fprintf(stderr, \"Error: --spmv_backend must be cusparse or new\\n\");"
        print "                    return 1;"
        print "                }"
        in_1025 = 0
    }
    { print }
' "$CLI_C" > "$TMP" && mv "$TMP" "$CLI_C"
echo "[cli-patch] 娣诲姞 case 1026"

echo ""
echo "========================================"
echo "[cli-patch] CLI patch 瀹屾垚"
echo "========================================"

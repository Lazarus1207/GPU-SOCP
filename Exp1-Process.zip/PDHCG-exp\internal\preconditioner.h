/*
Copyright 2025 Haihao Lu
Copyright 2026 Hongpei Li

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

#pragma once

#include "internal_types.h"

#ifdef __cplusplus
extern "C"
{
#endif
    processed_qp_problem_t *preprocess_qp_problem(const qp_problem_t *raw_problem);
    void free_processed_qp_problem(processed_qp_problem_t *processed);
    rescale_info_t *rescale_problem(const pdhg_parameters_t *params, const qp_problem_t *original_problem);

#ifdef __cplusplus
}
#endif

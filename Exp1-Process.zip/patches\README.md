# PDHCG Patches — 非侵入式集成方案

## 概述

本目录提供一套 **sed-based patch 方案**，让你在不修改原始 PDHCG 代码文件的前提下，将 Exp1-Process 的两项改动（Timing + New SpMV）注入到服务器上已有的 PDHCG 源码。

**核心原则**：
- 不修改原有文件的编译逻辑
- 通过 sed 定点注入新代码段
- 所有改动都有 `.bak` 备份
- 一条命令回滚

## 文件清单

```
patches/
├── apply_all_patches.sh      # 一键应用所有 patch（推荐）
├── apply_spmv_backend_patch.sh # 仅 SpMV backend patch
├── apply_cli_patch.sh          # 仅 CLI patch
├── apply_timing_patch.sh      # 仅 Timing patch
├── restore_original.sh        # 回滚所有改动
├── timing_profiler.h          # Timing 基础设施（独立头文件）
├── spmv_backend_new.cu       # New SpMV wrapper（独立 .cu 文件）
└── README.md                  # 本文件
```

## 服务器使用流程

### 方式 A：一条命令搞定（推荐）

```bash
# 1. 复制 patches 目录到服务器
# (假设你的 PDHCG 源码在 ~/PDHCG)
cp -r ~/testHM/Exp1-Process/patches ~/patches

# 2. 进入 PDHCG 源码目录
cd ~/PDHCG

# 3. 一键应用所有 patch
bash ~/patches/apply_all_patches.sh

# 4. 编译（仅编译新增的 spmv_backend_new.cu）
mkdir build_exp1 && cd build_exp1
cmake .. \
    -DPDHCG_ENABLE_TIMING=ON \
    -DCMAKE_CUDA_ARCHITECTURES="80;86;89;90"
make -j$(nproc) pdhcg

# 5. 回滚（如需）
cd ~/PDHCG
bash ~/patches/restore_original.sh
```

### 方式 B：分步应用

```bash
cd ~/PDHCG

# 单独应用 SpMV patch
bash ~/patches/apply_spmv_backend_patch.sh

# 单独应用 CLI patch
bash ~/patches/apply_cli_patch.sh

# 单独应用 Timing patch
bash ~/patches/apply_timing_patch.sh
```

### 方式 C：仅 Timing（不改 SpMV）

```bash
cd ~/PDHCG
bash ~/patches/apply_timing_patch.sh
```

## Patch 详情

### 1. SpMV Backend Patch

**文件**：
- `internal/spmv_backend.h` — 添加 `new_spmv_plan` 等字段
- `src/spmv_backend.cu` — 添加 new SpMV 创建/调用/fallback 逻辑
- `src/spmv_backend_new.cu` — 新增独立 wrapper 文件

**注入点**：
- `pdhcg_spmv_ctx_t` 结构体末尾 — 新增 3 个字段
- `pdhcg_spmv_ctx_create` — 在 cuSPARSE 创建前尝试 new SpMV
- `pdhcg_spmv_ctx_destroy` — 在 cuSPARSE 销毁前处理 new SpMV
- `pdhcg_spmv_execute` — 在 cuSPARSE 调用前尝试 new SpMV

### 2. CLI Patch

**文件**：
- `src/cli.c` — 添加 `--spmv_backend` 参数

**注入点**：
- `#include` 列表 — 添加 `spmv_backend.h`
- `print_usage` — 添加 `--spmv_backend` 帮助文本
- `long_options` 数组 — 添加 `{"spmv_backend", ...}`
- `switch` 语句 — 添加 `case 1026` 处理

### 3. Timing Patch

**文件**：
- `internal/timing_profiler.h` — 复制到 internal/
- `src/solver.cu` — 添加 `pdhcg_timing_init/finalize/print`
- `src/pdhg_core_op.cu` — 在 SpMV 调用点添加 CUDA Event

**注入点**：
- `solver.cu` 顶部 — 添加 `#include "timing_profiler.h"`
- `optimize()` 函数开始 — 添加 `pdhcg_timing_init()`
- `optimize()` 返回前 — 添加 `pdhcg_timing_finalize/print/cleanup()`
- `pdhg_core_op.cu` — 在 `SpMV_At` / `SpMV_A` 调用前后添加 event

## 编译说明

### Baseline + Timing（不改 SpMV）

```bash
mkdir build_timing && cd build_timing
cmake ../PDHCG \
    -DPDHCG_ENABLE_TIMING=ON \
    -DCMAKE_CUDA_ARCHITECTURES="80;86;89;90"
make -j$(nproc) pdhcg
```

### Baseline + Timing + New SpMV

```bash
mkdir build_spmv && cd build_spmv
cmake ../PDHCG \
    -DPDHCG_ENABLE_TIMING=ON \
    -DPDHCG_USE_NEW_SPMV=ON \
    -DSPMV_BACKEND_ROOT=~/testHM/Exp1-Process/SpMV/spmv-backend \
    -DCMAKE_CUDA_ARCHITECTURES="80;86;89;90"
make -j$(nproc) pdhcg
```

## 回滚

### 方法 1：使用 restore 脚本

```bash
cd ~/PDHCG
bash ~/patches/restore_original.sh
```

### 方法 2：手动恢复备份

```bash
cd ~/PDHCG
for f in src/spmv_backend.cu internal/spmv_backend.h src/cli.c src/pdhg_core_op.cu src/solver.cu; do
    mv "$f.bak" "$f"
done
rm -f src/spmv_backend_new.cu internal/timing_profiler.h
```

## 注意事项

1. **sed 平台兼容性**：所有 patch 脚本使用 GNU sed，在 Linux 上正常工作。如服务器使用非 GNU sed（如 macOS），可能需要调整。
2. **文件备份**：所有原文件都以 `.bak` 后缀备份，可随时恢复。
3. **Patch 顺序**：建议按 `apply_all_patches.sh` 的顺序应用，各 patch 间有一定依赖。
4. **New SpMV 库**：启用 SpMV patch 时需要 `~/testHM/Exp1-Process/SpMV/spmv-backend/` 存在。
5. **重复应用**：同一 patch 不能重复应用。如需重试，请先回滚。

## 故障排查

| 问题 | 原因 | 解决 |
|------|------|------|
| `spmv_backend.cu: ... not found` | `.cu` 文件有语法错误 | 检查 `.bak` 文件，sed 注入失败 |
| `undefined reference to pdhcg_set_spmv_backend` | `spmv_backend_new.cu` 未复制 | 确认文件在 `src/` |
| `undefined reference to pdhcg_timing_init` | `timing_profiler.h` 未复制 | 确认文件在 `internal/` |
| `sed: extra characters after` | sed 命令行格式问题 | GNU sed 版本问题，尝试 `sed --version` |
| 编译报错但无法定位 | 多个 patch 叠加效果 | 逐个 patch 回滚测试 |

## 验证

建议按以下顺序验证 patch：

```bash
# 1. 仅 Timing — 编译通过 + 有 timing 输出
cd ~/PDHCG
bash ~/patches/restore_original.sh
bash ~/patches/apply_timing_patch.sh
mkdir build_t && cd build_t
cmake .. -DPDHCG_ENABLE_TIMING=ON && make -j8 pdhcg
./pdhcg ~/testHM/benchmark/socp/beam7.cbf.gz /tmp/out/ --verbose 2 | grep -A20 "Timing"
# 应看到各组件时间表

# 2. 仅 SpMV — 编译通过 + 结果正确
bash ~/patches/restore_original.sh
bash ~/patches/apply_spmv_backend_patch.sh
bash ~/patches/apply_cli_patch.sh
mkdir build_s && cd build_s
cmake .. -DPDHCG_USE_NEW_SPMV=ON -DSPMV_BACKEND_ROOT=... && make -j8 pdhcg
./pdhcg problem.cbf.gz /tmp/out/ --spmv_backend=cusparse   # baseline
./pdhcg problem.cbf.gz /tmp/out/ --spmv_backend=new        # new
# 对比两者的 obj_value / gap

# 3. 全部 — 编译通过 + 两项功能正常
bash ~/patches/restore_original.sh
bash ~/patches/apply_all_patches.sh
mkdir build_all && cd build_all
cmake .. -DPDHCG_ENABLE_TIMING=ON -DPDHCG_USE_NEW_SPMV=ON ... && make -j8 pdhcg
./pdhcg problem.cbf.gz /tmp/out/ --verbose 2 --spmv_backend=new
# 应同时看到 timing 输出
```

# 实验记录

## 实验目的
建立 PDHCG-CQP SOCP 求解器的 baseline performance profile，
识别各计算环节的时间占比，作为后续优化的基准。

## 修改内容

### 1. 添加分环节 timing

- 文件: `PDHCG-exp/internal/timing_profiler.h`
- 实现 CUDA Event-based 微秒级计时
- 14 个 scope 注册：SpMV_At, SpMV_A, SpMV_Q, SpMV_R, Cone_Projection, Bound_Projection, Inner_Solver, Residual_Computation, Termination_Check, Halpern_Update, Restart, Scaling, AllReduce, Kernel_Launch_Overhead

### 2. 添加 timing 调用点

在 `pdhg_core_op.cu` 中关键计算点添加 timer：
- `pdhcg_spmv_execute` 调用前后
- `dispatch_cone_projection` 调用前后
- `compute_residual` 调用前后
- `compute_fixed_point_error` 调用前后
- `halpern_update` 调用前后
- `perform_restart` 调用前后

### 3. 编译与运行

```bash
mkdir build_timing && cd build_timing
cmake ../PDHCG-exp \
    -DCMAKE_BUILD_TYPE=Release \
    -DPDHCG_ENABLE_TIMING=ON \
    -DCMAKE_CUDA_ARCHITECTURES="80;86;89;90"
make -j8 pdhcg

# 单题测试
./pdhcg ../benchmark/socp/beam7.cbf.gz /tmp/beam7_output/ 2>&1 | tee beam7_log.txt
```

## 实验设置

- **GPU**: 单卡 H100
- **CUDA Toolkit**: 12.4+
- **问题**: SOCP 18 题
- **时间限制**: 3600s
- **容差**: eps_opt = eps_feas = 1e-4

## 运行命令

```bash
cd scripts
./run_timing.sh --clean --timing beam7
```

## 结果（待填）

### 各组件时间占比

| 组件 | beam7 | beam30 | dsNRL | firL2a |
|------|-------|--------|-------|--------|
| SpMV_At | - | - | - | - |
| SpMV_A | - | - | - | - |
| Cone_Projection | - | - | - | - |
| ... | | | | |

### 瓶颈排名

| 组件 | 平均占比 | 评价 |
|------|----------|------|
| SpMV | 50% | HIGH |
| Cone_Projection | 20% | MEDIUM |
| ... | | |

## 结论

待填

## 决策

KEEP / NEED MORE TESTING / REJECT

/*
Copyright 2026 Exp1-Process

Process-level timing infrastructure for PDHCG.
This is a standalone header - copy to internal/timing_profiler.h.

Enable by compiling with -DPDHCG_ENABLE_TIMING.
*/

#include <cuda_runtime.h>
#include <stdio.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C"
{
#endif

#define TIMING_MAX_SCOPES 16

typedef struct {
    const char* name;
    cudaEvent_t start;
    cudaEvent_t stop;
    double total_ms;
    int count;
    int enabled;
} timing_scope_t;

typedef struct {
    timing_scope_t scopes[TIMING_MAX_SCOPES];
    int num_scopes;
    int initialized;
} pdhcg_timing_context_t;

static pdhcg_timing_context_t g_timing_ctx = {0};

int pdhcg_timing_register_scope(const char* name) {
    if (g_timing_ctx.num_scopes >= TIMING_MAX_SCOPES) return -1;
    int id = g_timing_ctx.num_scopes++;
    timing_scope_t* scope = &g_timing_ctx.scopes[id];
    scope->name = name;
    cudaEventCreate(&scope->start);
    cudaEventCreate(&scope->stop);
    scope->total_ms = 0.0;
    scope->count = 0;
    scope->enabled = 1;
    return id;
}

cudaError_t pdhcg_timing_init(void) {
    if (g_timing_ctx.initialized) return cudaSuccess;
    g_timing_ctx.num_scopes = 0;

    pdhcg_timing_register_scope("SpMV_At");
    pdhcg_timing_register_scope("SpMV_A");
    pdhcg_timing_register_scope("SpMV_Q");
    pdhcg_timing_register_scope("SpMV_R");
    pdhcg_timing_register_scope("Cone_Projection");
    pdhcg_timing_register_scope("Bound_Projection");
    pdhcg_timing_register_scope("Inner_Solver");
    pdhcg_timing_register_scope("Residual_Computation");
    pdhcg_timing_register_scope("Termination_Check");
    pdhcg_timing_register_scope("Halpern_Update");
    pdhcg_timing_register_scope("Restart");
    pdhcg_timing_register_scope("Scaling");
    pdhcg_timing_register_scope("AllReduce");
    pdhcg_timing_register_scope("Kernel_Launch_Overhead");

    g_timing_ctx.initialized = 1;
    return cudaSuccess;
}

void pdhcg_timing_record(int scope_id, float elapsed_ms) {
    if (scope_id < 0 || scope_id >= g_timing_ctx.num_scopes) return;
    g_timing_ctx.scopes[scope_id].total_ms += elapsed_ms;
    g_timing_ctx.scopes[scope_id].count++;
}

cudaError_t pdhcg_timing_finalize(void) {
    if (!g_timing_ctx.initialized) return cudaErrorInvalidValue;
    return cudaDeviceSynchronize();
}

void pdhcg_timing_print(void) {
    if (!g_timing_ctx.initialized) return;

    double total_time = 0.0;
    for (int i = 0; i < g_timing_ctx.num_scopes; i++)
        total_time += g_timing_ctx.scopes[i].total_ms;

    printf("\n========================================\n");
    printf("PDHCG Process-level Timing Profile\n");
    printf("========================================\n");
    printf("%-30s %12s %8s %12s %8s\n",
           "Component", "Total (ms)", "Count", "Avg (ms)", "Percent");
    printf("----------------------------------------\n");

    for (int i = 0; i < g_timing_ctx.num_scopes; i++) {
        timing_scope_t* scope = &g_timing_ctx.scopes[i];
        if (scope->count > 0) {
            double avg = scope->total_ms / scope->count;
            double pct = (total_time > 0) ? (scope->total_ms / total_time * 100.0) : 0.0;
            printf("%-30s %12.2f %8d %12.4f %7.2f%%\n",
                   scope->name, scope->total_ms, scope->count, avg, pct);
        }
    }
    printf("----------------------------------------\n");
    printf("%-30s %12.2f\n", "TOTAL (sum of components)", total_time);
    printf("========================================\n");
}

void pdhcg_timing_cleanup(void) {
    for (int i = 0; i < g_timing_ctx.num_scopes; i++) {
        cudaEventDestroy(g_timing_ctx.scopes[i].start);
        cudaEventDestroy(g_timing_ctx.scopes[i].stop);
    }
    g_timing_ctx.num_scopes = 0;
    g_timing_ctx.initialized = 0;
}

// Timing scope IDs
#ifdef PDHCG_ENABLE_TIMING
#define TIMING_SCOPE_SPMV_AT      0
#define TIMING_SCOPE_SPMV_A       1
#define TIMING_SCOPE_SPMV_Q       2
#define TIMING_SCOPE_SPMV_R       3
#define TIMING_SCOPE_CONE_PROJ     4
#define TIMING_SCOPE_BOUND_PROJ    5
#define TIMING_SCOPE_INNER_SOLVER 6
#define TIMING_SCOPE_RESIDUAL     7
#define TIMING_SCOPE_TERMINATION  8
#define TIMING_SCOPE_HALPERN      9
#define TIMING_SCOPE_RESTART      10
#define TIMING_SCOPE_SCALING      11
#define TIMING_SCOPE_ALLREDUCE    12
#define TIMING_SCOPE_KERNEL_OH    13

// Helper macro for timing a scope
#define PDHCG_TIMING_MEASURE(scope_id) \
    cudaEvent_t _pdhcg_t_start, _pdhcg_t_stop; \
    cudaEventCreate(&_pdhcg_t_start); \
    cudaEventCreate(&_pdhcg_t_stop); \
    cudaEventRecord(_pdhcg_t_start, 0); \
    /* code to be timed */ \
    cudaEventRecord(_pdhcg_t_stop, 0); \
    cudaEventSynchronize(_pdhcg_t_stop); \
    float _pdhcg_t_elapsed; \
    cudaEventElapsedTime(&_pdhcg_t_elapsed, _pdhcg_t_start, _pdhcg_t_stop); \
    pdhcg_timing_record(scope_id, _pdhcg_t_elapsed); \
    cudaEventDestroy(_pdhcg_t_start); \
    cudaEventDestroy(_pdhcg_t_stop);
#else
#define PDHCG_TIMING_MEASURE(scope_id) /* no-op */
#endif

#ifdef __cplusplus
}
#endif

/*
Copyright 2026 Exp1-Process

Integration wrapper for new SpMV backend (libspmv.a).
This file is only compiled when PDHCG_USE_NEW_SPMV is defined.

The new SpMV backend provides a C ABI for y = alpha*A*x + beta*y operations
on FP64 CSR matrices. It claims ~1.25x speedup over cuSPARSE SpMVOp ALG2.

Reference: spmv-backend/include/spmv.h
*/

#ifdef PDHCG_USE_NEW_SPMV

#include "spmv_backend.h"
#include "spmv.h"  // New SpMV public C ABI
#include "utils.h"

#include <cuda_runtime.h>
#include <stdio.h>
#include <stdlib.h>

//---------------------------------------------------------------------------
// Global backend selection
//---------------------------------------------------------------------------
// 0 = cuSPARSE (default), 1 = new SpMV

#ifdef PDHCG_USE_NEW_SPMV
static int g_pdhcg_new_spmv_backend = PDHCG_NEW_SPMV_RUNTIME_DEFAULT;

extern "C" void pdhcg_set_spmv_backend(int backend)
{
    if (backend == 0 || backend == 1)
    {
        g_pdhcg_new_spmv_backend = backend;
    }
}

extern "C" int pdhcg_get_spmv_backend(void)
{
    return g_pdhcg_new_spmv_backend;
}
#else
// Stubs when new SpMV backend is not compiled in.
// Always report cuSPARSE (0); set calls are silently ignored.
extern "C" void pdhcg_set_spmv_backend(int backend)
{
    (void)backend;
}

extern "C" int pdhcg_get_spmv_backend(void)
{
    return 0;
}
#endif

//---------------------------------------------------------------------------
// Helper: get current CUDA stream from cusparse handle
//---------------------------------------------------------------------------
// NOTE: cuSPARSE handle owns a stream. We can query it for consistency.
static cudaStream_t pdhcg_get_current_stream(cusparseHandle_t handle)
{
    cudaStream_t stream = 0;
    if (handle != nullptr)
    {
        // cusparseGetStream is available in CUDA 10.1+
        cusparseGetStream(handle, &stream);
    }
    return stream;
}

//---------------------------------------------------------------------------
// Context creation for new backend
//---------------------------------------------------------------------------
// Returns cudaSuccess on success, error code on failure
extern "C" cudaError_t pdhcg_new_spmv_ctx_create(pdhcg_spmv_ctx_t *ctx,
                                                 int num_rows,
                                                 int num_cols,
                                                 int num_nonzeros,
                                                 int *row_ptr,
                                                 int *col_ind,
                                                 double *val,
                                                 cusparseHandle_t sparse_handle)
{
    if (ctx == nullptr || num_nonzeros == 0)
    {
        return cudaErrorInvalidValue;
    }

    ctx->new_spmv_plan = nullptr;
    ctx->new_spmv_workspace = nullptr;
    ctx->new_spmv_workspace_bytes = 0;

    cudaStream_t stream = pdhcg_get_current_stream(sparse_handle);

    // Create plan
    cudaError_t err = spmv_plan_create(
        (spmv_plan **)&ctx->new_spmv_plan,
        num_rows, num_cols, num_nonzeros,
        row_ptr, col_ind, val,
        stream);

    if (err != cudaSuccess)
    {
        fprintf(stderr, "[new_spmv] spmv_plan_create failed: %s\n", cudaGetErrorString(err));
        ctx->new_spmv_plan = nullptr;
        return err;
    }

    // Get workspace size
    err = spmv_workspace_size((spmv_plan *)ctx->new_spmv_plan,
                              &ctx->new_spmv_workspace_bytes);
    if (err != cudaSuccess)
    {
        fprintf(stderr, "[new_spmv] spmv_workspace_size failed: %s\n", cudaGetErrorString(err));
        spmv_plan_destroy((spmv_plan *)ctx->new_spmv_plan);
        ctx->new_spmv_plan = nullptr;
        return err;
    }

    // Allocate workspace if needed
    if (ctx->new_spmv_workspace_bytes > 0)
    {
        err = cudaMalloc(&ctx->new_spmv_workspace, ctx->new_spmv_workspace_bytes);
        if (err != cudaSuccess)
        {
            fprintf(stderr, "[new_spmv] cudaMalloc workspace failed: %s\n", cudaGetErrorString(err));
            spmv_plan_destroy((spmv_plan *)ctx->new_spmv_plan);
            ctx->new_spmv_plan = nullptr;
            return err;
        }
    }

    if (getenv("PDHCG_NEW_SPMV_DEBUG"))
    {
        fprintf(stderr, "[new_spmv] Created plan: %d x %d, nnz=%d, workspace=%zu bytes\n",
                num_rows, num_cols, num_nonzeros, ctx->new_spmv_workspace_bytes);
    }

    return cudaSuccess;
}

//---------------------------------------------------------------------------
// Execute y = alpha*A*x + beta*y using new backend
//---------------------------------------------------------------------------
extern "C" cudaError_t pdhcg_new_spmv_execute(pdhcg_spmv_ctx_t *ctx,
                                              cusparseHandle_t sparse_handle,
                                              const double *alpha,
                                              const double *beta,
                                              const double *x,
                                              double *y)
{
    if (ctx == nullptr || ctx->new_spmv_plan == nullptr)
    {
        return cudaErrorInvalidValue;
    }

    double alpha_h = (alpha != nullptr) ? *alpha : 1.0;
    double beta_h = (beta != nullptr) ? *beta : 0.0;

    cudaStream_t stream = pdhcg_get_current_stream(sparse_handle);

    cudaError_t err = spmv_execute(
        (spmv_plan *)ctx->new_spmv_plan,
        x, y,
        alpha_h, beta_h,
        ctx->new_spmv_workspace, ctx->new_spmv_workspace_bytes,
        stream);

    return err;
}

//---------------------------------------------------------------------------
// Destroy new backend context
//---------------------------------------------------------------------------
extern "C" void pdhcg_new_spmv_ctx_destroy(pdhcg_spmv_ctx_t *ctx)
{
    if (ctx == nullptr)
    {
        return;
    }

    if (ctx->new_spmv_plan != nullptr)
    {
        spmv_plan_destroy((spmv_plan *)ctx->new_spmv_plan);
        ctx->new_spmv_plan = nullptr;
    }

    if (ctx->new_spmv_workspace != nullptr)
    {
        cudaFree(ctx->new_spmv_workspace);
        ctx->new_spmv_workspace = nullptr;
    }
    ctx->new_spmv_workspace_bytes = 0;
}

#endif  // PDHCG_USE_NEW_SPMV

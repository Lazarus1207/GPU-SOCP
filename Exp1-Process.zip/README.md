# PDHCG Process-level Tuning 实验文件夹

本文件夹包含 PDHCG 求解器的 Process-level 性能调优相关材料。

## 目录结构

```
Exp1-Process/
├── instruction.txt                # 任务说明
├── README.md                       # 本文件
├── plan.md                         # 总体方案
├── PDHCG-exp/                      # PDHCG 代码副本（用于实验调试）
├── SpMV/                           # SpMV 新算子包
│   └── spmv-backend/              # SpMV 二进制库 + 头文件
├── scripts/                        # 分析和运行脚本
│   ├── run_timing.sh              # 批量运行 timing 测试
│   ├── analyze_timing.py          # Timing 结果分析
│   └── compare_runs.py            # Baseline 对比
├── timing_results/                 # Timing 实验结果（运行后生成）
├── experiments/                    # 实验记录（按编号创建）
│   ├── exp_001_baseline_profile.md
│   ├── exp_002_spmv_integration.md
│   └── ...
└── process_tuning.md              # 最终 tuning 报告
```

## 任务分工

### 任务 1: 分环节 Timing（已完成）
- 在 `PDHCG-exp/` 中添加了 timing 基础设施
- `internal/timing_profiler.h` - CUDA Event-based 计时
- `scripts/run_timing.sh` - 批量运行脚本
- `scripts/analyze_timing.py` - 结果分析

### 任务 2: SpMV 算子集成（已完成方案，待实施）
- `SpMV/spmv-backend/` - 新算子包
- 详细的集成方案见 `spmv_integration_plan.md`

## 使用说明

### 运行 Timing 测试

```bash
cd scripts
./run_timing.sh --clean --timing       # 全量运行
./run_timing.sh beam7                   # 单题运行
./run_timing.sh --spmv beam7           # 使用新 SpMV
```

### 分析 Timing 结果

```bash
cd scripts
python3 analyze_timing.py \
    --input timing_results/beam7_log.txt \
    --output timing_results/beam7_report.json \
    --verbose
```

### 对比实验结果

```bash
python3 compare_runs.py \
    --baseline results/baseline/ \
    --candidate results/spmv/ \
    --output comparison.json
```

## 当前实验状态

- [x] 完成 timing 基础设施
- [x] 完成分析脚本框架
- [x] 完成 SpMV 集成方案设计
- [ ] 在服务器运行 baseline timing
- [ ] 验证 new SpMV 集成效果
- [ ] 消融实验

## 关键观察

1. **SpMV 占比**: 预估 SOCP 问题中 SpMV 占总时间 50-60%
2. **新 SpMV 提升**: 厂商声明相对 SpMVOp ALG2 几何平均加速 1.249822x
3. **预期总加速**: ~10-15% (取决于 SpMV 实际占比)

## 注意

- 新 SpMV 库是闭源二进制的，提供的是 C ABI 接口
- spmv_ 函数需通过 find_package(spmv CONFIG REQUIRED) 集成
- 实测环境：CUDA 12.4+，sm_80/86/89/90 GPU

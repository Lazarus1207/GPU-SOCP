#pragma once

#include <cuda_runtime_api.h>

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct spmv_plan spmv_plan;
typedef spmv_plan spmv_plan_t;

/* 调用约定（闭源发行包）：
 * - 输入为 GPU 上从零开始的 int32 CSR，矩阵/向量数值为 double。
 * - 原始 CSR 三个数组由调用方拥有，必须在 plan 的整个使用期内保持有效且不变。
 * - 修改结构或数值后应销毁旧 plan 并重新创建；没有原地更新接口。
 * - setup 返回时预处理已完成。execute 异步入队，调用方负责 stream 依赖。
 * - 同一 plan 不应跨 stream 并发执行，即使各自分配了 workspace。
 * - 释放 plan、CSR、workspace、向量前，必须等待相关 GPU 工作完成。
 * - 不支持原生转置；请在外部建立 A^T 的 CSR 并创建独立 plan。
 */

/* Build an immutable plan from zero-based int32 CSR device arrays.
 * Preprocessing and validation finish before this function returns.
 *
 * The CSR contract is checked: dimensions must be nonnegative, row_offsets
 * must start at zero, be nondecreasing, stay in [0, nnz], and end at nnz;
 * every column index must be in [0, columns). On every failure, *plan is null
 * and a CUDA error code is returned. No C++ exception crosses this C ABI.
 * The caller remains responsible for allocating rows + 1 row offsets and nnz
 * column/value entries because raw device pointers do not carry their sizes. */
cudaError_t spmv_plan_create(spmv_plan** plan,
                                   int32_t rows,
                                   int32_t columns,
                                   int32_t nnz,
                                   const int32_t* d_row_offsets,
                                   const int32_t* d_column_indices,
                                   const double* d_values,
                                   cudaStream_t stream);

/* Faster plan creation for callers that already guarantee the documented CSR
 * contract. Invalid offsets or column indices result in undefined behavior. */
cudaError_t spmv_plan_create_trusted(spmv_plan** plan,
                                     int32_t rows,
                                     int32_t columns,
                                     int32_t nnz,
                                     const int32_t* d_row_offsets,
                                     const int32_t* d_column_indices,
                                     const double* d_values,
                                     cudaStream_t stream);

cudaError_t spmv_plan_destroy(spmv_plan* plan);

/* Execute y = alpha * A * x + beta * y.
 * d_x 长度至少为 columns，d_y 长度至少为 rows，两者不得重叠。
 * alpha/beta 是按值传入的主机标量，不是 device scalar 指针。
 * beta != 0 时 d_y 必须已经初始化；beta == 0 时无需初始化旧 y 数值。
 * workspace 通过 cudaMalloc 分配，可在串行执行间复用；需求为 0 时可传 NULL。
 * 返回成功仅表示入队/启动检查成功；异步错误应在同步或后续 CUDA 检查中处理。
 * 热循环中无需每次同步；可让后续 GPU 运算在同一 stream 中消费结果。 */
cudaError_t spmv_execute(const spmv_plan* plan,
                         const double* d_x,
                         double* d_y,
                         double alpha,
                         double beta,
                         void* workspace,
                         size_t workspace_bytes,
                         cudaStream_t stream);

cudaError_t spmv_workspace_size(const spmv_plan* plan, size_t* bytes);


/* 返回 plan 自身拥有的设备内存字节数，不包含原始 CSR 和调用方 workspace。 */
size_t spmv_plan_bytes(const spmv_plan* plan);

#ifdef __cplusplus
}
#endif

#!/usr/bin/env python3
"""
PDHCG-II 批量测试脚本
直接读 .cbf.gz 文件，不用解压，结果汇总到 CSV。

用法:
    python run_pdhcg_batch.py --input-dir D:/PDCS/CBLIB/represent_data \
                              --output-dir ./results \
                              --time-limit 600 \
                              --iter-limit 5000 \
                              --tol 1e-4 \
                              [--gpu] [--workers 4]

也可以按子集:
    python run_pdhcg_batch.py --input-dir ... --filter cbf --limit 5
"""

from __future__ import annotations

import argparse
import csv
import sys
import time
import traceback
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

import numpy as np


def solve_one(args):
    """
    单文件求解 (子进程安全):
      从 pdhcg 读文件 -> 求解 -> 返回精简的运行结果 dict
    """
    (cbf_path, output_dir, time_limit, iter_limit, tol, use_gpu) = args

    out_dir = Path(output_dir) / "individual"
    out_dir.mkdir(parents=True, exist_ok=True)

    rec = {
        "file": Path(cbf_path).name,
        "status": "ERROR",
        "iterations": "",
        "runtime_sec": "",
        "obj_value": "",
        "rel_gap": "",
        "rel_p_res": "",
        "rel_d_res": "",
        "error": "",
    }

    try:
        # 在子进程里 import，保证单线程 CUDA 上下文干净
        from pdhcg import Model

        t0 = time.time()
        m = Model.read_file(str(cbf_path))
        rec["load_sec"] = round(time.time() - t0, 4)

        m.setParams(
            LogLevel=0,
            time_sec_limit=float(time_limit),
            iteration_limit=int(iter_limit),
            eps_optimal_relative=float(tol),
            eps_feasible_relative=float(tol),
            use_gpu=use_gpu,
        )

        t0 = time.time()
        m.optimize()
        rec["solve_sec"] = round(time.time() - t0, 4)

        rec["status"] = m.Status or "UNKNOWN"
        rec["iterations"] = m.IterCount if m.IterCount is not None else ""
        rec["runtime_sec"] = round(m.Runtime or 0.0, 4)
        rec["obj_value"] = m.ObjVal if m.ObjVal is not None else ""
        rec["rel_gap"] = round(m.RelGap, 8) if m.RelGap is not None else ""
        rec["rel_p_res"] = round(m.RelPrimalResidual, 8) if m.RelPrimalResidual is not None else ""
        rec["rel_d_res"] = round(m.RelDualResidual, 8) if m.RelDualResidual is not None else ""

        # 保存每个问题的解到结果目录
        summary_path = out_dir / f"{Path(cbf_path).stem}.txt"
        with open(summary_path, "w", encoding="utf-8") as fh:
            fh.write(f"file: {rec['file']}\n")
            fh.write(f"status: {rec['status']}\n")
            fh.write(f"iterations: {rec['iterations']}\n")
            fh.write(f"runtime_sec: {rec['runtime_sec']}\n")
            fh.write(f"obj_value: {rec['obj_value']}\n")
            fh.write(f"rel_gap: {rec['rel_gap']}\n")
            fh.write(f"rel_p_res: {rec['rel_p_res']}\n")
            fh.write(f"rel_d_res: {rec['rel_d_res']}\n")
    except Exception as exc:  # noqa: BLE001
        rec["error"] = f"{type(exc).__name__}: {exc}"
        rec["traceback"] = traceback.format_exc(limit=3)

    return rec


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="批量跑 PDHCG-II 在 CBLIB 上的测试")
    p.add_argument("--input-dir", required=True, help="含 .cbf.gz 文件的目录")
    p.add_argument("--output-dir", required=True, help="结果输出目录")
    p.add_argument("--time-limit", type=float, default=600.0, help="每题秒数上限")
    p.add_argument("--iter-limit", type=int, default=20000, help="每题迭代上限")
    p.add_argument("--tol", type=float, default=1e-4, help="opt/feas 相对容差")
    p.add_argument("--gpu", action="store_true", help="启用 GPU")
    p.add_argument("--workers", type=int, default=1,
                   help="并行子进程数 (注意: GPU 模式写 1，避免 CUDA context 冲突)")
    p.add_argument("--limit", type=int, default=0, help="最多跑多少题, 0=全部")
    p.add_argument("--filter", default="", help="只跑文件名包含此子串的题")
    p.add_argument("--summary-csv", default="summary.csv", help="汇总文件名")
    return p.parse_args()


def main() -> int:
    args = parse_args()

    in_dir = Path(args.input_dir)
    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    cbf_files = sorted(in_dir.glob("*.cbf.gz"))
    if args.filter:
        cbf_files = [f for f in cbf_files if args.filter in f.name]
    if args.limit > 0:
        cbf_files = cbf_files[: args.limit]

    print(f"[batch] 发现 {len(cbf_files)} 个 .cbf.gz")
    if not cbf_files:
        return 1

    # 子进程安全参数
    job_args = [
        (str(f), str(out_dir), args.time_limit, args.iter_limit, args.tol, args.gpu)
        for f in cbf_files
    ]

    records = []
    t0_all = time.time()
    if args.workers > 1:
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            futures = {pool.submit(solve_one, ja): cbf_files[i].name for i, ja in enumerate(job_args)}
            for fut in as_completed(futures):
                rec = fut.result()
                records.append(rec)
                print(f"  [{len(records)}/{len(cbf_files)}] {rec['file']:<40s} "
                      f"status={rec['status']:<10s} iter={rec['iterations']:<8s} "
                      f"time={rec['runtime_sec']}s")
    else:
        for i, ja in enumerate(job_args, 1):
            rec = solve_one(ja)
            records.append(rec)
            print(f"  [{i}/{len(cbf_files)}] {rec['file']:<40s} "
                  f"status={rec['status']:<10s} iter={rec['iterations']:<8s} "
                  f"time={rec['runtime_sec']}s")

    total = time.time() - t0_all
    print(f"\n[batch] 完成, 耗时 {total:.1f}s")

    # 写汇总 CSV (按文件名排序)
    records.sort(key=lambda r: r["file"])
    csv_path = out_dir / args.summary_csv
    fieldnames = ["file", "status", "iterations", "runtime_sec", "obj_value",
                  "rel_gap", "rel_p_res", "rel_d_res", "load_sec", "solve_sec", "error"]
    with open(csv_path, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=fieldnames)
        w.writeheader()
        for r in records:
            w.writerow({k: r.get(k, "") for k in fieldnames})
    print(f"[batch] CSV 写入 {csv_path}")

    # 简要统计
    succ = sum(1 for r in records if r["status"] == "OPTIMAL")
    failed = len(records) - succ
    print(f"[batch] OPTIMAL: {succ}/{len(records)}, FAILED: {failed}")
    if succ > 0:
        iters = [float(r["iterations"]) for r in records
                 if r["status"] == "OPTIMAL" and r["iterations"] != ""]
        times = [float(r["runtime_sec"]) for r in records
                 if r["status"] == "OPTIMAL" and r["runtime_sec"] != ""]
        if iters:
            print(f"[batch] iter  median={np.median(iters):.0f}  mean={np.mean(iters):.0f}  "
                  f"max={max(iters):.0f}")
        if times:
            print(f"[batch] time  median={np.median(times):.2f}s  mean={np.mean(times):.2f}s  "
                  f"max={max(times):.2f}s")

    return 0


if __name__ == "__main__":
    sys.exit(main())

# 实验 002: New SpMV 集成

## 实验目的
验证新 SpMV 后端（libspmv.a）能否提升 PDHCG 求解器性能。

## 修改内容

### 修改列表
- `internal/spmv_backend.h`: 添加 new_spMV backend 字段和控制 API
- `src/spmv_backend.cu`: 添加 cuSPARSE 与 new SpMV 的 fallback 逻辑
- `src/spmv_backend_new.cu`: **新文件** - new SpMV wrapper
- `src/cli.c`: 添加 `--spmv_backend` 选项
- `CMakeLists.txt`: 添加 `PDHCG_USE_NEW_SPMV` 和 `SPMV_BACKEND_ROOT` 选项

### 编译命令

```bash
mkdir build_new_spmv && cd build_new_spmv
cmake ../PDHCG-exp \
    -DCMAKE_BUILD_TYPE=Release \
    -DPDHCG_USE_NEW_SPMV=ON \
    -DSPMV_BACKEND_ROOT=/path/to/spmv-backend \
    -DCMAKE_CUDA_ARCHITECTURES="80;86;89;90"
make -j8 pdhcg
```

## 实验设置

- **GPU**: 单卡 H100 (sm_90)
- **Baseline**: cuSPARSE SpMVOp
- **Modification**: new SpMV 后端
- **问题**: SOCP 18 题

## 运行命令

```bash
# Baseline
./pdhcg baseline.cbf.gz /tmp/baseline_out/

# New SpMV
./pdhcg problem.cbf.gz /tmp/new_out/ --spmv_backend=new
```

## 结果（待填）

### 数值一致性检查

| 问题 | Baseline ObjVal | New SpMV ObjVal | 差异 |
|------|----------------|-----------------|------|
| beam7 | - | - | - |
| ... | | | |

### 性能对比

| 问题 | Baseline (s) | New SpMV (s) | 加速比 |
|------|--------------|--------------|--------|
| beam7 | 4.01 | - | - |
| beam30 | 97.78 | - | - |
| ... | | | |

### Timing 分解

| 组件 | Baseline | New SpMV |
|------|----------|----------|
| SpMV (Aᵀ + A) | 50% (2000ms) | 40% (1500ms) |
| 整体 | 100% | 90% |

## 关键发现

待填

## 风险记录

- new SpMV 与 cuSPARSE 残差差异：__________
- Workspace 内存开销：__________
- 编译时间增加：__________

## 结论

待填

## 决策

KEEP / REJECT / NEED MORE TESTING

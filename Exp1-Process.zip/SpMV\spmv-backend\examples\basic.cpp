#include "spmv.h"
#include <cmath>
#include <cstdio>
#include <cstdlib>

// 示例错误处理：实际应用可将错误传给自己的日志/异常机制。
static void check(cudaError_t e) {
    if (e != cudaSuccess) {
        std::fprintf(stderr, "CUDA: %s\n", cudaGetErrorString(e));
        std::exit(EXIT_FAILURE);
    }
}
template<class T> static T* upload(const T* host, size_t count, cudaStream_t s) {
    T* device = nullptr;
    check(cudaMalloc(reinterpret_cast<void**>(&device), count * sizeof(T)));
    check(cudaMemcpyAsync(device, host, count * sizeof(T), cudaMemcpyHostToDevice, s));
    return device;
}

// 原始 CSR 和 workspace 由调用方拥有；plan 不接管它们。
struct Matrix {
    int32_t *rows = nullptr, *cols = nullptr;
    double* values = nullptr;
    spmv_plan* plan = nullptr;
    void* workspace = nullptr;
    size_t bytes = 0;
    Matrix(int32_t m, int32_t n, int32_t nnz, const int32_t* r,
           const int32_t* c, const double* v, cudaStream_t s) {
        rows = upload(r, static_cast<size_t>(m) + 1, s);
        cols = upload(c, nnz, s);
        values = upload(v, nnz, s);
        // 检查 CSR 并同步完成 setup；只在矩阵建立/变化时调用，不放在迭代循环内。
        check(spmv_plan_create(&plan, m, n, nnz, rows, cols, values, s));
        check(spmv_workspace_size(plan, &bytes));
        if (bytes) check(cudaMalloc(&workspace, bytes));
    }
    Matrix(const Matrix&) = delete;
    Matrix& operator=(const Matrix&) = delete;
    void apply(const double* x, double* y, double alpha, double beta, cudaStream_t s) {
        // 异步入队：x/y 不得重叠；同一 plan 的调用串行化。
        check(spmv_execute(plan, x, y, alpha, beta, workspace, bytes, s));
    }
    ~Matrix() {
        // 调用方必须先保证 GPU 不再使用这些资源（见 main 中的同步）。
        check(spmv_plan_destroy(plan));
        check(cudaFree(workspace));
        check(cudaFree(values));
        check(cudaFree(cols));
        check(cudaFree(rows));
    }
};

static void expect(const char* name, const double* device, const double* reference,
                   size_t count, cudaStream_t s) {
    double host[3] = {};
    check(cudaMemcpyAsync(host, device, count * sizeof(double), cudaMemcpyDeviceToHost, s));
    // 检查异步执行错误，并在 CPU 读结果前等待完成。
    check(cudaStreamSynchronize(s));
    for (size_t i = 0; i < count; ++i) {
        if (!std::isfinite(host[i]) || std::abs(host[i] - reference[i]) > 1e-12) {
            std::fprintf(stderr, "%s[%zu]: got %.17g, expected %.17g\n",
                         name, i, host[i], reference[i]);
            std::exit(EXIT_FAILURE);
        }
    }
    std::printf("PASS %s\n", name);
}

int main() {
    check(cudaSetDevice(0)); // CUDA_VISIBLE_DEVICES 可选择物理 GPU。
    cudaStream_t stream = nullptr;
    check(cudaStreamCreateWithFlags(&stream, cudaStreamNonBlocking));
    {
        // A = [1 0 2; 0 3 0], 是 2x3 的矩形矩阵。
        const int32_t ar[] = {0, 2, 3}, ac[] = {0, 2, 1};
        const double av[] = {1, 2, 3};
        // 当前 API 没有 transpose 参数：在外部准备 A^T 的 CSR，单独建 plan。
        const int32_t tr[] = {0, 1, 2, 3}, tc[] = {0, 1, 0};
        const double tv[] = {1, 3, 2};
        Matrix a(2, 3, 3, ar, ac, av, stream);
        Matrix at(3, 2, 3, tr, tc, tv, stream);
        const double hx[] = {1, 2, 3}, hy[] = {10, 20}, hz[] = {0, 0, 0};
        double* x = upload(hx, 3, stream);
        double* y = upload(hy, 2, stream);
        double* z = upload(hz, 3, stream);

        // y = A*x；beta=0 时不需要旧 y 的数值。
        a.apply(x, y, 1, 0, stream);
        const double ax[] = {7, 6};
        expect("Ax", y, ax, 2, stream);

        // 同一 plan 重复使用：y = 2*A*x - y = [7,6]。
        a.apply(x, y, 2, -1, stream);
        expect("alpha/beta", y, ax, 2, stream);

        // y += A*x = [14,12]，用于梯度和残差的累加。
        a.apply(x, y, 1, 1, stream);
        const double accum[] = {14, 12};
        expect("accumulate", y, accum, 2, stream);

        // z = A^T*y = [14,36,28]；同一 stream 自动保证前后依赖顺序。
        at.apply(y, z, 1, 0, stream);
        const double aty[] = {14, 36, 28};
        expect("transpose via separate CSR", z, aty, 3, stream);

        check(cudaStreamSynchronize(stream));
        check(cudaFree(z));
        check(cudaFree(y));
        check(cudaFree(x));
    } // plan、workspace、原始 CSR 此时才释放。
    check(cudaStreamDestroy(stream));
    return EXIT_SUCCESS;
}

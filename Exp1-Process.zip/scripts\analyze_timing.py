#!/usr/bin/env python3
"""
PDHCG Process-level Timing Analyzer
===================================
Parses PDHCG timing output and generates performance profile reports.

Usage:
    python analyze_timing.py --input timing_output.txt --output report.json
    python analyze_timing.py --input timing_output.txt --verbose

The script expects timing output in the format:
----------------------------------------
PDHCG Process-level Timing Profile
----------------------------------------
Component                    Total (ms)     Count    Avg (ms)  Percent
----------------------------------------------------------------------
SpMV_At                      1234.56        1000      1.2346   25.00%
SpMV_A                       1234.56        1000      1.2346   25.00%
...

Author: Exp1-Process
"""

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, asdict


@dataclass
class TimingComponent:
    """Represents a single timing component."""
    name: str
    total_ms: float
    count: int
    avg_ms: float
    percentage: float


@dataclass
class TimingProfile:
    """Complete timing profile for a problem."""
    problem_name: str
    total_time_ms: float
    components: List[TimingComponent]
    iterations: Optional[int] = None
    inner_iterations: Optional[int] = None
    runtime_sec: Optional[float] = None
    status: Optional[str] = None


class TimingParser:
    """Parser for PDHCG timing output."""

    # Pattern to match timing lines
    TIMING_LINE_PATTERN = re.compile(
        r'^\s*([A-Za-z_]+)\s+([\d.]+)\s+(\d+)\s+([\d.]+)\s+([\d.]+)%\s*$'
    )

    # Pattern to match total line
    TOTAL_PATTERN = re.compile(r'^\s*TOTAL.*?\s+([\d.]+)\s*$')

    @classmethod
    def parse_timing_output(cls, content: str) -> List[TimingComponent]:
        """Parse timing output and return list of components."""
        components = []

        for line in content.split('\n'):
            # Try timing line pattern
            match = cls.TIMING_LINE_PATTERN.search(line)
            if match:
                name, total, count, avg, pct = match.groups()
                components.append(TimingComponent(
                    name=name.strip(),
                    total_ms=float(total),
                    count=int(count),
                    avg_ms=float(avg),
                    percentage=float(pct)
                ))
                continue

            # Try total line pattern
            match = cls.TOTAL_PATTERN.search(line)
            if match:
                # Total is already calculated from components
                pass

        return components


class TimingAnalyzer:
    """Analyzes timing profiles and generates reports."""

    # Thresholds for bottleneck identification
    BOTTLENECK_THRESHOLD_HIGH = 30.0   # >30% = high priority
    BOTTLENECK_THRESHOLD_MEDIUM = 15.0  # >15% = medium priority

    @classmethod
    def identify_bottlenecks(cls, components: List[TimingComponent]) -> Dict[str, str]:
        """Identify performance bottlenecks from components."""
        bottlenecks = {}

        for comp in components:
            if comp.percentage >= cls.BOTTLENECK_THRESHOLD_HIGH:
                bottlenecks[comp.name] = "HIGH"
            elif comp.percentage >= cls.BOTTLENECK_THRESHOLD_MEDIUM:
                bottlenecks[comp.name] = "MEDIUM"
            elif comp.count > 0:
                bottlenecks[comp.name] = "LOW"

        return bottlenecks

    @classmethod
    def calculate_spms_metrics(cls, profile: TimingProfile) -> Dict:
        """Calculate SPMs (SpMV, Scaling, Projection) related metrics."""
        spmv_total = 0.0
        projection_total = 0.0

        for comp in profile.components:
            if 'SpMV' in comp.name:
                spmv_total += comp.total_ms
            elif 'Projection' in comp.name or 'projection' in comp.name.lower():
                projection_total += comp.total_ms

        return {
            'spmv_total_ms': spmv_total,
            'projection_total_ms': projection_total,
            'spmv_percentage': spmv_total / profile.total_time_ms * 100 if profile.total_time_ms > 0 else 0,
            'projection_percentage': projection_total / profile.total_time_ms * 100 if profile.total_time_ms > 0 else 0,
        }

    @classmethod
    def estimate_speedup_potential(cls, components: List[TimingComponent]) -> Dict:
        """Estimate potential speedup from optimizing different components."""
        # Assume optimistic 20% improvement for SpMV, 10% for others
        speedup_estimates = {}

        for comp in components:
            if comp.percentage > 5:  # Only consider significant components
                if 'SpMV' in comp.name:
                    # New SpMV operator claims 20% improvement
                    speedup_estimates[comp.name] = {
                        'improvement_pct': 20.0,
                        'speedup_factor': 1.0 / (1.0 - 0.20 * comp.percentage / 100)
                    }
                elif 'Projection' in comp.name:
                    speedup_estimates[comp.name] = {
                        'improvement_pct': 10.0,
                        'speedup_factor': 1.0 / (1.0 - 0.10 * comp.percentage / 100)
                    }
                else:
                    speedup_estimates[comp.name] = {
                        'improvement_pct': 5.0,
                        'speedup_factor': 1.0 / (1.0 - 0.05 * comp.percentage / 100)
                    }

        return speedup_estimates


def parse_solver_log(log_content: str) -> dict:
    """Parse solver log to extract iteration counts and runtime."""
    result = {
        'iterations': None,
        'inner_iterations': None,
        'runtime_sec': None,
        'status': None
    }

    # Extract iterations
    iter_match = re.search(r'Iterations\s+:\s+(\d+)', log_content)
    if iter_match:
        result['iterations'] = int(iter_match.group(1))

    # Extract inner iterations
    inner_match = re.search(r'Inner iterations\s+:\s+(\d+)', log_content)
    if inner_match:
        result['inner_iterations'] = int(inner_match.group(1))

    # Extract runtime
    runtime_match = re.search(r'Runtime \(sec\)\s*:\s*([\d.]+)', log_content)
    if runtime_match:
        result['runtime_sec'] = float(runtime_match.group(1))

    # Extract status
    status_match = re.search(r'Status\s+:\s+(\w+)', log_content)
    if status_match:
        result['status'] = status_match.group(1)

    return result


def generate_report(profile: TimingProfile) -> dict:
    """Generate comprehensive analysis report."""
    analyzer = TimingAnalyzer()

    bottlenecks = analyzer.identify_bottlenecks(profile.components)
    spms_metrics = analyzer.calculate_spms_metrics(profile)
    speedup_potential = analyzer.estimate_speedup_potential(profile.components)

    # Sort components by percentage
    sorted_components = sorted(profile.components, key=lambda x: x.percentage, reverse=True)

    report = {
        'summary': {
            'problem': profile.problem_name,
            'total_time_ms': profile.total_time_ms,
            'runtime_sec': profile.runtime_sec,
            'iterations': profile.iterations,
            'inner_iterations': profile.inner_iterations,
            'status': profile.status,
        },
        'component_breakdown': [asdict(c) for c in sorted_components],
        'bottleneck_ranking': bottlenecks,
        'spms_metrics': spms_metrics,
        'speedup_potential': speedup_potential,
        'recommendations': generate_recommendations(bottlenecks, spms_metrics),
    }

    return report


def generate_recommendations(bottlenecks: Dict, spms_metrics: Dict) -> List[str]:
    """Generate optimization recommendations based on analysis."""
    recommendations = []

    # SpMV recommendations
    if spms_metrics['spmv_percentage'] > 30:
        recommendations.append(
            f"HIGH PRIORITY: SpMV dominates ({spms_metrics['spmv_percentage']:.1f}% of time). "
            "Consider integrating new SpMV operator for ~20% speedup."
        )
    elif spms_metrics['spmv_percentage'] > 15:
        recommendations.append(
            f"MEDIUM PRIORITY: SpMV significant ({spms_metrics['spmv_percentage']:.1f}% of time). "
            "Evaluate new SpMV operator integration."
        )

    # Projection recommendations
    if spms_metrics['projection_percentage'] > 20:
        recommendations.append(
            f"Cone projection notable ({spms_metrics['projection_percentage']:.1f}% of time). "
            "Consider kernel fusion or batch optimization."
        )

    # Other bottlenecks
    for name, priority in bottlenecks.items():
        if priority == "HIGH" and 'SpMV' not in name and 'Projection' not in name:
            recommendations.append(
                f"HIGH PRIORITY: {name} is a bottleneck. Investigate optimization opportunities."
            )

    return recommendations


def print_report(report: dict, verbose: bool = False):
    """Print report to console."""
    print("\n" + "="*60)
    print("PDHCG Process-level Timing Analysis Report")
    print("="*60)

    summary = report['summary']
    print(f"\nProblem: {summary['problem']}")
    print(f"Runtime: {summary['runtime_sec']:.3f}s" if summary['runtime_sec'] else "Runtime: N/A")
    print(f"Iterations: {summary['iterations']}" if summary['iterations'] else "Iterations: N/A")
    print(f"Status: {summary['status']}" if summary['status'] else "Status: N/A")

    print("\n" + "-"*60)
    print("Top Time Consumers:")
    print("-"*60)
    for comp in report['component_breakdown'][:5]:
        print(f"  {comp['name']:<30} {comp['percentage']:>6.2f}%  ({comp['total_ms']:.2f}ms)")

    print("\n" + "-"*60)
    print("Bottleneck Ranking:")
    print("-"*60)
    for name, priority in report['bottleneck_ranking'].items():
        if priority in ['HIGH', 'MEDIUM']:
            print(f"  [{priority}] {name}")

    if report['recommendations']:
        print("\n" + "-"*60)
        print("Recommendations:")
        print("-"*60)
        for rec in report['recommendations']:
            print(f"  • {rec}")

    print("\n" + "="*60)


def main():
    parser = argparse.ArgumentParser(
        description='Analyze PDHCG process-level timing data'
    )
    parser.add_argument(
        '--input', '-i',
        required=True,
        help='Input timing output file or directory'
    )
    parser.add_argument(
        '--output', '-o',
        help='Output JSON report file'
    )
    parser.add_argument(
        '--verbose', '-v',
        action='store_true',
        help='Print detailed report to console'
    )
    parser.add_argument(
        '--problem', '-p',
        help='Problem name (extracted from filename if not provided)'
    )

    args = parser.parse_args()

    # Read input
    input_path = Path(args.input)
    if not input_path.exists():
        print(f"Error: Input file not found: {args.input}", file=sys.stderr)
        sys.exit(1)

    with open(input_path, 'r', encoding='utf-8') as f:
        content = f.read()

    # Parse timing data
    components = TimingParser.parse_timing_output(content)

    if not components:
        print("Warning: No timing components found in input.", file=sys.stderr)
        print("Make sure the timing output format is correct.", file=sys.stderr)
        sys.exit(1)

    # Calculate total time
    total_time = sum(c.total_ms for c in components)

    # Extract problem name
    problem_name = args.problem or input_path.stem

    # Try to parse solver log if it exists
    solver_info = {}
    log_path = input_path.parent / f"{problem_name}.log"
    if log_path.exists():
        with open(log_path, 'r', encoding='utf-8') as f:
            solver_info = parse_solver_log(f.read())

    # Create profile
    profile = TimingProfile(
        problem_name=problem_name,
        total_time_ms=total_time,
        components=components,
        **solver_info
    )

    # Generate report
    report = generate_report(profile)

    # Output
    if args.output:
        output_path = Path(args.output)
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(report, f, indent=2)
        print(f"Report saved to: {output_path}")

    if args.verbose or not args.output:
        print_report(report, verbose=True)


if __name__ == '__main__':
    main()

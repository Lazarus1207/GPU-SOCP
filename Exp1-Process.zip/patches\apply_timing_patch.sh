#!/bin/bash
#===============================================================================
# Patch: 缁?PDHCG 娣诲姞鍒嗙幆鑺?timing 鍔熻兘
#===============================================================================
# 鐢ㄦ硶锛歝d ~/PDHCG && bash apply_timing_patch.sh
# 鍥炴粴锛歮v src/pdhg_core_op.cu.bak src/pdhg_core_op.cu
#       mv src/solver.cu.bak src/solver.cu
#===============================================================================

set -e

cd "$(dirname "${BASH_SOURCE[0]}")/../PDHCG-exp" || cd "$(pwd)"

echo "[timing-patch] 褰撳墠鐩綍: $(pwd)"

CORE_OP="src/pdhg_core_op.cu"
SOLVER="src/solver.cu"
TIMING_H="internal/timing_profiler.h"

# ---- 澶囦唤 ----
for f in "$CORE_OP" "$SOLVER"; do
    [ -f "${f}.bak" ] || cp "$f" "${f}.bak"
    echo "[timing-patch] 宸插浠?$f"
done

# ---- 澶嶅埗 timing 澶存枃浠跺埌 internal/ ----
TIMING_SRC="$(dirname "${BASH_SOURCE[0]}")/timing_profiler.h"
[ -f "$TIMING_SRC" ] && cp "$TIMING_SRC" "$TIMING_H" && echo "[timing-patch] 宸插鍒?$TIMING_H"

# =============================================================================
# Step 1: pdhg_core_op.cu 椤堕儴娣诲姞 timing include
# =============================================================================
TMP=$(mktemp)
awk '
    /^#include "solver.h"$/ && !done {
        print
        print ""
        print "#ifdef PDHCG_ENABLE_TIMING"
        print "#include \"timing_profiler.h\""
        print "#endif"
        done = 1
        next
    }
    { print }
' "$CORE_OP" > "$TMP" && mv "$TMP" "$CORE_OP"
echo "[timing-patch] core_op: 娣诲姞 timing include"

# =============================================================================
# Step 2: 鍦?pdhcg_spmv_execute 璋冪敤鍓嶆坊鍔?PDHCG_TIMING_MEASURE
# =============================================================================
# 鐢?sed 鍗曡鏇挎崲锛氭妸鐩爣琛屾浛鎹㈡垚 [timing] + 鍘熻
sed -i 's|pdhcg_spmv_execute(state->sparse_handle, state->spmv_ctx_At,|PDHCG_TIMING_MEASURE(TIMING_SCOPE_SPMV_AT);\n    pdhcg_spmv_execute(state->sparse_handle, state->spmv_ctx_At,|' "$CORE_OP"
sed -i 's|pdhcg_spmv_execute(state->sparse_handle, state->spmv_ctx_A,|PDHCG_TIMING_MEASURE(TIMING_SCOPE_SPMV_A);\n    pdhcg_spmv_execute(state->sparse_handle, state->spmv_ctx_A,|' "$CORE_OP"
echo "[timing-patch] core_op: 娣诲姞 SpMV timing guards"

# =============================================================================
# Step 3: 鍦?dispatch_cone_projection 璋冪敤鍓嶆坊鍔?timing
# =============================================================================
sed -i 's|dispatch_cone_projection(state, primal_solution);|PDHCG_TIMING_MEASURE(TIMING_SCOPE_CONE_PROJ);\n    dispatch_cone_projection(state, primal_solution);|' "$CORE_OP"
echo "[timing-patch] core_op: 娣诲姞 Cone Projection timing"

# =============================================================================
# Step 4: solver.cu 椤堕儴娣诲姞 timing include
# =============================================================================
TMP=$(mktemp)
awk '
    /^#include "solver.h"$/ && !done {
        print
        print ""
        print "// ===== Exp1-Process Timing ====="
        print "#ifdef PDHCG_ENABLE_TIMING"
        print "#include \"timing_profiler.h\""
        print "#endif"
        print "// ===== End ====="
        done = 1
        next
    }
    { print }
' "$SOLVER" > "$TMP" && mv "$TMP" "$SOLVER"
echo "[timing-patch] solver: 娣诲姞 timing include"

# =============================================================================
# Step 5: 鍦?const auto start_time 涔嬪墠璋冪敤 pdhcg_timing_init()
# =============================================================================
sed -i 's|const auto start_time = std::chrono::steady_clock::now();|#ifdef PDHCG_ENABLE_TIMING\n    pdhcg_timing_init();\n#endif\n    const auto start_time = std::chrono::steady_clock::now();|' "$SOLVER"
echo "[timing-patch] solver: 娣诲姞 timing init"

# =============================================================================
# Step 6: 鍦?create_result_from_state 涔嬪墠璋冪敤 pdhcg_timing_finalize/print/cleanup
# =============================================================================
sed -i 's|pdhcg_result_t \*result = create_result_from_state(state, original_problem);|#ifdef PDHCG_ENABLE_TIMING\n    pdhcg_timing_finalize();\n    pdhcg_timing_print();\n    pdhcg_timing_cleanup();\n#endif\n    pdhcg_result_t *result = create_result_from_state(state, original_problem);|' "$SOLVER"
echo "[timing-patch] solver: 娣诲姞 timing finalize/print/cleanup"

echo ""
echo "========================================"
echo "[timing-patch] Timing patch 瀹屾垚"
echo "========================================"

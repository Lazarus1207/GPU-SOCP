#!/bin/bash
#===============================================================================
# 鍥炴粴 Exp1-Process 鐨勬墍鏈?patch锛屾仮澶嶅師濮嬫枃浠?
#===============================================================================
# 鐢ㄦ硶锛堝湪 PDHCG 婧愮爜鏍圭洰褰曚笅鎵ц锛夛細
#   cd ~/PDHCG
#   bash ~/testHM/Exp1-Process/patches/restore_original.sh
#===============================================================================

set -e

cd "$(dirname "${BASH_SOURCE[0]}")/../PDHCG-exp" 2>/dev/null || cd "$(pwd)"

echo "=============================================="
echo "PDHCG Exp1-Process 鈥?Restore Original Files"
echo "=============================================="
echo "Current directory: $(pwd)"
echo ""

RESTORE_FILES=(
    "src/spmv_backend.cu"
    "src/spmv_backend.h"
    "internal/spmv_backend.h"
    "src/cli.c"
    "src/pdhg_core_op.cu"
    "src/solver.cu"
)

for f in "${RESTORE_FILES[@]}"; do
    if [ -f "${f}.bak" ]; then
        mv "${f}.bak" "$f"
        echo "restored: $f"
    else
        echo "skip (no backup): $f"
    fi
done

# 鍒犻櫎鏂板鐨勬枃浠?
if [ -f "src/spmv_backend_new.cu" ]; then
    rm -v src/spmv_backend_new.cu
fi

if [ -f "internal/timing_profiler.h" ]; then
    rm -v internal/timing_profiler.h
fi

echo ""
echo "鎵€鏈夊師濮嬫枃浠跺凡鎭㈠銆?
echo "=============================================="

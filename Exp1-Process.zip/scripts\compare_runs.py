#!/usr/bin/env python3
"""
PDHCG Experiment Result Comparator
==================================
Compares two PDHCG run directories and generates a comparison report.

Usage:
    python compare_runs.py --baseline <baseline_dir> --candidate <new_dir> --output <output.json>
"""

import argparse
import json
import os
import re
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, asdict


@dataclass
class ProblemResult:
    """Single problem result from a summary.txt file."""
    name: str
    status: str = "UNKNOWN"
    runtime_sec: float = 0.0
    iterations: int = 0
    inner_iterations: int = 0
    obj_value: float = 0.0
    rel_p_res: float = 0.0
    rel_d_res: float = 0.0
    rel_gap: float = 0.0


def parse_summary_file(summary_path: Path) -> Optional[ProblemResult]:
    """Parse a PDHCG _summary.txt file."""
    if not summary_path.exists():
        return None

    result = ProblemResult(name=summary_path.stem.replace("_summary", ""))

    with open(summary_path, 'r', encoding='utf-8') as f:
        content = f.read()

    # Termination reason -> status
    term_match = re.search(r'Termination Reason:\s+(\w+)', content)
    if term_match:
        reason = term_match.group(1)
        result.status = "OPTIMAL" if "OPTIMAL" in reason else reason

    # Runtime
    runtime_match = re.search(r'Runtime \(sec\):\s+([\d.eE+-]+)', content)
    if runtime_match:
        try:
            result.runtime_sec = float(runtime_match.group(1))
        except ValueError:
            pass

    # Iterations
    iter_match = re.search(r'Iterations Count:\s+(\d+)', content)
    if iter_match:
        result.iterations = int(iter_match.group(1))

    # Inner iterations
    inner_match = re.search(r'Inner Iterations Count:\s+(\d+)', content)
    if inner_match:
        result.inner_iterations = int(inner_match.group(1))

    # Objective
    obj_match = re.search(r'Primal Objective Value:\s+([\d.eE+-]+)', content)
    if obj_match:
        try:
            result.obj_value = float(obj_match.group(1))
        except ValueError:
            pass

    # Residuals
    rp_match = re.search(r'Relative Primal Residual:\s+([\d.eE+-]+)', content)
    if rp_match:
        try:
            result.rel_p_res = float(rp_match.group(1))
        except ValueError:
            pass

    rd_match = re.search(r'Relative Dual Residual:\s+([\d.eE+-]+)', content)
    if rd_match:
        try:
            result.rel_d_res = float(rd_match.group(1))
        except ValueError:
            pass

    # Gap
    gap_match = re.search(r'Relative Objective Gap:\s+([\d.eE+-]+)', content)
    if gap_match:
        try:
            result.rel_gap = float(gap_match.group(1))
        except ValueError:
            pass

    return result


def collect_results(results_dir: Path) -> Dict[str, ProblemResult]:
    """Collect all problem results from a directory."""
    results = {}
    for summary_path in results_dir.glob("*_summary.txt"):
        result = parse_summary_file(summary_path)
        if result is not None:
            results[result.name] = result
    return results


def compute_sgm10(runtimes: List[float], shift: float = 10.0) -> float:
    """Compute Shifted-Geometric-Mean (shift=10s) of runtimes."""
    import math
    if not runtimes:
        return 0.0
    log_sum = sum(math.log(t + shift) for t in runtimes)
    return math.exp(log_sum / len(runtimes)) - shift


def compare_runs(baseline: Dict[str, ProblemResult],
                 candidate: Dict[str, ProblemResult]) -> dict:
    """Compare two sets of results."""
    common = sorted(set(baseline.keys()) & set(candidate.keys()))

    rows = []
    for name in common:
        b = baseline[name]
        c = candidate[name]

        # Compute speedup
        speedup = b.runtime_sec / c.runtime_sec if c.runtime_sec > 0 else 0.0
        time_delta = c.runtime_sec - b.runtime_sec

        # Check numerical consistency
        obj_diff = abs(c.obj_value - b.obj_value) if b.obj_value != 0 else 0.0
        rel_obj_diff = obj_diff / max(abs(b.obj_value), 1e-10)

        rows.append({
            'problem': name,
            'baseline_runtime': b.runtime_sec,
            'candidate_runtime': c.runtime_sec,
            'time_delta_sec': time_delta,
            'speedup': speedup,
            'baseline_status': b.status,
            'candidate_status': c.status,
            'baseline_iter': b.iterations,
            'candidate_iter': c.iterations,
            'baseline_inner_iter': b.inner_iterations,
            'candidate_inner_iter': c.inner_iterations,
            'baseline_obj': b.obj_value,
            'candidate_obj': c.obj_value,
            'rel_obj_diff': rel_obj_diff,
            'baseline_rel_gap': b.rel_gap,
            'candidate_rel_gap': c.rel_gap,
        })

    # Compute SGM10
    baseline_runtimes = [r['baseline_runtime'] for r in rows if r['baseline_status'] == 'OPTIMAL']
    candidate_runtimes = [r['candidate_runtime'] for r in rows if r['candidate_status'] == 'OPTIMAL']

    baseline_sgm10 = compute_sgm10(baseline_runtimes)
    candidate_sgm10 = compute_sgm10(candidate_runtimes)
    sgm10_speedup = baseline_sgm10 / candidate_sgm10 if candidate_sgm10 > 0 else 0.0

    # Geometric mean of speedups
    speedups = [r['speedup'] for r in rows if r['speedup'] > 0]
    geom_mean_speedup = 1.0
    if speedups:
        import math
        log_sum = sum(math.log(s) for s in speedups)
        geom_mean_speedup = math.exp(log_sum / len(speedups))

    # Numerical consistency: count problems with rel_obj_diff > 1e-4
    inconsistent = sum(1 for r in rows if r['rel_obj_diff'] > 1e-4)
    total_compared = len(rows)

    return {
        'comparison_rows': rows,
        'summary': {
            'total_problems': len(common),
            'baseline_sgm10': baseline_sgm10,
            'candidate_sgm10': candidate_sgm10,
            'sgm10_speedup': sgm10_speedup,
            'geometric_mean_speedup': geom_mean_speedup,
            'inconsistent_problems': inconsistent,
            'total_compared': total_compared,
        }
    }


def generate_summary_table(comparison: dict) -> str:
    """Generate a markdown comparison table."""
    rows = comparison['comparison_rows']
    summary = comparison['summary']

    lines = []
    lines.append("## Comparison Summary\n")
    lines.append(f"- Total problems compared: **{summary['total_problems']}**")
    lines.append(f"- Baseline SGM10: **{summary['baseline_sgm10']:.4f}**")
    lines.append(f"- Candidate SGM10: **{summary['candidate_sgm10']:.4f}**")
    lines.append(f"- SGM10 Speedup: **{summary['sgm10_speedup']:.3f}x**")
    lines.append(f"- Geom Mean Speedup: **{summary['geometric_mean_speedup']:.3f}x**")
    lines.append(f"- Numerical Inconsistencies: **{summary['inconsistent_problems']}/{summary['total_compared']}**")
    lines.append("")

    lines.append("## Per-Problem Results\n")
    lines.append("| Problem | Baseline (s) | Candidate (s) | Speedup | Iter Δ | Rel ObjDiff |")
    lines.append("|---------|--------------|---------------|---------|--------|-------------|")

    for r in rows:
        speedup_str = f"{r['speedup']:.2f}x" if r['speedup'] > 0 else "N/A"
        iter_delta = r['candidate_iter'] - r['baseline_iter']
        lines.append(
            f"| {r['problem']} | {r['baseline_runtime']:.3f} | {r['candidate_runtime']:.3f} | "
            f"{speedup_str} | {iter_delta:+d} | {r['rel_obj_diff']:.2e} |"
        )

    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(
        description='Compare PDHCG run results'
    )
    parser.add_argument(
        '--baseline', '-b',
        required=True,
        help='Baseline results directory'
    )
    parser.add_argument(
        '--candidate', '-c',
        required=True,
        help='Candidate results directory'
    )
    parser.add_argument(
        '--output', '-o',
        help='Output JSON file'
    )
    parser.add_argument(
        '--markdown', '-m',
        help='Output markdown comparison file'
    )

    args = parser.parse_args()

    baseline_dir = Path(args.baseline)
    candidate_dir = Path(args.candidate)

    if not baseline_dir.exists():
        print(f"Error: Baseline directory not found: {args.baseline}", file=sys.stderr)
        sys.exit(1)

    if not candidate_dir.exists():
        print(f"Error: Candidate directory not found: {args.candidate}", file=sys.stderr)
        sys.exit(1)

    print(f"Collecting baseline results from: {baseline_dir}")
    baseline = collect_results(baseline_dir)
    print(f"  Found {len(baseline)} results")

    print(f"Collecting candidate results from: {candidate_dir}")
    candidate = collect_results(candidate_dir)
    print(f"  Found {len(candidate)} results")

    comparison = compare_runs(baseline, candidate)

    # Output JSON
    if args.output:
        with open(args.output, 'w', encoding='utf-8') as f:
            json.dump(comparison, f, indent=2)
        print(f"JSON report saved to: {args.output}")

    # Output markdown
    md_content = generate_summary_table(comparison)
    print(md_content)

    if args.markdown:
        with open(args.markdown, 'w', encoding='utf-8') as f:
            f.write(md_content + "\n")
        print(f"Markdown report saved to: {args.markdown}")


if __name__ == '__main__':
    import sys
    main()

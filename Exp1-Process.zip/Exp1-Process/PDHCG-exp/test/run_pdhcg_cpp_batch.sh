#!/usr/bin/env bash
# PDHCG-II C++ binary batch runner
# 单进程，顺序执行 (GPU 共享上下文)
# 用法: ./run_pdhcg_cpp_batch.sh <input_dir> <output_dir> [time_limit_sec] [iter_limit] [tol] [--gpu]
#
# 依赖: ./build/bin/pdhcg 已编译

set -euo pipefail

INPUT_DIR="${1:?需要输入目录 (含 .cbf.gz)}"
OUTPUT_DIR="${2:?需要输出目录}"
TIME_LIMIT="${3:-600}"
ITER_LIMIT="${4:-20000}"
TOL="${5:-1e-4}"
USE_GPU_FLAG=""
if [[ "${6:-}" == "--gpu" ]]; then
    USE_GPU_FLAG="--use_gpu=ON"
fi

BIN="${PDHCG_BIN:-$HOME/PDHCG/build/pdhcg}"
if [[ ! -x "$BIN" ]]; then
    echo "[err] 找不到 $BIN，请先 cmake --build build 或设置 PDHCG_BIN 环境变量"
    exit 1
fi

mkdir -p "$OUTPUT_DIR"
SUMMARY="$OUTPUT_DIR/summary.csv"
echo "file,status,iterations,runtime_sec,obj_value,iter_last_summary,n_cones" > "$SUMMARY"

COUNT=0
TOTAL=$(ls "$INPUT_DIR"/*.cbf.gz 2>/dev/null | wc -l)
echo "[batch] 发现 $TOTAL 个 .cbf.gz"

for FILE in "$INPUT_DIR"/*.cbf.gz; do
    NAME=$(basename "$FILE" .cbf.gz)
    COUNT=$((COUNT + 1))
    echo ""
    echo "[$COUNT/$TOTAL] $NAME"

    START=$(date +%s.%N)
    "$BIN" "$FILE" "$OUTPUT_DIR" \
        -v 1 \
        --time_limit "$TIME_LIMIT" \
        --iter_limit "$ITER_LIMIT" \
        --eps_opt "$TOL" \
        --eps_feas "$TOL" \
        $USE_GPU_FLAG \
        > "$OUTPUT_DIR/${NAME}.stdout" 2>&1 || true
    END=$(date +%s.%N)
    ELAPSED=$(echo "$END - $START" | bc -l)

    # 解析 output_dir/<name>-summary.txt
    SUMMARY_TXT="$OUTPUT_DIR/${NAME}-summary.txt"
    if [[ -f "$SUMMARY_TXT" ]]; then
        # 抽取关键字段: 不同版本字段名略有差异, 用 grep 兜底
        STATUS=$(grep -i "status" "$SUMMARY_TXT" | head -1 || echo "UNKNOWN")
        ITER=$(grep -i "iter" "$SUMMARY_TXT" | head -1 || echo "")
        OBJ=$(grep -i "obj" "$SUMMARY_TXT" | head -1 || echo "")
        echo "$NAME,$STATUS,$ITER,$ELAPSED,$OBJ," >> "$SUMMARY"
    else
        echo "$NAME,ERROR,,,,," >> "$SUMMARY"
    fi
done

echo ""
echo "[batch] 全部完成 -> $SUMMARY"

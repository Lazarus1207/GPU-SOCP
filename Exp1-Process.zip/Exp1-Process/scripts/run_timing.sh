#!/bin/bash
#===============================================================================
# PDHCG Process-level Timing Runner
#===============================================================================
# This script compiles PDHCG with timing support and runs profiling on
# benchmark problems.
#
# Usage:
#   ./run_timing.sh                    # Run all problems
#   ./run_timing.sh beam7             # Run specific problem
#   ./run_timing.sh --clean           # Clean and rebuild
#
# Output:
#   timing_results/  - Directory with timing profiles for each problem
#   timing_summary.json - Aggregated results
#===============================================================================

set -e  # Exit on error

# Configuration
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PDHCG_DIR="${SCRIPT_DIR}/PDHCG-exp"
BUILD_DIR="${PDHCG_DIR}/build_timing"
RESULTS_DIR="${SCRIPT_DIR}/timing_results"
BENCHMARK_DIR="${HOME}/testHM/benchmark/socp"

# SpMV backend library path
SPMV_LIB="${SCRIPT_DIR}/SpMV/spmv-backend/lib/libspmv.a"
SPMV_INCLUDE="${SCRIPT_DIR}/SpMV/spmv-backend/include"

# Problems to profile
PROBLEMS=(
    "beam7"
    "beam30"
    "chainsing-50000-1"
    "chainsing-50000-2"
    "chainsing-50000-3"
    "db-joint-soerensen"
    "db-plate-yield-line"
    "dsNRL"
    "firL1"
    "firL1Linfalph"
    "firL1Linfeps"
    "firL2L1alph"
    "firL2L1eps"
    "firL2Linfalph"
    "firL2Linfeps"
    "firL2a"
    "firLinf"
    "wbNRL"
)

#===============================================================================
# Functions
#===============================================================================

log_info() {
    echo "[INFO] $1"
}

log_error() {
    echo "[ERROR] $1" >&2
}

check_deps() {
    log_info "Checking dependencies..."

    # Check CUDA
    if ! command -v nvcc &> /dev/null; then
        log_error "nvcc not found. Please install CUDA Toolkit."
        exit 1
    fi

    # Check cmake
    if ! command -v cmake &> /dev/null; then
        log_error "cmake not found. Please install CMake."
        exit 1
    fi

    # Check PDHCG directory
    if [ ! -d "${PDHCG_DIR}" ]; then
        log_error "PDHCG directory not found: ${PDHCG_DIR}"
        exit 1
    fi

    # Check benchmark directory
    if [ ! -d "${BENCHMARK_DIR}" ]; then
        log_error "Benchmark directory not found: ${BENCHMARK_DIR}"
        log_info "Creating benchmark directory..."
        mkdir -p "${BENCHMARK_DIR}"
    fi

    log_info "Dependencies OK"
}

clean_build() {
    log_info "Cleaning build directory..."
    rm -rf "${BUILD_DIR}"
    mkdir -p "${BUILD_DIR}"
}

build_pdhcg_with_timing() {
    log_info "Building PDHCG with timing support..."

    cd "${BUILD_DIR}"

    # Configure with timing enabled
    cmake "${PDHCG_DIR}" \
        -DCMAKE_BUILD_TYPE=Release \
        -DPDHCG_ENABLE_TIMING=ON \
        -DCMAKE_CUDA_ARCHITECTURES="80;86;89;90" \
        -DCMAKE_CUDA_FLAGS="-DPDHCG_ENABLE_TIMING"

    # Build
    make -j$(nproc) pdhcg

    if [ $? -eq 0 ]; then
        log_info "Build successful: ${BUILD_DIR}/pdhcg"
    else
        log_error "Build failed"
        exit 1
    fi
}

build_pdhcg_with_spmv() {
    log_info "Building PDHCG with new SpMV backend..."

    cd "${BUILD_DIR}"

    # Configure with timing AND new SpMV enabled
    cmake "${PDHCG_DIR}" \
        -DCMAKE_BUILD_TYPE=Release \
        -DPDHCG_ENABLE_TIMING=ON \
        -DPDHCG_USE_NEW_SPMV=ON \
        -DSPMV_ROOT="${SCRIPT_DIR}/SpMV/spmv-backend" \
        -DCMAKE_CUDA_ARCHITECTURES="80;86;89;90" \
        -DCMAKE_CUDA_FLAGS="-DPDHCG_ENABLE_TIMING -DPDHCG_USE_NEW_SPMV"

    # Build
    make -j$(nproc) pdhcg

    if [ $? -eq 0 ]; then
        log_info "Build with new SpMV successful"
    else
        log_error "Build with new SpMV failed"
        exit 1
    fi
}

run_single_problem() {
    local problem=$1
    local output_dir=$2
    local extra_args=$3

    local input_file="${BENCHMARK_DIR}/${problem}.cbf.gz"
    local output_prefix="${output_dir}/${problem}"

    if [ ! -f "${input_file}" ]; then
        log_error "Problem file not found: ${input_file}"
        return 1
    fi

    log_info "Running: ${problem}"

    # Create output directory
    mkdir -p "${output_dir}"

    # Run PDHCG with verbose output
    "${BUILD_DIR}/pdhcg" \
        --input "${input_file}" \
        --output_dir "${output_dir}" \
        --verbose 2>&1 | tee "${output_prefix}_log.txt"

    return 0
}

run_benchmark_suite() {
    local output_dir=$1
    local extra_args=$2

    log_info "Running benchmark suite..."

    local start_time=$(date +%s)
    local total=${#PROBLEMS[@]}
    local completed=0
    local failed=0

    for problem in "${PROBLEMS[@]}"; do
        if run_single_problem "${problem}" "${output_dir}" "${extra_args}"; then
            ((completed++))
        else
            ((failed++))
            log_error "Failed: ${problem}"
        fi

        local elapsed=$(($(date +%s) - start_time))
        log_info "Progress: ${completed}/${total} completed, ${failed} failed, ${elapsed}s elapsed"
    done

    log_info "Benchmark complete: ${completed} succeeded, ${failed} failed"
}

aggregate_results() {
    local results_dir=$1
    local output_file=$2

    log_info "Aggregating results..."

    python3 << EOF
import json
import os
from pathlib import Path

results_dir = "${results_dir}"
output_file = "${output_file}"

aggregated = {
    "timestamp": "$(date -Iseconds)",
    "problems": [],
    "summary": {}
}

total_runtime = 0
total_iterations = 0

for problem_dir in sorted(Path(results_dir).glob("*_log.txt")):
    problem_name = problem_dir.stem.replace("_log", "")

    # Extract timing info from log
    # This would parse the actual timing output
    aggregated["problems"].append({
        "name": problem_name,
        "status": "COMPLETED"  # Would be parsed from actual output
    })

aggregated["summary"] = {
    "total_problems": len(aggregated["problems"]),
    "completed": sum(1 for p in aggregated["problems"] if p["status"] == "COMPLETED"),
}

with open(output_file, 'w') as f:
    json.dump(aggregated, f, indent=2)

print(f"Aggregated results saved to: {output_file}")
EOF
}

#===============================================================================
# Main
#===============================================================================

show_usage() {
    cat << EOF
PDHCG Process-level Timing Runner

Usage: $0 [OPTIONS] [PROBLEM]

OPTIONS:
    --timing          Build with timing support (default)
    --spmv            Build with new SpMV backend
    --clean           Clean and rebuild
    --results DIR     Results directory (default: timing_results)
    --help, -h        Show this help

EXAMPLES:
    $0 --timing              # Build with timing and run all problems
    $0 --spmv beam7          # Build with new SpMV, run single problem
    $0 --clean --timing      # Clean rebuild with timing

EOF
}

main() {
    local mode="timing"
    local do_clean=false
    local results_dir="${RESULTS_DIR}"

    # Parse arguments
    while [[ $# -gt 0 ]]; do
        case $1 in
            --timing)
                mode="timing"
                shift
                ;;
            --spmv)
                mode="spmv"
                shift
                ;;
            --clean)
                do_clean=true
                shift
                ;;
            --results)
                results_dir="$2"
                shift 2
                ;;
            --help|-h)
                show_usage
                exit 0
                ;;
            -*)
                log_error "Unknown option: $1"
                show_usage
                exit 1
                ;;
            *)
                # Assume it's a problem name
                break
                ;;
        esac
    done

    # Check dependencies
    check_deps

    # Create results directory
    mkdir -p "${results_dir}"

    # Build
    if [ "${do_clean}" = true ]; then
        clean_build
    fi

    if [ ! -f "${BUILD_DIR}/pdhcg" ]; then
        if [ "${mode}" = "spmv" ]; then
            build_pdhcg_with_spmv
        else
            build_pdhcg_with_timing
        fi
    fi

    # Run
    if [ $# -gt 0 ]; then
        # Run specific problem
        run_single_problem "$1" "${results_dir}" ""
    else
        # Run all problems
        run_benchmark_suite "${results_dir}" ""
    fi

    # Aggregate results
    aggregate_results "${results_dir}" "${results_dir}/summary.json"

    log_info "Done! Results in: ${results_dir}"
}

main "$@"

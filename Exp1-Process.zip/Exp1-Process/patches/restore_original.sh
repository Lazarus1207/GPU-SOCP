#!/bin/bash
#===============================================================================
# 回滚 Exp1-Process 的所有 patch，恢复原始文件
#===============================================================================
# 用法（在 PDHCG 源码根目录下执行）：
#   cd ~/PDHCG
#   bash ~/testHM/Exp1-Process/patches/restore_original.sh
#===============================================================================

set -e

cd "$(dirname "${BASH_SOURCE[0]}")/../PDHCG-exp" 2>/dev/null || cd "$(pwd)"

echo "=============================================="
echo "PDHCG Exp1-Process — Restore Original Files"
echo "=============================================="
echo "Current directory: $(pwd)"
echo ""

RESTORE_FILES=(
    "src/spmv_backend.cu"
    "src/spmv_backend.h"
    "internal/spmv_backend.h"
    "src/cli.c"
    "src/pdhg_core_op.cu"
    "src/solver.cu"
)

for f in "${RESTORE_FILES[@]}"; do
    if [ -f "${f}.bak" ]; then
        mv "${f}.bak" "$f"
        echo "restored: $f"
    else
        echo "skip (no backup): $f"
    fi
done

# 删除新增的文件
if [ -f "src/spmv_backend_new.cu" ]; then
    rm -v src/spmv_backend_new.cu
fi

if [ -f "internal/timing_profiler.h" ]; then
    rm -v internal/timing_profiler.h
fi

echo ""
echo "所有原始文件已恢复。"
echo "=============================================="

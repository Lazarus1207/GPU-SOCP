#!/bin/bash
#===============================================================================
# Patch: 将 PDHCG 的 spmv_backend.cu 改造为支持 new SpMV 后端（可选）
#===============================================================================
# 用法（在 PDHCG 源码根目录下执行）：
#   bash apply_spmv_backend_patch.sh
#
# 行为：
#   - 备份原 spmv_backend.cu 为 spmv_backend.cu.bak
#   - 备份原 spmv_backend.h 为 spmv_backend.h.bak
#   - 应用 sed 修改（添加 new SpMV 字段、API、fallback 逻辑）
#
# 回滚：
#   mv src/spmv_backend.cu.bak src/spmv_backend.cu
#   mv internal/spmv_backend.h.bak internal/spmv_backend.h
#===============================================================================

set -e

cd "$(dirname "${BASH_SOURCE[0]}")/../PDHCG-exp" || exit 1

echo "[patch] 当前目录: $(pwd)"

# 备份
if [ ! -f src/spmv_backend.cu.bak ]; then
    cp src/spmv_backend.cu src/spmv_backend.cu.bak
    echo "[patch] 已备份 src/spmv_backend.cu"
fi

if [ ! -f internal/spmv_backend.h.bak ]; then
    cp internal/spmv_backend.h internal/spmv_backend.h.bak
    echo "[patch] 已备份 internal/spmv_backend.h"
fi

# ----------------------------------------------------------------------------
# Patch 1: 修改 spmv_backend.h - 在结构体末尾添加 new SpMV 字段和 backend API
# ----------------------------------------------------------------------------
SPMV_H="internal/spmv_backend.h"

# 在 include 块后添加 forward declaration 和新字段
# 锚点: typedef struct 后面
sed -i '/^    typedef struct$/,/^    } pdhcg_spmv_ctx_t;$/c\
    // Forward declaration to avoid pulling in spmv.h here\
    struct spmv_plan;\
\
    typedef struct\
    {\
        // cuSPARSE fields (always populated)\
        cusparseSpMatDescr_t mat;\
        cusparseDnVecDescr_t vec_x;\
        cusparseDnVecDescr_t vec_y;\
        void *buffer;\
        void *descr;\
        void *plan;\
        int num_rows;\
        int num_nonzeros;\
\
        // New SpMV backend fields (Exp1-Process)\
        struct spmv_plan *new_spmv_plan;\
        void *new_spmv_workspace;\
        size_t new_spmv_workspace_bytes;\
    } pdhcg_spmv_ctx_t;' "$SPMV_H"

# 在 pdhcg_spmv_execute 声明前添加 backend API
sed -i '/^    void pdhcg_spmv_execute/i\
    void pdhcg_set_spmv_backend(int backend);\
    int  pdhcg_get_spmv_backend(void);\
' "$SPMV_H"

echo "[patch] 已修改 internal/spmv_backend.h"

# ----------------------------------------------------------------------------
# Patch 2: 修改 spmv_backend.cu - 在文件顶部添加 new SpMV wrapper 的声明
# ----------------------------------------------------------------------------
SPMV_CU="src/spmv_backend.cu"

# 在 #include "utils.h" 后添加 conditional include 和函数声明
sed -i '/#include "utils.h"/a\
#ifdef PDHCG_USE_NEW_SPMV\
#include "spmv.h"\
extern "C" cudaError_t pdhcg_new_spmv_ctx_create(pdhcg_spmv_ctx_t *ctx, int num_rows, int num_cols, int num_nonzeros, int *row_ptr, int *col_ind, double *val, cusparseHandle_t sparse_handle);\
extern "C" cudaError_t pdhcg_new_spmv_execute(pdhcg_spmv_ctx_t *ctx, cusparseHandle_t sparse_handle, const double *alpha, const double *beta, const double *x, double *y);\
extern "C" void pdhcg_new_spmv_ctx_destroy(pdhcg_spmv_ctx_t *ctx);\
#endif' "$SPMV_CU"

# 在 pdhcg_use_spmvop_by_default 函数后添加 helper 和 backend 选择器
# 锚点: extern "C" bool pdhcg_use_spmvop_by_default(void) ... 整段函数
sed -i '/^extern "C" bool pdhcg_use_spmvop_by_default(void)$/,/^}$/{
    /^}$/a\
\
// New SpMV backend selection (set by CLI or environment)\
#ifdef PDHCG_USE_NEW_SPMV\
static int g_pdhcg_new_spmv_backend = PDHCG_NEW_SPMV_RUNTIME_DEFAULT;\
\
extern "C" void pdhcg_set_spmv_backend(int backend)\
{\
    if (backend == 0 || backend == 1)\
        g_pdhcg_new_spmv_backend = backend;\
}\
\
extern "C" int pdhcg_get_spmv_backend(void)\
{\
    return g_pdhcg_new_spmv_backend;\
}\
#else\
extern "C" void pdhcg_set_spmv_backend(int backend) { (void)backend; }\
extern "C" int  pdhcg_get_spmv_backend(void) { return 0; }\
#endif\
\
static inline bool pdhcg_use_new_spmv(int nnz)\
{\
#ifdef PDHCG_USE_NEW_SPMV\
    return (nnz > 0) && (pdhcg_get_spmv_backend() == 1);\
#else\
    (void)nnz; return false;\
#endif\
}
}' "$SPMV_CU"

echo "[patch] 已修改 src/spmv_backend.cu"

# ----------------------------------------------------------------------------
# Patch 3: 在 pdhcg_spmv_ctx_create 中添加 new SpMV 尝试逻辑
# ----------------------------------------------------------------------------
# 锚点: "if (num_nonzeros == 0)" 之后、"CUSPARSE_CHECK(cusparseCreateCsr(...))" 之前
sed -i '/if (num_nonzeros == 0)$/,/^    }$/{
    /^    }$/a\
\
    // Try new SpMV backend first if selected\
    if (pdhcg_use_new_spmv(num_nonzeros))\
    {\
#ifdef PDHCG_USE_NEW_SPMV\
        cudaError_t err = pdhcg_new_spmv_ctx_create(ctx, num_rows, num_cols, num_nonzeros, row_ptr, col_ind, val, sparse_handle);\
        if (err == cudaSuccess)\
            return ctx;\
        fprintf(stderr, "[spmv_backend] new SpMV create failed (%s)\\n", cudaGetErrorString(err));\
        ctx->new_spmv_plan = nullptr;\
        ctx->new_spmv_workspace = nullptr;\
#endif\
    }
}' "$SPMV_CU"

echo "[patch] 已添加 new SpMV 尝试逻辑"

# ----------------------------------------------------------------------------
# Patch 4: 在 pdhcg_spmv_ctx_destroy 中添加 new SpMV 销毁逻辑
# ----------------------------------------------------------------------------
# 锚点: "#if PDHCG_USE_SPMVOP" 之前
sed -i '/^#if PDHCG_USE_SPMVOP$/i\
#ifdef PDHCG_USE_NEW_SPMV\
    if (ctx->new_spmv_plan != nullptr)\
    {\
        pdhcg_new_spmv_ctx_destroy(ctx);\
        free(ctx);\
        return;\
    }\
#endif\
' "$SPMV_CU"

echo "[patch] 已添加 new SpMV 销毁逻辑"

# ----------------------------------------------------------------------------
# Patch 5: 在 pdhcg_spmv_execute 中添加 new SpMV 调用 fallback
# ----------------------------------------------------------------------------
# 锚点: "CUSPARSE_CHECK(cusparseDnVecSetValues(ctx->vec_x, (void *)x));" 之前
sed -i '/^    CUSPARSE_CHECK(cusparseDnVecSetValues(ctx->vec_x, (void \*)x));$/i\
#ifdef PDHCG_USE_NEW_SPMV\
    if (ctx->new_spmv_plan != nullptr)\
    {\
        cudaError_t err = pdhcg_new_spmv_execute(ctx, sparse_handle, alpha, beta, x, y);\
        if (err == cudaSuccess) return;\
        fprintf(stderr, "[spmv_backend] new SpMV execute failed (%s)\\n", cudaGetErrorString(err));\
    }\
#endif\
' "$SPMV_CU"

echo "[patch] 已添加 new SpMV 执行 fallback"

echo ""
echo "============================================================"
echo "[patch] SpMV backend patch 应用完成！"
echo "[patch] 备份文件: src/spmv_backend.cu.bak, internal/spmv_backend.h.bak"
echo "[patch] 回滚: mv src/spmv_backend.cu.bak src/spmv_backend.cu"
echo "============================================================"

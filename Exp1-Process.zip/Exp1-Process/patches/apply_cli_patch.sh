#!/bin/bash
#===============================================================================
# Patch: 给 PDHCG CLI 添加 --spmv_backend 参数
#===============================================================================
# 用法（在 PDHCG 源码根目录下执行）：
#   bash apply_cli_patch.sh
#
# 行为：
#   - 备份 src/cli.c 为 src/cli.c.bak
#   - 添加 #include "spmv_backend.h"
#   - 添加 --spmv_backend 命令行选项
#   - 添加使用说明
#
# 回滚：mv src/cli.c.bak src/cli.c
#===============================================================================

set -e

cd "$(dirname "${BASH_SOURCE[0]}")/../PDHCG-exp" || exit 1

echo "[patch] 当前目录: $(pwd)"

CLI_C="src/cli.c"

# 备份
if [ ! -f "${CLI_C}.bak" ]; then
    cp "$CLI_C" "${CLI_C}.bak"
    echo "[patch] 已备份 $CLI_C"
fi

# 1. 添加 #include "spmv_backend.h"
sed -i '/^#include "solver.h"$/a\
#include "spmv_backend.h"' "$CLI_C"
echo "[patch] 添加 #include"

# 2. 在使用说明处添加 --spmv_backend 说明（紧跟 --soc_form 之后）
sed -i '/soc_form <form>    QCQP cone formulation/i\
\
    fprintf(stderr, "      --spmv_backend <type>  SpMV backend: cusparse or new (default: cusparse, requires new build).\\n");\
    /* keep */\
    fprintf(stderr, "      --soc_form <form>    QCQP cone formulation:' "$CLI_C"
# 上述 sed 是脆弱的（行匹配不一定精确），下面用更稳健的方式
# 实际替换策略：直接在整个 help 文本后添加
sed -i 's|soc_form <form>    QCQP cone formulation: .rotated. or .standard. (default: rotated).|soc_form <form>    QCQP cone formulation: '"'"'rotated'"'"' or '"'"'standard'"'"' (default: rotated).\\n      --spmv_backend <type>  SpMV backend: cusparse or new (default: cusparse, requires new build).|' "$CLI_C"

echo "[patch] 添加 help 文本"

# 3. 在 long_options 中添加选项（紧跟 curtis_reid_iter 后）
sed -i '/"curtis_reid_iter", required_argument, 0, 1025},/a\
                                           {"spmv_backend", required_argument, 0, 1026},' "$CLI_C"

echo "[patch] 添加 long_options"

# 4. 在 switch 中添加 case 处理（紧跟 case 1025 后）
sed -i '/case 1025:$/,/break;$/{
    /break;$/a\
            case 1026:\
                if (strcmp(optarg, "cusparse") == 0 || strcmp(optarg, "cusparse_spmvop") == 0)\
                {\
                    pdhcg_set_spmv_backend(0);\
                }\
                else if (strcmp(optarg, "new") == 0 || strcmp(optarg, "new_spmv") == 0)\
                {\
                    pdhcg_set_spmv_backend(1);\
                }\
                else\
                {\
                    fprintf(stderr, "Error: spmv_backend must be .cusparse. or .new.\\n");\
                    return 1;\
                }\
                break;
}' "$CLI_C"

echo "[patch] 添加 case 1026"

echo ""
echo "============================================================"
echo "[patch] CLI patch 应用完成！"
echo "[patch] 回滚: mv src/cli.c.bak src/cli.c"
echo "============================================================"

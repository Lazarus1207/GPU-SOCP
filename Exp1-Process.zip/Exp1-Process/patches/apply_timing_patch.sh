#!/bin/bash
#===============================================================================
# Patch: 给 PDHCG 添加分环节 timing 功能
#===============================================================================
# 用法（在 PDHCG 源码根目录下执行）：
#   bash apply_timing_patch.sh
#
# 行为：
#   - 备份 pdhg_core_op.cu 和 solver.cu
#   - 在 pdhg_core_op.cu 的关键调用点添加 timing guards
#   - 在 solver.cu 的优化函数前后添加 timing 初始化/打印
#
# 回滚：
#   mv src/pdhg_core_op.cu.bak src/pdhg_core_op.cu
#   mv src/solver.cu.bak src/solver.cu
#===============================================================================

set -e

cd "$(dirname "${BASH_SOURCE[0]}")/../PDHCG-exp" || exit 1

echo "[patch] 当前目录: $(pwd)"

CORE_OP="src/pdhg_core_op.cu"
SOLVER="src/solver.cu"

# 备份
for f in "$CORE_OP" "$SOLVER"; do
    if [ ! -f "${f}.bak" ]; then
        cp "$f" "${f}.bak"
        echo "[patch] 已备份 $f"
    fi
done

# 1. 在 pdhg_core_op.cu 顶部添加 timing include
# 锚点: #include "solver.h" 后
sed -i '/^#include "solver.h"$/a\
\
#ifdef PDHCG_ENABLE_TIMING\
#include "timing_profiler.h"\
#endif' "$CORE_OP"

echo "[patch] 添加 timing include"

# 2. 在 pdhcg_spmv_execute 调用周围添加 timing
# 在 "pdhcg_spmv_execute(state->sparse_handle, state->spmv_ctx_At," 之前添加 timing start
sed -i '/pdhcg_spmv_execute(state->sparse_handle, state->spmv_ctx_At,/{h;s/.*/PDHCG_TIMING_MEASURE(TIMING_SCOPE_SPMV_AT);/;G}' "$CORE_OP"
# 在该调用块结束后（下一行以 pdhcg_all_reduce_array 开始）添加 timing stop
sed -i '/pdhcg_all_reduce_array/,/pdhcg_spmv_execute(state->sparse_handle, state->spmv_ctx_A,/{
    /pdhcg_all_reduce_array/{h;s/.*/\/\/ TIMING STOP AT\n&/;G}
}' "$CORE_OP"

# 对第二个 SpMV 调用也添加 timing
sed -i '/pdhcg_spmv_execute(state->sparse_handle, state->spmv_ctx_A,/{h;s/.*/PDHCG_TIMING_MEASURE(TIMING_SCOPE_SPMV_A);/;G}' "$CORE_OP"

echo "[patch] 添加 SpMV timing guards"

# 3. 在 dispatch_cone_projection 调用周围添加 timing
sed -i '/dispatch_cone_projection(state, primal_solution);/{h;s/.*/PDHCG_TIMING_MEASURE(TIMING_SCOPE_CONE_PROJ);/;G}' "$CORE_OP"

echo "[patch] 添加 Cone Projection timing"

# 4. 在 compute_residual 函数入口添加 timing
# 锚点: 函数开始
sed -i '/^void compute_residual(pdhg_solver_state_t \*state, norm_type_t optimality_norm)$/,/^}$/{
    /^void compute_residual/{h;s/.*/\/\/ TIMING: Residual computation\n&/;G}
}' "$CORE_OP"

echo "[patch] 添加 Residual timing"

# 5. 在 solver.cu 的 optimize 函数中:
#    - 在开始时调用 pdhcg_timing_init()
#    - 在结束前调用 pdhcg_timing_print() 和 pdhcg_timing_cleanup()
SOLVER_TMP=$(mktemp)

cat > "$SOLVER_TMP" << 'SOLVER_EOF'
// ===== Exp1-Process Timing Patch =====
#ifdef PDHCG_ENABLE_TIMING
#include "timing_profiler.h"
#endif
// ===== End Timing Patch =====

SOLVER_EOF

# 在 #include "solver.h" 后插入 timing include
sed -i '/^#include "solver.h"$/r '"$SOLVER_TMP" "$SOLVER"

# 在 const auto start_time = std::chrono::steady_clock::now(); 之前添加 timing init
sed -i '/const auto start_time = std::chrono::steady_clock::now();/i\
#ifdef PDHCG_ENABLE_TIMING\
    pdhcg_timing_init();\
#endif' "$SOLVER"

# 在 return result; 之前添加 timing finalize 和 print
# 找到 pdhcg_result_t *result = create_result_from_state
sed -i '/pdhcg_result_t \*result = create_result_from_state(state, original_problem);/{
    h
    s/.*/\/\/ ===== Exp1-Process Timing Finalize =====\n#ifdef PDHCG_ENABLE_TIMING\n    pdhcg_timing_finalize();\n    pdhcg_timing_print();\n    pdhcg_timing_cleanup();\n#endif\n\/\/ ===== End Timing Finalize =====\n&/
    G
}' "$SOLVER"

rm "$SOLVER_TMP"

echo "[patch] 添加 solver timing init/finalize"

echo ""
echo "============================================================"
echo "[patch] Timing patch 应用完成！"
echo "[patch] 回滚:"
echo "  mv src/pdhg_core_op.cu.bak src/pdhg_core_op.cu"
echo "  mv src/solver.cu.bak src/solver.cu"
echo "============================================================"

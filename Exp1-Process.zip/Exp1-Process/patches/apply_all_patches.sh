#!/bin/bash
#===============================================================================
# PDHCG Exp1-Process — 一键应用所有 patch
#
# 用法：
#   cd ~/PDHCG  # 进入 PDHCG 源码根目录
#   bash ~/testHM/Exp1-Process/patches/apply_all_patches.sh
#
# 本脚本完成：
#   1. 备份所有原文件 (*.bak)
#   2. 应用 SpMV backend patch
#   3. 应用 CLI patch
#   4. 复制 timing profiler header
#   5. 打印使用说明
#
# 回滚：运行 restore_original.sh
#===============================================================================

set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PDHCG_DIR="${PDHCG_DIR:-$(pwd)}"

echo "=============================================="
echo "PDHCG Exp1-Process — Patch Application"
echo "=============================================="
echo "PDHCG directory: $PDHCG_DIR"
echo ""

# ===========================================================================
# 检查目录
# ===========================================================================
if [ ! -d "$PDHCG_DIR/src" ]; then
    echo "[ERROR] 不是 PDHCG 源码目录（找不到 src/）"
    echo "用法: cd ~/PDHCG && bash $SCRIPT_DIR/apply_all_patches.sh"
    exit 1
fi

cd "$PDHCG_DIR"

# ===========================================================================
# 备份
# ===========================================================================
echo "[1/6] 备份原文件..."
BACKUP_FILES=(
    "src/spmv_backend.cu"
    "src/spmv_backend.h"
    "internal/spmv_backend.h"
    "src/cli.c"
    "src/pdhg_core_op.cu"
    "src/solver.cu"
)
for f in "${BACKUP_FILES[@]}"; do
    if [ -f "$f" ] && [ ! -f "${f}.bak" ]; then
        cp "$f" "${f}.bak"
        echo "  backed up: $f"
    fi
done
echo ""

# ===========================================================================
# Patch 1: SpMV Backend (spmv_backend.h)
# ===========================================================================
echo "[2/6] Patch 1: SpMV Backend (spmv_backend.h)..."
SPMV_H="internal/spmv_backend.h"

# 在 typedef struct { ... } pdhcg_spmv_ctx_t; 块前添加 forward declaration
sed -i '/typedef struct$/,/^    } pdhcg_spmv_ctx_t;$/c\
    struct spmv_plan;\
\
    typedef struct\
    {\
        cusparseSpMatDescr_t mat;\
        cusparseDnVecDescr_t vec_x;\
        cusparseDnVecDescr_t vec_y;\
        void *buffer;\
        void *descr;\
        void *plan;\
        int num_rows;\
        int num_nonzeros;\
        struct spmv_plan *new_spmv_plan;\
        void *new_spmv_workspace;\
        size_t new_spmv_workspace_bytes;\
    } pdhcg_spmv_ctx_t;' "$SPMV_H"

# 添加 backend API 声明（在 pdhcg_spmv_execute 之前）
sed -i '/void pdhcg_spmv_execute/i\
    void pdhcg_set_spmv_backend(int backend);\
    int  pdhcg_get_spmv_backend(void);\
' "$SPMV_H"
echo "  done: spmv_backend.h"

# ===========================================================================
# Patch 2: SpMV Backend (spmv_backend.cu)
# ===========================================================================
echo "[3/6] Patch 2: SpMV Backend (spmv_backend.cu)..."
SPMV_CU="src/spmv_backend.cu"

# 在 #include "utils.h" 后添加 new SpMV 声明
sed -i '/#include "utils.h"/a\
#ifdef PDHCG_USE_NEW_SPMV\
#include "spmv.h"\
extern "C" cudaError_t pdhcg_new_spmv_ctx_create(pdhcg_spmv_ctx_t *ctx, int num_rows, int num_cols, int num_nonzeros, int *row_ptr, int *col_ind, double *val, cusparseHandle_t sparse_handle);\
extern "C" cudaError_t pdhcg_new_spmv_execute(pdhcg_spmv_ctx_t *ctx, cusparseHandle_t sparse_handle, const double *alpha, const double *beta, const double *x, double *y);\
extern "C" void pdhcg_new_spmv_ctx_destroy(pdhcg_spmv_ctx_t *ctx);\
#endif' "$SPMV_CU"

# 添加 backend 选择 helper（在 pdhcg_use_spmvop_by_default 函数后）
sed -i '/^extern "C" bool pdhcg_use_spmvop_by_default(void)$/,/^}$/{ /^}$/a\
\
#ifdef PDHCG_USE_NEW_SPMV\
static int g_pdhcg_new_spmv_backend = PDHCG_NEW_SPMV_RUNTIME_DEFAULT;\
extern "C" void pdhcg_set_spmv_backend(int backend){if(backend==0||backend==1)g_pdhcg_new_spmv_backend=backend;}\
extern "C" int pdhcg_get_spmv_backend(void){return g_pdhcg_new_spmv_backend;}\
#else\
extern "C" void pdhcg_set_spmv_backend(int backend){(void)backend;}\
extern "C" int pdhcg_get_spmv_backend(void){return 0;}\
#endif\
static inline bool pdhcg_use_new_spmv(int nnz){\
#ifdef PDHCG_USE_NEW_SPMV\
return(nnz>0)\&\&(pdhcg_get_spmv_backend()==1);\
#else\
(void)nnz;return false;\
#endif\
}
}' "$SPMV_CU"

# 在 pdhcg_spmv_ctx_create 中，num_nonzeros==0 检查之后、cusparseCreateCsr 之前添加 new SpMV 尝试
sed -i '/if (num_nonzeros == 0)$/,/^    }$/{
    /^    }$/a\
    if(pdhcg_use_new_spmv(num_nonzeros)){\
#ifdef PDHCG_USE_NEW_SPMV\
        cudaError_t err=pdhcg_new_spmv_ctx_create(ctx,num_rows,num_cols,num_nonzeros,row_ptr,col_ind,val,sparse_handle);\
        if(err==cudaSuccess)return ctx;\
        fprintf(stderr,"[spmv] new backend failed: %s\\n",cudaGetErrorString(err));\
        ctx->new_spmv_plan=nullptr;\
        ctx->new_spmv_workspace=nullptr;\
#endif\
    }
}' "$SPMV_CU"

# 在 pdhcg_spmv_ctx_destroy 中，num_nonzeros==0 检查后添加 new backend 销毁
sed -i '/if (ctx->num_nonzeros == 0)$/,/^    }$/{
    /^    }$/a\
#ifdef PDHCG_USE_NEW_SPMV\
    if(ctx->new_spmv_plan!=nullptr){pdhcg_new_spmv_ctx_destroy(ctx);free(ctx);return;}\
#endif
}' "$SPMV_CU"

# 在 pdhcg_spmv_execute 中，在 cusparseDnVecSetValues 之前添加 new backend 调用
sed -i '/CUSPARSE_CHECK(cusparseDnVecSetValues(ctx->vec_x, (void \*)x);$/i\
#ifdef PDHCG_USE_NEW_SPMV\
    if(ctx->new_spmv_plan!=nullptr){\
        cudaError_t err=pdhcg_new_spmv_execute(ctx,sparse_handle,alpha,beta,x,y);\
        if(err==cudaSuccess)return;\
        fprintf(stderr,"[spmv] new backend exec failed: %s\\n",cudaGetErrorString(err));\
    }\
#endif
}' "$SPMV_CU"
echo "  done: spmv_backend.cu"

# ===========================================================================
# Patch 3: CLI (cli.c)
# ===========================================================================
echo "[4/6] Patch 3: CLI (cli.c)..."
CLI_C="src/cli.c"

# 添加 include
sed -i '/#include "solver.h"$/a\
#include "spmv_backend.h"' "$CLI_C"

# 添加 --spmv_backend 到 help（跟在 --soc_form 之后）
sed -i 's|soc_form <form>.*|soc_form <form>    QCQP cone formulation: '"'"'rotated'"'"' or '"'"'standard'"'"' (default: rotated).\\n    fprintf(stderr, "      --spmv_backend <type>  SpMV backend: cusparse or new (default: cusparse, requires new build).\\n");|' "$CLI_C"

# 添加 long option
sed -i '/{"curtis_reid_iter", required_argument, 0, 1025},$/a\
                                           {"spmv_backend", required_argument, 0, 1026},' "$CLI_C"

# 添加 case 1026（跟在 case 1025 后）
sed -i '/params.curtis_reid_iterations = atoi(optarg);$/,/break;$/{/break;$/a\
            case 1026:\
                if(strcmp(optarg,"cusparse")==0||strcmp(optarg,"cusparse_spmvop")==0){pdhcg_set_spmv_backend(0);}\
                else if(strcmp(optarg,"new")==0||strcmp(optarg,"new_spmv")==0){pdhcg_set_spmv_backend(1);}\
                else{fprintf(stderr,"Error: spmv_backend must be .cusparse. or .new.\\n");return 1;}\
                break;
}' "$CLI_C"
echo "  done: cli.c"

# ===========================================================================
# Patch 4: Timing Infrastructure
# ===========================================================================
echo "[5/6] Patch 4: Timing Infrastructure..."

# 复制 timing profiler header 到 internal/
cp "$SCRIPT_DIR/timing_profiler.h" internal/timing_profiler.h
echo "  copied: internal/timing_profiler.h"

# 在 solver.cu 中添加 timing 初始化和打印
SOLVER_CU="src/solver.cu"

# 在 solver.cu 顶部添加 include（跟在 solver.h 之后）
sed -i '/#include "solver.h"/a\
#ifdef PDHCG_ENABLE_TIMING\
#include "timing_profiler.h"\
#endif' "$SOLVER_CU"

# 在 start_time 声明前添加 timing init
sed -i '/std::chrono::steady_clock::now()/{h;s/.*/\/\/ Exp1-Process: Init timing\n#ifdef PDHCG_ENABLE_TIMING\n    pdhcg_timing_init();\n#endif\n&/;G}' "$SOLVER_CU"

# 在 return result; 之前添加 timing finalize（找到 optimize 函数中的 create_result_from_state 调用）
sed -i '/pdhcg_result_t \*result = create_result_from_state/{h;s/.*/\/\/ Exp1-Process: Finalize timing\n#ifdef PDHCG_ENABLE_TIMING\n    pdhcg_timing_finalize();\n    pdhcg_timing_print();\n    pdhcg_timing_cleanup();\n#endif\n&/;G}' "$SOLVER_CU"

# 在 pdhg_core_op.cu 顶部添加 timing include
CORE_OP="src/pdhg_core_op.cu"
sed -i '/#include "solver.h"/a\
#ifdef PDHCG_ENABLE_TIMING\
#include "timing_profiler.h"\
#endif' "$CORE_OP"

# 在 SpMV A^T 调用前添加 timing（找 pdhcg_spmv_execute.*spmv_ctx_At 调用）
sed -i '/pdhcg_spmv_execute(state->sparse_handle, state->spmv_ctx_At,/{h;s/.*/\/\/ Exp1-Process: SpMV At\n#ifdef PDHCG_ENABLE_TIMING\n    cudaEvent_t _t0,_t1;cudaEventCreate(\&_t0);cudaEventCreate(\&_t1);cudaEventRecord(_t0,0);\n#endif\n&/;G}' "$CORE_OP"
sed -i '/pdhcg_spmv_execute(state->sparse_handle, state->spmv_ctx_At,/,/pdhcg_all_reduce_array/{
    /pdhcg_all_reduce_array/{h;s/.*/\n#endif\n&/;G}
}' "$CORE_OP"

# 在 SpMV A 调用前添加 timing
sed -i '/pdhcg_spmv_execute(state->sparse_handle, state->spmv_ctx_A,/{h;s/.*/\/\/ Exp1-Process: SpMV A\n#ifdef PDHCG_ENABLE_TIMING\n    cudaEvent_t _t2,_t3;cudaEventCreate(\&_t2);cudaEventCreate(\&_t3);cudaEventRecord(_t2,0);\n#endif\n&/;G}' "$CORE_OP"
sed -i '/pdhcg_spmv_execute(state->sparse_handle, state->spmv_ctx_A,/,/pdhcg_all_reduce_array/{
    /pdhcg_all_reduce_array/{h;s/.*/\n#endif\n&/;G}
}' "$CORE_OP"

echo "  done: timing patches"

# ===========================================================================
# 复制 new SpMV wrapper 到 src/
# ===========================================================================
echo "[6/6] 复制 new SpMV wrapper..."
cp "$SCRIPT_DIR/spmv_backend_new.cu" src/spmv_backend_new.cu
echo "  copied: src/spmv_backend_new.cu"

# ===========================================================================
# 完成
# ===========================================================================
echo ""
echo "=============================================="
echo "所有 patch 应用完成！"
echo ""
echo "下一步 — 编译（参考 Exp1-Process/USAGE.md）："
echo ""
echo "  # Baseline + timing"
echo "  mkdir build_timing && cd build_timing"
echo '  cmake .. -DPDHCG_ENABLE_TIMING=ON -DCMAKE_CUDA_ARCHITECTURES="80;86;89;90"'
echo "  make -j\$(nproc) pdhcg"
echo ""
echo "  # 运行时测试"
echo "  ./pdhcg /path/to/problem.cbf.gz /tmp/out/ --verbose 2"
echo ""
echo "回滚命令："
for f in "${BACKUP_FILES[@]}"; do
    echo "  mv $f.bak $f"
done
echo "=============================================="

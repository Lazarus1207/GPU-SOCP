/*
Copyright 2026 Hongpei Li
Copyright 2026 Exp1-Process

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

#ifndef SPMV_BACKEND_H
#define SPMV_BACKEND_H

#include <cusparse.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C"
{
#endif

    // Forward declaration to avoid pulling in spmv.h here
    struct spmv_plan;

    typedef struct
    {
        // cuSPARSE fields (always populated)
        cusparseSpMatDescr_t mat;
        cusparseDnVecDescr_t vec_x;
        cusparseDnVecDescr_t vec_y;
        void *buffer;
        void *descr;
        void *plan;
        int num_rows;
        int num_nonzeros;

        // New SpMV backend fields (Exp1-Process)
        // Only populated when PDHCG_USE_NEW_SPMV is enabled at build time
        // AND pdhcg_get_spmv_backend() == 1 at runtime
        struct spmv_plan *new_spmv_plan;
        void *new_spmv_workspace;
        size_t new_spmv_workspace_bytes;
    } pdhcg_spmv_ctx_t;

    //---------------------------------------------------------------------------
    // Backend selection API (Exp1-Process)
    //---------------------------------------------------------------------------
    // 0 = cuSPARSE (default), 1 = new SpMV
    // Requires PDHCG_USE_NEW_SPMV at compile time for runtime switching to 1.
    void pdhcg_set_spmv_backend(int backend);
    int  pdhcg_get_spmv_backend(void);

    //---------------------------------------------------------------------------
    // Original PDHCG SpMV API (unchanged signature)
    //---------------------------------------------------------------------------
    bool pdhcg_use_spmvop_by_default(void);

    pdhcg_spmv_ctx_t *pdhcg_spmv_ctx_create(cusparseHandle_t sparse_handle,
                                            int num_rows,
                                            int num_cols,
                                            int num_nonzeros,
                                            int *row_ptr,
                                            int *col_ind,
                                            double *val,
                                            cusparseDnVecDescr_t vec_x,
                                            cusparseDnVecDescr_t vec_y);

    void pdhcg_spmv_ctx_destroy(pdhcg_spmv_ctx_t *ctx);

    void pdhcg_spmv_execute(cusparseHandle_t sparse_handle,
                            pdhcg_spmv_ctx_t *ctx,
                            const double *alpha,
                            const double *beta,
                            const double *x,
                            double *y);

#ifdef __cplusplus
}
#endif

#endif // SPMV_MV_BACKEND_H

#!/bin/bash
#===============================================================================
# PDHCG Exp1-Process 鈥?涓€閿簲鐢ㄦ墍鏈?patch
#
# 鐢ㄦ硶锛?
#   cd ~/PDHCG  # 杩涘叆 PDHCG 婧愮爜鏍圭洰褰?
#   bash ~/testHM/Exp1-Process/patches/apply_all_patches.sh
#
# 鏈剼鏈畬鎴愶細
#   1. 澶囦唤鎵€鏈夊師鏂囦欢 (*.bak)
#   2. 搴旂敤 SpMV backend patch
#   3. 搴旂敤 CLI patch
#   4. 澶嶅埗 timing profiler header
#   5. 鎵撳嵃浣跨敤璇存槑
#
# 鍥炴粴锛氳繍琛?restore_original.sh
#===============================================================================

set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PDHCG_DIR="${PDHCG_DIR:-$(pwd)}"

echo "=============================================="
echo "PDHCG Exp1-Process 鈥?Patch Application"
echo "=============================================="
echo "PDHCG directory: $PDHCG_DIR"
echo ""

# ===========================================================================
# 妫€鏌ョ洰褰?
# ===========================================================================
if [ ! -d "$PDHCG_DIR/src" ]; then
    echo "[ERROR] 涓嶆槸 PDHCG 婧愮爜鐩綍锛堟壘涓嶅埌 src/锛?
    echo "鐢ㄦ硶: cd ~/PDHCG && bash $SCRIPT_DIR/apply_all_patches.sh"
    exit 1
fi

cd "$PDHCG_DIR"

# ===========================================================================
# 澶囦唤
# ===========================================================================
echo "[1/6] 澶囦唤鍘熸枃浠?.."
BACKUP_FILES=(
    "src/spmv_backend.cu"
    "src/spmv_backend.h"
    "internal/spmv_backend.h"
    "src/cli.c"
    "src/pdhg_core_op.cu"
    "src/solver.cu"
)
for f in "${BACKUP_FILES[@]}"; do
    if [ -f "$f" ] && [ ! -f "${f}.bak" ]; then
        cp "$f" "${f}.bak"
        echo "  backed up: $f"
    fi
done
echo ""

# ===========================================================================
# Patch 1: SpMV Backend (spmv_backend.h)
# ===========================================================================
echo "[2/6] Patch 1: SpMV Backend (spmv_backend.h)..."
SPMV_H="internal/spmv_backend.h"

# 鍦?typedef struct { ... } pdhcg_spmv_ctx_t; 鍧楀墠娣诲姞 forward declaration
sed -i '/typedef struct$/,/^    } pdhcg_spmv_ctx_t;$/c\
    struct spmv_plan;\
\
    typedef struct\
    {\
        cusparseSpMatDescr_t mat;\
        cusparseDnVecDescr_t vec_x;\
        cusparseDnVecDescr_t vec_y;\
        void *buffer;\
        void *descr;\
        void *plan;\
        int num_rows;\
        int num_nonzeros;\
        struct spmv_plan *new_spmv_plan;\
        void *new_spmv_workspace;\
        size_t new_spmv_workspace_bytes;\
    } pdhcg_spmv_ctx_t;' "$SPMV_H"

# 娣诲姞 backend API 澹版槑锛堝湪 pdhcg_spmv_execute 涔嬪墠锛?
sed -i '/void pdhcg_spmv_execute/i\
    void pdhcg_set_spmv_backend(int backend);\
    int  pdhcg_get_spmv_backend(void);\
' "$SPMV_H"
echo "  done: spmv_backend.h"

# ===========================================================================
# Patch 2: SpMV Backend (spmv_backend.cu)
# ===========================================================================
echo "[3/6] Patch 2: SpMV Backend (spmv_backend.cu)..."
SPMV_CU="src/spmv_backend.cu"

# 鍦?#include "utils.h" 鍚庢坊鍔?new SpMV 澹版槑
sed -i '/#include "utils.h"/a\
#ifdef PDHCG_USE_NEW_SPMV\
#include "spmv.h"\
extern "C" cudaError_t pdhcg_new_spmv_ctx_create(pdhcg_spmv_ctx_t *ctx, int num_rows, int num_cols, int num_nonzeros, int *row_ptr, int *col_ind, double *val, cusparseHandle_t sparse_handle);\
extern "C" cudaError_t pdhcg_new_spmv_execute(pdhcg_spmv_ctx_t *ctx, cusparseHandle_t sparse_handle, const double *alpha, const double *beta, const double *x, double *y);\
extern "C" void pdhcg_new_spmv_ctx_destroy(pdhcg_spmv_ctx_t *ctx);\
#endif' "$SPMV_CU"

# 娣诲姞 backend 閫夋嫨 helper锛堝湪 pdhcg_use_spmvop_by_default 鍑芥暟鍚庯級
sed -i '/^extern "C" bool pdhcg_use_spmvop_by_default(void)$/,/^}$/{ /^}$/a\
\
#ifdef PDHCG_USE_NEW_SPMV\
static int g_pdhcg_new_spmv_backend = PDHCG_NEW_SPMV_RUNTIME_DEFAULT;\
extern "C" void pdhcg_set_spmv_backend(int backend){if(backend==0||backend==1)g_pdhcg_new_spmv_backend=backend;}\
extern "C" int pdhcg_get_spmv_backend(void){return g_pdhcg_new_spmv_backend;}\
#else\
extern "C" void pdhcg_set_spmv_backend(int backend){(void)backend;}\
extern "C" int pdhcg_get_spmv_backend(void){return 0;}\
#endif\
static inline bool pdhcg_use_new_spmv(int nnz){\
#ifdef PDHCG_USE_NEW_SPMV\
return(nnz>0)\&\&(pdhcg_get_spmv_backend()==1);\
#else\
(void)nnz;return false;\
#endif\
}
}' "$SPMV_CU"

# 鍦?pdhcg_spmv_ctx_create 涓紝num_nonzeros==0 妫€鏌ヤ箣鍚庛€乧usparseCreateCsr 涔嬪墠娣诲姞 new SpMV 灏濊瘯
sed -i '/if (num_nonzeros == 0)$/,/^    }$/{
    /^    }$/a\
    if(pdhcg_use_new_spmv(num_nonzeros)){\
#ifdef PDHCG_USE_NEW_SPMV\
        cudaError_t err=pdhcg_new_spmv_ctx_create(ctx,num_rows,num_cols,num_nonzeros,row_ptr,col_ind,val,sparse_handle);\
        if(err==cudaSuccess)return ctx;\
        fprintf(stderr,"[spmv] new backend failed: %s\\n",cudaGetErrorString(err));\
        ctx->new_spmv_plan=nullptr;\
        ctx->new_spmv_workspace=nullptr;\
#endif\
    }
}' "$SPMV_CU"

# 鍦?pdhcg_spmv_ctx_destroy 涓紝num_nonzeros==0 妫€鏌ュ悗娣诲姞 new backend 閿€姣?
sed -i '/if (ctx->num_nonzeros == 0)$/,/^    }$/{
    /^    }$/a\
#ifdef PDHCG_USE_NEW_SPMV\
    if(ctx->new_spmv_plan!=nullptr){pdhcg_new_spmv_ctx_destroy(ctx);free(ctx);return;}\
#endif
}' "$SPMV_CU"

# 鍦?pdhcg_spmv_execute 涓紝鍦?cusparseDnVecSetValues 涔嬪墠娣诲姞 new backend 璋冪敤
sed -i '/CUSPARSE_CHECK(cusparseDnVecSetValues(ctx->vec_x, (void \*)x);$/i\
#ifdef PDHCG_USE_NEW_SPMV\
    if(ctx->new_spmv_plan!=nullptr){\
        cudaError_t err=pdhcg_new_spmv_execute(ctx,sparse_handle,alpha,beta,x,y);\
        if(err==cudaSuccess)return;\
        fprintf(stderr,"[spmv] new backend exec failed: %s\\n",cudaGetErrorString(err));\
    }\
#endif
}' "$SPMV_CU"
echo "  done: spmv_backend.cu"

# ===========================================================================
# Patch 3: CLI (cli.c)
# ===========================================================================
echo "[4/6] Patch 3: CLI (cli.c)..."
CLI_C="src/cli.c"

# 娣诲姞 include
sed -i '/#include "solver.h"$/a\
#include "spmv_backend.h"' "$CLI_C"

# 娣诲姞 --spmv_backend 鍒?help锛堣窡鍦?--soc_form 涔嬪悗锛?
sed -i 's|soc_form <form>.*|soc_form <form>    QCQP cone formulation: '"'"'rotated'"'"' or '"'"'standard'"'"' (default: rotated).\\n    fprintf(stderr, "      --spmv_backend <type>  SpMV backend: cusparse or new (default: cusparse, requires new build).\\n");|' "$CLI_C"

# 娣诲姞 long option
sed -i '/{"curtis_reid_iter", required_argument, 0, 1025},$/a\
                                           {"spmv_backend", required_argument, 0, 1026},' "$CLI_C"

# 娣诲姞 case 1026锛堣窡鍦?case 1025 鍚庯級
sed -i '/params.curtis_reid_iterations = atoi(optarg);$/,/break;$/{/break;$/a\
            case 1026:\
                if(strcmp(optarg,"cusparse")==0||strcmp(optarg,"cusparse_spmvop")==0){pdhcg_set_spmv_backend(0);}\
                else if(strcmp(optarg,"new")==0||strcmp(optarg,"new_spmv")==0){pdhcg_set_spmv_backend(1);}\
                else{fprintf(stderr,"Error: spmv_backend must be .cusparse. or .new.\\n");return 1;}\
                break;
}' "$CLI_C"
echo "  done: cli.c"

# ===========================================================================
# Patch 4: Timing Infrastructure
# ===========================================================================
echo "[5/6] Patch 4: Timing Infrastructure..."

# 澶嶅埗 timing profiler header 鍒?internal/
cp "$SCRIPT_DIR/timing_profiler.h" internal/timing_profiler.h
echo "  copied: internal/timing_profiler.h"

# 鍦?solver.cu 涓坊鍔?timing 鍒濆鍖栧拰鎵撳嵃
SOLVER_CU="src/solver.cu"

# 鍦?solver.cu 椤堕儴娣诲姞 include锛堣窡鍦?solver.h 涔嬪悗锛?
sed -i '/#include "solver.h"/a\
#ifdef PDHCG_ENABLE_TIMING\
#include "timing_profiler.h"\
#endif' "$SOLVER_CU"

# 鍦?start_time 澹版槑鍓嶆坊鍔?timing init
sed -i '/std::chrono::steady_clock::now()/{h;s/.*/\/\/ Exp1-Process: Init timing\n#ifdef PDHCG_ENABLE_TIMING\n    pdhcg_timing_init();\n#endif\n&/;G}' "$SOLVER_CU"

# 鍦?return result; 涔嬪墠娣诲姞 timing finalize锛堟壘鍒?optimize 鍑芥暟涓殑 create_result_from_state 璋冪敤锛?
sed -i '/pdhcg_result_t \*result = create_result_from_state/{h;s/.*/\/\/ Exp1-Process: Finalize timing\n#ifdef PDHCG_ENABLE_TIMING\n    pdhcg_timing_finalize();\n    pdhcg_timing_print();\n    pdhcg_timing_cleanup();\n#endif\n&/;G}' "$SOLVER_CU"

# 鍦?pdhg_core_op.cu 椤堕儴娣诲姞 timing include
CORE_OP="src/pdhg_core_op.cu"
sed -i '/#include "solver.h"/a\
#ifdef PDHCG_ENABLE_TIMING\
#include "timing_profiler.h"\
#endif' "$CORE_OP"

# 鍦?SpMV A^T 璋冪敤鍓嶆坊鍔?timing锛堟壘 pdhcg_spmv_execute.*spmv_ctx_At 璋冪敤锛?
sed -i '/pdhcg_spmv_execute(state->sparse_handle, state->spmv_ctx_At,/{h;s/.*/\/\/ Exp1-Process: SpMV At\n#ifdef PDHCG_ENABLE_TIMING\n    cudaEvent_t _t0,_t1;cudaEventCreate(\&_t0);cudaEventCreate(\&_t1);cudaEventRecord(_t0,0);\n#endif\n&/;G}' "$CORE_OP"
sed -i '/pdhcg_spmv_execute(state->sparse_handle, state->spmv_ctx_At,/,/pdhcg_all_reduce_array/{
    /pdhcg_all_reduce_array/{h;s/.*/\n#endif\n&/;G}
}' "$CORE_OP"

# 鍦?SpMV A 璋冪敤鍓嶆坊鍔?timing
sed -i '/pdhcg_spmv_execute(state->sparse_handle, state->spmv_ctx_A,/{h;s/.*/\/\/ Exp1-Process: SpMV A\n#ifdef PDHCG_ENABLE_TIMING\n    cudaEvent_t _t2,_t3;cudaEventCreate(\&_t2);cudaEventCreate(\&_t3);cudaEventRecord(_t2,0);\n#endif\n&/;G}' "$CORE_OP"
sed -i '/pdhcg_spmv_execute(state->sparse_handle, state->spmv_ctx_A,/,/pdhcg_all_reduce_array/{
    /pdhcg_all_reduce_array/{h;s/.*/\n#endif\n&/;G}
}' "$CORE_OP"

echo "  done: timing patches"

# ===========================================================================
# 澶嶅埗 new SpMV wrapper 鍒?src/
# ===========================================================================
echo "[6/6] 澶嶅埗 new SpMV wrapper..."
cp "$SCRIPT_DIR/spmv_backend_new.cu" src/spmv_backend_new.cu
echo "  copied: src/spmv_backend_new.cu"

# ===========================================================================
# 瀹屾垚
# ===========================================================================
echo ""
echo "=============================================="
echo "鎵€鏈?patch 搴旂敤瀹屾垚锛?
echo ""
echo "涓嬩竴姝?鈥?缂栬瘧锛堝弬鑰?Exp1-Process/USAGE.md锛夛細"
echo ""
echo "  # Baseline + timing"
echo "  mkdir build_timing && cd build_timing"
echo '  cmake .. -DPDHCG_ENABLE_TIMING=ON -DCMAKE_CUDA_ARCHITECTURES="80;86;89;90"'
echo "  make -j\$(nproc) pdhcg"
echo ""
echo "  # 杩愯鏃舵祴璇?
echo "  ./pdhcg /path/to/problem.cbf.gz /tmp/out/ --verbose 2"
echo ""
echo "鍥炴粴鍛戒护锛?
for f in "${BACKUP_FILES[@]}"; do
    echo "  mv $f.bak $f"
done
echo "=============================================="

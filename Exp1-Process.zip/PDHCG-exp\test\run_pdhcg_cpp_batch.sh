#!/usr/bin/env bash
# PDHCG-II C++ binary batch runner
# 鍗曡繘绋嬶紝椤哄簭鎵ц (GPU 鍏变韩涓婁笅鏂?
# 鐢ㄦ硶: ./run_pdhcg_cpp_batch.sh <input_dir> <output_dir> [time_limit_sec] [iter_limit] [tol] [--gpu]
#
# 渚濊禆: ./build/bin/pdhcg 宸茬紪璇?

set -euo pipefail

INPUT_DIR="${1:?闇€瑕佽緭鍏ョ洰褰?(鍚?.cbf.gz)}"
OUTPUT_DIR="${2:?闇€瑕佽緭鍑虹洰褰晑"
TIME_LIMIT="${3:-600}"
ITER_LIMIT="${4:-20000}"
TOL="${5:-1e-4}"
USE_GPU_FLAG=""
if [[ "${6:-}" == "--gpu" ]]; then
    USE_GPU_FLAG="--use_gpu=ON"
fi

BIN="${PDHCG_BIN:-$HOME/PDHCG/build/pdhcg}"
if [[ ! -x "$BIN" ]]; then
    echo "[err] 鎵句笉鍒?$BIN锛岃鍏?cmake --build build 鎴栬缃?PDHCG_BIN 鐜鍙橀噺"
    exit 1
fi

mkdir -p "$OUTPUT_DIR"
SUMMARY="$OUTPUT_DIR/summary.csv"
echo "file,status,iterations,runtime_sec,obj_value,iter_last_summary,n_cones" > "$SUMMARY"

COUNT=0
TOTAL=$(ls "$INPUT_DIR"/*.cbf.gz 2>/dev/null | wc -l)
echo "[batch] 鍙戠幇 $TOTAL 涓?.cbf.gz"

for FILE in "$INPUT_DIR"/*.cbf.gz; do
    NAME=$(basename "$FILE" .cbf.gz)
    COUNT=$((COUNT + 1))
    echo ""
    echo "[$COUNT/$TOTAL] $NAME"

    START=$(date +%s.%N)
    "$BIN" "$FILE" "$OUTPUT_DIR" \
        -v 1 \
        --time_limit "$TIME_LIMIT" \
        --iter_limit "$ITER_LIMIT" \
        --eps_opt "$TOL" \
        --eps_feas "$TOL" \
        $USE_GPU_FLAG \
        > "$OUTPUT_DIR/${NAME}.stdout" 2>&1 || true
    END=$(date +%s.%N)
    ELAPSED=$(echo "$END - $START" | bc -l)

    # 瑙ｆ瀽 output_dir/<name>-summary.txt
    SUMMARY_TXT="$OUTPUT_DIR/${NAME}-summary.txt"
    if [[ -f "$SUMMARY_TXT" ]]; then
        # 鎶藉彇鍏抽敭瀛楁: 涓嶅悓鐗堟湰瀛楁鍚嶇暐鏈夊樊寮? 鐢?grep 鍏滃簳
        STATUS=$(grep -i "status" "$SUMMARY_TXT" | head -1 || echo "UNKNOWN")
        ITER=$(grep -i "iter" "$SUMMARY_TXT" | head -1 || echo "")
        OBJ=$(grep -i "obj" "$SUMMARY_TXT" | head -1 || echo "")
        echo "$NAME,$STATUS,$ITER,$ELAPSED,$OBJ," >> "$SUMMARY"
    else
        echo "$NAME,ERROR,,,,," >> "$SUMMARY"
    fi
done

echo ""
echo "[batch] 鍏ㄩ儴瀹屾垚 -> $SUMMARY"

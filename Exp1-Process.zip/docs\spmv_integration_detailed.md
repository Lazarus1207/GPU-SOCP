# PDHCG New SpMV Integration - Detailed Switchable Plan

## 1. 架构总览

```
┌──────────────────────────────────────────────────────────────┐
│                       PDHCG Solver Core                       │
│                                                              │
│  ┌──────────────────────────────────────────────────────┐   │
│  │           pdhg_core_op.cu (main loop)                │   │
│  │                                                       │   │
│  │   pdhcg_spmv_execute(...)    ← 单一调用入口           │   │
│  └──────────────────────────────────────────────────────┘   │
│                              │                                │
│                              ▼                                │
│  ┌──────────────────────────────────────────────────────┐   │
│  │              spmv_backend.h (统一接口)                 │   │
│  │                                                       │   │
│  │   pdhcg_spmv_ctx_create/destroy/execute               │   │
│  │   pdhcg_set/get_spmv_backend                          │   │
│  └──────────────────────────────────────────────────────┘   │
│                              │                                │
│                  ┌───────────┴───────────┐                    │
│                  ▼                       ▼                    │
│  ┌──────────────────────┐  ┌──────────────────────────┐    │
│  │   cuSPARSE backend   │  │   New SpMV backend       │    │
│  │   (always present)   │  │   (compiled in optional)  │    │
│  │                      │  │                            │    │
│  │   SpMVOp / SpMV      │  │   libspmv.a (C ABI)       │    │
│  └──────────────────────┘  └──────────────────────────┘    │
└──────────────────────────────────────────────────────────────┘
```

## 2. 三种编译/运行模式

### 模式 A：纯 cuSPARSE（baseline，向后兼容）

```bash
mkdir build_baseline && cd build_baseline
cmake ../PDHCG-exp -DPDHCG_USE_NEW_SPMV=OFF
make -j
# 默认使用 cuSPARSE SpMV
./pdhcg --input beam7.cbf.gz
```

### 模式 B：编译时启用 new SpMV，运行时默认 cuSPARSE（推荐开发模式）

```bash
mkdir build_with_new && cd build_with_new
cmake ../PDHCG-exp \
    -DPDHCG_USE_NEW_SPMV=ON \
    -DSPMV_BACKEND_ROOT=/path/to/spmv-backend
make -j
# 默认使用 cuSPARSE
./pdhcg --input beam7.cbf.gz
# 运行时切换到 new SpMV
./pdhcg --input beam7.cbf.gz --spmv_backend=new
```

### 模式 C：编译时默认 new SpMV（最快，但失去灵活性）

```bash
mkdir build_new && cd build_new
cmake ../PDHCG-exp \
    -DPDHCG_USE_NEW_SPMV=ON \
    -DSPMV_BACKEND_ROOT=/path/to/spmv-backend \
    -DPDHCG_NEW_SPMV_RUNTIME_DEFAULT=1
make -j
# 默认使用 new SpMV
./pdhcg --input beam7.cbf.gz
```

## 3. 实现的关键点

### 3.1 头文件改动 (`internal/spmv_backend.h`)

```c
// 增加 forward declaration，避免引入 spmv.h
struct spmv_plan;

typedef struct {
    // 原有 cuSPARSE 字段
    cusparseSpMatDescr_t mat;
    cusparseDnVecDescr_t vec_x;
    cusparseDnVecDescr_t vec_y;
    void *buffer;
    void *descr;
    void *plan;
    int num_rows;
    int num_nonzeros;

    // 新增：new SpMV backend 字段
    struct spmv_plan *new_spmv_plan;     // NULL = 用 cuSPARSE
    void *new_spmv_workspace;
    size_t new_spmv_workspace_bytes;
} pdhcg_spmv_ctx_t;

// 新增 backend 选择 API
void pdhcg_set_spmv_backend(int backend);  // 0=cuSPARSE, 1=new
int  pdhcg_get_spmv_backend(void);
```

### 3.2 实现文件改动 (`src/spmv_backend.cu`)

**关键设计**：
1. `pdhcg_spmv_ctx_create` 总是同时支持两种 backend
2. 运行时通过 `pdhcg_get_spmv_backend()` 选择
3. 如果 new backend 失败，自动 fallback 到 cuSPARSE
4. 不修改任何上层调用代码（最小侵入）

```c
static inline bool pdhcg_use_new_spmv(int num_nonzeros)
{
#ifdef PDHCG_USE_NEW_SPMV
    return (num_nonzeros > 0) && (pdhcg_get_spmv_backend() == 1);
#else
    return false;
#endif
}
```

### 3.3 New SpMV wrapper (`src/spmv_backend_new.cu`)

**关键决策**：
1. **Stream 一致性**：从 cusparse handle 获取 stream，传入 new SpMV
2. **Workspace 预分配**：在 ctx_create 时一次分配，避免迭代中分配开销
3. **错误处理**：任何错误都会自动 fallback 到 cuSPARSE
4. **不修改 CSR**：new SpMV plan 借用原始 CSR，符合 PDHCG 现有生命周期

```cpp
extern "C" cudaError_t pdhcg_new_spmv_ctx_create(pdhcg_spmv_ctx_t *ctx, ...) {
    cudaStream_t stream = pdhcg_get_current_stream(sparse_handle);
    cudaError_t err = spmv_plan_create(
        (spmv_plan**)&ctx->new_spmv_plan,
        rows, cols, nnz, row_ptr, col_ind, val, stream);
    // ... workspace allocation
    return err;
}
```

## 4. CLI 参数接入

修改 `src/cli.c` 添加 `--spmv_backend` 选项：

```c
// 在 options table 中添加
{"spmv_backend", required_argument, NULL, 'B'},
// 处理
case 'B':
    if (strcmp(optarg, "cusparse") == 0) {
        pdhcg_set_spmv_backend(0);
    } else if (strcmp(optarg, "new") == 0) {
        pdhcg_set_spmv_backend(1);
    } else {
        fprintf(stderr, "Unknown backend: %s\n", optarg);
        return 1;
    }
    break;
```

## 5. 与现有 kernel 的潜在冲突分析

### 5.1 SpMV 调用链检查

| 调用点 | 调用方式 | new SpMV 影响 |
|--------|----------|---------------|
| `pdhg_update` (dual) | `pdhcg_spmv_execute(spmv_ctx_At, ...)` | 仅 backend 切换，无影响 |
| `pdhg_update` (primal) | `pdhcg_spmv_execute(spmv_ctx_A, ...)` | 同上 |
| `compute_residual` | 同上 | 同上 |
| `compute_fixed_point_error` | 同上 | 同上 |

**结论**：SpMV 调用是黑盒替换，不影响 cone projection、Halpern、residual 等其他模块。

### 5.2 数据布局要求

- new SpMV 要求 0-based int32 CSR
- PDHCG 当前 CSR 格式正好满足（`CUSPARSE_INDEX_BASE_ZERO`）
- **无冲突**

### 5.3 Stream 同步

- new SpMV 是异步调用，依赖 stream 同步
- PDHCG 使用 cusparse handle 的 stream，二者一致
- **无冲突**

### 5.4 CSR 数据生命周期

- new SpMV plan 借用原始 CSR 指针
- PDHCG 在 `state` 销毁前一直保留 CSR
- **匹配良好**

### 5.5 Vector descriptor 一致性

- new SpMV API 不使用 `cusparseDnVecDescr_t`
- 我们传入原始 `double*` 指针
- **无冲突**

## 6. 验证测试矩阵

| 问题规模 | nnz | 期望行为 |
|---------|-----|----------|
| chainsing-50000-1 | 0.9M | 测试小规模性能 |
| beam7 | 15M | 中等规模 |
| firL2a | 50M | 大规模 |
| firL2Linfalph | 122M | 超大规模 |

## 7. 失败回退策略

如果 new SpMV 在某些情况下失败：

1. **运行时 fallback**：自动切到 cuSPARSE
2. **编译时回退**：重新编译 `-DPDHCG_USE_NEW_SPMV=OFF`
3. **混合策略**：某些 ctx 用 new，其他用 cuSPARSE

## 8. 性能验证

### 实验设计

```
Baseline: cuSPARSE (PDHCG_USE_SPMVOP=ON)
   ↓
Modification: new SpMV
   ↓
Benchmark: 全 18 题 SOCP
   ↓
Compare: runtime / iteration / inner-iteration
```

### 预期结果

| 组件 | baseline | new SpMV | 改善 |
|------|----------|----------|------|
| SpMV 时间 | 50% | 40% (-20%) | -10% |
| 总时间 | 100% | 90% | -10% |
| SGM10 | 31.04 | ~28 | -10% |

## 9. 与 Timing 系统的集成

启用 `-DPDHCG_ENABLE_TIMING` 后，可以同时测量：
- new SpMV 的 kernel 时间
- 与 cuSPARSE 的对比
- 实际节省时间

```bash
# 编译时同时启用
cmake ../PDHCG-exp \
    -DPDHCG_ENABLE_TIMING=ON \
    -DPDHCG_USE_NEW_SPMV=ON \
    -DSPMV_BACKEND_ROOT=/path/to/spmv-backend

# 运行时切换 backend，对比
./pdhcg --input beam7.cbf.gz --spmv_backend=cusparse 2>&1 | tee cusparse.log
./pdhcg --input beam7.cbf.gz --spmv_backend=new       2>&1 | tee new.log
python3 ../scripts/analyze_timing.py -i new.log -o new_report.json
```

## 10. 实施清单

- [x] 修改 `internal/spmv_backend.h` 添加新字段和 API
- [x] 创建 `src/spmv_backend_new.cu` wrapper
- [x] 修改 `src/spmv_backend.cu` 添加 fallback 逻辑
- [x] 修改 `CMakeLists.txt` 添加编译选项
- [ ] 修改 `src/cli.c` 添加 `--spmv_backend` 参数
- [ ] 创建 test_spmv_backend.cu 测试两种 backend 一致性
- [ ] 编译验证
- [ ] 在服务器运行实际测试

## 11. 风险与缓解

| 风险 | 影响 | 缓解 |
|------|------|------|
| 数值不一致 | 残差不收 | 自动 fallback |
| Workspace 分配失败 | 求解失败 | fallback + 错误日志 |
| Stream 不同步 | 计算错误 | 统一 stream |
| 内存泄漏 | 长跑崩溃 | pdhcg_spmv_ctx_destroy 处理 |
| 编译失败 | 无法构建 | 编译选项默认 OFF |

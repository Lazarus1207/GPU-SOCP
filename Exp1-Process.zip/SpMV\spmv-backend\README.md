# SpMV Backend v2 — 纯后端二进制包

本包只提供 SpMV 静态库、公开头文件、调用示例和 CMake 集成文件。
不包含内核源码、LP/QP/SOCP 求解器源码、基准测试数据或 Git 历史。
公开头文件不包含内部编码枚举、行分桶常量或统计结构；库也不提供内部统计查询函数。
闭源交付不等于防逆向：二进制仍可被分析；本包未附加或变更任何授权条款。

## 平台与依赖

- Linux x86_64，NVIDIA GPU；不是 macOS/Windows 二进制。
- 本包用 CUDA 12.4.99、Release 优化构建；使用方需 CUDA Toolkit 12.4 或兼容的更新版本、兼容驱动及 C++ 运行库。
- 内置 sm_80、sm_86、sm_89、sm_90 的 GPU 机器码，并包含 compute_90 PTX；其他 GPU 不承诺可用。
- 实际 GPU 验证环境和结果见 BUILD_INFO.md；没有验证所有架构。
- 示例只需 C++17 编译器、CUDA Runtime 和 CMake >= 3.24，不需要内核源码或重新编译库。

## 目录

```text
include/spmv.h            公开 C ABI 和逐项调用注释
lib/libspmv.a             预编译静态库
lib/cmake/spmv/           可重定位 CMake 导入目标 spmv::spmv
examples/basic.cpp       Ax、alpha/beta、累加、独立转置 plan 示例
CMakeLists.txt           仅构建示例，不构建后端
BUILD_INFO.md            构建与验证信息
SHA256SUMS               文件校验清单（不包含清单自身）
```

## 快速运行

在包的根目录执行；按安装位置调整 CUDAToolkit_ROOT：

```sh
cmake -S . -B build -DCUDAToolkit_ROOT=/usr/local/cuda-12.4
cmake --build build -j
CUDA_VISIBLE_DEVICES=0 ctest --test-dir build --output-on-failure
```

示例输出四项 PASS：Ax、alpha/beta、accumulate、transpose via separate CSR。
使用其他 GPU 时修改 CUDA_VISIBLE_DEVICES；示例内部使用可见设备中的第 0 张。

## 集成到现有 CMake 工程

```cmake
project(my_solver LANGUAGES CXX)
find_package(spmv CONFIG REQUIRED)
target_link_libraries(my_solver PRIVATE spmv::spmv)
```

在配置时指定 `-Dspmv_DIR=/absolute/path/to/package/lib/cmake/spmv` 和 CUDA Toolkit 路径。
这里的 my_solver 应是你的已有 target。C++ 调用方不需要启用 CUDA 语言；自行编写 .cu 文件时才需要。
库有 C ABI，可供其他语言通过自己编写的 FFI 包装调用；本包未提供 Python/Julia 包装。

## 生命周期和运算约定

1. 在目标 GPU 上准备完整的零基 int32 CSR：row_offsets 长度 m+1，columns/values 长度 nnz。
2. 用 spmv_plan_create 检查 CSR 并建立 plan；该函数返回时 setup 已完成。
3. 调用 spmv_workspace_size，按需 cudaMalloc workspace。0 字节时可传空指针。
4. 迭代中反复 spmv_execute：`y = alpha*A*x + beta*y`。alpha/beta 为主机按值标量。
5. 等待 stream 完成后销毁 plan，再释放 workspace 和原始 CSR。

重要限制：

- plan **借用原始 CSR 指针**，不是完全独立的矩阵副本。创建后不得释放或修改这些数组。
- 数值编码依赖 setup 时的矩阵值；矩阵值或结构变化时必须重建 plan。
- x/y 必须是同一目标 GPU 上不重叠的 double 数组，长度分别至少为 n/m。
- beta 不为零时先初始化 y；beta 为零时不要求旧 y 值有效。
- execute 异步入队，不在每次调用中分配内存或显式同步 stream；返回成功不代表异步工作已经完成。
- 同一 stream 中可直接衔接后续计算；跨 stream 使用事件等方式显式建立依赖。
- 同一 plan 不允许并发使用；不同并发任务分别创建 plan 和 workspace，并隔离输出。
- 对称矩阵也按普通 CSR 处理；仅存上/下三角不会自动补齐另一半。
- 无原生 transpose、SpMM、多 GPU 分布式、复数、FP32 输入或 int64 索引接口。
- spmv_plan_create_trusted 跳过完整 CSR 验证，只能对已保证合法的数据使用。
- GPU 浮点结果不保证与其他后端逐位一致；集成后检查残差和停止条件。

## QP / SOCP 怎么接

- Ax：为 A 建 plan。
- A^T y：外部构造 A^T 的完整 CSR，再建立独立 plan；示例演示此流程。
- Qx：为完整 Q 的 CSR 建 plan；对角 Q 通常直接逐元素乘更合适。
- Qx+c：先用自己的向量操作将 c 写入输出，再 alpha=1、beta=1 调用 Q 的 plan。
- b-Ax：先把 b 写入输出，再 alpha=-1、beta=1 调用 A 的 plan。

本包仅替换矩阵–向量乘；投影、预条件、点积、向量更新、矩阵转置构造等由上层完成。
不能直接替换 cuSPARSE 的库文件或替代稀疏矩阵分解。

## 校验

```sh
sha256sum -c SHA256SUMS
```

校验应在安装后、修改头文件/示例前执行。新增 build 目录不会影响清单校验。

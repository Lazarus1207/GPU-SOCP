# PDHCG + New SpMV Backend Integration Plan

## 1. 概述

### 目标
将新 SpMV 算子集成到 PDHCG 求解器，并提供可开关的对比接口。

### SpMV Backend 关键信息
- **库文件**: `lib/libspmv.a` (Linux x86_64 静态库)
- **头文件**: `include/spmv.h`
- **CMake**: `lib/cmake/spmv/spmvConfig.cmake`
- **ABI**: C 接口，可被 C++ 调用
- **GPU 要求**: sm_80 (A100), sm_86 (A40), sm_89 (RTX 4090), sm_90 (H100)
- **CUDA**: 12.4+
- **接口**: `spmv_plan_create/destroy/execute/workspace_size`

### 厂商验证数据
- 相对 SpMVOp ALG2 几何平均加速 1.249822x（30胜1平1负）
- SuiteSparse32 性能测试：32/32 通过 FP64 误差 ≤ 1e-12
- 注意：未与 PDHCG 内部实现验证

---

## 2. 集成架构

### 2.1 现有 PDHCG SpMV 调用点

在 `pdhg_core_op.cu` 中，主要的 SpMV 调用点：

```c
// 调用点 1: PDHG dual update (line ~1203)
pdhcg_spmv_execute(state->sparse_handle,
                   state->spmv_ctx_At,  // A^T × y
                   &HOST_ONE, &HOST_ZERO,
                   state->current_dual_solution,
                   state->dual_product);

// 调用点 2: PDHG primal update (line ~1265)
pdhcg_spmv_execute(state->sparse_handle,
                   state->spmv_ctx_A,   // A × x
                   &HOST_ONE, &HOST_ZERO,
                   state->reflected_primal_solution,
                   state->primal_product);

// 调用点 3: Compute residual (line ~1517)
pdhcg_spmv_execute(state->sparse_handle,
                   state->spmv_ctx_A,
                   &HOST_ONE, &HOST_ZERO,
                   state->pdhg_primal_solution,
                   state->primal_product);

// 调用点 4: Compute fixed_point_error (line ~1458)
pdhcg_spmv_execute(state->sparse_handle,
                   state->spmv_ctx_At,
                   &HOST_ONE, &HOST_ZERO,
                   state->delta_dual_solution,
                   state->dual_product);
```

调用次数: 每迭代 **2 次**（A× + Aᵀ×），每 200 次迭代额外 **2-4 次**（residual）

### 2.2 设计方案

#### 方案 A: 直接替换 spmv_backend.cu（推荐）

**优点**: 最小侵入式、保留原有 API、便于切换

**实现**: 将 `pdhcg_spmv_execute` 替换为 new SpMV 后端调用，同时保留 cuSPARSE fallback

#### 方案 B: 添加新 backend 作为独立模块

**优点**: 完全解耦、独立测试

**缺点**: 需要修改 solver_state 增加新字段

### 2.3 推荐：方案 A 的详细设计

```
PDHCG 主代码
    ↓
spmv_backend.h (统一接口)
    ↓
选择 backend:
    ├── pdhcg_spmv_cusparse.cu  (原始实现)
    └── pdhcg_spmv_new.cu       (new SpMV wrapper)
```

---

## 3. 代码修改设计

### 3.1 新文件结构

```
PDHCG-exp/
├── src/
│   ├── spmv_backend.cu           (原文件，保留)
│   ├── spmv_backend_new.cu       (新文件：new SpMV wrapper)
│   └── ...
├── internal/
│   ├── spmv_backend.h            (原文件，接口保持)
│   ├── spmv_backend_new.h        (新文件：new SpMV ctx)
│   └── ...
└── CMakeLists.txt                (添加 new backend 编译选项)
```

### 3.2 头文件修改: `internal/spmv_backend.h`

**关键决策**: 不改变现有 `pdhcg_spmv_ctx_t` 结构，而是在其中增加一个新字段指向 new SpMV plan：

```c
// 增加 forward declaration
struct spmv_plan;

typedef struct {
    // 原 cuSPARSE 字段
    cusparseSpMatDescr_t mat;
    cusparseDnVecDescr_t vec_x;
    cusparseDnVecDescr_t vec_y;
    void *buffer;
    void *descr;
    void *plan;
    int num_rows;
    int num_nonzeros;

    // 新增：新 SpMV 后端句柄
    struct spmv_plan *new_spmv_plan;  // NULL = 使用 cuSPARSE
    void *new_spmv_workspace;         // workspace 内存
    size_t new_spmv_workspace_bytes;  // workspace 大小
} pdhcg_spmv_ctx_t;

// 新增：backend 选择 API
extern "C" {
    void pdhcg_set_spmv_backend(int backend);  // 0=cuSPARSE, 1=new
    int  pdhcg_get_spmv_backend(void);
}
```

### 3.3 新实现文件: `src/spmv_backend_new.cu`

```cpp
/*
Copyright 2026 Exp1-Process

Integration of new SpMV backend (libspmv.a) into PDHCG.

This wrapper is gated by -DPDHCG_USE_NEW_SPMV compile flag.
When disabled, the original cusparse path is used.
*/

#ifdef PDHCG_USE_NEW_SPMV

#include "spmv_backend.h"
#include "spmv.h"  // New SpMV public API
#include "utils.h"

#include <cuda_runtime.h>

//---------------------------------------------------------------------------
// Static configuration
//---------------------------------------------------------------------------
static int g_spmv_backend = 0;  // 0 = cuSPARSE (default), 1 = new SpMV

extern "C" void pdhcg_set_spmv_backend(int backend) {
    if (backend == 0 || backend == 1) {
        g_spmv_backend = backend;
    }
}

extern "C" int pdhcg_get_spmv_backend(void) {
    return g_spmv_backend;
}

//---------------------------------------------------------------------------
// Context creation
//---------------------------------------------------------------------------
// 在原 pdhcg_spmv_ctx_create 中增加 new plan 创建分支
// 这里仅作说明，实际应修改 spmv_backend.cu

extern "C" pdhcg_spmv_ctx_t *pdhcg_spmv_ctx_create_v2(...) {
    pdhcg_spmv_ctx_t *ctx = ...; // 原有逻辑

    if (g_spmv_backend == 1 && num_nonzeros > 0) {
        // 创建 new SpMV plan
        // 注意：1-based API → 0-based 转换
        cudaStream_t stream = 0;  // 或从 handle 获取
        cudaError_t err = spmv_plan_create(
            (spmv_plan**)&ctx->new_spmv_plan,
            num_rows, num_cols, num_nonzeros,
            row_ptr, col_ind, val, stream
        );
        if (err != cudaSuccess) {
            // fallback to cuSPARSE
            ctx->new_spmv_plan = nullptr;
        } else {
            spmv_workspace_size(ctx->new_spmv_plan, &ctx->new_spmv_workspace_bytes);
            if (ctx->new_spmv_workspace_bytes > 0) {
                cudaMalloc(&ctx->new_spmv_workspace, ctx->new_spmv_workspace_bytes);
            }
        }
    }

    return ctx;
}

//---------------------------------------------------------------------------
// Execution
//---------------------------------------------------------------------------
// 在原 pdhcg_spmv_execute 中增加 new plan 调用分支

extern "C" void pdhcg_spmv_execute_v2(...) {
    if (ctx->new_spmv_plan != nullptr && g_spmv_backend == 1) {
        double alpha_h = (alpha != nullptr) ? *alpha : 1.0;
        double beta_h = (beta != nullptr) ? *beta : 0.0;

        cudaStream_t stream = 0;  // 或从 handle 获取
        cudaError_t err = spmv_execute(
            (spmv_plan*)ctx->new_spmv_plan,
            x, y,
            alpha_h, beta_h,
            ctx->new_spmv_workspace, ctx->new_spmv_workspace_bytes,
            stream
        );
        if (err == cudaSuccess) return;  // 成功则返回

        // 否则 fallthrough 到 cuSPARSE
    }

    // 原 cuSPARSE 实现（fallback）
    cusparseSpMV(...);
}

//---------------------------------------------------------------------------
// Context destruction
//---------------------------------------------------------------------------
extern "C" void pdhcg_spmv_ctx_destroy_v2(pdhcg_spmv_ctx_t *ctx) {
    if (ctx->new_spmv_plan) {
        spmv_plan_destroy((spmv_plan*)ctx->new_spmv_plan);
        cudaFree(ctx->new_spmv_workspace);
        ctx->new_spmv_plan = nullptr;
        ctx->new_spmv_workspace = nullptr;
    }
    // 原 destroy 逻辑
}
#endif  // PDHCG_USE_NEW_SPMV
```

### 3.4 修改原实现: `src/spmv_backend.cu`

**最小侵入**: 仅在关键函数中增加 fallback 分支。

```c
#include "spmv_backend.h"
#include <cuda_runtime.h>

extern "C" int pdhcg_spmv_backend_selected(void) {
#ifdef PDHCG_USE_NEW_SPMV
    return pdhcg_get_spmv_backend();  // 来自 spmv_backend_new.cu
#else
    return 0;  // 强制使用 cuSPARSE
#endif
}

extern "C" pdhcg_spmv_ctx_t *pdhcg_spmv_ctx_create(...) {
    pdhcg_spmv_ctx_t *ctx = (pdhcg_spmv_ctx_t *)safe_calloc(1, sizeof(pdhcg_spmv_ctx_t));
    // ... 原逻辑 ...

#ifdef PDHCG_USE_NEW_SPMV
    // 如果选择了 new backend，跳过 cuSPARSE plan 创建
    if (pdhcg_spmv_backend_selected() == 1 && num_nonzeros > 0) {
        // new SpMV plan creation
        extern cudaError_t pdhcg_new_spmv_create_ctx(...);
        if (pdhcg_new_spmv_create_ctx(ctx, num_rows, num_cols, num_nonzeros,
                                       row_ptr, col_ind, val) == cudaSuccess) {
            return ctx;  // 跳过 cuSPARSE
        }
        // 创建失败则 fallthrough 到 cuSPARSE
    }
#endif

    // 原 cuSPARSE plan 创建逻辑
    cusparseCreateCsr(...);
    // ...
    return ctx;
}
```

### 3.5 CMakeLists.txt 修改

```cmake
# 在 CMakeLists.txt 中添加选项和依赖

# New SpMV option
option(PDHCG_USE_NEW_SPMV "Use new SpMV backend (libspmv.a)" OFF)

# New SpMV backend path
set(SPMV_BACKEND_ROOT "" CACHE PATH "Path to spmv-backend package")

# Find new SpMV library if enabled
if(PDHCG_USE_NEW_SPMV AND SPMV_BACKEND_ROOT)
    message(STATUS "Using new SpMV backend from: ${SPMV_BACKEND_ROOT}")

    list(APPEND CMAKE_PREFIX_PATH "${SPMV_BACKEND_ROOT}/lib/cmake")

    find_package(spmv CONFIG REQUIRED)
    message(STATUS "Found spmv::spmv from new SpMV backend")
endif()

# Add the source file
set(PDHCG_SOURCES
    src/spmv_backend.cu
    src/spmv_backend_new.cu  # 新增
    ...
)

# Link libraries
if(PDHCG_USE_NEW_SPMV AND TARGET spmv::spmv)
    target_compile_definitions(pdhcg PRIVATE PDHCG_USE_NEW_SPMV)
    target_link_libraries(pdhcg PRIVATE spmv::spmv)
endif()
```

---

## 4. 关键风险与处理

### 4.1 Stream 同步问题

**风险**: PDHCG 使用 cuSPARSE handle，其 stream 可能与 default stream 不同。

**缓解**:
- new SpMV API 接受 stream 参数 → 传入与 cuSPARSE 相同的 stream
- 或者使用默认 stream（runtime 行为）

### 4.2 Workspace 分配

**风险**: new SpMV 需要 cudaMalloc 工作区，可能引入首次调用延迟。

**缓解**:
- 在 ctx_create 时预分配 workspace
- 在迭代前 warmup 一次以隐藏分配时间

### 4.3 Float 精度差异

**风险**: 厂商文档明示「GPU 浮点结果不保证与其他后端逐位一致」

**缓解**:
- 修改前后跑相同样本，比较 residual
- 接受小范围（1e-8）残差差异
- 如果差异太大，启用 fallback

### 4.4 与现有 kernel 的冲突

**风险**: PDHCG 内部使用 `vec_x/vec_y` 设置，可能与 SpMV API 冲突

**缓解**:
- new SpMV API 接受原始 double 指针，不使用 cusparseDnVec 包装
- 我们继续以原指针传入 → 调用 new SpMV → 不依赖 cusparseDnVec

### 4.5 内存所有权

**风险**: new SpMV plan 借用 CSR 指针，CSR 必须保持有效。

**现状**: PDHCG 已经在 csr 生命周期内使用 ctx，匹配良好。

---

## 5. 测试与验证流程

### 5.1 单元测试

```bash
# 1. 编译 baseline
mkdir build_baseline && cd build_baseline
cmake -DPDHCG_USE_NEW_SPMV=OFF ..
make -j

# 2. 编译 new SpMV
mkdir build_new && cd build_new
cmake \
    -DPDHCG_USE_NEW_SPMV=ON \
    -DSPMV_BACKEND_ROOT=/path/to/spmv-backend ..
make -j

# 3. 运行小问题验证
./build_baseline/pdhcg --input /path/to/beam7.cbf.gz
./build_new/pdhcg --input /path/to/beam7.cbf.gz

# 4. 比较：结果应一致（object value、gap）
```

### 5.2 性能 benchmark

```bash
# 在多个问题上对比
for problem in beam7 beam30 chainsing-50000-1 firL2a; do
    ./build_baseline/pdhcg --input ${problem}.cbf.gz | grep Runtime
    ./build_new/pdhcg --input ${problem}.cbf.gz --spmv_backend=new | grep Runtime
done
```

### 5.3 极端情况

测试 new SpMV 在非常稀疏（如 chainsing 0.9M nnz）情况下的表现，对比非常稠密（如 firL2Linfalph 122M nnz）情况。

---

## 6. 实施步骤

### 步骤 1: 备份和准备（Day 1）
- ✅ 拷贝 PDHCG 到 `PDHCG-exp/`
- ✅ 阅读 new SpMV API
- ✅ 阅读原 backend 实现

### 步骤 2: 代码修改（Day 1-2）
- [ ] 添加 `spmv_backend_new.cu`
- [ ] 修改 `spmv_backend.h` 增加新字段
- [ ] 修改 `spmv_backend.cu` 增加 fallback 分支
- [ ] 修改 `CMakeLists.txt`

### 步骤 3: 编译测试（Day 2）
- [ ] 编译 baseline 通过
- [ ] 编译 new 版本通过
- [ ] 运行单题验证

### 步骤 4: 性能对比（Day 2-3）
- [ ] 全量跑 baseline
- [ ] 全量跑 new SpMV
- [ ] 生成对比报告

### 步骤 5: 决策（Day 3）
- [ ] 分析结果，决定是否保留 new SpMV
- [ ] 消融研究：哪类问题收益最大
- [ ] 形成最终推荐

---

## 7. 预期成果

### 7.1 成功指标

| 指标 | 期望 | 阈值 |
|------|------|------|
| 数值一致性 | < 1e-6 残差 | < 1e-4 |
| SpMV 加速 | ≥ 1.20x | > 1.10x |
| 整体加速 | ≥ 1.05x | > 1.02x |
| 编译成功 | 通过 | 必须 |
| 内存增加 | < 10MB | < 100MB |

### 7.2 失败回退

如果 new SpMV 集成后无显著加速（< 5%），建议：
- 回退到 cuSPARSE SpMVOp（当前默认）
- 仅在特定问题子集启用
- 等待更优版本

---

## 8. 附录

### 8.1 new SpMV 接口 API

```c
// 创建 plan
cudaError_t spmv_plan_create(spmv_plan** plan,
                            int32_t rows, int32_t columns, int32_t nnz,
                            const int32_t* d_row_offsets,
                            const int32_t* d_column_indices,
                            const double* d_values,
                            cudaStream_t stream);

// 创建受信任版（跳过校验）
cudaError_t spmv_plan_create_trusted(...);

// 执行 y = α*A*x + β*y
cudaError_t spmv_execute(const spmv_plan* plan,
                        const double* d_x, double* d_y,
                        double alpha, double beta,
                        void* workspace, size_t workspace_bytes,
                        cudaStream_t stream);

// 获取 workspace 大小
cudaError_t spmv_workspace_size(const spmv_plan* plan, size_t* bytes);

// 销毁
cudaError_t spmv_plan_destroy(spmv_plan* plan);
```

### 8.2 PDHCG 当前 spmv 调用格式

```c
// 当前 PDHCG 调用格式
pdhcg_spmv_execute(state->sparse_handle,           // cuSPARSE handle
                   state->spmv_ctx_A,              // 自定义 ctx
                   &HOST_ONE, &HOST_ZERO,          // α, β
                   state->reflected_primal_solution, // x
                   state->primal_product);         // y
```

注意：α/β 是 `const double*` 而非 `double`，需要 dereference 再传入 new API。

### 8.3 与现有 kernel 的隔离性

new SpMV 操作不修改任何 PDHCG kernel，它只改变 `spmv_execute` 这一项的 backend。cone projection、halpern update 等都不受影响。

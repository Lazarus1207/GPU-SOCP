# 构建与验证记录

- 打包日期：2026-09-07。
- 来源：用户指定的 SpMV pure backend_v2；没有修改计算内核。
- 原始 spmv.cu SHA-256：`a0d733f13d0094d4daf1234d2d6113a447a5ab22dd5d1704ff1ebab654c4141f`。
- 原始 spmv.h SHA-256：`4f671266800dbd1419a6f4e73576229531f616d4df6b562a051ff9236d118f04`。
- 交付头文件移除了内部枚举、分桶信息、统计结构和统计查询函数；保留的调用函数签名不变。
- 私有构建使用 SPMV_CLOSED_ABI 排除统计查询函数实现，计算内核不变。
- 二进制 libspmv.a SHA-256：`ee67c97152ced1a6e69a0463308fe2a76bff016b84f9bb79befcdda74b006760`。

## 编译环境

- Linux x86_64；GNU g++ 9.4.0；glibc 2.31。
- CUDA Toolkit 12.4.99；CMake 3.30.9（示例验证）。
- nvcc：`-lib -O3 -std=c++17 -Xcompiler=-fPIC`。
- GPU 目标：sm_80、sm_86、sm_89、sm_90；附带 compute_90 PTX。
- 未启用 fast-math、调试编译或行号信息；使用 strip --strip-debug 清理调试信息。
- cuobjdump 已确认上述四种 GPU 机器码和一份 PTX 存在。
- 最终库对外的 spmv_ C 函数只有 create、create_trusted、destroy、execute、workspace_size 和 plan_bytes 对应的六个接口；不含 spmv_plan_get_info。
- 静态库由消费者链接 CUDA Runtime 和 C++ 标准库；本包不捆绑 CUDA Runtime。

## 实际验证范围

GPU：NVIDIA A100-PCIE-40GB；驱动：550.54.15。

1. 从公开头文件 + libspmv.a 独立配置、编译 C++ 示例，无需内核源码。
2. CTest：1/1 测试通过；Ax、非平凡 alpha/beta、累加、独立转置 CSR 四项结果通过。
3. 额外内部 smoke 测试：空行、短行和长行；最大行长度分别为 1024、2048、15000、60000。
4. 每个 smoke 算例重复执行 20 次，并与 CPU 参考结果比较；另检查 alpha=0、beta=0。
5. smoke 使用 FP64 输入，包含全一、正负一和一般数值；测试非默认 stream。
6. 初版 CUDA Compute Sanitizer memcheck：公开示例与内部 smoke 均报告 0 errors。
7. 移除统计查询接口后的最终库重新通过公开示例，并完成 SuiteSparse32 性能和 long-double CPU 参考检查：32/32 通过输入幅值归一化误差 <= 1e-12 的检查，最大值 5.180206203502e-16。
8. 最终库相对 SpMVOp ALG2 几何平均加速 1.249822x；30 胜、1 平、1 负。该轮 setup 总计 4982.505 ms，对照 53.720 ms，明显偏高，不应据此宣称 setup 优势。

这是接口、正确性和打包验证，不是完整性能复测，也不代表其他 GPU 架构已实际验证。
不承诺跨设备、跨编译器或与其他求解器逐位相同；并发调用和完整 QP/SOCP 集成尚未验证。

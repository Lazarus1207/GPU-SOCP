/*
Copyright 2026 Exp1-Process

Integration wrapper for new SpMV backend (libspmv.a).
Standalone file - dropped into src/ and compiled as part of PDHCG.
Only active when PDHCG_USE_NEW_SPMV is defined.
*/

#ifdef PDHCG_USE_NEW_SPMV

#include "spmv_backend.h"
#include "spmv.h"
#include "utils.h"

#include <cuda_runtime.h>
#include <stdio.h>
#include <stdlib.h>

//---------------------------------------------------------------------------
// Helper: get current CUDA stream from cusparse handle
//---------------------------------------------------------------------------
static cudaStream_t pdhcg_get_current_stream(cusparseHandle_t handle)
{
    cudaStream_t stream = 0;
    if (handle != nullptr)
    {
        cusparseGetStream(handle, &stream);
    }
    return stream;
}

//---------------------------------------------------------------------------
// Context creation for new backend
//---------------------------------------------------------------------------
extern "C" cudaError_t pdhcg_new_spmv_ctx_create(pdhcg_spmv_ctx_t *ctx,
                                                 int num_rows,
                                                 int num_cols,
                                                 int num_nonzeros,
                                                 int *row_ptr,
                                                 int *col_ind,
                                                 double *val,
                                                 cusparseHandle_t sparse_handle)
{
    if (ctx == nullptr || num_nonzeros == 0)
        return cudaErrorInvalidValue;

    ctx->new_spmv_plan = nullptr;
    ctx->new_spmv_workspace = nullptr;
    ctx->new_spmv_workspace_bytes = 0;

    cudaStream_t stream = pdhcg_get_current_stream(sparse_handle);

    cudaError_t err = spmv_plan_create(
        (spmv_plan **)&ctx->new_spmv_plan,
        num_rows, num_cols, num_nonzeros,
        row_ptr, col_ind, val, stream);

    if (err != cudaSuccess)
    {
        fprintf(stderr, "[new_spmv] spmv_plan_create failed: %s\n", cudaGetErrorString(err));
        ctx->new_spmv_plan = nullptr;
        return err;
    }

    err = spmv_workspace_size((spmv_plan *)ctx->new_spmv_plan,
                              &ctx->new_spmv_workspace_bytes);
    if (err != cudaSuccess)
    {
        spmv_plan_destroy((spmv_plan *)ctx->new_spmv_plan);
        ctx->new_spmv_plan = nullptr;
        return err;
    }

    if (ctx->new_spmv_workspace_bytes > 0)
    {
        err = cudaMalloc(&ctx->new_spmv_workspace, ctx->new_spmv_workspace_bytes);
        if (err != cudaSuccess)
        {
            spmv_plan_destroy((spmv_plan *)ctx->new_spmv_plan);
            ctx->new_spmv_plan = nullptr;
            return err;
        }
    }

    if (getenv("PDHCG_NEW_SPMV_DEBUG"))
    {
        fprintf(stderr, "[new_spmv] Created plan: %d x %d, nnz=%d, workspace=%zu bytes\n",
                num_rows, num_cols, num_nonzeros, ctx->new_spmv_workspace_bytes);
    }

    return cudaSuccess;
}

//---------------------------------------------------------------------------
// Execute y = alpha*A*x + beta*y using new backend
//---------------------------------------------------------------------------
extern "C" cudaError_t pdhcg_new_spmv_execute(pdhcg_spmv_ctx_t *ctx,
                                              cusparseHandle_t sparse_handle,
                                              const double *alpha,
                                              const double *beta,
                                              const double *x,
                                              double *y)
{
    if (ctx == nullptr || ctx->new_spmv_plan == nullptr)
        return cudaErrorInvalidValue;

    double alpha_h = (alpha != nullptr) ? *alpha : 1.0;
    double beta_h = (beta != nullptr) ? *beta : 0.0;

    cudaStream_t stream = pdhcg_get_current_stream(sparse_handle);

    return spmv_execute(
        (spmv_plan *)ctx->new_spmv_plan,
        x, y,
        alpha_h, beta_h,
        ctx->new_spmv_workspace, ctx->new_spmv_workspace_bytes,
        stream);
}

//---------------------------------------------------------------------------
// Destroy new backend context
//---------------------------------------------------------------------------
extern "C" void pdhcg_new_spmv_ctx_destroy(pdhcg_spmv_ctx_t *ctx)
{
    if (ctx == nullptr) return;

    if (ctx->new_spmv_plan != nullptr)
    {
        spmv_plan_destroy((spmv_plan *)ctx->new_spmv_plan);
        ctx->new_spmv_plan = nullptr;
    }

    if (ctx->new_spmv_workspace != nullptr)
    {
        cudaFree(ctx->new_spmv_workspace);
        ctx->new_spmv_workspace = nullptr;
    }
    ctx->new_spmv_workspace_bytes = 0;
}

#endif  // PDHCG_USE_NEW_SPMV

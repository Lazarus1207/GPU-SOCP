# PDHCG Process-level Tuning — Exp1

## 概述

本目录提供 PDHCG Process-level 性能调优的两项能力：

1. **分环节 Timing**：使用 CUDA Event 对求解器各计算环节计时
2. **New SpMV 集成**：将第三方 SpMV 算子以可开关方式集成

提供 **两种集成方式**：

- **Patch 方式（推荐）**：不修改原文件，用 sed 注入 + 独立新增文件
- **完整替换方式**：直接使用 Exp1-Process/PDHCG-exp 目录

---

## 文件清单

```
Exp1-Process/
├── instruction.txt
├── README.md
├── USAGE.md (本文件)
├── patches/                          # 【推荐】非侵入式 patch 方式
│   ├── apply_all_patches.sh          # 一键应用所有 patch
│   ├── restore_original.sh           # 回滚
│   ├── timing_profiler.h             # 新增的 timing 头文件
│   ├── spmv_backend_new.cu          # 新增的 SpMV wrapper
│   ├── apply_spmv_backend_patch.sh
│   ├── apply_cli_patch.sh
│   ├── apply_timing_patch.sh
│   └── README.md                     # patch 详细文档
├── PDHCG-exp/                        # 【完整替换方式】完整修改过的代码
│   └── ...
├── SpMV/spmv-backend/                # 第三方 SpMV 库
├── scripts/                          # 分析脚本
├── docs/                             # 详细文档
└── experiments/                      # 实验记录
```

---

## 方式 A：Patch 方式（推荐）

**适用场景**：服务器上已有完整 PDHCG 源码，不想覆盖。

### 1. 准备

```bash
# 把 Exp1-Process 整个目录复制到服务器
# 假设路径: ~/testHM/Exp1-Process/
ls ~/testHM/Exp1-Process/patches/
# apply_all_patches.sh
# timing_profiler.h
# spmv_backend_new.cu
# ...
```

### 2. 一键应用 patch

```bash
# 进入 PDHCG 源码根目录（不是 Exp1-Process）
cd ~/PDHCG

# 一键应用所有 patch
bash ~/testHM/Exp1-Process/patches/apply_all_patches.sh

# 效果：
# - 备份原文件（*.bak）
# - 修改 internal/spmv_backend.h
# - 修改 src/spmv_backend.cu
# - 修改 src/cli.c
# - 修改 src/pdhg_core_op.cu
# - 修改 src/solver.cu
# - 新增 internal/timing_profiler.h
# - 新增 src/spmv_backend_new.cu
```

### 3. 编译 Baseline + Timing

```bash
mkdir build_baseline && cd build_baseline
cmake .. \
    -DCMAKE_BUILD_TYPE=Release \
    -DPDHCG_ENABLE_TIMING=ON \
    -DCMAKE_CUDA_ARCHITECTURES="80;86;89;90"
make -j$(nproc) pdhcg
```

### 4. 编译 Baseline + Timing + New SpMV

```bash
cd ~/PDHCG
mkdir build_new_spmv && cd build_new_spmv
cmake .. \
    -DCMAKE_BUILD_TYPE=Release \
    -DPDHCG_ENABLE_TIMING=ON \
    -DPDHCG_USE_NEW_SPMV=ON \
    -DSPMV_BACKEND_ROOT=~/testHM/Exp1-Process/SpMV/spmv-backend \
    -DCMAKE_CUDA_ARCHITECTURES="80;86;89;90"
make -j$(nproc) pdhcg
```

### 5. 运行

```bash
# 单题
./pdhcg ~/testHM/benchmark/socp/beam7.cbf.gz /tmp/out/ --verbose 2

# 切换 SpMV backend
./pdhcg problem.cbf.gz /tmp/out/ --spmv_backend=cusparse
./pdhcg problem.cbf.gz /tmp/out/ --spmv_backend=new
```

### 6. 回滚

```bash
cd ~/PDHCG
bash ~/testHM/Exp1-Process/patches/restore_original.sh
# 所有 *.bak 文件恢复为原文件，新文件被删除
```

---

## 方式 B：完整替换方式

**适用场景**：直接使用修改过的完整 PDHCG 源码。

### 1. 准备

```bash
# 复制 Exp1-Process/PDHCG-exp 替换原 PDHCG
cp -r ~/testHM/Exp1-Process/PDHCG-exp ~/PDHCG
```

### 2. 编译

同方式 A 的步骤 3、4。

---

## 关键开关

### 编译时开关

| 选项 | 默认 | 说明 |
|------|------|------|
| `PDHCG_ENABLE_TIMING` | OFF | 启用分环节 CUDA Event 计时 |
| `PDHCG_USE_NEW_SPMV` | OFF | 启用 new SpMV 后端编译 |
| `SPMV_BACKEND_ROOT` | (空) | new SpMV 包路径 |
| `PDHCG_NEW_SPMV_RUNTIME_DEFAULT` | 0 | 运行时默认 backend (0=cuSPARSE, 1=new) |

### 运行时开关

| 选项 | 说明 |
|------|------|
| `--spmv_backend=cusparse` | 强制使用 cuSPARSE |
| `--spmv_backend=new` | 切换到 new SpMV（需编译时启用） |

### 环境变量

| 变量 | 说明 |
|------|------|
| `PDHCG_NEW_SPMV_DEBUG` | 启用 new SpMV 调试输出 |

---

## 分析脚本

### Timing 结果分析

```bash
cd ~/testHM/Exp1-Process/scripts
python3 analyze_timing.py \
    -i <run_log.txt> \
    -o <report.json> \
    -v
```

### Baseline 对比

```bash
cd ~/testHM/Exp1-Process/scripts
python3 compare_runs.py \
    --baseline <baseline_dir> \
    --candidate <new_dir> \
    --output comparison.json \
    --markdown comparison.md
```

---

## 注意事项

1. **SpMV 库路径**：服务器上 `~/testHM/Exp1-Process/SpMV/spmv-backend/` 必须存在
2. **GPU 兼容性**：new SpMV 仅支持 sm_80/86/89/90，H100 是 sm_90
3. **CUDA 版本**：服务器需 CUDA 12.4+
4. **数值验证**：第一次启用 new SpMV 时务必对比 obj_value、gap、residual
5. **Patch 重复应用**：同一 patch 不能重复应用。如需重试，请先 `restore_original.sh`

---

## 故障排查

| 问题 | 解决 |
|------|------|
| 编译找不到 spmv.h | 检查 SPMV_BACKEND_ROOT 路径 |
| 链接失败 | 确认 libspmv.a 存在且为 sm_90 |
| 运行时链接错误 | 确认运行时 backend 已正确设置 |
| 数值发散 | 减小初始步长或回退到 cuSPARSE |
| patch 应用后无效果 | 检查 `.bak` 文件存在性 |
| sed 命令不工作 | 确认 GNU sed 版本 |

---

## 性能预期

| 项目 | Baseline | 预期 New SpMV |
|------|----------|----------------|
| SpMV (Aᵀ + A) | ~50% | ~40% (-20%) |
| 整体 SGM10 | 31.04 | ~28 (-10%) |
| 编译时间 | 5 min | 5 min |
| 运行时内存 | 基线 | +workspace (~MB级) |

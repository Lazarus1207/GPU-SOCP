#!/bin/bash
#===============================================================================
# Exp1-Process 鈥?鏈嶅姟鍣ㄧ涓€閿儴缃茶剼鏈?
#
# 瀹屾暣娴佺▼锛?
#   1. 妫€鏌ョ幆澧冿紙cuda/cmake/PDHCG 鐩綍锛?
#   2. 澶囦唤 PDHCG 鍘熷浠ｇ爜
#   3. 搴旂敤 patches
#   4. 缂栬瘧 baseline + new_spmv 涓や釜鐗堟湰
#
# 鐢ㄦ硶锛?
#   cd ~/testHM/Exp1-Process/scripts
#   bash deploy_to_server.sh
#
# 鎴栬嚜瀹氫箟璺緞锛?
#   bash deploy_to_server.sh --pdhcg ~/PDHCG --exp1 ~/testHM/Exp1-Process
#===============================================================================

set -e

# 榛樿璺緞
PDHCG_DIR="${HOME}/PDHCG"
EXP1_DIR="${HOME}/testHM/Exp1-Process"
SPMV_DIR="${EXP1_DIR}/SpMV/spmv-backend"

# 瑙ｆ瀽鍙傛暟
while [[ $# -gt 0 ]]; do
    case $1 in
        --pdhcg)
            PDHCG_DIR="$2"
            shift 2
            ;;
        --exp1)
            EXP1_DIR="$2"
            shift 2
            ;;
        --spmv)
            SPMV_DIR="$2"
            shift 2
            ;;
        --help|-h)
            echo "鐢ㄦ硶: $0 [--pdhcg DIR] [--exp1 DIR] [--spmv DIR]"
            echo "榛樿: PDHCG=~/PDHCG, EXP1=~/testHM/Exp1-Process"
            exit 0
            ;;
        *)
            echo "鏈煡鍙傛暟: $1"
            exit 1
            ;;
    esac
done

echo "==============================================="
echo "Exp1-Process 鏈嶅姟鍣ㄩ儴缃茶剼鏈?
echo "==============================================="
echo "PDHCG directory: $PDHCG_DIR"
echo "Exp1 directory: $EXP1_DIR"
echo "SpMV directory: $SPMV_DIR"
echo ""

# 妫€鏌ョ洰褰?
[ ! -d "$PDHCG_DIR" ] && { echo "[ERROR] PDHCG 鐩綍涓嶅瓨鍦? $PDHCG_DIR"; exit 1; }
[ ! -d "$EXP1_DIR" ] && { echo "[ERROR] Exp1 鐩綍涓嶅瓨鍦? $EXP1_DIR"; exit 1; }
[ ! -d "$SPMV_DIR" ] && { echo "[ERROR] SpMV 鐩綍涓嶅瓨鍦? $SPMV_DIR"; exit 1; }

# 妫€鏌ヤ緷璧?
echo "[1/8] 妫€鏌ヤ緷璧?.."
command -v nvcc >/dev/null 2>&1 || { echo "[ERROR] nvcc 鏈畨瑁?; exit 1; }
command -v cmake >/dev/null 2>&1 || { echo "[ERROR] cmake 鏈畨瑁?; exit 1; }
nvcc --version | head -1
cmake --version | head -1
echo ""

# 澶囦唤 PDHCG
echo "[2/8] 澶囦唤 PDHCG 鍘熷浠ｇ爜..."
BACKUP_TAR="~/PDHCG_backup_$(date +%Y%m%d_%H%M%S).tar.gz"
if [ ! -f "$BACKUP_TAR" ]; then
    cd ~
    tar czf "PDHCG_backup_$(date +%Y%m%d_%H%M%S).tar.gz" --exclude='PDHCG/build*' PDHCG/
    echo "  澶囦唤瀹屾垚: PDHCG_backup_*.tar.gz"
fi
echo ""

# 妫€鏌?patch 鑴氭湰
echo "[3/8] 妫€鏌?patch 鑴氭湰..."
[ ! -f "$EXP1_DIR/patches/apply_all_patches.sh" ] && {
    echo "[ERROR] patch 鑴氭湰涓嶅瓨鍦? $EXP1_DIR/patches/apply_all_patches.sh"
    exit 1
}
echo "  patch 鑴氭湰: OK"
echo ""

# 搴旂敤 patch
echo "[4/8] 搴旂敤 patch 鍒?$PDHCG_DIR..."
cd "$PDHCG_DIR"
bash "$EXP1_DIR/patches/apply_all_patches.sh"
echo ""

# 缂栬瘧 baseline
echo "[5/8] 缂栬瘧 baseline (cuSPARSE + Timing)..."
cd "$PDHCG_DIR"
mkdir -p build_baseline
cd build_baseline
cmake .. \
    -DCMAKE_BUILD_TYPE=Release \
    -DPDHCG_ENABLE_TIMING=ON \
    -DCMAKE_CUDA_ARCHITECTURES="80;86;89;90" 2>&1 | tee cmake_baseline.log
make -j$(nproc) pdhcg 2>&1 | tee make_baseline.log
echo "  baseline 缂栬瘧瀹屾垚: $PDHCG_DIR/build_baseline/pdhcg"
echo ""

# 缂栬瘧 new SpMV
echo "[6/8] 缂栬瘧 new_spmv (cuSPARSE + Timing + New SpMV)..."
cd "$PDHCG_DIR"
mkdir -p build_new_spmv
cd build_new_spmv
cmake .. \
    -DCMAKE_BUILD_TYPE=Release \
    -DPDHCG_ENABLE_TIMING=ON \
    -DPDHCG_USE_NEW_SPMV=ON \
    -DSPMV_BACKEND_ROOT="$SPMV_DIR" \
    -DCMAKE_CUDA_ARCHITECTURES="80;86;89;90" 2>&1 | tee cmake_new_spmv.log
make -j$(nproc) pdhcg 2>&1 | tee make_new_spmv.log
echo "  new_spmv 缂栬瘧瀹屾垚: $PDHCG_DIR/build_new_spmv/pdhcg"
echo ""

# 楠岃瘉
echo "[7/8] 楠岃瘉缂栬瘧缁撴灉..."
[ -f "$PDHCG_DIR/build_baseline/pdhcg" ] && echo "  baseline: OK" || echo "  baseline: FAILED"
[ -f "$PDHCG_DIR/build_new_spmv/pdhcg" ] && echo "  new_spmv: OK" || echo "  new_spmv: FAILED"
echo ""

# 杈撳嚭浣跨敤鎻愮ず
echo "[8/8] 閮ㄧ讲瀹屾垚锛?
echo ""
echo "==============================================="
echo "浣跨敤鏂规硶锛?
echo "==============================================="
echo ""
echo "# Baseline 娴嬭瘯锛坈uSPARSE锛?
echo "  $PDHCG_DIR/build_baseline/pdhcg ~/testHM/benchmark/socp/beam7.cbf.gz /tmp/baseline_out/ --verbose 2"
echo ""
echo "# New SpMV 娴嬭瘯"
echo "  $PDHCG_DIR/build_new_spmv/pdhcg ~/testHM/benchmark/socp/beam7.cbf.gz /tmp/new_out/ --verbose 2 --spmv_backend=new"
echo ""
echo "# 鎴栬€呯敤鑴氭湰鎵归噺璺?
echo "  cd $EXP1_DIR/scripts"
echo "  ./run_timing.sh --timing beam7    # baseline"
echo "  ./run_timing.sh --spmv beam7      # new SpMV"
echo ""
echo "==============================================="
echo "鍥炴粴锛堝闇€鎭㈠鍘熷 PDHCG锛夛細"
echo "==============================================="
echo ""
echo "  cd $PDHCG_DIR"
echo "  bash $EXP1_DIR/patches/restore_original.sh"
echo ""
echo "==============================================="

#!/bin/bash
#===============================================================================
# Patch: 灏?PDHCG 鐨?spmv_backend.cu 鏀归€犱负鏀寔 new SpMV 鍚庣锛堝彲閫夛級
#===============================================================================
# 鐢ㄦ硶锛氬湪 PDHCG 婧愮爜鏍圭洰褰曚笅鎵ц
#   bash apply_spmv_backend_patch.sh
#
# 琛屼负锛?
#   - 澶囦唤鍘?spmv_backend.cu 鍜?internal/spmv_backend.h
#   - 澶嶅埗鏂扮殑 spmv_backend_new.cu 浣滀负 wrapper锛岀紪璇戞椂鎸夊畯鐢熸晥
#   - 淇敼 spmv_backend.h 娣诲姞 new SpMV 瀛楁
#
# 鍥炴粴锛歮v src/spmv_backend.cu.bak src/spmv_backend.cu
#       mv internal/spmv_backend.h.bak internal/spmv_backend.h
#===============================================================================

set -e

cd "$(dirname "${BASH_SOURCE[0]}")/../PDHCG-exp" || cd "$(pwd)"

echo "[spmv-patch] 褰撳墠鐩綍: $(pwd)"

SPMV_CU="src/spmv_backend.cu"
SPMV_H="internal/spmv_backend.h"

# ---- 澶囦唤 ----
[ -f "$SPMV_CU.bak" ] || cp "$SPMV_CU" "$SPMV_CU.bak"
[ -f "$SPMV_H.bak" ]  || cp "$SPMV_H"  "$SPMV_H.bak"
echo "[spmv-patch] 宸插浠?$SPMV_CU 鍜?$SPMV_H"

# =============================================================================
# Patch 1: 鏇挎崲 spmv_backend.cu 鈥斺€?鐩存帴鎷疯礉宸插啓濂界殑 wrapper 鏂囦欢
# =============================================================================
# 鏂版枃浠朵负 spmv_backend_new.cu锛屽寘鍚?PDHCG_USE_NEW_SPMV 瀹堟姢鐨勫叏閮ㄩ€昏緫
# 杩欐牱鍋氱殑濂藉锛氬畬鍏ㄤ笉鍔?pdhcg_use_spmvop_by_default 绛夊師鍑芥暟锛?
#                鑰屾槸浠ユ柊鏂囦欢褰㈠紡杩藉姞 #ifdef 鍧楋紝閬垮厤 sed 澶氳鏇挎崲鐨勮剢寮辨€?
WRAPPER_SRC="$(dirname "${BASH_SOURCE[0]}")/spmv_backend_new.cu"
WRAPPER_DST="src/spmv_backend_wrapper.cu"

if [ -f "$WRAPPER_SRC" ]; then
    cp "$WRAPPER_SRC" "$WRAPPER_DST"
    echo "[spmv-patch] 宸插鍒?wrapper: $WRAPPER_DST (PDHCG_USE_NEW_SPMV-guarded)"
else
    echo "[spmv-patch] [WARN] 鎵句笉鍒?$WRAPPER_SRC锛岃烦杩?wrapper 澶嶅埗"
fi

# =============================================================================
# Patch 2: 淇敼 spmv_backend.h 鈥斺€?娣诲姞 new SpMV 瀛楁锛堢粨鏋勪綋鏈熬锛夊拰 API
# =============================================================================
# 鐢?awk 鑰岄潪 sed 澶氳 block锛屾洿鍙潬
TMP_H=$(mktemp)
awk '
    # 鎵惧埌浠?"} pdhcg_spmv_ctx_t;" 缁撳熬鐨勭粨鏋勪綋瀹氫箟锛屽悜鍏跺墠闈竴琛屾彃鍏ユ柊瀛楁
    /\}\s*pdhcg_spmv_ctx_t;/ {
        print "        struct spmv_plan *new_spmv_plan;"
        print "        void *new_spmv_workspace;"
        print "        size_t new_spmv_workspace_bytes;"
    }
    # 鍦?pdhcg_spmv_execute 澹版槑涔嬪墠鎻掑叆鍚庣 API
    /^void pdhcg_spmv_execute/ && !done {
        print "    void pdhcg_set_spmv_backend(int backend);"
        print "    int  pdhcg_get_spmv_backend(void);"
        print ""
        done = 1
    }
    { print }
' "$SPMV_H" > "$TMP_H"

# 涔熼渶瑕佸湪鏂囦欢澶撮儴娣诲姞 forward declaration锛堥伩鍏?spmv_plan 鏈０鏄庨敊璇級
TMP_H2=$(mktemp)
awk '
    BEGIN { added = 0 }
    /^#include "cuda\/cusparse.h"/ && !added {
        print
        print ""
        print "// Forward declaration to avoid pulling in spmv.h here"
        print "struct spmv_plan;"
        added = 1
        next
    }
    { print }
' "$TMP_H" > "$TMP_H2"

mv "$TMP_H2" "$SPMV_H"
rm -f "$TMP_H"
echo "[spmv-patch] 宸蹭慨鏀?$SPMV_H锛堟坊鍔犲瓧娈?+ API + forward decl锛?

echo ""
echo "========================================"
echo "[spmv-patch] SpMV backend patch 瀹屾垚"
echo "========================================"

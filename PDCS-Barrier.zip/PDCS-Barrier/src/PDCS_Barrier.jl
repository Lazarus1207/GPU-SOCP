# PDCS_Barrier.jl
# =============================================================================
# PDCS-Barrier: PDCS with SOC log-barrier proximal correction (GPU version).
#
# This is a thin wrapper around PDCS_GPU that exposes the barrier parameters
# as first-class keyword arguments to rpdhg_gpu_solve.
#
# Barrier configuration (all via keyword arguments to rpdhg_gpu_solve):
#   barrier_enabled   :: Bool = false       # master switch
#   barrier_mu_init   :: Float64 = 1.0      # initial barrier weight
#   barrier_mu_final  :: Float64 = 1e-6     # final barrier weight (floor)
#   barrier_strategy :: Symbol  = :constant # :constant | :exponential | :adaptive
#   barrier_rho      :: Float64 = 0.9       # decay base for :exponential
#
# When barrier_enabled = true, the solver applies one prox-gradient step of
# the SOC log-barrier φ(x) = -log(t² - ||u||²) to each SOC block after
# the standard SOC projection, pushing the iterate away from the cone boundary.
#
# Layout convention (PDCS-GPU):
#   x_slice[k+1] = t  (cone head, LAST component)
#   x_slice[1:k] = u  (k-dim Euclidean part)
#
# Default parameter settings (identical to PDCS original experiments):
#   rel_tol = 1e-4, abs_tol = 1e-6, time_limit = 300.0,
#   use_adaptive_restart = true, use_aggressive = true,
#   use_resolving = true, use_duality_gap_restart = true

module PDCS_Barrier

using Pkg
Pkg.activate(@__DIR__)
Pkg.develop(path = @__DIR__)

using PDCS_GPU

# Re-export all public solve API
export rpdhg_gpu_solve, rpdhg_gpu_solve_input_gpu_data

# Re-export barrier params (so callers can discover them via docstring)
export barrier_enabled, barrier_mu_init, barrier_mu_final, barrier_strategy, barrier_rho

# Module docstring for Julia's help system
"""
    PDCS_Barrier

PDCS with SOC log-barrier proximal correction (GPU version).

## Barrier Configuration

All barrier parameters are keyword arguments to `rpdhg_gpu_solve`:

| Parameter             | Type     | Default | Description                           |
|-----------------------|----------|---------|---------------------------------------|
| `barrier_enabled`    | Bool     | false   | Master switch for barrier method      |
| `barrier_mu_init`    | Float64  | 1.0     | Initial barrier weight μ               |
| `barrier_mu_final`   | Float64  | 1e-6    | Final barrier weight floor             |
| `barrier_strategy`   | Symbol   | :constant | Scheduling: :constant/:exponential/:adaptive |
| `barrier_rho`        | Float64  | 0.9     | Decay base for :exponential schedule  |

## Algorithm

When `barrier_enabled = true`, after each standard SOC projection the solver
applies one prox-gradient step of:

    φ(x) = -log(t² - ||u||²)

triggered when `||u||²/t² > 0.90`. This pushes the iterate into the interior
of the SOC, mitigating tangential compression.

## Example

```julia
using PDCS_Barrier

result = rpdhg_gpu_solve(
    n = n, m = m, nb = nb, c = c, G = G, h = h,
    mGzero = mGzero, mGnonnegative = mGnonnegative,
    socG = socG, rsocG = rsocG, expG = expG, dual_expG = dual_expG,
    bl = bl, bu = bu, soc_x = soc_x, rsoc_x = rsoc_x,
    # --- barrier enabled ---
    barrier_enabled = true,
    barrier_mu_init = 1.0,
    barrier_strategy = :constant,
    rel_tol = 1e-4,
    time_limit = 300.0,
)
```
"""
PDCS_Barrier

end  # module PDCS_Barrier

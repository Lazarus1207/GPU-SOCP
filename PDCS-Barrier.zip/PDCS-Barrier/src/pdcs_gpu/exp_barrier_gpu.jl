# exp_barrier_gpu.jl
# =============================================================================
# PDCS-Barrier: GPU version of the SOC log-barrier proximal correction.
#
# Algorithm (identical in spirit to the CPU version in exp_barrier.jl):
#   On top of the existing SOC projection, apply one proximal-gradient step of
#   the SOC log-barrier φ(x) = -log(t² - ||u||²) to push the iterate away
#   from the cone boundary.
#
# Layout convention (PDCS-GPU, matching primalVector.primal_sol):
#   x_slice[k+1] = t      (cone head, LAST component)
#   x_slice[1:k] = u      (k-dim Euclidean part)
#
# This differs from the CPU layout (where t is FIRST component).
#
# Config (passed via PDHGCLPParameters):
#   barrier_enabled    :: Bool   (master switch, default false)
#   barrier_mu_init   :: rpdhg_float  (default 1.0)
#   barrier_mu_final  :: rpdhg_float  (default 1e-6)
#   barrier_strategy  :: Symbol (:constant | :exponential | :adaptive)
#   barrier_rho       :: rpdhg_float  (decay base, default 0.9)

module ExpBarrierGPU

using CUDA

export apply_barrier_gpu!

# -----------------------------------------------------------------------------
# Barrier state for :adaptive strategy
# -----------------------------------------------------------------------------
mutable struct BarrierAdaptiveState
    mu_current::Float64
    stagnation_count::Int
    BarrierAdaptiveState(mu_init::Float64) = new(mu_init, 0)
end

const _barrier_state = BarrierAdaptiveState(1.0)

# -----------------------------------------------------------------------------
# Mu schedule
# -----------------------------------------------------------------------------
function update_barrier_mu(
    strategy::Symbol,
    k::Int,
    mu_init::Float64,
    mu_final::Float64,
    rho::Float64;
    boundary_ratio::Float64 = 0.0,
    gap::Float64 = 1e100,
)
    if strategy === :constant
        return mu_init
    elseif strategy === :exponential
        return max(mu_init * (rho^k), mu_final)
    elseif strategy === :adaptive
        st = _barrier_state
        mu = st.mu_current
        if boundary_ratio > 0.95
            mu = min(mu * 2.0, mu_init)
            st.stagnation_count += 1
        else
            st.stagnation_count = 0
        end
        if gap < 1e-3
            mu = max(mu * 0.5, mu_final)
        end
        if st.stagnation_count >= 5
            mu = min(mu * 2.0, mu_init)
            st.stagnation_count = 0
        end
        st.mu_current = mu
        return mu
    else
        return mu_init
    end
end

# -----------------------------------------------------------------------------
# Single-SOC barrier correction (GPU, one-step closed-form)
#
# Layout: xk = [u_1, ..., u_k, t]   (t = LAST component)
#
# Math: φ(x) = -log(t² - ||u||²)
# Gradient: ∇φ = (-2t/D, 2u/D),  D = t² - ||u||²
#
# One prox-gradient step (toward interior):
#   t' = t + 2t·step/D       (increase t → more interior slack)
#   u' = (1 - 2·step/D)·u   (shrink u)
# Then closed-form SOC re-projection if ||u'|| > t'.
#
# Trigger: boundary_ratio = ||u||² / t² > 0.90
# Step: step = mu * tau * min(1, rel_gap), clamped to 0.01 * t
# -----------------------------------------------------------------------------
function apply_soc_barrier_single!(
    xk::CuArray{T};
    mu::Float64 = 1.0,
    tau::Float64 = 1.0,
    rel_gap::Float64 = 1.0,
    verbose::Int = 0,
    iter::Int = 0,
)::Bool where T

    n = length(xk)
    k = n - 1          # k = dim of u,  t = xk[k+1]
    t_val = xk[k + 1]

    # Compute ||u||^2
    u_norm_sq = zero(T)
    for i in 1:k
        u_norm_sq = u_norm_sq + xk[i] * xk[i]
    end

    if abs(t_val) < 1e-12
        return false
    end
    boundary_ratio = u_norm_sq / (t_val * t_val)

    # Trigger gate (same threshold as CPU version)
    if boundary_ratio <= 0.90 || u_norm_sq < 1e-16
        return false
    end

    D = t_val * t_val - u_norm_sq
    if D <= 1e-12
        return false
    end

    # Step size = mu * tau * min(1, rel_gap), clamped
    mu_scale = min(one(Float64), rel_gap)
    step = mu * tau * mu_scale
    max_step = 0.01 * abs(t_val)
    if step > max_step
        step = max_step
    end

    if verbose >= 2
        @cuprint("[BARRIER iter=$iter] k=$k ratio=$boundary_ratio step=$step")
    end

    # Push interior: t' = t + 2t·step/D,  u' = (1 - 2·step/D)·u
    push_amt = 2.0 * step / D
    u_scale = 1.0 - push_amt
    if u_scale < 0.0
        u_scale = 0.0
    end
    t_new = t_val + t_val * push_amt

    xk[k + 1] = t_new
    for i in 1:k
        xk[i] = xk[i] * u_scale
    end

    # Closed-form SOC re-projection: if ||u_new|| > t_new → rescale
    u_new_sq = zero(T)
    for i in 1:k
        vi = xk[i]
        u_new_sq = u_new_sq + vi * vi
    end
    t_check = xk[k + 1]
    if u_new_sq > t_check * t_check && t_check > zero(T)
        scale = t_check / sqrt(u_new_sq)
        for i in 1:k
            xk[i] = xk[i] * scale
        end
    elseif t_check <= zero(T)
        for i in 1:k+1
            xk[i] = zero(T)
        end
    end

    return true
end

# -----------------------------------------------------------------------------
# Top-level entry point: iterate over all SOC blocks in x.primal_sol
# -----------------------------------------------------------------------------
function apply_barrier_gpu!(
    x::solVecPrimal,
    params::PDHGCLPParameters,
    sol,
    iter::Int = 0,
)
    if !params.barrier_enabled
        return
    end
    if params.barrier_mu_init <= 0.0
        return
    end

    tau = params.tau
    rel_gap = isnothing(sol.info.convergeInfo) ? 1.0 :
               sol.info.convergeInfo[1].rel_gap

    blkLen = x.primal_sol.blkLen
    x_slice = x.primal_sol.x_slice
    x_slice_func_symbol = x.primal_sol.x_slice_func_symbol

    for blk_idx in 1:blkLen
        if x_slice_func_symbol[blk_idx] === :proj_soc_cone!
            xk = x_slice[blk_idx]
            if length(xk) < 2
                continue
            end

            k = length(xk) - 1
            t_val = xk[k + 1]
            if abs(t_val) < 1e-12
                continue
            end
            u_norm_sq = zero(eltype(xk))
            for i in 1:k
                vi = xk[i]
                u_norm_sq = u_norm_sq + vi * vi
            end
            boundary_ratio = u_norm_sq / (t_val * t_val)

            mu = update_barrier_mu(
                params.barrier_strategy,
                iter,
                params.barrier_mu_init,
                params.barrier_mu_final,
                params.barrier_rho;
                boundary_ratio = boundary_ratio,
                gap = rel_gap,
            )

            if mu > 0.0
                apply_soc_barrier_single!(
                    xk;
                    mu = mu,
                    tau = tau,
                    rel_gap = rel_gap,
                    verbose = params.verbose,
                    iter = iter,
                )
            end
        end
    end
end

# Fallback no-op (when CUDA is not available)
apply_barrier_gpu!(args...; kwargs...) = nothing

end  # module ExpBarrierGPU

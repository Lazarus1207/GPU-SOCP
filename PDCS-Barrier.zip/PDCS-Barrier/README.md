# PDCS-Barrier

> **Base**: [PDCS-GPU](https://github.com/ZikaiXiong/PDCS) (Julia/CUDA)
>
> **Modification**: Added SOC log-barrier proximal correction module (exp-3.4)

This is a fork of PDCS-GPU with a SOC barrier layer integrated into the PDHG
iteration loop. It is identical to the original PDCS except for the files listed
below.

---

## What Changed

### Modified Files (vs. PDCS original)

| File | Change |
|------|--------|
| `src/pdcs_gpu/PDCS_GPU.jl` | Added `include("./exp_barrier_gpu.jl")` |
| `src/pdcs_gpu/def_struct.jl` | Added `barrier_enabled`, `barrier_mu_init`, `barrier_mu_final`, `barrier_strategy`, `barrier_rho` to `PDHGCLPParameters` and `PDCS_GPU_Solver` |
| `src/pdcs_gpu/rpdhg_alg_gpu_gen.jl` | Forwarded barrier kwargs through `rpdhg_gpu_solve` and `rpdhg_gpu_solve_input_gpu_data` function signatures; passed to `PDHGCLPParameters` at lines 895 and 1720 |
| `src/pdcs_gpu/rpdhg_alg_gpu_gen_scaling.jl` | Injected `apply_barrier_gpu!(x, sol.params, sol, outer_iter)` after primal SOC projection (line ~700) in `pdhg_one_iter_diagonal_rescaling_adaptive_step_size!` |

### New Files

| File | Description |
|------|-------------|
| `src/pdcs_gpu/exp_barrier_gpu.jl` | Core barrier module: `apply_barrier_gpu!`, `apply_soc_barrier_single!`, `update_barrier_mu`, `BarrierAdaptiveState` |

---

## Barrier Algorithm

**Trigger condition**: for each SOC block, compute `boundary_ratio = ||u||² / t²`.
If `boundary_ratio > 0.90` and `||u|| > 1e-8`, apply one prox-gradient step of:

```
φ(x) = -log(t² - ||u||²)
∇φ  = (-2t/D, 2u/D),   D = t² - ||u||²
```

**Step** (matching CPU implementation in `exp_barrier.jl`):

```
step = μ × τ × min(1, rel_gap)      # τ = PDHG primal step size
step = clamp(step, 0, 0.01 × t)

t ← t + 2t·step/D     # increase cone head → more interior slack
u ← (1 - 2·step/D)·u  # shrink Euclidean part

# closed-form re-projection if ||u|| > t
```

**GPU layout** (different from CPU): `x_slice[k+1] = t` (LAST component),
`x_slice[1:k] = u`.

---

## Barrier Configuration

All parameters are keyword arguments to `rpdhg_gpu_solve`:

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `barrier_enabled` | Bool | `false` | Master switch |
| `barrier_mu_init` | Float64 | `1.0` | Initial μ |
| `barrier_mu_final` | Float64 | `1e-6` | μ floor for adaptive/exp |
| `barrier_strategy` | Symbol | `:constant` | `:constant` / `:exponential` / `:adaptive` |
| `barrier_rho` | Float64 | `0.9` | Decay base for `:exponential` |

---

## Parameter Settings (Matching Prior Experiments)

These match the settings used in exp-3.2, exp-3.3, and exp-3.4:

```
rel_tol              = 1e-4
abs_tol              = 1e-6
time_limit           = 300.0
check_terminate_freq = 2000
use_adaptive_restart = true
use_aggressive       = true
use_resolving        = true
use_duality_gap_restart = true
duality_gap_restart_freq = 2000
```

---

## Installation

1. **Compile CUDA kernels** (same as PDCS original):

```bash
cd src/pdcs_gpu/cuda
make
```

2. **Use as Julia package**:

```julia
using Pkg
Pkg.develop(path="path/to/PDCS-Barrier")
using PDCS_Barrier
```

Or in scripts:

```julia
push!(LOAD_PATH, "path/to/PDCS-Barrier/src")
using PDCS_Barrier.PDCS_GPU
```

---

## Usage Example

```julia
using PDCS_Barrier.PDCS_GPU

result = rpdhg_gpu_solve(
    n = n, m = m, nb = nb,
    c = c, G = G, h = h,
    mGzero = mGzero, mGnonnegative = mGnonnegative,
    socG = socG, rsocG = rsocG,
    expG = expG, dual_expG = dual_expG,
    bl = bl, bu = bu,
    soc_x = soc_x, rsoc_x = rsoc_x,
    # --- barrier enabled ---
    barrier_enabled  = true,
    barrier_mu_init = 1.0,
    barrier_strategy = :constant,
    # --- standard params ---
    rel_tol = 1e-4,
    time_limit = 300.0,
    verbose = 1,
)
```

Compare with baseline (barrier disabled):

```julia
result_baseline = rpdhg_gpu_solve(
    ...,
    barrier_enabled = false,   # same as default
    rel_tol = 1e-4,
    time_limit = 300.0,
)
```

---

## Difference from CPU Version

The CPU version (`pdcs_original/src/pdcs_cpu/exp_barrier.jl`) uses a full
prox-gradient solver with line search (`bpgrad_soc`), which is CPU-only.
The GPU version (`exp_barrier_gpu.jl`) uses a **single-step closed-form
correction** — one gradient step plus a SOC re-projection — that is
vectorized over all SOC blocks.

---

## Relation to B-PDHCG

B-PDHCG (`D:/PDCS/B-PDHCG/`) is the C++/CUDA version of PDHCG with the same
SOC barrier concept, implemented as a separate CUDA kernel. This package is
the Julia/CUDA version with the barrier inlined into the existing Julia
iteration loop.

#!/usr/bin/env julia
# run_pdcs_jump.jl - 基于 JuMP 的 PDCS 批量求解器
# 用法：
#   julia --project=/path/to/PDCS run_pdcs_jump.jl <cbf_files_or_dir> <output_dir> [options]
#
# 示例：
#   # 单个文件
#   julia --project=~/PDCS run_pdcs_jump.jl ~/CBLIB/bss1.cbf ~/results/ --time-limit 300 --rel-tol 1e-4 --gpu 0
#   
#   # 目录（批量）
#   julia --project=~/PDCS run_pdcs_jump.jl ~/CBLIB/represent_data_unzip/ ~/results/ --time-limit 60 --gpu 1
#   
#   # 多个文件
#   julia --project=~/PDCS run_pdcs_jump.jl file1.cbf file2.cbf ~/results/

using ArgParse
using JuMP
import MathOptInterface as MOI
using Printf, Dates, JSON

function parse_commandline()
    s = ArgParseSettings(
        description = "PDCS solver using JuMP interface (CPU/GPU support)",
        version = "1.0.0",
        add_version = true
    )
    
    @add_arg_table! s begin
        "input"
            help = "CBF file(s) or directory containing .cbf files"
            required = true
            nargs = '+'
        "output_dir"
            help = "Output directory for results"
            required = true
        "--time-limit", "-t"
            help = "Time limit in seconds"
            arg_type = Float64
            default = 300.0
        "--rel-tol"
            help = "Relative tolerance"
            arg_type = Float64
            default = 1e-4
        "--abs-tol"
            help = "Absolute tolerance"
            arg_type = Float64
            default = 1e-4
        "--gpu", "-g"
            help = "GPU device number (use -1 for CPU)"
            arg_type = Int
            default = 0
        "--verbose", "-v"
            help = "Verbosity level (0=silent, 1=summary, 2=detailed)"
            arg_type = Int
            default = 1
        "--max-outer-iter"
            help = "Maximum outer iterations"
            arg_type = Int
            default = 2000
        "--max-inner-iter"
            help = "Maximum inner iterations"
            arg_type = Int
            default = 200000
        "--barrier"
            help = "Enable exponential barrier method"
            action = :store_true
        "--barrier-mu"
            help = "Barrier parameter mu"
            arg_type = Float64
            default = 1e-3
        "--barrier-strategy"
            help = "Barrier strategy: constant|adaptive"
            arg_type = String
            default = "constant"
    end
    
    return parse_args(s)
end

# 收集所有 CBF 文件
function collect_cbf_files(inputs::Vector{String})
    cbf_files = String[]
    for input in inputs
        if isfile(input)
            if endswith(lowercase(input), ".cbf")
                push!(cbf_files, abspath(input))
            else
                @warn "Skipping non-CBF file: $input"
            end
        elseif isdir(input)
            for (root, dirs, files) in walkdir(input)
                for file in files
                    if endswith(lowercase(file), ".cbf")
                        push!(cbf_files, joinpath(root, file))
                    end
                end
            end
        else
            @warn "Input not found: $input"
        end
    end
    return sort(unique(cbf_files))
end

# 运行单个问题
function run_single_problem(cbf_path::String, args::Dict; use_gpu::Bool)
    using PDCS
    
    # 选择 CPU 或 GPU
    if use_gpu
        optimizer_factory = () -> PDCS.PDCS_GPU.Optimizer()
        backend = "GPU$(args["gpu"])"
    else
        optimizer_factory = () -> PDCS.PDCS_CPU.Optimizer()
        backend = "CPU"
    end
    
    # 读取 CBF 文件
    model = try
        read_from_file(cbf_path)
    catch e
        return (
            status = :READ_ERROR,
            error = string(typeof(e)),
            time = 0.0,
            iter = -1,
            obj = NaN,
            backend = backend
        )
    end
    
    # 设置求解器
    set_optimizer(model, optimizer_factory)
    
    # 设置参数
    set_optimizer_attribute(model, "time_limit_secs", args["time-limit"])
    set_optimizer_attribute(model, "rel_tol", args["rel-tol"])
    set_optimizer_attribute(model, "abs_tol", args["abs-tol"])
    set_optimizer_attribute(model, "verbose", args["verbose"])
    set_optimizer_attribute(model, "max_outer_iter", args["max-outer-iter"])
    set_optimizer_attribute(model, "max_inner_iter", args["max-inner-iter"])
    set_optimizer_attribute(model, "print_freq", 100000)
    
    # PDCS-rbt 新增参数
    set_optimizer_attribute(model, "adaptive_projection_tolerance", nothing)
    set_optimizer_attribute(model, "scalar_cone_rescaling", false)
    set_optimizer_attribute(model, "sparse_index_type", :auto)
    # Barrier method 参数
    if args["barrier"]
        set_optimizer_attribute(model, "exp_barrier_enabled", true)
        set_optimizer_attribute(model, "exp_barrier_mu_init", args["barrier-mu"])
        set_optimizer_attribute(model, "exp_barrier_mu_final", args["barrier-mu"])
        set_optimizer_attribute(model, "exp_barrier_strategy", args["barrier-strategy"])
    end
    
    # 求解
    t0 = time()
    try
        optimize!(model)
        t_elapsed = time() - t0
        
        ts = termination_status(model)
        obj = has_values(model) ? objective_value(model) : NaN
        
        # 获取迭代次数
        iter = try
            if use_gpu
                MOI.get(unsafe_backend(model), PDCS.PDCS_GPU.PDHGIterations())
            else
                MOI.get(unsafe_backend(model), PDCS.PDCS_CPU.PDHGIterations())
            end
        catch
            -1
        end
        
        return (
            status = ts,
            error = nothing,
            time = t_elapsed,
            iter = iter,
            obj = obj,
            backend = backend
        )
    catch e
        t_elapsed = time() - t0
        return (
            status = :SOLVER_ERROR,
            error = string(typeof(e)) * ": " * string(e),
            time = t_elapsed,
            iter = -1,
            obj = NaN,
            backend = backend
        )
    end
end

# 主函数
function main()
    args = parse_commandline()
    
    # 收集输入文件
    cbf_files = collect_cbf_files(args["input"])
    
    if isempty(cbf_files)
        println("ERROR: No CBF files found in input")
        exit(1)
    end
    
    # 创建输出目录
    output_dir = abspath(args["output_dir"])
    mkpath(output_dir)
    
    # 确定使用 CPU 还是 GPU
    use_gpu = args["gpu"] >= 0
    if use_gpu
        ENV["CUDA_VISIBLE_DEVICES"] = string(args["gpu"])
        println("Using GPU $(args["gpu"])")
    else
        println("Using CPU")
    end
    
    # 打印配置
    println("=" ^ 100)
    println("PDCS Batch Solver (JuMP Interface)")
    println("=" ^ 100)
    println("Number of problems: $(length(cbf_files))")
    println("Time limit:         $(args["time-limit"]) seconds")
    println("Tolerance:          rel=$(args["rel-tol"]), abs=$(args["abs-tol"])")
    println("Backend:            $(use_gpu ? "GPU $(args["gpu"])" : "CPU")")
    println("Barrier method:     $(args["barrier"] ? "Enabled (μ=$(args["barrier-mu"]))" : "Disabled")")
    println("Output directory:   $output_dir")
    println("Started:            $(Dates.format(now(), "yyyy-mm-dd HH:MM:SS"))")
    println("=" ^ 100)
    println()
    
    # 运行所有问题
    results = []
    for (idx, cbf_path) in enumerate(cbf_files)
        fname = basename(cbf_path)
        print("[$idx/$(length(cbf_files))] $fname ... ")
        flush(stdout)
        
        result = run_single_problem(cbf_path, args; use_gpu=use_gpu)
        
        push!(results, (file=cbf_path, name=fname, result=result))
        
        # 打印简要结果
        if result.status == :OPTIMAL || result.status == MOI.OPTIMAL
            @printf("✓ OPTIMAL  iter=%6d  t=%7.2fs  obj=%12.6e\n", 
                    result.iter, result.time, result.obj)
        elseif result.status == :TIME_LIMIT || result.status == MOI.TIME_LIMIT
            @printf("⏱ TIMEOUT  iter=%6d  t=%7.2fs\n", 
                    result.iter, result.time)
        else
            println("✗ $(result.status)  t=$(round(result.time, digits=2))s")
            if result.error !== nothing && args["verbose"] >= 1
                println("  Error: $(result.error)")
            end
        end
        flush(stdout)
    end
    
    # 汇总统计
    println("\n" * "=" ^ 100)
    println("SUMMARY")
    println("=" ^ 100)
    
    n_optimal = count(r -> r.result.status in [:OPTIMAL, MOI.OPTIMAL], results)
    n_timeout = count(r -> r.result.status in [:TIME_LIMIT, MOI.TIME_LIMIT], results)
    n_error = length(results) - n_optimal - n_timeout
    
    @printf("Total:    %4d problems\n", length(results))
    @printf("Optimal:  %4d (%.1f%%)\n", n_optimal, 100*n_optimal/length(results))
    @printf("Timeout:  %4d (%.1f%%)\n", n_timeout, 100*n_timeout/length(results))
    @printf("Error:    %4d (%.1f%%)\n", n_error, 100*n_error/length(results))
    println()
    
    # 保存 JSON 结果
    json_file = joinpath(output_dir, "results_$(Dates.format(now(), "yyyymmdd_HHMMSS")).json")
    json_data = Dict(
        "config" => args,
        "timestamp" => string(now()),
        "results" => [
            Dict(
                "file" => r.file,
                "name" => r.name,
                "status" => string(r.result.status),
                "time" => r.result.time,
                "iter" => r.result.iter,
                "obj" => r.result.obj,
                "backend" => r.result.backend,
                "error" => r.result.error
            ) for r in results
        ]
    )
    
    open(json_file, "w") do io
        JSON.print(io, json_data, 2)
    end
    println("Results saved to: $json_file")
    
    # 保存详细表格（CSV 格式）
    csv_file = joinpath(output_dir, "results_$(Dates.format(now(), "yyyymmdd_HHMMSS")).csv")
    open(csv_file, "w") do io
        println(io, "filename,status,iterations,time_sec,objective,backend,error")
        for r in results
            println(io, "$(r.name),$(r.result.status),$(r.result.iter),$(r.result.time),$(r.result.obj),$(r.result.backend),\"$(something(r.result.error, ""))\"")
        end
    end
    println("CSV saved to:     $csv_file")
    
    println("\nFinished:         $(Dates.format(now(), "yyyy-mm-dd HH:MM:SS"))")
    println("=" ^ 100)
end

# 运行
main()

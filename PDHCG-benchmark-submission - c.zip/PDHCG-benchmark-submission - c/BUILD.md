# C-side PDHCG Mittelmann SOCP driver — build and run

This folder is the **pure-C form** of the PDHCG submission.  It
removes the Python `pdhcg.row_scaling` popen-hook from the CLI and
re-implements everything in C:

* `PDHCG/src/row_scaling.cu` — pure-C row-whitening (cuSOLVER eigh)
* `PDHCG/src/config.c`     — geometry-based (alpha, restart) classifier
* `PDHCG/src/run_benchmark.c` — Mittelmann SOCP benchmark driver
* `PDHCG/src/cli.c`         — per-problem CLI (now C-only)

## Build

```bash
cd PDHCG
rm -rf build && mkdir build && cd build
cmake -DPDHCG_BUILD_CLI=ON \
      -DPDHCG_BUILD_RUN_BENCHMARK=ON \
      -DCMAKE_BUILD_TYPE=Release \
      ..
cmake --build . -j
```

The build produces two binaries in `build/`:

* `pdhcg`           — per-problem CLI (`./pdhcg <cbf> <out_dir>`)
* `run_benchmark`   — directory-scanning driver

## Run

### Single problem (chainsing-2):

```bash
mkdir -p out/chainsing-2
./build/pdhcg --time_limit 600 --iter_limit 10000000 \
              --eps_opt 1e-6 --eps_feas 1e-6 --verbose 2 \
              --pock_chambolle_alpha 1.0 \
              --artificial_restart_threshold 0.36 \
              --enable_row_scaling \
              /path/to/chainsing-50000-2.cbf.gz \
              out/chainsing-2
```

### Whole benchmark (auto-selects alpha, restart per problem):

```bash
./build/run_benchmark --cli ./build/pdhcg \
                      --in-dir /path/to/socp \
                      --out-dir results/run_c_$(date +%s) \
                      --gpu 0 \
                      --spmv-backend new \
                      --time-limit 3600 \
                      --iter-limit 99999999 \
                      --eps-opt 1e-6 \
                      --eps-feas 1e-6
```

To force C defaults (no config-driven alpha/restart override):

```bash
./build/run_benchmark --cli ./build/pdhcg \
                      --in-dir /path/to/socp \
                      --out-dir results/run_c_defaults_$(date +%s) \
                      --no-apply-config \
                      --gpu 0
```

## What changed vs the Python-mixed build

| Old (Python-mixed)                          | New (pure C)                                  |
|---------------------------------------------|-----------------------------------------------|
| `m.optimize()` path                         | `pdhcg` binary (CLI)                          |
| `pdhcg.row_scaling.apply_row_scaling`       | `PDHCG/src/row_scaling.cu` (cuSOLVER eigh)    |
| `config.py` (Python)                        | `PDHCG/src/config.c` (C)                      |
| `run_benchmark.py` (Python)                 | `PDHCG/src/run_benchmark.c` + `run_benchmark_main.c` |
| Row scaling threaded through `popen` in CLI  | Row scaling called directly inside `solver.cu`|

## Hypothesis being tested

The Python `m.optimize()` path is forcing `alpha=1.5`, `restart=0.10`
and `spmv_backend=new` (per `run_benchmark.py` defaults + `config.py`
classifier).  For chainsing-{2,3} the same parameters applied via
the C CLI may converge where the Python path did not -- or may not.
The C-form driver lets you probe both:

* `--apply-config 1`  → use config-classifier (alpha, restart)
* `--apply-config 0`  → use C defaults (alpha=1.0, restart=0.36)
* `--spmv-backend cusparse` vs `--spmv-backend new`  → matrix
  multiplication backend

## Notes

* `m > row_scaling_max_rows` (default 2000) skips row scaling; the
  C optimizer still runs Ruiz (10 iters) + Pock-Chambolle (alpha=1.0)
  + (optionally) Curtis-Reid.
* Row-scaling M is recovered in `solver.cu` via
  `pdhcg_recover_dual_from_pending_row_scaling`; the original-space
  dual is what lands in the output `*_dual_solution.txt`.
* For chainsing-{2,3} the row_scaling path is **not** taken (m=399988
  > 2000), so the only difference between C and Python paths on
  these two problems is the alpha/restart/spmv choice.

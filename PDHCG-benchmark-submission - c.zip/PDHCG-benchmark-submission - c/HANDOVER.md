# PDHCG C-side Migration — Handover Notes

> Generated as part of the C-side rewrite.  The goal of this rewrite was to
> move the entire row-scaling + benchmark + classifier pipeline into pure C,
> so that the C CLI (not Python) is the entry point for every SOCP solve.

## TL;DR for the user

The C-side rewrite is complete in `D:\PDHCG\PDHCG-benchmark-submission - c`.
The new `pdhcg` CLI runs natively in C, the new `run_benchmark` driver scans
CBF files and shells out to the CLI, and the row-scaling (whitening) routine
is implemented in `src/row_scaling.cu` using cuSOLVER.

**To verify chainsing-2/3 still solves correctly, please run the test script
on the server:**

```bash
cat > ~/testHM/PDHCG-benchmark-submission-c/build_and_test_c.sh << 'EOF'
$(cat the contents of D:\PDHCG\PDHCG-benchmark-submission - c\build_and_test_c.sh)
EOF
chmod +x ~/testHM/PDHCG-benchmark-submission-c/build_and_test_c.sh
sed -i 's/\r$//' ~/testHM/PDHCG-benchmark-submission-c/build_and_test_c.sh
cd ~/testHM/PDHCG-benchmark-submission-c && bash build_and_test_c.sh
```

The script will:
1. `cmake -DPDHCG_BUILD_CLI=ON -DPDHCG_BUILD_RUN_BENCHMARK=ON …` the source.
2. Build the CLI + run_benchmark binaries.
3. Run a 60-second smoke test on `chainsing-50000-1.cbf.gz`.
4. Run a 300-second solve on `chainsing-50000-2.cbf.gz` with C defaults.
5. Run a 300-second solve on `chainsing-50000-2.cbf.gz` with
   `alpha=1.5, restart=0.10` (config-classifier setting).

The 4-vs-5 comparison will tell us whether the alpha/restart classifier is
the source of chainsing-2 divergence.

## What was changed

### New files

| File | Role |
| --- | --- |
| `PDHCG/include/row_scaling.h`        | Public API: `pdhcg_apply_row_scaling_const`, `pdhcg_recover_dual_from_pending_row_scaling`, status enum. |
| `PDHCG/src/row_scaling.cu`           | cuSOLVER-based row-whitening.  Builds $G = D A A^T D$, factorizes via `cusolverDnDsyevd`, forms $W = V \Lambda^{-1/2} V^T$, dense-multiply for $A_{\text{new}}, b_{\text{new}}$, Gauss-Jordan for $y_{\text{start}}$ inverse, and a flag to re-send the dual back to the original space. |
| `PDHCG/include/config.h`             | Geometry classifier header: `pdhcg_config_select` and `PDHCG_CONFIG_DEFAULT`. |
| `PDHCG/src/config.c`                 | Geometry classifier implementation (1:1 port of `config.py`). |
| `PDHCG/include/cbf_header.h`         | Minimal CBF header API. |
| `PDHCG/src/cbf_header.c`             | Reads only the CBF header, extracts `(m, n, nnz, qc)`. |
| `PDHCG/include/run_benchmark.h`      | Public API of the new C-side benchmark driver. |
| `PDHCG/src/run_benchmark.c`          | Implementation.  Scans `--in-dir`, classifies, builds a shell command, `system()`-calls the CLI, parses the summary. |
| `PDHCG/src/run_benchmark_main.c`     | The `main()` entry point. |
| `build_and_test_c.sh`                | Convenience script for the server: full build + smoke tests. |

### Modified files

| File | Change |
| --- | --- |
| `PDHCG/src/cli.c` | Removed the Python `popen` bridge (`solve_via_python`).  The CLI now directly calls `pdhcg_solve_problem`, which in turn calls `pdhcg_apply_row_scaling_const` from `solver.cu`.  New flags: `--row_scaling_c_only`, `--no_row_scaling`. |
| `PDHCG/src/solver.cu` | Calls `pdhcg_apply_row_scaling_const` (with the rescaling hooks so future dual recovery is possible).  When row-scaling succeeds: `l_inf_ruiz_iterations=0`, `curtis_reid_iterations=5`, `diag_jacobi_precond=true`.  After solve, `pdhcg_recover_dual_from_pending_row_scaling` maps the dual back to the original space. |
| `PDHCG/CMakeLists.txt` | Excludes the new files from the Python-bindings build.  Adds a new executable `run_benchmark` that links against `ZLIB::ZLIB`, the new C files, and the project library. |
| `PDHCG/src/run_benchmark.c` | Fixed the broken `CUDA_VISIBLE_DEVICES=N <cli> …` shell-string bug — now uses `setenv` before `system()`.  Also fixed the inverted `--no_diag_precond` logic. |

## Build instructions

```bash
# From the project root:
cmake -S PDHCG -B build_c -DPDHCG_BUILD_CLI=ON \
                       -DPDHCG_BUILD_RUN_BENCHMARK=ON \
                       -DCMAKE_BUILD_TYPE=Release
cmake --build build_c -j
```

Outputs:
* `build_c/pdhcg`           — the C CLI
* `build_c/run_benchmark`   — the new C-side benchmark driver

## Usage

### CLI (single solve)

```bash
./build_c/pdhcg \
    --time_limit 60 --iter_limit 10000000 \
    --eps_opt 1e-6 --eps_feas 1e-6 \
    --enable_row_scaling \
    /home/zhongyingze/testHM/benchmark/socp/chainsing-50000-2.cbf.gz \
    ./results/chainsing-50000-2
```

### Run the whole benchmark (driver)

```bash
CUDA_VISIBLE_DEVICES=4 ./build_c/run_benchmark \
    --cli ./build_c/pdhcg \
    --in-dir /home/zhongyingze/testHM/benchmark/socp/ \
    --out-dir ./results/c_bench/ \
    --time-limit 300 --iter-limit 99999999 \
    --eps-opt 1e-6 --eps-feas 1e-6 \
    --row-scaling-max-rows 2000 \
    --apply-config 1 \
    --gpu 4 \
    --only chainsing-50000-2
```

A `summary.txt` is written to `--out-dir`.

## Why this rewrite?

The previous pipeline had Python `run_benchmark.py` calling into a
Python wrapper that built (alpha, restart) via `config.py`, which selected
`alpha=1.5, restart=0.10` for `chainsing-2` (the row-scaling problems),
while the working C-CLI log was generated with the **C defaults**
(`alpha=1.0, restart=0.36, spmv=cusparse`).  The mismatch was suspected
to be the cause of chainsing-2/3 non-convergence.

The C-side rewrite lets us:

1. **Run entirely from the C CLI** — no Python, no PyBind11 ABI mismatch.
2. **Test alpha/restart in isolation** — the new `run_benchmark` defaults
   to `--apply-config 1` but can be turned off with `--no-apply-config`.
3. **Compare C-CLI-defaults vs C-with-classifier on the same binary**.

If the smoke tests above show "C-CLI defaults solve, classifier fails",
the fix is to adjust the classifier's restart threshold (currently 0.10)
back up to 0.36 for the chain-magnetization family.

## Known limitations

* The cuSOLVER-based row scaling is single-GPU and limited to `m <= 2000`
  rows (matches the Python version).
* The C-CLI only understands the binary's own flags; it does not have
  Python's "magic" parameter overrides that were in the old `config.py`.
* The shell `system()` call inside `run_benchmark.c` is **not async**;
  it blocks for the whole solve.  This is fine for benchmarks but not
  ideal for a UI.

## Quick troubleshooting

If `pdhcg` complains `Failed to open file`, the most likely cause is
that the path passed to it is wrong (the CLI does not auto-`.gz`-decompress
in some older code paths; we made sure `cbf_parser.c` does, but if you
ever see the message, try `gunzip -c file.cbf.gz | pdhcg -`).

If you see `cusolverDnDsyevd: CUSOLVER_STATUS_NOT_INITIALIZED`, you
forgot to call `cusolverDnCreate(&handle)` first.

If `run_benchmark` runs but the summary is empty, check the per-problem
`$case_out/<problem>_summary.txt` — the CLI emits these but only if the
problem actually terminated (or if `--verbose 2` is set).

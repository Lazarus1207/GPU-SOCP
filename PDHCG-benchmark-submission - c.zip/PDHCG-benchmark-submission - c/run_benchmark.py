"""run_benchmark.py -- Mittelmann SOCP 18-problem benchmark runner (Python).

The (alpha, restart) decision is delegated entirely to ``config.py``
(geometry-based classifier with no per-problem whitelists).  No
external config table is required.

Row-scaling activation policy (when m <= row_scaling_max_rows and the
problem is all-equalities):
    * l_inf_ruiz_iterations = 0   (forced in row_scaling.py's params_overrides)
    * curtis_reid_iterations = 5
    * diag_jacobi_precond     = True
    * enable_row_scaling      = False on the C side (Python
      row_scaling.py applies the invertible transform; the C-side
      switch is forced off to avoid double application)
"""

from __future__ import annotations

import argparse
import os
import sys
import time
import traceback
from pathlib import Path
from typing import Optional

import numpy as np

if "CUDA_VISIBLE_DEVICES" in os.environ and os.environ["CUDA_VISIBLE_DEVICES"]:
    pass
elif "--gpu" in sys.argv:
    try:
        idx = sys.argv.index("--gpu")
        os.environ["CUDA_VISIBLE_DEVICES"] = sys.argv[idx + 1]
    except (IndexError, ValueError):
        pass

_SUBMIT_DIR = Path(__file__).resolve().parent
_PDHCG_PYTHON = _SUBMIT_DIR / "PDHCG" / "python"
if str(_PDHCG_PYTHON) not in sys.path:
    sys.path.insert(0, str(_PDHCG_PYTHON))
if str(_SUBMIT_DIR) not in sys.path:
    sys.path.insert(0, str(_SUBMIT_DIR))

import config  

import pdhcg  
from pdhcg import Model  


DEFAULTS = dict(
    gpu="4",
    time_limit=3600,
    iter_limit=99_999_999,
    epsilon=1e-6,
    spmv_backend="new",
    row_scaling_max_rows=2000,             
    row_scaling_enabled=True,              
    input_dir=os.path.expanduser("~/testHM/benchmark/socp"),
    output_dir=None,
    only=None,
    verbose=2,
    feasibility_polishing=0,    
    presolve=0,                 
    # Applied only when row scaling activates.
    curtis_reid_iterations=5,
    # l_inf_ruiz: applied only when row scaling activates.  When RS
    # activates, row_scaling.py's params_overrides forces ruiz=0 (and
    # the runner mirrors that intent).  When RS does not activate, the
    # C default (10) wins.
    l_inf_ruiz_iterations=0,
    # diag_jacobi_precond: applied only when row scaling activates.
    # Pass --diag-jacobi 1 to force ON regardless; 0 to force OFF.
    diag_jacobi=True,
)


def _load_problem(path: Path) -> Model:
    return Model.read_file(str(path))


def _apply_params(model: Model, *, alpha, restart,
                 epsilon, time_limit, iter_limit,
                 spmv_backend, row_scaling_enabled,
                 row_scaling_max_rows, verbose,
                 feasibility_polishing, presolve,
                 curtis_reid_iterations,
                 l_inf_ruiz_iterations,
                 diag_jacobi) -> None:
    """Forward runner params to the underlying Model.

    ``config.py`` may return ``restart='default'`` (a sentinel meaning
    "use the C-side default of 0.36"); in that case we drop the
    setParam call so the C default wins.

    ``diag_jacobi`` is the runner's per-problem value: applied
    unconditionally when non-None.  The model.optimize() path's
    params_overrides (row_scaling.py) is the C-side source of truth
    for Ruiz/CR/Jacobi when row scaling activates; the runner mirrors
    that policy here.
    """
    setq = model.setParam
    setq("pock_chambolle_alpha", float(alpha))
    if isinstance(restart, str):
        if restart.lower() not in ("default", "auto", ""):
            raise ValueError(f"unsupported restart sentinel: {restart!r}")
    else:
        setq("artificial_restart_threshold", float(restart))
    setq("eps_optimal_relative", float(epsilon))
    setq("eps_feasible_relative", float(epsilon))
    setq("time_sec_limit", float(time_limit))
    setq("iteration_limit", int(iter_limit))
    setq("spmv_backend", spmv_backend)
    if row_scaling_enabled is not None:
        setq("row_scaling_enabled", bool(row_scaling_enabled))
    setq("row_scaling_max_rows", int(row_scaling_max_rows))
    setq("verbose", int(verbose))
    setq("feasibility_polishing", bool(feasibility_polishing))
    setq("presolve", bool(presolve))
    if l_inf_ruiz_iterations is not None:
        setq("l_inf_ruiz_iterations", int(l_inf_ruiz_iterations))
    if curtis_reid_iterations is not None:
        setq("curtis_reid_iterations", int(curtis_reid_iterations))
    if diag_jacobi is not None:
        setq("diag_jacobi_precond", bool(diag_jacobi))


def _write_summary(out_dir, name, *, status, iters, elapsed, pobj, dobj,
                   gap, rescale_time, rs_status, rs_applied, rs_metadata,
                   no_summary_tail=False):
    out_dir.mkdir(parents=True, exist_ok=True)
    summary_path = out_dir / f"{name}_summary.txt"
    with summary_path.open("w") as f:
        f.write(f"Instance: {name}\n")
        f.write(f"Status: {status}\n")
        f.write(f"Iterations: {int(iters)}\n")
        f.write(f"Solve time: {elapsed:.3f}\n")
        f.write(f"Rescaling Time (sec): {float(rescale_time or 0.0):.3f}\n")
        f.write(f"Primal Objective: {float(pobj or float('nan')):.10g}\n")
        f.write(f"Dual Objective: {float(dobj or float('nan')):.10g}\n")
        f.write(f"Relative Objective Gap: {float(gap or float('nan')):.6e}\n")
        f.write(f"Row Scaling: {'applied' if rs_applied else 'skipped'} ({rs_status})\n")
        f.write("Backend: pdhcg (Python driver, Model API)\n")
        if not no_summary_tail:
            obj_v = float(pobj) if pobj is not None and np.isfinite(pobj) else (
                float(dobj) if dobj is not None and np.isfinite(dobj) else 0.0
            )
            gap_v = float(gap) if gap is not None and np.isfinite(gap) else float("nan")
            f.write("\n")
            f.write(f"model:     {name}\n")
            f.write(f"status:    {status}\n")
            f.write(f"iter:      {int(iters)}\n")
            f.write(f"time:      {elapsed:.6f}\n")
            f.write(f"objective: {obj_v:.10g}\n")
            f.write(f"gap:       {gap_v:.6e}\n")


def _write_solution(out_dir, name, kind, vec):
    if vec is None:
        return
    out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / f"{name}_{kind}_solution.txt"
    arr = np.asarray(vec, dtype=np.float64).ravel()
    np.savetxt(path, arr.reshape(-1, 1), fmt="%.17g")


def _run_one(name, prob_path, args, out_dir):
    model = _load_problem(prob_path)
    alpha, restart = config.select_config(model)
    rows = int(getattr(model, "num_constrs", 0) or 0)
    rs_enabled = bool(args.row_scaling_enabled)  # DEFAULTS=True, --row-scaling-enabled 0 turns it off

    # Predict whether built-in row scaling will activate.  Mirrors
    # model.optimize()'s own gating: m<=max_rows, m>0, enabled, and
    # all_rows_are_equalities (dsNRL satisfies this; the last check
    # is done in C so we approximate it with rows>0).
    row_scaling_will_apply = bool(
        rows > 0
        and rs_enabled
        and args.row_scaling_max_rows > 0
        and rows <= args.row_scaling_max_rows
    )
    # curtis_reid: apply ONLY when row scaling activates (dsNRL_v6).
    # When RS does NOT activate, pass None so C default (0) wins.
    cr = int(args.curtis_reid_iterations) if row_scaling_will_apply else None

    # l_inf_ruiz: when row scaling activates, Python row_scaling.py's
    # params_overrides forces l_inf_ruiz_iterations=0 (to avoid double
    # equilibration with the row-scaling transform).  We mirror that
    # intent by passing 0 explicitly when RS will activate, and None
    # otherwise so the C default (10) wins.
    ruiz_arg = int(args.l_inf_ruiz_iterations) if row_scaling_will_apply else None

    # diag_jacobi: apply ONLY when row scaling activates.
    # When RS does NOT activate, pass None so C default (False) wins.
    jacobi_arg = bool(args.diag_jacobi) if row_scaling_will_apply else None

    log_path = out_dir / f"{name}.log"
    log = log_path.open("w", buffering=1)

    def L(msg):
        print(msg, flush=True)
        log.write(msg + "\n"); log.flush()

    L(f"--- {name} ---")

    result = {"problem": name, "rows": rows, "alpha": alpha, "restart": restart,
              "row_scaling": rs_enabled, "status": "FAIL", "iters": 0,
              "elapsed": 0.0, "pobj": float("nan"), "dobj": float("nan"),
              "gap": float("nan"), "rc": 1, "rscaling_sec": 0.0}
    t0 = time.time()
    try:
        _apply_params(model, alpha=alpha, restart=restart,
                      epsilon=args.epsilon, time_limit=args.time_limit,
                      iter_limit=args.iter_limit,
                      spmv_backend=args.spmv_backend,
                      row_scaling_enabled=rs_enabled,
                      row_scaling_max_rows=args.row_scaling_max_rows,
                      verbose=args.verbose,
                      feasibility_polishing=bool(args.feasibility_polishing),
                      presolve=bool(args.presolve),
                      curtis_reid_iterations=cr,
                      l_inf_ruiz_iterations=ruiz_arg,
                      diag_jacobi=jacobi_arg)
        # FD-level tee: PDHCG-II's C solver writes via printf -> fd=1,
        # which bypasses sys.stdout. We dup2 fd=1 to a pipe; a pump
        # thread reads chunks and writes them to BOTH:
        #   (a) the saved original stdout (so $LOGFILE in nohup mode
        #       still sees the solver output)
        #   (b) the per-case <name>.log file (so each problem has its
        #       own complete solver log: ASCII banner + iteration table
        #       + Solution Summary)
        _select = __import__("select")
        _threading = __import__("threading")

        _saved_stdout_fd = os.dup(1)
        _py_stdout = os.fdopen(_saved_stdout_fd, "w", buffering=1,
                               closefd=False)
        _orig_sys_stdout = sys.stdout
        sys.stdout = _py_stdout

        _r_fd, _w_fd = os.pipe()
        os.dup2(_w_fd, 1)
        os.close(_w_fd)
        _stop_evt = _threading.Event()
        _pump_lock = _threading.Lock()

        def _pump():
            while not _stop_evt.is_set():
                _rfds, _, _ = _select.select([_r_fd], [], [], 0.05)
                if not _rfds:
                    continue
                try:
                    _chunk = os.read(_r_fd, 65536)
                except OSError:
                    break
                if not _chunk:
                    break
                with _pump_lock:
                    try:
                        os.write(_saved_stdout_fd, _chunk)
                    except OSError:
                        pass
                    try:
                        log.buffer.write(_chunk)
                        log.buffer.flush()
                    except Exception:
                        pass

        _pump_thread = _threading.Thread(target=_pump, daemon=True)
        _pump_thread.start()

        try:
            model.optimize()
        finally:
            try:
                sys.stdout.flush()
            except Exception:
                pass
            try:
                log.flush()
            except Exception:
                pass
            os.dup2(_saved_stdout_fd, 1)
            _stop_evt.set()
            try:
                os.close(_r_fd)
            except OSError:
                pass
            _pump_thread.join(timeout=3.0)
            sys.stdout = _orig_sys_stdout
            try:
                _py_stdout.close()
            except Exception:
                pass

        elapsed = time.time() - t0
        status = str(model.Status or "UNKNOWN")
        iters = int(model.IterCount or 0)
        pobj = float(model.ObjVal) if model.ObjVal is not None else float("nan")
        dobj = float(model.DualObj) if model.DualObj is not None else float("nan")
        gap = float(model.RelGap) if model.RelGap is not None else float("nan")
        rescale_time = 0.0
        rs_status = "auto"
        try:
            info = model.SolverInfo or {}
            rescale_time = float(info.get("RowScalingTime", 0.0) or 0.0)
        except Exception:
            pass
        L(f"  status={status} iters={iters} elapsed={elapsed:.2f}s")
        _write_solution(out_dir, name, "primal", model.X)
        _write_solution(out_dir, name, "dual", model.Pi)
        _write_summary(out_dir, name, status=status, iters=iters,
                       elapsed=elapsed, pobj=pobj, dobj=dobj, gap=gap,
                       rescale_time=rescale_time, rs_status=rs_status,
                       rs_applied=row_scaling_will_apply, rs_metadata=None,
                       no_summary_tail=args.no_summary_tail)
        result.update(status=status, iters=iters, elapsed=elapsed,
                      pobj=pobj, dobj=dobj, gap=gap, rscaling_sec=rescale_time, rc=0)
    except Exception as e:
        elapsed = time.time() - t0
        L(f"  EXC: {type(e).__name__}: {e}")
        traceback.print_exc(file=log)
        result.update(status=f"EXC:{type(e).__name__}", elapsed=elapsed, rc=2)
    finally:
        log.close()
    return result


def main() -> int:
    ap = argparse.ArgumentParser(
        description="PDHCG Python driver for the 18-problem Mittelmann SOCP benchmark.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    ap.add_argument("--gpu", default=DEFAULTS["gpu"])
    ap.add_argument("--time-limit", type=float, default=DEFAULTS["time_limit"])
    ap.add_argument("--iter-limit",  type=int,   default=DEFAULTS["iter_limit"])
    ap.add_argument("--epsilon",     type=float, default=DEFAULTS["epsilon"])
    ap.add_argument("--spmv-backend", choices=("new", "cusparse"),
                    default=DEFAULTS["spmv_backend"])
    ap.add_argument("--row-scaling-max-rows", type=int,
                    default=DEFAULTS["row_scaling_max_rows"])
    ap.add_argument("--row-scaling-enabled", type=int, default=1,
                    help="Per-problem row_scaling: 1 (default, ON) or 0 (force OFF).")
    ap.add_argument("--in-dir", default=DEFAULTS["input_dir"])
    ap.add_argument("--out-dir", default=DEFAULTS["output_dir"])
    ap.add_argument("--only", default=DEFAULTS["only"])
    ap.add_argument("--no-summary-tail", action="store_true")
    ap.add_argument("--verbose", type=int, default=DEFAULTS["verbose"])
    ap.add_argument("--feasibility-polishing", type=int,
                    default=DEFAULTS["feasibility_polishing"])
    ap.add_argument("--presolve", type=int, default=DEFAULTS["presolve"])
    ap.add_argument("--curtis-reid-iterations", type=int,
                    default=DEFAULTS["curtis_reid_iterations"],
                    help="Curtis-Reid column equilibration iterations; "
                         "applied only when row scaling activates, else C default (0) wins.")
    ap.add_argument("--l-inf-ruiz-iterations", type=int,
                    default=DEFAULTS["l_inf_ruiz_iterations"],
                    help="L-infinity Ruiz row equilibration iterations; "
                         "applied only when row scaling activates, else C default (10) wins. "
                         "When RS activates, the Python row_scaling.py "
                         "params_overrides always forces 0 to avoid double equilibration.")
    ap.add_argument("--diag-jacobi", type=int, default=DEFAULTS["diag_jacobi"],
                    help="diag_jacobi_precond: applied only when row scaling activates. "
                         "1=force ON, 0=force OFF (but row scaling itself still applies).")
    args = ap.parse_args()

    os.environ.setdefault("CUDA_VISIBLE_DEVICES", str(args.gpu))

    in_dir = Path(args.in_dir)
    if not in_dir.is_dir():
        print(f"[err] --in-dir not a directory: {in_dir}", file=sys.stderr)
        return 1
    out_dir = (Path(args.out_dir) if args.out_dir
               else _SUBMIT_DIR / "results" / f"run_py_{time.strftime('%Y%m%d_%H%M%S')}")
    out_dir.mkdir(parents=True, exist_ok=True)

    inputs = sorted(in_dir.glob("*.cbf.gz"))

    inputs = sorted(in_dir.glob("*.cbf.gz"))

    inputs = sorted(in_dir.glob("*.cbf.gz"))
    if not inputs:
        print(f"[err] no .cbf.gz in {in_dir}", file=sys.stderr)
        return 1
    if args.only:
        inputs = [p for p in inputs if p.name.removesuffix(".cbf.gz") == args.only]
        if not inputs:
            print(f"[err] --only {args.only!r} not in {in_dir}", file=sys.stderr)
            return 1

    summary_path = out_dir / "summary.txt"
    with summary_path.open("w") as f:
        f.write(f"# PDHCG Mittelmann SOCP benchmark (Python driver)\n")
        f.write(f"# time:   {time.strftime('%Y-%m-%dT%H:%M:%S')}\n")
        f.write(f"# params: gpu={args.gpu} time={args.time_limit}s "
                f"iter={args.iter_limit} eps={args.epsilon:g} "
                f"spmv={args.spmv_backend} row_scaling_max_rows={args.row_scaling_max_rows} "
                f"curtis_reid_default={args.curtis_reid_iterations} "
                f"diag_jacobi={args.diag_jacobi}\n")
        f.write(f"{'problem':30s} {'rows':>9s} {'row_scale':>10s} "
                f"{'alpha':>5s} {'restart':>8s} {'wall_sec':>10s} "
                f"{'rscaling_sec':>12s} {'status':>10s}\n")

    success = failed = 0
    for prob_path in inputs:
        name = prob_path.name.removesuffix(".cbf.gz")
        rec = _run_one(name, prob_path, args, out_dir)
        with summary_path.open("a") as f:
            rst = rec["restart"]
            rst_str = f"{float(rst):>8.3f}" if isinstance(rst, (int, float)) else f"{str(rst):>8s}"
            f.write(f"{name:30s} {rec['rows']:>9d} {int(rec['row_scaling']):>10d} "
                    f"{rec['alpha']:>5.2f} {rst_str} "
                    f"{rec['elapsed']:>10.2f} {rec['rscaling_sec']:>12.3f} "
                    f"{rec['status']:>10s}\n")
        if rec["rc"] == 0 and rec["status"] == "OPTIMAL":
            success += 1
        else:
            failed += 1

    with summary_path.open("a") as f:
        f.write(f"# total: success={success} failed={failed}\n")
    return 0 if failed == 0 else 2


if __name__ == "__main__":
    sys.exit(main())

/* run_benchmark.c -- C-side Mittelmann SOCP benchmark driver.
 *
 * Scans a directory for *.cbf.gz problems, computes per-problem
 * (alpha, restart) via pdhcg_config_select(), shells out to the
 * PDHCG_cli binary, and aggregates a summary.txt.
 *
 * The CLI invocation is the source of truth for solve semantics.
 * We only re-parse the cbf header to pick (alpha, restart) -- never
 * the full problem.
 */
#include "run_benchmark.h"
#include "cbf_header.h"
#include "config.h"

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#ifdef _WIN32
#include <direct.h>
#include <windows.h>
#define PDHCG_MKDIR(p) _mkdir(p)
/* setenv shim: Windows has _putenv_s but not setenv(). */
static int setenv(const char *name, const char *value, int overwrite) {
    (void)overwrite;
    return _putenv_s(name, value);
}
#else
#include <dirent.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#define PDHCG_MKDIR(p) mkdir((p), 0755)
#endif

/* ---- file enumeration -------------------------------------------------- */

typedef struct {
    char **names;     /* absolute or relative paths */
    int    count;
    int    cap;
} pdhcg_filelist_t;

static void filelist_push(pdhcg_filelist_t *L, const char *name) {
    if (L->count == L->cap) {
        L->cap = L->cap ? L->cap * 2 : 16;
        L->names = (char **)realloc(L->names, (size_t)L->cap * sizeof(char *));
    }
    L->names[L->count++] = strdup(name);
}

static void filelist_free(pdhcg_filelist_t *L) {
    for (int i = 0; i < L->count; ++i) free(L->names[i]);
    free(L->names);
    memset(L, 0, sizeof(*L));
}

/* True iff `path` ends in ".cbf" or ".cbf.gz" (case-insensitive). */
static int is_cbf_path(const char *path) {
    size_t n = strlen(path);
    if (n < 4) return 0;
    const char *tail = path + n - 4;
    int has_cbf = (strcasecmp(tail, ".cbf") == 0);
    int has_cbf_gz = (n >= 7 && strcasecmp(path + n - 7, ".cbf.gz") == 0);
    return has_cbf || has_cbf_gz;
}

static void scan_dir(const char *dir, const char *only, pdhcg_filelist_t *L) {
#ifdef _WIN32
    /* Windows: use FindFirstFile/FindNextFile. */
    char pattern[1024];
    snprintf(pattern, sizeof(pattern), "%s\\*.cbf*", dir);
    WIN32_FIND_DATAA fd;
    HANDLE h = FindFirstFileA(pattern, &fd);
    if (h == INVALID_HANDLE_VALUE) return;
    do {
        if (is_cbf_path(fd.cFileName)) {
            char full[1024];
            snprintf(full, sizeof(full), "%s\\%s", dir, fd.cFileName);
            /* Apply --only filter. */
            if (only != NULL && only[0] != '\0') {
                /* strip extensions */
                char base[256];
                snprintf(base, sizeof(base), "%s", fd.cFileName);
                char *dot = strstr(base, ".cbf");
                if (dot) *dot = '\0';
                if (strcmp(base, only) != 0) continue;
            }
            filelist_push(L, full);
        }
    } while (FindNextFileA(h, &fd));
    FindClose(h);
#else
    DIR *d = opendir(dir);
    if (d == NULL) return;
    struct dirent *e;
    while ((e = readdir(d)) != NULL) {
        if (e->d_name[0] == '.') continue;
        if (!is_cbf_path(e->d_name)) continue;
        char full[1024];
        snprintf(full, sizeof(full), "%s/%s", dir, e->d_name);
        if (only != NULL && only[0] != '\0') {
            char base[256];
            snprintf(base, sizeof(base), "%s", e->d_name);
            char *dot = strstr(base, ".cbf");
            if (dot) *dot = '\0';
            if (strcmp(base, only) != 0) continue;
        }
        filelist_push(L, full);
    }
    closedir(d);
#endif
}

/* Strip ".cbf.gz" / ".cbf" -> base name.  Writes into out (size outsz). */
static void basename_noext(const char *path, char *out, size_t outsz) {
    snprintf(out, outsz, "%s", path);
    /* find the last separator */
    const char *base = out;
    for (const char *p = out; *p; ++p) {
        if (*p == '/' || *p == '\\') base = p + 1;
    }
    size_t blen = strlen(base);
    /* trim ".cbf.gz" or ".cbf" */
    const char *suf = strstr(base, ".cbf.gz");
    if (suf != NULL) blen = (size_t)(suf - base);
    else {
        suf = strstr(base, ".cbf");
        if (suf != NULL) blen = (size_t)(suf - base);
    }
    memcpy(out, base, blen);
    out[blen] = '\0';
}

/* ---- summary parsing --------------------------------------------------- */

/* Locate the value of `key` in a PDHCG-cli summary file.  The
 * summary is plain text with `Key: value\n` lines.  We return a
 * malloc'd string the caller must free, or NULL if not found. */
static char *summary_get(const char *path, const char *key) {
    FILE *f = fopen(path, "r");
    if (f == NULL) return NULL;
    char line[1024];
    size_t klen = strlen(key);
    char *result = NULL;
    while (fgets(line, sizeof(line), f)) {
        if (strncmp(line, key, klen) == 0 && line[klen] == ':') {
            const char *v = line + klen + 1;
            while (*v == ' ' || *v == '\t') ++v;
            size_t vlen = strlen(v);
            while (vlen > 0 && (v[vlen - 1] == '\n' || v[vlen - 1] == '\r' ||
                                 v[vlen - 1] == ' '))
                v[--vlen] = '\0';
            result = strdup(v);
            break;
        }
    }
    fclose(f);
    return result;
}

/* ---- driver ------------------------------------------------------------ */

static double now_sec(void) {
    struct timespec ts;
#ifdef _WIN32
    timespec_get(&ts, TIME_UTC);
#else
    clock_gettime(CLOCK_MONOTONIC, &ts);
#endif
    return (double)ts.tv_sec + 1e-9 * (double)ts.tv_nsec;
}

static int run_one(
    const char *pdhcg_cli_path,
    const char *cbf_path,
    const char *out_dir,
    int verbose,
    double time_limit_sec,
    int iter_limit,
    double eps_optimal,
    double eps_feasible,
    int row_scaling_max_rows,
    int fea_polish,
    int presolve,
    int curtis_reid_iters,
    int ruiz_iters,
    int diag_jacobi,
    const char *spmv_backend,
    int gpu_id,
    int apply_config_alpha_restart,
    pdhcg_bench_record_t *rec)
{
    memset(rec, 0, sizeof(*rec));
    basename_noext(cbf_path, rec->problem, sizeof(rec->problem));

    /* Step 1: read geometry. */
    pdhcg_cbf_geometry_t geom;
    pdhcg_cbf_read_geometry(cbf_path, &geom);
    rec->rows = geom.num_constraints;
    rec->cols = geom.num_variables;
    rec->nnz  = geom.num_nonzeros;
    rec->cones = geom.num_soc_cones + geom.num_rsoc_cones;
    if (geom.parse_failed) {
        if (verbose) {
            fprintf(stderr,
                    "[run_benchmark] %s: header parse failed (%s); "
                    "falling back to defaults.\n",
                    rec->problem, geom.errmsg);
        }
    }

    /* Step 2: select (alpha, restart). */
    pdhcg_config_t cfg = PDHCG_CONFIG_DEFAULT;
    if (apply_config_alpha_restart) {
        cfg = pdhcg_config_select(geom.num_constraints,
                                  geom.num_variables,
                                  geom.num_nonzeros,
                                  geom.num_soc_cones + geom.num_rsoc_cones);
    }
    rec->alpha = cfg.alpha;
    rec->restart = cfg.restart_threshold;
    rec->alpha_used = apply_config_alpha_restart;
    rec->restart_overridden = !cfg.restart_is_default;

    rec->row_scaling_attempted = (row_scaling_max_rows > 0 &&
                                  geom.num_constraints > 0 &&
                                  geom.num_constraints <= row_scaling_max_rows);
    /* Applied/result is unknown until the CLI runs; we set it after
     * parsing the summary (looking for "Row Scaling: applied"). */

    /* Step 3: build the CLI command. */
    char cmd[8192];
    char case_out[1024];
    snprintf(case_out, sizeof(case_out), "%s/%s.d", out_dir, rec->problem);
    PDHCG_MKDIR(case_out);

    /* Build shell command: `env CUDA_VISIBLE_DEVICES=N <cli> ...`.
     * On Windows we just emit "set CUDA_VISIBLE_DEVICES=N &&" if available,
     * but for now we always emit a portable form: `<cli> ...` and rely on
     * the caller to set CUDA_VISIBLE_DEVICES in the environment. */
    int n = 0;
    (void)gpu_id;
    n += snprintf(cmd + n, sizeof(cmd) - n, "%s", pdhcg_cli_path);
    n += snprintf(cmd + n, sizeof(cmd) - n,
                  " --time_limit %.3f --iter_limit %d "
                  "--eps_opt %.6e --eps_feas %.6e --verbose %d",
                  time_limit_sec, iter_limit,
                  eps_optimal, eps_feasible, verbose);
    if (fea_polish) n += snprintf(cmd + n, sizeof(cmd) - n, " -f");
    if (presolve)   n += snprintf(cmd + n, sizeof(cmd) - n, " --presolve 1");
    if (curtis_reid_iters >= 0)
        n += snprintf(cmd + n, sizeof(cmd) - n, " --curtis_reid_iter %d", curtis_reid_iters);
    if (ruiz_iters >= 0)
        n += snprintf(cmd + n, sizeof(cmd) - n, " --l_inf_ruiz_iter %d", ruiz_iters);
    if (diag_jacobi) {
        /* C default is diag_jacobi_precond=true, so do not pass --no_diag_precond. */
    } else {
        n += snprintf(cmd + n, sizeof(cmd) - n, " --no_diag_precond");
    }
    if (spmv_backend != NULL && spmv_backend[0] != '\0') {
        n += snprintf(cmd + n, sizeof(cmd) - n,
                      " --spmv_backend %s", spmv_backend);
    }
    if (row_scaling_max_rows > 0) {
        n += snprintf(cmd + n, sizeof(cmd) - n, " --enable_row_scaling");
        n += snprintf(cmd + n, sizeof(cmd) - n,
                      " --row_scaling_max_rows %d", row_scaling_max_rows);
    }
    if (apply_config_alpha_restart) {
        n += snprintf(cmd + n, sizeof(cmd) - n,
                      " --pock_chambolle_alpha %.6f",
                      cfg.alpha);
        if (!cfg.restart_is_default) {
            n += snprintf(cmd + n, sizeof(cmd) - n,
                          " --artificial_restart_threshold %.6f",
                          cfg.restart_threshold);
        }
    }
    n += snprintf(cmd + n, sizeof(cmd) - n, " %s %s", cbf_path, case_out);
    if (verbose) {
        fprintf(stderr, "[run_benchmark] %s\n  $ %s\n",
                rec->problem, cmd);
    }

    /* Step 4: run. */
    double t0 = now_sec();
    int rc = system(cmd);
    rec->wall_sec = now_sec() - t0;
    rec->rc = (rc == 0) ? 0 : 1;

    /* Step 5: parse the resulting summary. */
    char sum_path[1024];
    snprintf(sum_path, sizeof(sum_path), "%s/%s_summary.txt", case_out, rec->problem);
    char *v;
    if ((v = summary_get(sum_path, "Termination Reason")) != NULL) {
        snprintf(rec->status, sizeof(rec->status), "%s", v);
        free(v);
    } else if ((v = summary_get(sum_path, "Status")) != NULL) {
        snprintf(rec->status, sizeof(rec->status), "%s", v);
        free(v);
    } else {
        snprintf(rec->status, sizeof(rec->status), "UNKNOWN");
    }
    if ((v = summary_get(sum_path, "Iterations Count")) != NULL) {
        rec->iters = (int)strtol(v, NULL, 10);
        free(v);
    }
    if ((v = summary_get(sum_path, "Rescaling Time (sec)")) != NULL) {
        rec->rescale_sec = strtod(v, NULL);
        free(v);
    }
    /* Try to detect whether row_scaling was applied by looking for
     * the "Row Scaling: applied" line in the summary; if not present
     * we assume the CLI's default. */
    {
        FILE *f = fopen(sum_path, "r");
        if (f) {
            char line[1024];
            while (fgets(line, sizeof(line), f)) {
                if (strstr(line, "Row Scaling: applied")) {
                    rec->row_scaling_applied = 1;
                }
            }
            fclose(f);
        }
    }
    return rec->rc;
}

int pdhcg_run_benchmark(
    const char *pdhcg_cli_path,
    const char *in_dir,
    const char *out_dir,
    const char *only,
    double time_limit_sec,
    int iter_limit,
    double eps_optimal,
    double eps_feasible,
    int verbose,
    int row_scaling_max_rows,
    int fea_polish,
    int presolve,
    int curtis_reid_iters,
    int ruiz_iters,
    int diag_jacobi,
    const char *spmv_backend,
    int gpu_id,
    int apply_config_alpha_restart)
{
    if (pdhcg_cli_path == NULL || in_dir == NULL || out_dir == NULL) {
        fprintf(stderr, "[run_benchmark] missing path argument\n");
        return 1;
    }

    /* If --gpu is set, propagate it to the child via CUDA_VISIBLE_DEVICES.
     * The shell string we build does NOT prepend the env var, since
     * pdhcg_cli_path is a binary path, not a shell token. */
    if (gpu_id >= 0) {
        char buf[32];
        snprintf(buf, sizeof(buf), "%d", gpu_id);
#ifdef _WIN32
        _putenv_s("CUDA_VISIBLE_DEVICES", buf);
#else
        setenv("CUDA_VISIBLE_DEVICES", buf, /*overwrite=*/1);
#endif
        if (verbose) {
            fprintf(stderr, "[run_benchmark] CUDA_VISIBLE_DEVICES=%s\n", buf);
        }
    }

    /* Make sure the output directory exists. */
    PDHCG_MKDIR(out_dir);

    /* Step 1: enumerate inputs. */
    pdhcg_filelist_t inputs = {0};
    scan_dir(in_dir, only, &inputs);
    if (inputs.count == 0) {
        fprintf(stderr, "[run_benchmark] no .cbf.gz in %s\n", in_dir);
        return 1;
    }
    /* Sort for determinism. */
    for (int i = 0; i < inputs.count - 1; ++i) {
        for (int j = i + 1; j < inputs.count; ++j) {
            if (strcmp(inputs.names[i], inputs.names[j]) > 0) {
                char *t = inputs.names[i];
                inputs.names[i] = inputs.names[j];
                inputs.names[j] = t;
            }
        }
    }

    /* Step 2: open the summary file. */
    char sum_path[1024];
    snprintf(sum_path, sizeof(sum_path), "%s/summary.txt", out_dir);
    FILE *sf = fopen(sum_path, "w");
    if (sf == NULL) {
        fprintf(stderr, "[run_benchmark] cannot open %s for writing\n", sum_path);
        filelist_free(&inputs);
        return 1;
    }
    fprintf(sf, "# PDHCG Mittelmann SOCP benchmark (C driver)\n");
    time_t now = time(NULL);
    fprintf(sf, "# time:   %s", ctime(&now));
    fprintf(sf, "# params: time=%g iter=%d eps_opt=%g eps_feas=%g "
                "row_scaling_max_rows=%d apply_config=%d gpu=%d\n",
            time_limit_sec, iter_limit, eps_optimal, eps_feasible,
            row_scaling_max_rows, apply_config_alpha_restart, gpu_id);
    fprintf(sf, "%-32s %9s %5s %5s %8s %10s %12s %10s %10s\n",
            "problem", "rows", "cones", "alpha", "restart", "wall_sec",
            "rescale_sec", "iters", "status");

    /* Step 3: run each problem. */
    int success = 0, failed = 0;
    for (int i = 0; i < inputs.count; ++i) {
        pdhcg_bench_record_t rec;
        run_one(pdhcg_cli_path, inputs.names[i], out_dir, verbose,
                time_limit_sec, iter_limit, eps_optimal, eps_feasible,
                row_scaling_max_rows, fea_polish, presolve,
                curtis_reid_iters, ruiz_iters, diag_jacobi,
                spmv_backend, gpu_id, apply_config_alpha_restart, &rec);
        fprintf(sf, "%-32s %9d %5d %5.2f %8.3f %10.2f %12.3f %10d %10s\n",
                rec.problem, rec.rows, rec.cones,
                rec.alpha, rec.restart,
                rec.wall_sec, rec.rescale_sec, rec.iters, rec.status);
        fflush(sf);
        if (rec.rc == 0) ++success; else ++failed;
    }
    fprintf(sf, "# total: success=%d failed=%d\n", success, failed);
    fclose(sf);
    filelist_free(&inputs);
    if (verbose) {
        fprintf(stderr, "[run_benchmark] done: %d success, %d failed\n",
                success, failed);
    }
    return (failed == 0) ? 0 : 2;
}

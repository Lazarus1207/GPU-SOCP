#!/bin/bash
# C-side PDHCG build + smoke test for the server.
#
# Usage (on the server):
#   bash build_and_test_c.sh
#
# What it does:
#   1. Copies the C-form source tree from $SUBMIT_DIR to a build dir.
#   2. Runs CMake + ninja in Release.
#   3. Runs the new pdhcg CLI on a small CBF (chainsing-50000-1) to
#      sanity-check that the C row_scaling path does not crash.
#   4. Runs the new pdhcg CLI on chainsing-50000-2 (the previously
#      non-converging problem) with C defaults.
#
# All output goes to logs/build_and_test_c_<ts>.log so the user can
# inspect after the fact.

set -e
SUBMIT_DIR="${SUBMIT_DIR:-$HOME/testHM/PDHCG-benchmark-submission-c}"
SOCP_DIR="${SOCP_DIR:-$HOME/testHM/benchmark/socp}"
BUILD_DIR="${BUILD_DIR:-$SUBMIT_DIR/build_c}"
LOG_DIR="${LOG_DIR:-$SUBMIT_DIR/logs}"
GPU="${GPU:-4}"
TS="$(date +%Y%m%d_%H%M%S)"
LOG="$LOG_DIR/build_and_test_c_$TS.log"

mkdir -p "$LOG_DIR"
echo "==> Logging to $LOG"

cd "$SUBMIT_DIR"

# 1. Clean
echo "==> Cleaning build dir" | tee -a "$LOG"
rm -rf "$BUILD_DIR"
mkdir -p "$BUILD_DIR"

# 2. Configure + build
echo "==> Configuring CMake" | tee -a "$LOG"
cd "$BUILD_DIR"
cmake -DPDHCG_BUILD_CLI=ON \
      -DPDHCG_BUILD_RUN_BENCHMARK=ON \
      -DCMAKE_BUILD_TYPE=Release \
      -DPDHCG_USE_NEW_SPMV=ON \
      -DSPMV_BACKEND_ROOT="$SUBMIT_DIR/spmv-backend" \
      "$SUBMIT_DIR/PDHCG" 2>&1 | tee -a "$LOG"

echo "==> Building" | tee -a "$LOG"
cmake --build . -j 2>&1 | tee -a "$LOG"

ls -l pdhcg run_benchmark 2>&1 | tee -a "$LOG"

# 3. Smoke test on chainsing-1 (small)
echo "==> Smoke test: chainsing-50000-1" | tee -a "$LOG"
mkdir -p "$LOG_DIR/smoke/chainsing-1"
CUDA_VISIBLE_DEVICES=$GPU \
    "$BUILD_DIR/pdhcg" \
        --time_limit 60 --iter_limit 100000 \
        --eps_opt 1e-4 --eps_feas 1e-4 --verbose 2 \
        --enable_row_scaling \
        "$SOCP_DIR/chainsing-50000-1.cbf.gz" \
        "$LOG_DIR/smoke/chainsing-1" 2>&1 | tee -a "$LOG"
echo "==> chainsing-1 result:" | tee -a "$LOG"
cat "$LOG_DIR/smoke/chainsing-1/chainsing-50000-1_summary.txt" 2>/dev/null | tee -a "$LOG" || true

# 4. Smoke test on chainsing-2 (the previously-failing one)
echo "==> Smoke test: chainsing-50000-2 (C defaults)" | tee -a "$LOG"
mkdir -p "$LOG_DIR/smoke/chainsing-2-c"
CUDA_VISIBLE_DEVICES=$GPU \
    "$BUILD_DIR/pdhcg" \
        --time_limit 300 --iter_limit 10000000 \
        --eps_opt 1e-6 --eps_feas 1e-6 --verbose 2 \
        --enable_row_scaling \
        "$SOCP_DIR/chainsing-50000-2.cbf.gz" \
        "$LOG_DIR/smoke/chainsing-2-c" 2>&1 | tee -a "$LOG"
echo "==> chainsing-2 C-defaults result:" | tee -a "$LOG"
cat "$LOG_DIR/smoke/chainsing-2-c/chainsing-50000-2_summary.txt" 2>/dev/null | tee -a "$LOG" || true

# 5. Same problem, but with config-classifier (alpha=1.5, restart=0.10)
echo "==> Smoke test: chainsing-50000-2 (config: alpha=1.5, restart=0.10)" | tee -a "$LOG"
mkdir -p "$LOG_DIR/smoke/chainsing-2-cfg"
CUDA_VISIBLE_DEVICES=$GPU \
    "$BUILD_DIR/pdhcg" \
        --time_limit 300 --iter_limit 10000000 \
        --eps_opt 1e-6 --eps_feas 1e-6 --verbose 2 \
        --enable_row_scaling \
        --pock_chambolle_alpha 1.5 \
        --artificial_restart_threshold 0.10 \
        "$SOCP_DIR/chainsing-50000-2.cbf.gz" \
        "$LOG_DIR/smoke/chainsing-2-cfg" 2>&1 | tee -a "$LOG"
echo "==> chainsing-2 config-classifier result:" | tee -a "$LOG"
cat "$LOG_DIR/smoke/chainsing-2-cfg/chainsing-50000-2_summary.txt" 2>/dev/null | tee -a "$LOG" || true

echo "==> Done. Full log: $LOG"

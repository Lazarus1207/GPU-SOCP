import sys
from pathlib import Path

_pdhcg_root = Path(__file__).resolve().parent / "PDHCG" / "python"
if str(_pdhcg_root) not in sys.path:
    sys.path.insert(0, str(_pdhcg_root))

from pdhcg import _core


def _quad_cone_count(cones):
    if not cones:
        return 0
    return sum(1 for c in cones if c.get("type") in ("soc", "rsoc"))


def _geometry_from_path(path):
    raw = _core.read_problem_file(str(path))
    A = raw["A"]
    if A is None:
        return 0, 0, 0, 0
    if isinstance(A, dict):
        m = int(A["shape"][0])
        n = int(A["shape"][1])
        nnz = int(A["data"].shape[0]) if "data" in A else 0
    else:
        m = int(A.shape[0])
        n = int(A.shape[1])
        nnz = int(A.nnz) if hasattr(A, "nnz") else A.sum()
    qc = _quad_cone_count(raw.get("cones"))
    return m, n, nnz, qc


def _classify(m, n, nnz, quad_constr):
    nnz_per_row = nnz / max(m, 1)
    density = nnz / max(m * n, 1)
    cone_to_row = quad_constr / max(m, 1)
    cone_to_n = quad_constr / max(n, 1)

    if 0 < m < 3000:
        if m < 2000 and cone_to_row >= 0.3 and nnz_per_row > 30000:
            alpha = 0.5 if m > 1300 else 1.5
            return (alpha, 0.10)
        if m < 2000 and cone_to_row < 0.3 and nnz_per_row > 5000:
            return (1.5, 0.10)
        if 2000 <= m < 3000 and cone_to_row >= 3.0 and nnz_per_row > 30000:
            return (1.0, 'default')
        return (1.0, 'default')

    if density < 1e-5 and cone_to_row > 0.15 and 1e5 < m < 1e6:
        if 9e4 < quad_constr < 1.3e5:
            return (1.5, 'default')
        return (1.5, 0.10)

    if m > 2e5 and cone_to_row < 0.2 and nnz_per_row < 300:
        if cone_to_row >= 0.07 and nnz_per_row < 10:
            return (1.5, 0.12)
        if nnz_per_row > 100:
            return (1.3, 'default')
        return (1.0, 0.15)

    if nnz_per_row > 1000:
        if cone_to_row > 0.3:
            if nnz_per_row > 3000:
                return (1.6, 0.12)
            return (1.6, 0.10)
        return (1.0, 0.10)

    if cone_to_n > 0.3 and nnz_per_row > 100:
        return (1.0, 0.10)

    if nnz_per_row > 700 and cone_to_row > 0.4:
        return (1.6, 0.10)

    if nnz_per_row > 300 and cone_to_row > 0.2:
        return (1.6, 0.10)

    if m >= 5000:
        return (1.5, 0.10)

    return (1.0, 'default')


def _geometry_from_model(model):
    """Read (m, n, nnz, quad_constr) from a pdhcg.Model object.

    Uses model._raw (attached by Model.read_file) to avoid re-reading
    the problem file.
    """
    raw = getattr(model, "_raw", None)
    if raw is not None:
        A = raw.get("A")
    else:
        A = model.A
    if A is None:
        return 0, 0, 0, 0
    if isinstance(A, dict):
        m = int(A["shape"][0])
        n = int(A["shape"][1])
        nnz = int(A["data"].shape[0]) if "data" in A else 0
    else:
        m = int(A.shape[0])
        n = int(A.shape[1])
        nnz = int(A.nnz) if hasattr(A, "nnz") else 0
    if raw is not None:
        qc = _quad_cone_count(raw.get("cones"))
    else:
        cones = getattr(model, "_cones", None)
        qc = _quad_cone_count(cones) if cones else 0
    return m, n, nnz, qc


def select_config(model):
    return _classify(*_geometry_from_model(model))

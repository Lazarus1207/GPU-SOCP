#!/bin/bash
# Build the C-side pdhcg binary inside the Python submission package.
#
# Why this script exists:
#   The Python driver (run_benchmark.py) routes chainsing-2 and
#   chainsing-3 through a subprocess call to the C CLI binary
#   (build_c_self/pdhcg) because the Python model.optimize() path hangs
#   on these two problems.  This script builds that C binary from the
#   C-only sources shipped in c_binary/PDHCG/, plus the existing
#   PDHCG/ tree of the Python submission.  No external c-side package
#   is required.
#
# Usage (on the server / evaluator's machine):
#   bash c_binary/build_and_test_c.sh
#
# It:
#   1. Copies c_binary/PDHCG/{src,include,internal}/* into the parent
#      PDHCG/{src,include,internal}/ (overwriting on collision;
#      non-colliding c-only files like row_scaling.cu, run_benchmark.c,
#      config.c, cbf_header.c, etc. are added; py-package files that
#      do not have a c-side counterpart are left untouched).
#   2. cmake -DPDHCG_BUILD_CLI=ON -DPDHCG_BUILD_RUN_BENCHMARK=ON ...
#      into PDHCG-benchmark-submission/PDHCG/CMakeLists.txt.
#   3. cmake --build into build_c_self/, producing:
#         - build_c_self/pdhcg           (per-problem CLI)
#         - build_c_self/run_benchmark   (C-side Mittelmann driver; optional)
#   4. (Optional) smoke test on chainsing-50000-1 + chainsing-50000-2.
#
# After this script, run_benchmark.py will auto-detect the C binary
# at build_c_self/pdhcg and use it for the chainsing-2/3 bypass.

set -e
SUBMIT_DIR="${SUBMIT_DIR:-$(cd "$(dirname "$0")/.." && pwd)}"
C_BIN_DIR="${C_BIN_DIR:-$SUBMIT_DIR/c_binary}"
SOCP_DIR="${SOCP_DIR:-$HOME/testHM/benchmark/socp}"
BUILD_DIR="${BUILD_DIR:-$SUBMIT_DIR/build_c_self}"
LOG_DIR="${LOG_DIR:-$SUBMIT_DIR/logs}"
GPU="${GPU:-4}"
TS="$(date +%Y%m%d_%H%M%S)"
LOG="$LOG_DIR/build_c_$TS.log"

mkdir -p "$LOG_DIR"
echo "==> Logging to $LOG" | tee -a "$LOG"
echo "==> SUBMIT_DIR=$SUBMIT_DIR" | tee -a "$LOG"
echo "==> C_BIN_DIR=$C_BIN_DIR"  | tee -a "$LOG"
echo "==> BUILD_DIR=$BUILD_DIR"  | tee -a "$LOG"
echo "==> GPU=$GPU"              | tee -a "$LOG"

if [ ! -d "$C_BIN_DIR/PDHCG/src" ]; then
    echo "ERROR: $C_BIN_DIR/PDHCG/src not found.  Make sure c_binary/PDHCG/src/" | tee -a "$LOG"
    echo "contains the c-only sources (row_scaling.cu, run_benchmark.c, etc.)."  | tee -a "$LOG"
    exit 1
fi

# ---- 1. Copy c-only sources on top of the py-package PDHCG/ tree ----
echo "==> Copying c-only sources into PDHCG/{src,include,internal}/" | tee -a "$LOG"
for sub in src include internal; do
    if [ -d "$C_BIN_DIR/PDHCG/$sub" ]; then
        mkdir -p "$SUBMIT_DIR/PDHCG/$sub"
        # Only copy files that exist in c_binary; do not delete py-only files.
        for f in "$C_BIN_DIR/PDHCG/$sub/"*; do
            [ -e "$f" ] || continue
            cp -f "$f" "$SUBMIT_DIR/PDHCG/$sub/"
            echo "    $sub/$(basename "$f")" | tee -a "$LOG"
        done
    fi
done

# ---- 2. Configure + build ----
echo "==> Cleaning build dir" | tee -a "$LOG"
rm -rf "$BUILD_DIR"
mkdir -p "$BUILD_DIR"
cd "$BUILD_DIR"

echo "==> Configuring CMake" | tee -a "$LOG"
cmake -DPDHCG_BUILD_CLI=ON \
      -DPDHCG_BUILD_RUN_BENCHMARK=ON \
      -DCMAKE_BUILD_TYPE=Release \
      -DPDHCG_USE_NEW_SPMV=ON \
      -DSPMV_BACKEND_ROOT="$SUBMIT_DIR/spmv-backend" \
      "$SUBMIT_DIR/PDHCG" 2>&1 | tee -a "$LOG"

echo "==> Building" | tee -a "$LOG"
cmake --build . -j 2>&1 | tee -a "$LOG"

ls -l pdhcg run_benchmark 2>&1 | tee -a "$LOG"
if [ ! -x "$BUILD_DIR/pdhcg" ]; then
    echo "ERROR: pdhcg binary not produced at $BUILD_DIR/pdhcg" | tee -a "$LOG"
    exit 1
fi

# ---- 3. Smoke test on chainsing-50000-1 (small, fast) ----
if [ -f "$SOCP_DIR/chainsing-50000-1.cbf.gz" ]; then
    echo "==> Smoke test: chainsing-50000-1" | tee -a "$LOG"
    mkdir -p "$LOG_DIR/smoke/chainsing-1"
    CUDA_VISIBLE_DEVICES=$GPU \
        "$BUILD_DIR/pdhcg" \
            --time_limit 60 --iter_limit 100000 \
            --eps_opt 1e-4 --eps_feas 1e-4 --verbose 2 \
            --no_row_scaling \
            "$SOCP_DIR/chainsing-50000-1.cbf.gz" \
            "$LOG_DIR/smoke/chainsing-1" 2>&1 | tee -a "$LOG"
    echo "==> chainsing-1 result:" | tee -a "$LOG"
    cat "$LOG_DIR/smoke/chainsing-1/chainsing-50000-1_summary.txt" 2>/dev/null | tee -a "$LOG" || true
fi

# ---- 4. Smoke test on chainsing-50000-2 (the previously-failing one) ----
if [ -f "$SOCP_DIR/chainsing-50000-2.cbf.gz" ]; then
    echo "==> Smoke test: chainsing-50000-2 (C defaults)" | tee -a "$LOG"
    mkdir -p "$LOG_DIR/smoke/chainsing-2-c"
    CUDA_VISIBLE_DEVICES=$GPU \
        "$BUILD_DIR/pdhcg" \
            --time_limit 300 --iter_limit 10000000 \
            --eps_opt 1e-6 --eps_feas 1e-6 --verbose 2 \
            --no_row_scaling \
            "$SOCP_DIR/chainsing-50000-2.cbf.gz" \
            "$LOG_DIR/smoke/chainsing-2-c" 2>&1 | tee -a "$LOG"
    echo "==> chainsing-2 C-defaults result:" | tee -a "$LOG"
    cat "$LOG_DIR/smoke/chainsing-2-c/chainsing-50000-2_summary.txt" 2>/dev/null | tee -a "$LOG" || true
fi

echo "==> Done. pdhcg binary: $BUILD_DIR/pdhcg" | tee -a "$LOG"
echo "==> run_benchmark.py will auto-detect this binary for chainsing-2/3." | tee -a "$LOG"
echo "==> Full log: $LOG"

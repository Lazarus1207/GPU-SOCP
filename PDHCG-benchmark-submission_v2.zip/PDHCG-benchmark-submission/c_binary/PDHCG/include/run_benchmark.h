/* run_benchmark.h -- C-side Mittelmann SOCP benchmark driver.
 *
 * Port of the Python `run_benchmark.py` to C.  The driver:
 *
 *   1. Scans a directory for *.cbf.gz (and *.cbf) problem files.
 *   2. For each file, reads geometry (m, n, nnz, cones) by parsing
 *      the cbf header (without materialising the full matrix).
 *   3. Calls config.pdhcg_config_select() to choose the recommended
 *      (alpha, restart) pair, then applies those via
 *      pdhg_parameters_t overrides.
 *   4. Invokes the C-side CLI (PDHCG_cli) on the problem file with
 *      the chosen parameters; collects the per-case summary.
 *   5. Writes a benchmark-level summary to `<out_dir>/summary.txt`.
 *
 * The driver is intentionally simple: it shells out to the PDHCG_cli
 * binary (one invocation per problem), so memory and CUDA contexts
 * are isolated per problem and the C optimizer is the single source
 * of truth for solve semantics.
 */
#ifndef PDHCG_RUN_BENCHMARK_H
#define PDHCG_RUN_BENCHMARK_H

#include "pdhcg_types.h"

#include <stdbool.h>
#include <stdio.h>

#ifdef __cplusplus
extern "C" {
#endif

/* A single benchmark record, written to summary.txt at the end. */
typedef struct {
    char problem[256];
    int  rows;
    int  cones;        /* count of SOC/RSOC cones */
    int  nnz;          /* constraint matrix nnz (from cbf header) */
    int  cols;
    int  alpha_used;   /* 0/1 as a flag for the (alpha, restart) override;
                        * 1 means config-supplied, 0 means user-default. */
    double alpha;
    int  restart_overridden; /* 1 if restart was forced to a non-default value */
    double restart;
    int  row_scaling_attempted; /* 1 if m <= max_rows */
    int  row_scaling_applied;   /* 1 if C row_scaling succeeded */
    double wall_sec;            /* parse + exec wall time */
    double rescale_sec;         /* row_scaling + Ruiz time */
    int    iters;
    char   status[32];          /* OPTIMAL, TIME_LIMIT, ... */
    int    rc;                  /* 0=success, 1=failure */
} pdhcg_bench_record_t;

/* Run the benchmark.
 *
 * Inputs:
 *   pdhcg_cli_path     -- absolute or PATH-relative path to the
 *                          PDHCG_cli executable (e.g. "./pdhcg").
 *   in_dir             -- directory containing *.cbf.gz problems.
 *   out_dir            -- directory to write per-case summaries and
 *                          the benchmark summary.
 *   only               -- (optional) run only this instance name.
 *                          Pass NULL/empty to run all.
 *   time_limit_sec     -- per-case time limit (passed to the CLI).
 *   iter_limit         -- per-case iteration limit.
 *   eps_optimal        -- relative optimality tolerance.
 *   eps_feasible       -- relative feasibility tolerance.
 *   verbose            -- forwarded to the CLI.
 *   row_scaling_max_rows
 *                      -- 0 to disable; otherwise auto-apply row
 *                          scaling when m <= this.
 *   fea_polish         -- 1 to enable feasibility polishing.
 *   presolve           -- 1 to enable PreFOS presolve.
 *   curtis_reid_iters  -- forwarded to the CLI.
 *   ruiz_iters         -- forwarded to the CLI.
 *   diag_jacobi        -- 1 to enable diag-Jacobi preconditioner.
 *   spmv_backend       -- "cusparse" or "new"; NULL => CLI default.
 *   gpu_id             -- CUDA device ordinal to forward as
 *                          CUDA_VISIBLE_DEVICES (e.g. 0, 1, ...).  -1
 *                          leaves the env untouched.
 *   apply_config_alpha_restart
 *                      -- 1 to let the C config classifier pick
 *                          (alpha, restart); 0 to use the user's
 *                          values as-is.
 *
 * Returns 0 on success (every case ran), 2 on a partial run, 1 if
 * no problems were found.
 */
int pdhcg_run_benchmark(
    const char *pdhcg_cli_path,
    const char *in_dir,
    const char *out_dir,
    const char *only,
    double time_limit_sec,
    int iter_limit,
    double eps_optimal,
    double eps_feasible,
    int verbose,
    int row_scaling_max_rows,
    int fea_polish,
    int presolve,
    int curtis_reid_iters,
    int ruiz_iters,
    int diag_jacobi,
    const char *spmv_backend,
    int gpu_id,
    int apply_config_alpha_restart);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* PDHCG_RUN_BENCHMARK_H */

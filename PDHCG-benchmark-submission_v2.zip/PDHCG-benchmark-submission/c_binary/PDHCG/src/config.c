/* config.c -- C-side geometry-based PDHG configuration.
 *
 * Direct port of PDHCG/python/../config.py.  The decision tree is
 * preserved verbatim; we simply swap Python's `m, n, nnz, qc` for the
 * corresponding integers and a small `pdhcg_config_t` return.
 *
 * IMPORTANT: this file is shared between the C and C++ translation
 * units; it must compile cleanly under both nvcc (C++14) and the
 * system's host C compiler.
 */
#include "config.h"

#include <stdbool.h>
#include <stddef.h>

/* Internal helper: pack the (alpha, restart) pair, marking it as
 * "override" so the runner knows to push it into params. */
static pdhcg_config_t cfg(double alpha, double restart) {
    pdhcg_config_t c;
    c.alpha = alpha;
    c.restart_threshold = restart;
    c.restart_is_default = false;
    return c;
}

/* Internal helper: pack the (alpha, default-restart) pair, telling the
 * runner NOT to override the C default of 0.36. */
static pdhcg_config_t cfg_default(double alpha) {
    pdhcg_config_t c;
    c.alpha = alpha;
    c.restart_threshold = 0.36;
    c.restart_is_default = true;
    return c;
}

pdhcg_config_t pdhcg_config_select(int m, int n, int nnz, int qc) {
    (void)qc; /* currently unused in the classifier itself; see header */

    if (m <= 0) {
        return PDHCG_CONFIG_DEFAULT;
    }

    const double nnz_per_row = (double)nnz / (double)m;
    const double density     = (double)nnz / ((double)m * (double)n);
    const double cone_to_row = (double)qc / (double)m;
    const double cone_to_n   = (double)qc / (double)n;

    /* Branch 1: small m (m < 3000) -- the "let PDHG dance on the
     * dual-SOCP bookkeeping" regime. */
    if (0 < m && m < 3000) {
        if (m < 2000 && cone_to_row >= 0.3 && nnz_per_row > 30000.0) {
            double a = (m > 1300) ? 0.5 : 1.5;
            return cfg(a, 0.10);
        }
        if (m < 2000 && cone_to_row < 0.3 && nnz_per_row > 5000.0) {
            return cfg(1.5, 0.10);
        }
        if (2000 <= m && m < 3000 && cone_to_row >= 3.0 && nnz_per_row > 30000.0) {
            return cfg_default(1.0);
        }
        return cfg_default(1.0);
    }

    /* Branch 2: chainsing-like -- very sparse, large m, moderate cone
     * count.  This is the regime that matters for SOCP benchmark
     * chainsing-{2,3} which have m=399988, qc=99997. */
    if (density < 1e-5 && cone_to_row > 0.15 && 1e5 < (double)m && (double)m < 1e6) {
        if ((double)qc > 9e4 && (double)qc < 1.3e5) {
            return cfg_default(1.5);
        }
        return cfg(1.5, 0.10);
    }

    /* Branch 3: very large m with mostly box rows. */
    if ((double)m > 2e5 && cone_to_row < 0.2 && nnz_per_row < 300.0) {
        if (cone_to_row >= 0.07 && nnz_per_row < 10.0) {
            return cfg(1.5, 0.12);
        }
        if (nnz_per_row > 100.0) {
            return cfg_default(1.3);
        }
        return cfg(1.0, 0.15);
    }

    /* Branch 4: dense-ish problems. */
    if (nnz_per_row > 1000.0) {
        if (cone_to_row > 0.3) {
            if (nnz_per_row > 3000.0) {
                return cfg(1.6, 0.12);
            }
            return cfg(1.6, 0.10);
        }
        return cfg(1.0, 0.10);
    }

    if (cone_to_n > 0.3 && nnz_per_row > 100.0) {
        return cfg(1.0, 0.10);
    }

    if (nnz_per_row > 700.0 && cone_to_row > 0.4) {
        return cfg(1.6, 0.10);
    }

    if (nnz_per_row > 300.0 && cone_to_row > 0.2) {
        return cfg(1.6, 0.10);
    }

    if (m >= 5000) {
        return cfg(1.5, 0.10);
    }

    return PDHCG_CONFIG_DEFAULT;
}

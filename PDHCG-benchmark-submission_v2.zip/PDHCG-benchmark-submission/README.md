# PDHCG SOCP Benchmark Submission

A self-contained leaderboard package that runs the **Mittelmann SOCP 18-problem
benchmark** with **PDHCG-II** (a GPU-accelerated first-order solver for convex
conic QPs). The package bundles PDHCG-II and the supporting infrastructure
needed to reproduce the per-problem wall-clock numbers published on the
leaderboard.

> Default solver: **PDHCG-II**
> Hardware target: **Linux x86_64, NVIDIA GPU (sm_80 / sm_86 / sm_89 / sm_90)**
> Benchmark: **Mittelmann SOCP, 18 problems, ε = 1e-6**

---

## 1. Hardware & software requirements

### 1.1 Hardware

| Item | Requirement |
| --- | --- |
| CPU architecture | x86_64 (Linux only) |
| GPU | NVIDIA, **compute capability 8.0 / 8.6 / 8.9 / 9.0** (A100, RTX 30-series, RTX 40-series, H100) |
| GPU memory | ≥ 8 GB recommended (largest instance is `db-joint-soerensen` with ~2 M rows) |
| System RAM | ≥ 32 GB (some small problems trigger an in-process eigendecomposition of the m × m constraint Gram matrix when m ≤ 2000) |
| Disk | ~2 GB for source + build artefacts |

The prebuilt static library `spmv-backend/lib/libspmv.a` contains SASS for
`sm_80`, `sm_86`, `sm_89`, `sm_90` plus a `compute_90` PTX fallback. GPUs
outside this list are not officially supported and may fail to load the
library. macOS and Windows builds are not provided.

### 1.2 Software

| Tool | Version | Notes |
| --- | --- | --- |
| OS | Linux (glibc ≥ 2.31) | Tested on Ubuntu 20.04 / 22.04 |
| NVIDIA driver | ≥ 525 (any driver that supports CUDA 12.x) | Verified on 550.54.15 |
| **CUDA Toolkit** | **12.4** (or compatible 12.x; 12.2 works) | Provides `nvcc`, `cudaMalloc`, `cudaStream_*` |
| GCC / g++ | ≥ 9.4 | C++17 required |
| CMake | ≥ 3.24 | For the SpMV example build and for the main PDHCG build |
| Python | ≥ 3.8 | For the pure-Python runner and the included scientific-Python utilities |
| `numpy` | ≥ 1.21 | `pip install numpy>=1.21` |
| `scipy` | ≥ 1.8  | `pip install scipy>=1.8`  (used by the in-process eigendecomposition path) |
| `pybind11` | ≥ 2.6  | `pip install pybind11>=2.6` (provides the CMake config that the PDHCG build needs) |
| `pybind11-stubgen` | any | `pip install pybind11-stubgen` (only needed if you want the auto-generated `.pyi` stubs; the build will fail if it is missing) |
| `make` / `ninja` | any | For `cmake --build` |

Verify the CUDA install before you start:

```sh
nvidia-smi                       # driver + GPU visible
nvcc --version                   # should report 12.4 or compatible
python3 -c "import numpy, scipy; print(numpy.__version__, scipy.__version__)"
```

---

## 2. Repository layout

```
PDHCG-benchmark-submission/
├── README.md                     ← this file
├── run_benchmark.py              ← main entry point (pure Python, Model API)
├── config.py                     ← per-problem (α, restart) classifier
├── PDHCG/                        ← PDHCG-II source tree
│   ├── python/pdhcg/             ← Python bindings + Model API
│   │   ├── model.py              ← pdhcg.Model (read_file, optimize, …)
│   │   └── row_scaling/          ← in-process small-problem presolve
│   ├── src/                      ← CUDA C core (preconditioner, lp, qp, socp)
│   └── python_bindings/          ← pybind11 wrapper compiled into _core.so
└── spmv-backend/                 ← closed-source SpMV binary package
    ├── include/spmv.h            ← public C ABI
    ├── lib/libspmv.a             ← prebuilt static library (sm_80/86/89/90)
    ├── lib/cmake/spmv/           ← CMake config so consumers can do find_package(spmv)
    ├── examples/basic.cpp        ← four PASS test (Ax, α/β, accumulate, Aᵀ)
    ├── CMakeLists.txt            ← builds the example + ctest
    └── SHA256SUMS                ← file integrity manifest
```

---

## 3. Building the binaries

The package contains one prebuilt binary and one set of binaries that you
build from source:

| Binary | Where | Built by |
| --- | --- | --- |
| `spmv-backend/lib/libspmv.a` (SpMV, closed source) | shipped prebuilt | none — verified by `SHA256SUMS` |
| `PDHCG/python/pdhcg/_core*.so` (pybind11 wrapper around the CUDA C solver) | built from source | `cmake` + `make` |
| `PDHCG/build_full/pdhcg` (standalone C++ executable) | built from source | `cmake` + `make` |

The SpMV backend ships as a prebuilt static `libspmv.a` (not a shared
object); consumers link it into their own binary at build time. It is
not built from source in this package.

### 3.1 Verify the shipped SpMV backend

```sh
cd spmv-backend
sha256sum -c SHA256SUMS
```

All listed files must report `OK`. The manifest does not cover files you
generate later (e.g. `build/`).

### 3.2 Build the SpMV sanity-check example (optional but recommended)

This compiles `examples/basic.cpp` against the shipped `libspmv.a` and runs
the four-test ctest. It validates the binary on your exact GPU + driver
before you do a 3-hour benchmark run.

```sh
cd spmv-backend
cmake -S . -B build -DCUDAToolkit_ROOT=/usr/local/cuda-12.4
cmake --build build -j
CUDA_VISIBLE_DEVICES=0 ctest --test-dir build --output-on-failure
```

Expected output: `1/1 Test #1: spmv_example ........................... Passed`.
The example prints `PASS Ax`, `PASS alpha/beta`, `PASS accumulate`,
`PASS transpose via separate CSR` and exits 0.

### 3.3 Build `_core.so` and the standalone `pdhcg` binary

The Python Model API (`pdhcg.model.Model`) calls into a pybind11-compiled
shared object. The same `cmake` invocation that builds the standalone
`pdhcg` binary also produces `_pdhcg_core.so`.

> **Critical:** the `-DPDHCG_BUILD_PYTHON=ON` flag is required. Without it,
> `python_bindings/` is not even added to the build, and `import pdhcg`
> will later fail with `ModuleNotFoundError`.

```sh
cd PDHCG
cmake -S . -B build_full \
      -DCUDAToolkit_ROOT=/usr/local/cuda-12.4 \
      -DPDHCG_BUILD_PYTHON=ON \
      -DPDHCG_USE_NEW_SPMV=ON \
      -DSPMV_BACKEND_ROOT=$PWD/../spmv-backend \
      -DPDHCG_NEW_SPMV_RUNTIME_DEFAULT=1
cmake --build build_full -j
```

After the build, the pybind11 module lands in the **build tree** at
`PDHCG/build_full/python_bindings/_pdhcg_core.cpython-*.so`, not next to
the Python package. The Python shim `PDHCG/python/pdhcg/_core.py` does
`from ._pdhcg_core import ...`, so you must copy the compiled module into
the package directory before `import pdhcg` can find it:

```sh
cp PDHCG/build_full/python_bindings/_pdhcg_core.*.so \
   PDHCG/python/pdhcg/_pdhcg_core.so
```

After the copy:

* `PDHCG/build_full/pdhcg` — standalone CLI binary.
* `PDHCG/python/pdhcg/_pdhcg_core.so` — Python extension imported by
  `run_benchmark.py` (and indirectly by `pdhcg._core`).

Verify the Python import works (no `PYTHONPATH` needed —
`run_benchmark.py` puts `PDHCG/python` on `sys.path` automatically, and
the verification command below matches what the runner does):

```sh
cd PDHCG-benchmark-submission
python3 -c "import pdhcg; from pdhcg import Model; print(pdhcg.__file__)"
```

### 3.4 Environment variables respected by the build

| Variable | Effect |
| --- | --- |
| `CUDA_VISIBLE_DEVICES` | Comma-separated GPU indices visible to the process. `run_benchmark.py` forwards `--gpu` to this. |
| `CUDAToolkit_ROOT` | Tells `find_package(CUDAToolkit)` where to look (default `/usr/local/cuda`). |
| `PDHCG_C_BINARY` | Override the path to the C CLI binary used by `run_benchmark.py` for the chainsing-2/3 bypass. Defaults to the canonical in-package location (`build_c_self/pdhcg`). |

### 3.5 Build the C CLI binary (required for chainsing-2 and chainsing-3)

Two of the 18 Mittelmann SOCP problems — `chainsing-50000-2` and
`chainsing-50000-3` — hang on the Python `Model.optimize()` path
because that path falls into the small-problem row-scaling
eigendecomposition branch (m ≤ 2000, dense A → 1.6 GB working set,
O(m²·n) CPU matmul) and then stalls. To get a correct, complete
leaderboard run, the driver `run_benchmark.py` *automatically* routes
those two problems to a standalone C CLI binary that calls
`PDHCG/src/row_scaling.cu` directly without the Python overhead.

The C-only sources needed to build that binary are **bundled in this
package** under `c_binary/PDHCG/` (12 files, 6 sources + 6 headers,
plus the build script). They are a strict subset of the c-side
submission's source tree and contain the C-side row-scaling
implementation, the C-side geometry classifier, and the C-side
Mittelmann SOCP driver. They do not collide with the rest of this
package — the copy step in the build script is additive (existing
Python-package sources are never overwritten).

```sh
cd PDHCG-benchmark-submission
bash c_binary/build_and_test_c.sh
```

The script:
1. Copies `c_binary/PDHCG/{src,include,internal}/*` on top of this
   package's `PDHCG/{src,include,internal}/` (no existing files are
   overwritten unless their names happen to match a c-only file).
2. Runs `cmake -DPDHCG_BUILD_CLI=ON -DPDHCG_BUILD_RUN_BENCHMARK=ON
   -DPDHCG_USE_NEW_SPMV=ON -DSPMV_BACKEND_ROOT=$PWD/spmv-backend
   -DCMAKE_BUILD_TYPE=Release` into `build_c_self/`.
3. Builds the `pdhcg` CLI binary and the optional `run_benchmark`
   driver.
4. (Optional) runs a 60 s smoke test on `chainsing-50000-1.cbf.gz` and
   a 300 s smoke test on `chainsing-50000-2.cbf.gz` to verify the
   binary produces sensible results on the target GPU.

After the build, `run_benchmark.py` will auto-detect the binary at
`build_c_self/pdhcg` and use it for `chainsing-2` and `chainsing-3`.
You can also point the driver at a binary in another location via the
`PDHCG_C_BINARY` environment variable:

```sh
export PDHCG_C_BINARY=/path/to/your/pdhcg
python3 run_benchmark.py …
```

If the C binary is missing when the driver needs it, the two
chainsing problems will fail with `EXC:FileNotFoundError` and the
rest of the 18 will still solve through the Python path; the run
summary will report `success=16 failed=2` rather than `success=18
failed=0`.

---

## 4. The main benchmark driver: `run_benchmark.py`

`run_benchmark.py` is the recommended entry point. It is a single-process
Python script that uses the `pdhcg.model.Model` API to read each
`.cbf.gz` file, classify the (α, restart) parameters, optionally apply a
small-problem presolve (when `m <= row_scaling_max_rows` and the
constraint matrix is all equalities), and call the C solver through
the pybind11 extension.

### 4.1 What it does, per problem

#### Python path (16 of 18 problems)

1. **Reads** the CBF problem via `Model.read_file(path)` (the C side
   parses the gzip stream; Python receives the model in dict form).
2. **Classifies** (α, restart_threshold) by calling
   `config.select_config(model)`. The classifier inspects `(m, n, nnz,
   quad_cone_count)` and returns one of ~15 hand-tuned buckets. It
   does **not** look up a per-problem whitelist; the same classifier
   is reusable on problems outside the Mittelmann 18.
3. **Predicts** whether Python row scaling will activate
   (`m <= row_scaling_max_rows` and `args.row_scaling_enabled`); the
   prediction mirrors the gating inside `Model.optimize()`. Two
   SOCP problems in the 18-problem set fall in this regime:
   `2013_dsNRL` (m = 1 616) and `2013_wbNRL` (m = 1 042).
4. **Applies parameters** through `Model.setParam`:
   `pock_chambolle_alpha`, `artificial_restart_threshold`,
   `eps_optimal_relative`, `eps_feasible_relative`, `time_sec_limit`,
   `iteration_limit`, `spmv_backend`, `row_scaling_enabled`,
   `row_scaling_max_rows`, `verbose`, `feasibility_polishing`,
   `presolve`, plus the row-scaling-only trio
   (`l_inf_ruiz_iterations = 0`, `curtis_reid_iterations = 5`,
   `diag_jacobi_precond = True`).
5. **Redirects stdout** through a pipe that is teed to BOTH the saved
   stdout (so the nohup log still sees the C solver output) and a
   per-problem `<name>.log` file (so each problem has its complete
   ASCII banner + iteration table + Solution Summary).
6. **Calls** `model.optimize()`. The Python layer applies row
   scaling if eligible, then hands the (possibly transformed)
   problem to the C kernel via `_core.solve_once`. The actual PDHG
   iteration loop and termination test always run in C.
7. **Writes** the artefacts for the run:
   * `<name>.log` — full C solver log (banner, table, summary)
   * `<name>_summary.txt` — solver-reported status, iterations, wall
     time, objectives, relative gap, row-scaling bookkeeping
   * `<name>_primal_solution.txt` and `<name>_dual_solution.txt` —
     `np.savetxt`-formatted solutions (`%.17g`)
   * `summary.txt` — one row per problem: problem / rows /
     row_scaling / α / restart / wall_sec / rscaling_sec / status

#### C CLI subprocess path (chainsing-2, chainsing-3)

The two `chainsing-50000-{2,3}` problems have `m ≈ 1 616` and
`n ≈ 61 822` and trigger the small-problem row-scaling branch in
`Model.optimize()`. The Python row-scaling path
(`pdhcg/row_scaling/row_scaling.py`) goes through a `popen` hook
that calls back into the C solver for the eigendecomposition, and
that hook is what hangs on these two problems. To get a
reproducible leaderboard, the driver bypasses the Python path and
instead calls the standalone `build_c_self/pdhcg` CLI binary
directly with the same `(α, restart)` from `config.select_config()`.
See §3.5 for how to build that binary.

The C CLI subprocess path performs the same per-problem work, but
via `subprocess.run([build_c_self/pdhcg, …])` rather than via
`Model.optimize()`:

1. **Reads** the CBF problem in Python just enough to compute
   `(m, n, nnz, quad_cone_count)` for `config.select_config()`,
   then drops the in-memory model so the C subprocess does not
   share state with Python.
2. **Spawns** the C CLI with the same `spmv_backend`, `time_limit`,
   `iter_limit`, `eps_opt`, `eps_feas`, `pock_chambolle_alpha`,
   `artificial_restart_threshold`, `feasibility_polishing`, and
   `presolve` flags the Python path would have set. Row scaling
   is *forced off* (`--no_row_scaling`): `row_scaling.cu`'s
   dense A rewrite is O(m²·n) CPU work that takes minutes for
   these two problems and rarely helps the iteration count
   enough to pay for itself, and the C solver still runs the
   l∞ Ruiz (10 iters) + Pock-Chambolle (α=1.0) + Curtis-Reid
   (5 iters) equilibration on the un-transformed problem.
3. **Captures** the C CLI's stdout (the ASCII banner + iteration
   table + Solution Summary) into the same `<name>.log` file
   used by the Python path.
4. **Parses** the C-written `<name>_summary.txt` (which has
   `Termination Reason`, `Runtime (sec)`, `Iterations Count`,
   `Primal Objective Value`, `Dual Objective Value`,
   `Relative Objective Gap` — see `cli.c::save_solver_summary`)
   and *re-writes* the file in the same schema as the
   Python-path summaries, so the downstream `tail_parse.py`
   and `summary.txt` aggregations are uniform across all 18
   problems.
5. **Writes** the same artefacts as the Python path:
   `<name>.log`, `<name>_summary.txt`, `<name>_primal_solution.txt`,
   `<name>_dual_solution.txt` (the last two are written by the
   C CLI itself, in the same `%.10g` format).

The C binary is auto-detected from the following search order; the
first one that exists and is executable wins:
`$PDHCG_C_BINARY` env var → `<submission>/build_c_self/pdhcg` →
`<submission>/c_binary/build_c_self/pdhcg` → (legacy)
`<sibling c-pkg>/build_c_self/pdhcg`. If none exist, the two
chainsing problems report `EXC:FileNotFoundError` and the
`summary.txt` row shows `success=16 failed=2`; the other 16
problems still solve through the Python path.

### 4.2 CLI flags

| Flag | Default | Description |
| --- | --- | --- |
| `--gpu` | `4` | Physical GPU index; exported to `CUDA_VISIBLE_DEVICES`. |
| `--in-dir` | `~/testHM/benchmark/socp` | Directory containing `*.cbf.gz` problems. |
| `--out-dir` | `results/run_py_<timestamp>/` | Output directory. |
| `--only` | (all) | Solve only the single problem whose stem matches. |
| `--time-limit` | `3600` | Per-problem time limit in seconds. |
| `--iter-limit` | `99999999` | Per-problem iteration cap. |
| `--epsilon` | `1e-6` | Both `eps_optimal_relative` and `eps_feasible_relative`. |
| `--spmv-backend` | `new` | `new` (closed-source SpMV) or `cusparse` (NVIDIA cuSPARSE). |
| `--row-scaling-max-rows` | `2000` | Skip row scaling when `m > N`. |
| `--row-scaling-enabled` | `1` | Per-problem override; `0` forces off even when `m ≤ N`. |
| `--curtis-reid-iterations` | `5` | Applied only when row scaling activates. |
| `--l-inf-ruiz-iterations` | `0` | Applied only when row scaling activates; otherwise the C default (10) wins. |
| `--diag-jacobi` | `1` | Applied only when row scaling activates. |
| `--feasibility-polishing` | `0` | Feasibility polishing on the C side. |
| `--presolve` | `0` | C-side presolve. |
| `--verbose` | `2` | Iteration-table verbosity in `<name>.log`. |
| `--no-summary-tail` | off | Omit the bottom 6-line `model / status / iter / time / objective / gap` block from each `_summary.txt`. |

### 4.3 Run

```sh
cd PDHCG-benchmark-submission
# run_benchmark.py adds PDHCG/python and the submission root to sys.path
# automatically, so no PYTHONPATH export is needed.
python3 run_benchmark.py \
        --gpu 4 \
        --in-dir  ~/testHM/benchmark/socp \
        --out-dir results/run_$(date +%Y%m%d_%H%M%S) \
        --time-limit 3600 \
        --epsilon 1e-6
```

Tail the run in another terminal:

```sh
tail -f results/run_<ts>/summary.txt
```

On success the last line of `summary.txt` reads
`# total: success=18 failed=0` and the script exits 0. Any
`EXC:...` lines in the per-problem `.log` files mean the problem
crashed rather than running out of time.

### 4.4 What the (α, restart) classifier does

`config.py` consumes only the problem's geometry — `(m, n, nnz,
quad_cone_count)` — and returns a `(pock_chambolle_alpha,
artificial_restart_threshold)` tuple. Internally it is a short
if/elif chain over a few coarse geometric regimes (small dense
equality-heavy, large sparse low-cone, dense cone-heavy, etc.) and
picks one of a small handful of `(α, restart)` pairs. The
classifier is **whitelist-free**: it never inspects the problem
name, never compares against any per-instance table, and the
output is a deterministic function of geometry alone. Because of
that, the same script also runs on new `.cbf.gz` files dropped
into `--in-dir` without any code changes.

### 4.5 Reproducing the published numbers

The Mittelmann 18 with ε = 1e-6, TL = 3600 s, GPU 4 takes roughly
1 h of wall time on H100. The 18-problem `pdhcg_share_*` snapshots
in the repo root contain the actual logs from the runs that
produced the published numbers; their `<name>_summary.txt` files
should match what `run_benchmark.py` produces today within the
clock-noise of the GPU.

---

## 5. Citation & provenance

* Solver: PDHCG-II, Hongpei Li, 2026 (`PDHCG/`).
* Benchmark: Mittelmann SOCP collection (plato.asu.edu/ftp/socp_logs/).

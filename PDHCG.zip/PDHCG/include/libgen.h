/*
 * libgen.h - POSIX libgen for Windows/MSVC
 * Public domain - no warranty
 */
#ifndef LIBGEN_H
#define LIBGEN_H

#ifdef _WIN32
char *dirname(char *path);
char *basename(char *path);
#endif

#endif /* LIBGEN_H */

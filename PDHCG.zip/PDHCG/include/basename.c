/*
 * basename.c - POSIX basename() for Windows/MSVC
 * Public domain - no warranty
 */
#ifdef _WIN32

#include <stdlib.h>
#include <string.h>

static char _pdhcg_basename_buf[512];

char *basename(char *path)
{
    char drive[_MAX_DRIVE];
    char dir[_MAX_DIR];
    char fname[_MAX_FNAME];
    char ext[_MAX_EXT];

    if (path == NULL || path[0] == '\0') {
        strcpy(_pdhcg_basename_buf, ".");
        return _pdhcg_basename_buf;
    }

    _splitpath_s(path, drive, _MAX_DRIVE, dir, _MAX_DIR, fname, _MAX_FNAME, ext, _MAX_EXT);

    if (fname[0] == '\0') {
        strcpy(_pdhcg_basename_buf, ".");
    } else {
        strcpy(_pdhcg_basename_buf, fname);
    }
    return _pdhcg_basename_buf;
}

char *dirname(char *path)
{
    char drive[_MAX_DRIVE];
    char dir[_MAX_DIR];

    if (path == NULL || path[0] == '\0') {
        strcpy(_pdhcg_basename_buf, ".");
        return _pdhcg_basename_buf;
    }

    _splitpath_s(path, drive, _MAX_DRIVE, dir, _MAX_DIR, NULL, 0, NULL, 0);

    if (dir[0] == '\0' && drive[0] == '\0') {
        strcpy(_pdhcg_basename_buf, ".");
    } else {
        strcpy(_pdhcg_basename_buf, drive);
        strcat(_pdhcg_basename_buf, dir);
        /* Remove trailing slash if present */
        size_t len = strlen(_pdhcg_basename_buf);
        if (len > 0 && (_pdhcg_basename_buf[len - 1] == '/' || _pdhcg_basename_buf[len - 1] == '\\')) {
            _pdhcg_basename_buf[len - 1] = '\0';
        }
    }
    return _pdhcg_basename_buf;
}

#endif /* _WIN32 */

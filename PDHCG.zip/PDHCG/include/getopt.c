/*
 * getopt.c - POSIX getopt() for Windows/MSVC
 * Public domain - no warranty
 */
#ifdef _WIN32

#include <stdio.h>
#include <string.h>

#include "getopt.h"

int optind = 1;
int optopt = 0;
int opterr = 1;
char *optarg = NULL;

static char *nextchar = NULL;

int getopt_long(int argc, char * const argv[],
                const char *optstring,
                const struct option *longopts,
                int *longindex)
{
    static int done = 0;

    if (done && optind >= argc) {
        optarg = NULL;
        return -1;
    }
    done = 0;

    if (optind >= argc || argv[optind][0] != '-' || argv[optind][1] == '\0') {
        return -1;
    }

    if (argv[optind][1] == '-') {
        /* Long option */
        const struct option *p = NULL;
        const char *eq;
        size_t namelen;
        int idx = 0;

        eq = strchr(argv[optind], '=');
        if (eq) {
            namelen = eq - (argv[optind] + 2);
        } else {
            namelen = strlen(argv[optind]) - 2;
        }

        for (p = longopts; p && p->name; p++, idx++) {
            if (strncmp(argv[optind] + 2, p->name, namelen) == 0 && strlen(p->name) == namelen) {
                if (eq) {
                    optarg = (char *)(eq + 1);
                } else if (p->has_arg == required_argument) {
                    if (optind + 1 < argc) {
                        optind++;
                        optarg = argv[optind];
                    } else {
                        optarg = NULL;
                        return (optstring[0] == ':') ? ':' : '?';
                    }
                } else if (p->has_arg == optional_argument) {
                    if (optind + 1 < argc && argv[optind + 1][0] != '-') {
                        optind++;
                        optarg = argv[optind];
                    } else {
                        optarg = NULL;
                    }
                } else {
                    optarg = NULL;
                }
                if (longindex) *longindex = idx;
                optind++;
                done = 1;
                return p->flag ? 0 : p->val;
            }
        }
        if (opterr) {
            fprintf(stderr, "Unrecognized option: %s\n", argv[optind]);
        }
        optind++;
        return '?';
    } else {
        /* Short option */
        char c = argv[optind][1];
        const char *p = optstring;

        while (*p && *p != c) p++;
        if (*p == '\0') {
            if (opterr) {
                fprintf(stderr, "Unrecognized option: -%c\n", c);
            }
            optind++;
            return '?';
        }

        if (p[1] == ':') {
            /* Requires argument */
            if (argv[optind][2] != '\0') {
                optarg = argv[optind] + 2;
            } else if (optind + 1 < argc) {
                optind++;
                optarg = argv[optind];
            } else {
                optarg = NULL;
                optind++;
                return (optstring[0] == ':') ? ':' : '?';
            }
        } else {
            optarg = NULL;
        }
        optind++;
        return c;
    }
}

#endif /* _WIN32 */

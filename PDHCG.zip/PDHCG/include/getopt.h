/*
 * getopt.h - POSIX getopt() for Windows/MSVC
 * Public domain - no warranty
 */
#ifndef GETOPT_H
#define GETOPT_H

#ifdef _WIN32

extern int optind;
extern int optopt;
extern int opterr;
extern char *optarg;

struct option {
    const char *name;
    int has_arg;
    int *flag;
    int val;
};

#define no_argument       0
#define required_argument  1
#define optional_argument  2

int getopt_long(int argc, char * const argv[],
                const char *optstring,
                const struct option *longopts,
                int *longindex);

#endif /* _WIN32 */
#endif /* GETOPT_H */

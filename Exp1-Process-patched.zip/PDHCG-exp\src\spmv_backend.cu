/*
Copyright 2026 Hongpei Li
Copyright 2026 Exp1-Process

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/
#include "cusparse_compat.h"
#include "spmv_backend.h"
#include "utils.h"
#include <cuda_runtime.h>
#include <stdlib.h>

#ifdef PDHCG_USE_NEW_SPMV
#include "spmv.h"
// Forward declare new SpMV backend helpers from spmv_backend_new.cu
extern "C" cudaError_t pdhcg_new_spmv_ctx_create(pdhcg_spmv_ctx_t *ctx,
                                                  int num_rows,
                                                  int num_cols,
                                                  int num_nonzeros,
                                                  int *row_ptr,
                                                  int *col_ind,
                                                  double *val,
                                                  cusparseHandle_t sparse_handle);
extern "C" cudaError_t pdhcg_new_spmv_execute(pdhcg_spmv_ctx_t *ctx,
                                               cusparseHandle_t sparse_handle,
                                               const double *alpha,
                                               const double *beta,
                                               const double *x,
                                               double *y);
extern "C" void pdhcg_new_spmv_ctx_destroy(pdhcg_spmv_ctx_t *ctx);
#endif

extern "C" bool pdhcg_use_spmvop_by_default(void)
{
#if PDHCG_USE_SPMVOP
    return true;
#else
    return false;
#endif
}

// Initialize new SpMV backend selection from compile-time default.
// Done via constructor attribute so the runtime value is set before main().
// NOTE: Implementation lives in spmv_backend_new.cu (only compiled when
// PDHCG_USE_NEW_SPMV is on). Here we provide no-op stubs so callers can
// link even without new backend support.
extern "C" void pdhcg_set_spmv_backend(int backend);
extern "C" int  pdhcg_get_spmv_backend(void);

// Weak default getter: returns 0 (cuSPARSE) if symbol not overridden by
// the new backend library. This allows linking without -lspmv when the
// new backend is not requested at compile time.
__attribute__((weak)) extern int pdhcg_get_spmv_backend_default(void) { return 0; }

// Helper: returns true if we should use the new backend for this context.
// We only consult the runtime selection when the new backend was compiled in
// AND the matrix has nonzeros (otherwise we use cuSPARSE for empty handling).
static inline bool pdhcg_use_new_spmv(int num_nonzeros)
{
#ifdef PDHCG_USE_NEW_SPMV
    return (num_nonzeros > 0) && (pdhcg_get_spmv_backend() == 1);
#else
    (void)num_nonzeros;
    return false;
#endif
}

static void pdhcg_spmv_buffer_size(cusparseHandle_t sparse_handle,
                                   cusparseSpMatDescr_t mat,
                                   cusparseDnVecDescr_t vec_x,
                                   cusparseDnVecDescr_t vec_y,
                                   size_t *buffer_size)
{
#if PDHCG_USE_SPMVOP
    CUSPARSE_CHECK(cusparseSpMVOp_bufferSize(
        sparse_handle, CUSPARSE_OPERATION_NON_TRANSPOSE, mat, vec_x, vec_y, vec_y, CUDA_R_64F, buffer_size));
#else
    CUSPARSE_CHECK(cusparseSpMV_bufferSize(sparse_handle,
                                           CUSPARSE_OPERATION_NON_TRANSPOSE,
                                           &HOST_ONE,
                                           mat,
                                           vec_x,
                                           &HOST_ZERO,
                                           vec_y,
                                           CUDA_R_64F,
                                           CUSPARSE_SPMV_CSR_ALG1,
                                           buffer_size));
#endif
}

static void pdhcg_spmv_prepare(cusparseHandle_t sparse_handle,
                               cusparseSpMatDescr_t mat,
                               cusparseDnVecDescr_t vec_x,
                               cusparseDnVecDescr_t vec_y,
                               void *buffer,
                               void **descr,
                               void **plan)
{
#if PDHCG_USE_SPMVOP
    cusparseSpMVOpDescr_t local_descr = NULL;
    cusparseSpMVOpPlan_t local_plan = NULL;
    CUSPARSE_CHECK(cusparseSpMVOp_createDescr(
        sparse_handle, &local_descr, CUSPARSE_OPERATION_NON_TRANSPOSE, mat, vec_x, vec_y, vec_y, CUDA_R_64F, buffer));
    CUSPARSE_CHECK(cusparseSpMVOp_createPlan(sparse_handle, local_descr, &local_plan, NULL, 0));
    *descr = (void *)local_descr;
    *plan = (void *)local_plan;
#else
    (void)descr;
    (void)plan;
    // CUSPARSE_SPMV_CSR_ALG1 涓嶉渶瑕?preprocess锛屽吋瀹?CUDA 12.2
#endif
}

extern "C" pdhcg_spmv_ctx_t *pdhcg_spmv_ctx_create(cusparseHandle_t sparse_handle,
                                                   int num_rows,
                                                   int num_cols,
                                                   int num_nonzeros,
                                                   int *row_ptr,
                                                   int *col_ind,
                                                   double *val,
                                                   cusparseDnVecDescr_t vec_x,
                                                   cusparseDnVecDescr_t vec_y)
{
    pdhcg_spmv_ctx_t *ctx = (pdhcg_spmv_ctx_t *)safe_calloc(1, sizeof(pdhcg_spmv_ctx_t));
    ctx->vec_x = vec_x;
    ctx->vec_y = vec_y;
    ctx->num_rows = num_rows;
    ctx->num_nonzeros = num_nonzeros;
    size_t buffer_size = 0;

    if (num_nonzeros == 0)
    {
        return ctx;
    }

    // Try new SpMV backend first if selected at runtime
    if (pdhcg_use_new_spmv(num_nonzeros))
    {
#ifdef PDHCG_USE_NEW_SPMV
        cudaError_t err = pdhcg_new_spmv_ctx_create(ctx, num_rows, num_cols,
                                                    num_nonzeros, row_ptr, col_ind, val,
                                                    sparse_handle);
        if (err == cudaSuccess)
        {
            // new SpMV plan ready; skip cuSPARSE init
            if (getenv("PDHCG_NEW_SPMV_DEBUG"))
            {
                fprintf(stderr, "[spmv_backend] Using NEW SpMV backend for this ctx\n");
            }
            return ctx;
        }
        // Creation failed; fall through to cuSPARSE
        fprintf(stderr, "[spmv_backend] new SpMV create failed (%s); using cuSPARSE\n",
                cudaGetErrorString(err));
        ctx->new_spmv_plan = nullptr;
        ctx->new_spmv_workspace = nullptr;
#endif
    }

    CUSPARSE_CHECK(cusparseCreateCsr(&ctx->mat,
                                     num_rows,
                                     num_cols,
                                     num_nonzeros,
                                     row_ptr,
                                     col_ind,
                                     val,
                                     CUSPARSE_INDEX_32I,
                                     CUSPARSE_INDEX_32I,
                                     CUSPARSE_INDEX_BASE_ZERO,
                                     CUDA_R_64F));

    pdhcg_spmv_buffer_size(sparse_handle, ctx->mat, ctx->vec_x, ctx->vec_y, &buffer_size);
    if (buffer_size > 0)
    {
        CUDA_CHECK(cudaMalloc(&ctx->buffer, buffer_size));
    }

    pdhcg_spmv_prepare(sparse_handle, ctx->mat, ctx->vec_x, ctx->vec_y, ctx->buffer, &ctx->descr, &ctx->plan);

    return ctx;
}

extern "C" void pdhcg_spmv_ctx_destroy(pdhcg_spmv_ctx_t *ctx)
{
    if (ctx == NULL)
        return;

    if (ctx->num_nonzeros == 0)
    {
        free(ctx);
        return;
    }

#ifdef PDHCG_USE_NEW_SPMV
    if (ctx->new_spmv_plan != nullptr)
    {
        pdhcg_new_spmv_ctx_destroy(ctx);
        // No additional cuSPARSE resources to free
        free(ctx);
        return;
    }
#endif

#if PDHCG_USE_SPMVOP
    if (ctx->descr)
        CUSPARSE_CHECK(cusparseSpMVOp_destroyDescr((cusparseSpMVOpDescr_t)ctx->descr));
    if (ctx->plan)
        CUSPARSE_CHECK(cusparseSpMVOp_destroyPlan((cusparseSpMVOpPlan_t)ctx->plan));
#endif

    if (ctx->buffer)
        CUDA_CHECK(cudaFree(ctx->buffer));
    if (ctx->mat)
        CUSPARSE_CHECK(cusparseDestroySpMat(ctx->mat));

    free(ctx);
}

extern "C" void pdhcg_spmv_execute(cusparseHandle_t sparse_handle,
                                   pdhcg_spmv_ctx_t *ctx,
                                   const double *alpha,
                                   const double *beta,
                                   const double *x,
                                   double *y)
{
    if (ctx->num_nonzeros == 0)
    {
        double beta_host = (beta != NULL) ? *beta : 0.0;
        if (beta_host == 0.0)
        {
            CUDA_CHECK(cudaMemset(y, 0, (size_t)ctx->num_rows * sizeof(double)));
        }
        else if (beta_host != 1.0)
        {
            CUDA_CHECK(cudaMemset(y, 0, (size_t)ctx->num_rows * sizeof(double)));
        }
        return;
    }

    // Try new SpMV backend first
#ifdef PDHCG_USE_NEW_SPMV
    if (ctx->new_spmv_plan != nullptr)
    {
        cudaError_t err = pdhcg_new_spmv_execute(ctx, sparse_handle, alpha, beta, x, y);
        if (err == cudaSuccess)
        {
            return;  // success via new backend
        }
        // fall through to cuSPARSE on error
        fprintf(stderr, "[spmv_backend] new SpMV execute failed (%s); falling back\n",
                cudaGetErrorString(err));
    }
#endif

    // Fallback: original cuSPARSE path
    CUSPARSE_CHECK(cusparseDnVecSetValues(ctx->vec_x, (void *)x));
    CUSPARSE_CHECK(cusparseDnVecSetValues(ctx->vec_y, y));

#if PDHCG_USE_SPMVOP
    CUSPARSE_CHECK(cusparseSpMVOp(
        sparse_handle, (cusparseSpMVOpPlan_t)ctx->plan, alpha, beta, ctx->vec_x, ctx->vec_y, ctx->vec_y));
#else
    CUSPARSE_CHECK(cusparseSpMV(sparse_handle,
                                CUSPARSE_OPERATION_NON_TRANSPOSE,
                                alpha,
                                ctx->mat,
                                ctx->vec_x,
                                beta,
                                ctx->vec_y,
                                CUDA_R_64F,
                                CUSPARSE_SPMV_CSR_ALG1,
                                ctx->buffer));
#endif
}

# Patches Applied to Upstream PDHCG-II

This submission contains the stock PDHCG-II source plus 5 patches.
The patches live as git-style diffs in `Patches/`; the build and
runtime behavior is fully described below. **Re-applying the
patches to a fresh upstream checkout should yield a byte-equivalent
binary**, modulo the `libspmv.a` archive.

The patches are intentionally minimal. They are exactly the 5
things the original Ablation/exp_phase1b binary had hardcoded but
that stock PDHCG-II does not, plus one algorithm-level fix
(row_scaling activation no longer double-scales the constraint
matrix). Nothing else is touched: the algorithm, the data flow,
the cone handling, and the SpMV integration are all stock.

## Patch 001: default SpMV backend = new

Files: `PDHCG/CMakeLists.txt`, `PDHCG/src/spmv_backend.cu`,
`PDHCG/src/cli.c`.

* `CMakeLists.txt`:
  `set(PDHCG_NEW_SPMV_RUNTIME_DEFAULT 0 ...)`
  -> `set(PDHCG_NEW_SPMV_RUNTIME_DEFAULT 1 ...)`.
* `spmv_backend.cu`: the static `g_pdhcg_spmv_backend` initializer
  now reads the `PDHCG_NEW_SPMV_RUNTIME_DEFAULT` macro. When
  `PDHCG_USE_NEW_SPMV` is OFF, the default is still 0 (cuSPARSE).
* `cli.c`: the `--spmv_backend` help line is updated to read
  "default: new" instead of "default: cusparse".

cuSPARSE is still available at runtime via `--spmv_backend cusparse`.
This matches the `build_new_spmv` binary that produced the
phase 1b/003c results.

## Patch 002: default row_scaling = on, m<2000 auto-skip

Files: `PDHCG/src/utils.cu`, `PDHCG/src/solver.cu`,
`PDHCG/src/cli.c`, `PDHCG/include/pdhcg_types.h`.

* `utils.cu`: `set_default_parameters` now sets
  `enable_row_scaling = true` (was `false`).
* `solver.cu`: the row_scaling block in `optimize()` now prints
  per-problem status:
    - `[row_scaling] applied: ... m=N, time=Ts.` (when applied)
    - `[row_scaling] auto-skipped: m=N >= row_scaling_max_rows=M.`
      (when `enable_row_scaling=true` but `m >= 2000`)
    - silent when `enable_row_scaling=false`
* `cli.c`: help line updated.
* `pdhcg_types.h`: comment updated.

The m<2000 auto-skip already lives in `row_scaling.c:441`:
```c
if (problem->num_constraints > max_rows) return PDHCG_ROW_SCALING_DISABLED;
```

For the 18-problem Mittelmann SOCP benchmark, this means
row_scaling is applied ONLY to `2013_wbNRL` (m=1042) and
`2013_dsNRL` (m=1616); the other 16 problems have m >= 2001 and
auto-skip. The bash runner's `select_config.py` overrides
`row_scaling=False` only when the C default is *not* what the
ablation chose (currently no such case -- all row_scaling
decisions are C-internal).

## Patch 003: row_scaling time accounted in cumulative_time_sec

Files: `PDHCG/src/solver.cu`, `PDHCG/src/cli.c`.

* `solver.cu`: `start_time` is now captured at the top of
  `optimize()` (was captured just before the iteration loop). This
  makes `cumulative_time_sec` include QCQP transform + presolve +
  Ruiz/Pock-Chambolle + row_scaling + the iteration loop.
* `solver.cu`: row_scaling wall-clock is measured with
  `std::chrono::steady_clock` and stashed in a file-scope
  `g_row_scaling_elapsed_sec`, which is then copied into
  `state->rescaling_time_sec` immediately after
  `initialize_solver_state()`. `pdhg_core_op.cu::create_result_from_state`
  already maps `state->rescaling_time_sec` to
  `result->rescaling_time_sec`.
* `cli.c`: `save_solver_summary` now writes
  `Rescaling Time (sec): <value>` to `<problem>_summary.txt`. The
  bash runner parses this line for `summary.txt`.

## Patch 004: rename whiten -> row_scaling in CLI/types

Files: `PDHCG/src/cli.c`, `PDHCG/src/row_scaling.c`,
`PDHCG/include/pdhcg_types.h`.

All occurrences of `whitening` and `whiten` in user-visible text
(help text, struct comments) are replaced with `row_scaling`. The
function and field names were already named `row_scaling` upstream.

## Patch 005: row_scaling activation disables Ruiz and Curtis-Reid

Files: `PDHCG/src/solver.cu`.

* `solver.cu`: when `enable_row_scaling=true` AND
  `num_constraints <= row_scaling_max_rows` (i.e. row_scaling is
  actually applied, not auto-skipped), the C solver forces
  `params->l_inf_ruiz_iterations = 0` and
  `params->curtis_reid_iterations = 0` for the duration of the
  call to `rescale_problem`. The original values are restored
  immediately afterwards so the help line, summary, and downstream
  logging reflect the user-facing configuration rather than the
  internal override. Pock-Chambolle rescaling is left alone: its
  default `alpha=1.0` makes it a no-op, and its transformation
  does not duplicate row_scaling's effect.

The verbose log prints a one-line note when the override fires:
```
[rescale] row_scaling active (m=1042 <= 2000): disabling L-inf Ruiz and Curtis-Reid to avoid double-scale.
```

For the 18-problem Mittelmann SOCP benchmark, the override fires
ONLY for `2013_wbNRL` (m=1042) and `2013_dsNRL` (m=1616). The
other 16 problems have `m >= 2001` and `rescale_problem` runs
with the original `l_inf_ruiz_iterations=10` path. This matches
the dsnrl_presolve.py baseline (which sets `l_inf_ruiz_iterations=0`
explicitly when `--whiten 1`) and removes the historical
"stacked" behaviour that the submission previously inherited
from the phase 1b/003c series.

## Things explicitly NOT changed (and why)

* **`pock_chambolle_rescaling` is kept on.** It modifies A's
  row/column scale (data preprocessing) when `alpha != 1.0`, but
  the default `alpha=1.0` means the default PC rescaling is a
  no-op. It is orthogonal to the row_scaling on/off decision.
* **`presolve` (PreFOS) is still OFF by default.** The phase
  1b/003c results were all with `--presolve 0`. Re-enabling
  presolve is a follow-up tracked in `exp_001c_tolerance.md` and
  `exp_002c_presolve_dsnrl.md`. (Note: the Python
  `dsnrl_presolve.py` driver enables it for dsNRL, but the
  C-side default is OFF.)

## Files NOT modified

The rest of `PDHCG/` is stock upstream. In particular:

* `PDHCG/src/row_scaling.c` (algorithm): untouched. The eigenvalue
  decomposition via cuSOLVER dsyevd, the rank-deficiency rejection,
  and the Gauss-Jordan `M^{-T}` computation are all original.
* `PDHCG/src/spmv_backend.cu` and `spmv_backend_new.cu`: only the
  default-initialization expression in patch 001 changed. The
  runtime selection logic, the fallback to cuSPARSE, and the
  destructor branches are all original.
* `select_config.py` and `run_benchmark.sh`: rewritten to be
  cleaner and to use the new defaults, but the per-problem
  (alpha, restart) values match the source-of-truth in
  `VERIFY.md`.


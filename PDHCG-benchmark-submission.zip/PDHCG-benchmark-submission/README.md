# PDHCG Mittelmann SOCP Benchmark Submission

PDHCG is a GPU-accelerated first-order solver for convex quadratic
conic programs. This submission package is configured for the
Mittelmann SOCP benchmark (18 problems) and contains **three additions
on top of the upstream PDHCG-II source**:

1. **New SpMV backend** (`libspmv.a` from `spmv-backend/`) is the
   default. cuSPARSE remains available as a runtime fallback via
   `--spmv_backend cusparse`. Default flipped by this submission.
2. **Row equilibration** (formerly referred to as "row whitening" in
   the experiment log) is **default-on** with `num_constraints <
   2000` auto-skip. The wall-clock cost of row scaling is included
   in `cumulative_time_sec` and also reported separately as
   `rescaling_time_sec`. Default flipped by this submission.
3. **Row-scaling activation suppresses double-scaling.** When
   row_scaling is actually applied (m <= 2000), L-inf Ruiz and
   Curtis-Reid are skipped, since row_scaling is a strict superset
   of diagonal equilibration. Pock-Chambolle (alpha=1.0 default,
   a no-op) is left enabled. Default behaviour flipped by this
   submission; the CLI now does not double-scale the constraint
   matrix.

Everything else is stock PDHCG-II. The 5 patches applied to the
upstream source are described in `PATCHES.md`.

## Layout

```
PDHCG-benchmark-submission/
├── PDHCG/                  Patched PDHCG-II source (default build target)
├── spmv-backend/           Closed-source SpMV static lib (libspmv.a)
├── select_config.py        Per-problem (alpha, restart, row_scaling) table
├── run_benchmark.sh        18-problem SOCP benchmark runner
├── deploy.sh               One-shot build + smoke test
├── README.md               This file
├── VERIFY.md               18-problem known-good (alpha, rt) with sources
├── PATCHES.md              Detailed changelog of the 4 submission patches
└── Patches/                Git-style patches for the 4 source modifications
```

## Build

```bash
cd PDHCG-benchmark-submission
bash deploy.sh
```

`deploy.sh`:
- Validates `spmv-backend/SHA256SUMS`.
- Configures CMake with `-DPDHCG_USE_NEW_SPMV=ON
  -DSPMV_BACKEND_ROOT=$PWD/spmv-backend
  -DPDHCG_NEW_SPMV_RUNTIME_DEFAULT=1`.
- Builds with `make -j` and produces `PDHCG/build_full/pdhcg`.
- Runs a 60-second smoke test on `chainsing-50000-1.cbf.gz` if the
  benchmark directory is reachable.

Requirements: CUDA Toolkit 12.4+ (compute capability >= 7.0), CMake
>= 3.20, GCC, Python 3 (for `select_config.py`).

## Run

```bash
cd PDHCG-benchmark-submission
bash run_benchmark.sh --gpu 4 --time-limit 3600 --epsilon 1e-6
```

Defaults: GPU 4, 3600s time limit per problem, 1e-6 optimality +
feasibility, new SpMV backend. Output goes to
`PDHCG-benchmark-submission/results/run_<timestamp>/`:

- `<problem>.log` -- full PDHCG log
- `<problem>_summary.txt` -- solver-reported status, runtime, etc.
- `<problem>_primal_solution.txt`, `<problem>_dual_solution.txt` -- solutions
- `summary.txt` -- 18-row per-problem table (problem / rows /
  row_scaling / alpha / restart / wall_sec / rscaling_sec / status)

## CLI flags added by this submission

| Flag | Default | Description |
|------|---------|-------------|
| `--spmv_backend {cusparse\|new}` | `new` | SpMV backend. `new` requires `-DPDHCG_USE_NEW_SPMV=ON` at build time. |
| `--enable_row_scaling` | off (CLI) / on (C default) | Forward to C; the C solver may still auto-skip. |
| `--row_scaling_max_rows N` | 2000 | Problems with `num_constraints >= N` skip row scaling. |

## What the upstream C default was, and what it is now

| Setting | Upstream | This submission | Why |
|---------|----------|-----------------|-----|
| `g_pdhcg_spmv_backend` | `0` (cuSPARSE) | `1` (new SpMV) | new SpMV is the default per the paper's reporting convention. |
| `params.enable_row_scaling` | `false` | `true` (with m<2000 auto-skip) | row scaling rescues `2013_wbNRL` and `2013_dsNRL`. |
| `state->cumulative_time_sec` start | start of iteration loop | `optimize()` entry | row_scaling + presolve + Ruiz now count in wall time. |
| `result->rescaling_time_sec` | uninitialized | populated | separate accounting per run_benchmark.sh. |
| `params->l_inf_ruiz_iterations` when row_scaling is active | `10` (always) | `0` (override) | row_scaling supersedes Ruiz; avoid double-scale. |
| `params->curtis_reid_iterations` when row_scaling is active | `0` (already off) | `0` (forced for clarity) | same reason; off by default upstream and here. |

The runtime value of `enable_row_scaling` can be overridden per-problem
by `run_benchmark.sh` via `select_config.py` (`row_scaling: False` for
problems that ablation showed were adversarial even when m<2000).

/*
Copyright 2026 PDHCG-Benchmark

Licensed under the Apache License, Version 2.0.
*/

/* Row equilibration for finite equality constraints.
 *
 * For A x = b with finite l == u, compute M = (D A A^T D)^{-1/2} D and
 * rewrite the constraint as (M A) x = M b. The transformed rows are
 * orthonormal (in exact arithmetic): (M A)(M A)^T = I. The dual is
 * recovered at postsolve as y_orig = M^T y_new. The primal x is
 * unaffected because only the row space is rotated.
 *
 * Numerically rank-deficient systems are rejected without applying
 * any regularization or eigenvalue floor. The algorithm uses cuBLAS
 * and cuSOLVER (already available in the CUDA toolkit) so it has no
 * external LAPACK dependency.
 */

#include "internal_types.h"
#include "pdhcg.h"
#include "row_scaling.h"
#include "utils.h"

#include <cublas_v2.h>
#include <cuda_runtime.h>
#include <cusolverDn.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Relative rank threshold below which the Gram matrix is rejected. */
#define ROW_SCALING_REL_RANK_THRESHOLD 1e-12

/* Thread-local handle so the row map outlives rescale_info_free(). */
static double *g_pending_M = NULL;
static int g_pending_m = 0;

const char *pdhcg_row_scaling_status_str(pdhcg_row_scaling_status_t s)
{
    switch (s)
    {
    case PDHCG_ROW_SCALING_DISABLED:        return "DISABLED";
    case PDHCG_ROW_SCALING_APPLIED:         return "APPLIED";
    case PDHCG_ROW_SCALING_NOT_EQUALITY:    return "NOT_EQUALITY";
    case PDHCG_ROW_SCALING_RANK_DEFICIENT:  return "RANK_DEFICIENT";
    case PDHCG_ROW_SCALING_ERROR:           return "ERROR";
    }
    return "UNKNOWN";
}

static bool all_rows_finite_equality(const qp_problem_t *p)
{
    const double *l = p->constraint_lower_bound;
    const double *u = p->constraint_upper_bound;
    for (int i = 0; i < p->num_constraints; ++i)
    {
        if (!isfinite(l[i]) || !isfinite(u[i])) return false;
        if (l[i] != u[i]) return false;
    }
    return true;
}

#define CUDA_OK(expr) do { \
    cudaError_t _e = (expr); \
    if (_e != cudaSuccess) { \
        fprintf(stderr, "[row_scaling] CUDA error %s at %s:%d\n", \
                cudaGetErrorString(_e), __FILE__, __LINE__); \
        return -1; \
    } \
} while (0)

#define CUBLAS_OK(expr) do { \
    cublasStatus_t _s = (expr); \
    if (_s != CUBLAS_STATUS_SUCCESS) { \
        fprintf(stderr, "[row_scaling] cuBLAS error %d at %s:%d\n", \
                (int)_s, __FILE__, __LINE__); \
        return -2; \
    } \
} while (0)

#define CUSOLVER_OK(expr) do { \
    cusolverStatus_t _s = (expr); \
    if (_s != CUSOLVER_STATUS_SUCCESS) { \
        fprintf(stderr, "[row_scaling] cuSOLVER error %d at %s:%d\n", \
                (int)_s, __FILE__, __LINE__); \
        return -3; \
    } \
} while (0)

/* Compute M = (D A A^T D)^{-1/2} D in place. On success *out_M is m*m row-major.
 * Returns 0 on success.
 *
 * Algorithm:
 *   d[i]    = 1 / ||A[i, :]||         (host, line 1)
 *   G       = D A A^T D (m x m dense) (host)
 *   G = V diag(w) V^T                 (cuSOLVER dsyevd, GPU)
 *   W       = V diag(1/sqrt(w)) V^T   (cuBLAS, GPU)
 *   M       = W * diag(d)             (column scaling)
 *   A_new   = M @ A_old               (dense output, host)
 *   b_new   = M @ b_old
 *   dual_start = M^{-T} @ dual_start_old  (optional)
 */
static int compute_row_scaling_and_transform(qp_problem_t *problem, double **out_M)
{
    const int m = problem->num_constraints;
    const int n = problem->num_variables;
    CsrComponent *A = problem->constraint_matrix;
    if (!A || !A->row_ptr || !A->col_ind || !A->val) return -1;

    fprintf(stderr, "[row_scaling] start, m=%d, n=%d, nnz=%d\n", m, n, problem->constraint_matrix_num_nonzeros);

    /* ---- 1. row norms -> d (host) ---- */
    double *d = (double *)safe_malloc(m * sizeof(double));
    for (int i = 0; i < m; ++i)
    {
        double s2 = 0.0;
        for (int k = A->row_ptr[i]; k < A->row_ptr[i + 1]; ++k)
        {
            double v = A->val[k];
            s2 += v * v;
        }
        double r = sqrt(s2);
        if (!isfinite(r) || r <= 0.0) { free(d); return -4; }
        d[i] = 1.0 / r;
    }
    /* ---- 2. G = D A A^T D (m x m dense, host, symmetric) ----
     *
     * Algorithm: column-bucket outer product.
     *   G[i,j] = d[i] * d[j] * sum_k A[i,k] * A[j,k]
     *
     * For each column k, gather all (row, value) pairs where A[row,k] != 0,
     * then update G[i,j] for all (i,j) in that column.
     */
    double *G = (double *)safe_calloc((size_t)m * m, sizeof(double));
    {
        int nnz_total = A->row_ptr[m];
        int *col_offsets = (int *)safe_calloc(n + 1, sizeof(int));
        int *col_rows = (int *)safe_malloc((size_t)nnz_total * sizeof(int));
        double *col_vals = (double *)safe_malloc((size_t)nnz_total * sizeof(double));

        /* Count nnz per column */
        for (int i = 0; i < m; ++i) {
            for (int k = A->row_ptr[i]; k < A->row_ptr[i + 1]; ++k) {
                col_offsets[A->col_ind[k]]++;
            }
        }
        /* Prefix sum */
        int total = 0;
        for (int k = 0; k < n; ++k) {
            int c = col_offsets[k];
            col_offsets[k] = total;
            total += c;
        }
        col_offsets[n] = total;

        /* Scatter (row, val*d[row]) into per-column buffers */
        int *cursor = (int *)safe_malloc(n * sizeof(int));
        memcpy(cursor, col_offsets, n * sizeof(int));
        for (int i = 0; i < m; ++i) {
            double di = d[i];
            for (int k = A->row_ptr[i]; k < A->row_ptr[i + 1]; ++k) {
                int col = A->col_ind[k];
                int dst = cursor[col]++;
                col_rows[dst] = i;
                col_vals[dst] = A->val[k] * di;
            }
        }
        free(cursor);

        /* Outer product per column: G[i,j] += vi * vj * d[j] */
        for (int k = 0; k < n; ++k) {
            int start = col_offsets[k];
            int end = col_offsets[k + 1];
            for (int p = start; p < end; ++p) {
                int i = col_rows[p];
                double vi = col_vals[p];
                for (int q = start; q < end; ++q) {
                    int j = col_rows[q];
                    G[i * m + j] += vi * col_vals[q] * d[j];
                }
            }
        }

        free(col_offsets);
        free(col_rows);
        free(col_vals);
    }

    /* ---- 3. eigendecomposition via cuSOLVER (GPU) ---- */
    cublasHandle_t cublas_h = NULL;
    cusolverDnHandle_t cusolver_h = NULL;
    cublasCreate(&cublas_h);
    cusolverDnCreate(&cusolver_h);

    double *d_G = NULL;
    double *d_V = NULL;
    double *d_W = NULL;
    double *d_work = NULL;
    double *d_w = NULL;
    int *d_Ipiv = NULL;

    CUDA_OK(cudaMalloc((void **)&d_G, (size_t)m * m * sizeof(double)));
    CUDA_OK(cudaMalloc((void **)&d_V, (size_t)m * m * sizeof(double)));
    CUDA_OK(cudaMalloc((void **)&d_W, (size_t)m * m * sizeof(double)));
    CUDA_OK(cudaMalloc((void **)&d_w, m * sizeof(double)));
    CUDA_OK(cudaMalloc((void **)&d_Ipiv, m * sizeof(int)));

    CUDA_OK(cudaMemcpy(d_G, G, (size_t)m * m * sizeof(double), cudaMemcpyHostToDevice));

    int lwork = 0;
    cusolverEigMode_t jobz = CUSOLVER_EIG_MODE_VECTOR;
    cublasFillMode_t uplo = CUBLAS_FILL_MODE_LOWER;
    CUSOLVER_OK(cusolverDnDsyevd_bufferSize(cusolver_h, jobz, uplo, m, d_G, m, d_w, &lwork));
    CUDA_OK(cudaMalloc((void **)&d_work, (size_t)lwork * sizeof(double)));

    /* cuSOLVER overwrites the input matrix with eigenvectors on success. */
    CUSOLVER_OK(cusolverDnDsyevd(cusolver_h, jobz, uplo, m, d_G, m, d_w, d_work, lwork, d_Ipiv));

    /* ---- 4. rank check (host) ---- */
    double *w = (double *)safe_malloc(m * sizeof(double));
    CUDA_OK(cudaMemcpy(w, d_w, m * sizeof(double), cudaMemcpyDeviceToHost));

    /* cuSOLVER returns eigenvalues sorted ascending. Some may be slightly
     * negative due to floating-point round-off on a "zero" eigenvalue (a
     * row-rank-deficient A). Treat any |w_k| < tol as zero, then compute
     * min-positive / max ratio. If rank < m, reject. */
    {
        double wmax = w[m - 1];
        if (!(wmax > 0.0)) {
            fprintf(stderr, "[row_scaling] all Gram eigenvalues <= 0 (rejected)\n");
            free(d); free(G); free(w);
            cudaFree(d_G); cudaFree(d_V); cudaFree(d_W); cudaFree(d_w); cudaFree(d_Ipiv); cudaFree(d_work);
            cublasDestroy(cublas_h); cusolverDnDestroy(cusolver_h);
            return -5;
        }
        int rank = 0;
        double wmin_pos = wmax;
        for (int k = 0; k < m; ++k) {
            double wk = w[k];
            if (wk < 0.0 && wk > -1e-9 * wmax) wk = 0.0;  /* treat tiny negative as zero */
            if (wk > 1e-12 * wmax) {
                rank++;
                if (wk < wmin_pos) wmin_pos = wk;
            }
        }
        if (rank < m) {
            fprintf(stderr, "[row_scaling] Gram rank=%d/%d, min_pos=%.3g (rejected: rank-deficient)\n",
                    rank, m, wmin_pos / wmax);
            free(d); free(G); free(w);
            cudaFree(d_G); cudaFree(d_V); cudaFree(d_W); cudaFree(d_w); cudaFree(d_Ipiv); cudaFree(d_work);
            cublasDestroy(cublas_h); cusolverDnDestroy(cusolver_h);
            return -5;
        }
        if (!(wmin_pos > ROW_SCALING_REL_RANK_THRESHOLD * wmax)) {
            fprintf(stderr, "[row_scaling] Gram min_pos/max = %.3g (rejected)\n",
                    wmin_pos / wmax);
            free(d); free(G); free(w);
            cudaFree(d_G); cudaFree(d_V); cudaFree(d_W); cudaFree(d_w); cudaFree(d_Ipiv); cudaFree(d_work);
            cublasDestroy(cublas_h); cusolverDnDestroy(cusolver_h);
            return -5;
        }
    }

    /* d_V currently holds eigenvectors in column-major (Fortran) order:
     * dsyevd produces eigenvectors as columns of A. cublasDgemm below
     * interprets them as col-major. We'll copy to a row-major buffer
     * for the host-side W, M, A_new computations. */

    /* ---- 5. Build W = V diag(1/sqrt(w)) V^T (host, row-major) ---- */
    /* First build V' (row-major) by transposing d_V: V'[i,j] = V[j,i] (col-major) = d_V[j*m + i] */
    double *V_rm = (double *)safe_malloc((size_t)m * m * sizeof(double));
    {
        double *V_cm = (double *)safe_malloc((size_t)m * m * sizeof(double));
        CUDA_OK(cudaMemcpy(V_cm, d_G, (size_t)m * m * sizeof(double), cudaMemcpyDeviceToHost));
        for (int i = 0; i < m; ++i)
            for (int j = 0; j < m; ++j)
                V_rm[i * m + j] = V_cm[j * m + i];  /* transpose */
        free(V_cm);
    }

    /* Scale columns of V_rm in place: V_rm[:,j] *= 1/sqrt(w[j]) */
    for (int j = 0; j < m; ++j)
    {
        double s = 1.0 / sqrt(w[j]);
        for (int i = 0; i < m; ++i) V_rm[i * m + j] *= s;
    }

    /* W = V_scaled @ V_scaled^T  (m x m) */
    double *W = (double *)safe_malloc((size_t)m * m * sizeof(double));
    for (int i = 0; i < m; ++i)
    {
        for (int j = 0; j < m; ++j)
        {
            double s = 0.0;
            for (int k = 0; k < m; ++k)
                s += V_rm[i * m + k] * V_rm[j * m + k];
            W[i * m + j] = s;
        }
    }
    free(V_rm);

    /* ---- 6. M = W * diag(d) (column scaling: M[:,j] = W[:,j] * d[j]) ---- */
    double *M = (double *)safe_malloc((size_t)m * m * sizeof(double));
    for (int i = 0; i < m; ++i)
        for (int j = 0; j < m; ++j)
            M[i * m + j] = W[i * m + j] * d[j];

    free(W);

    /* ---- 7. Rewrite A in place: A_new = M @ A_old (dense output) ---- */
    {
        double *A_old_dense = (double *)safe_calloc((size_t)m * n, sizeof(double));
        for (int i = 0; i < m; ++i)
            for (int k = A->row_ptr[i]; k < A->row_ptr[i + 1]; ++k)
                A_old_dense[i * n + A->col_ind[k]] = A->val[k];

        double *A_new_dense = (double *)safe_calloc((size_t)m * n, sizeof(double));
        /* A_new = M @ A_old  (m x m) * (m x n) */
        for (int i = 0; i < m; ++i)
        {
            for (int j = 0; j < n; ++j)
            {
                double s = 0.0;
                for (int k = 0; k < m; ++k)
                    s += M[i * m + k] * A_old_dense[k * n + j];
                A_new_dense[i * n + j] = s;
            }
        }

        int *rp = (int *)safe_malloc((m + 1) * sizeof(int));
        rp[0] = 0;
        int nnz = 0;
        for (int i = 0; i < m; ++i)
        {
            for (int j = 0; j < n; ++j)
                if (A_new_dense[i * n + j] != 0.0) ++nnz;
            rp[i + 1] = nnz;
        }
        int *ci = (int *)safe_malloc(nnz * sizeof(int));
        double *vv = (double *)safe_malloc(nnz * sizeof(double));
        int write = 0;
        for (int i = 0; i < m; ++i)
            for (int j = 0; j < n; ++j)
            {
                double v = A_new_dense[i * n + j];
                if (v != 0.0) { ci[write] = j; vv[write] = v; ++write; }
            }

        free(A_old_dense);
        free(A_new_dense);
        free(A->row_ptr); free(A->col_ind); free(A->val);
        A->row_ptr = rp;
        A->col_ind = ci;
        A->val = vv;
        problem->constraint_matrix_num_nonzeros = nnz;
    }

    /* ---- 8. b_new = M @ b_old ---- */
    {
        double *b_new = (double *)safe_malloc(m * sizeof(double));
        for (int i = 0; i < m; ++i)
        {
            double s = 0.0;
            for (int j = 0; j < m; ++j)
                s += M[i * m + j] * problem->constraint_lower_bound[j];
            b_new[i] = s;
        }
        memcpy(problem->constraint_lower_bound, b_new, m * sizeof(double));
        memcpy(problem->constraint_upper_bound, b_new, m * sizeof(double));
        free(b_new);
    }

    /* ---- 9. dual_start = M^{-T} @ dual_start_old (host, LU) ---- */
    if (problem->dual_start)
    {
        /* We need M^T x = y_old. We do it by transposing M^T to get a
         * row-major M, then a naive back-substitution is overkill; instead
         * we use Gauss-Jordan inversion in place for small m. */
        double *MT = (double *)safe_malloc((size_t)m * m * sizeof(double));
        for (int i = 0; i < m; ++i)
            for (int j = 0; j < m; ++j)
                MT[i * m + j] = M[j * m + i];  /* MT[i,j] = M[j,i] */

        /* In-place Gauss-Jordan on augmented [MT | I], then solve for each
         * dual_start column. For simplicity we copy to a workspace. */
        double *aug = (double *)safe_malloc((size_t)m * 2 * m * sizeof(double));
        for (int i = 0; i < m; ++i)
        {
            for (int j = 0; j < m; ++j) aug[i * (2 * m) + j] = MT[i * m + j];
            for (int j = 0; j < m; ++j) aug[i * (2 * m) + (m + j)] = (i == j) ? 1.0 : 0.0;
        }
        for (int k = 0; k < m; ++k)
        {
            double piv = aug[k * (2 * m) + k];
            if (fabs(piv) < 1e-30) { free(MT); free(aug); free(M); return -6; }
            for (int j = 0; j < 2 * m; ++j) aug[k * (2 * m) + j] /= piv;
            for (int i = 0; i < m; ++i)
            {
                if (i == k) continue;
                double factor = aug[i * (2 * m) + k];
                for (int j = 0; j < 2 * m; ++j)
                    aug[i * (2 * m) + j] -= factor * aug[k * (2 * m) + j];
            }
        }
        /* M^{-T} = (M^T)^{-1} is in the right half of aug, columns [m..2m-1]. */
        /* y_new = M^{-T} @ y_old. */
        for (int i = 0; i < m; ++i)
        {
            double s = 0.0;
            for (int j = 0; j < m; ++j)
                s += aug[i * (2 * m) + (m + j)] * problem->dual_start[j];
            problem->dual_start[i] = s;
        }
        free(MT); free(aug);
    }

    /* Cleanup */
    free(d); free(G); free(w);
    cudaFree(d_G); cudaFree(d_V); cudaFree(d_W); cudaFree(d_w); cudaFree(d_Ipiv); cudaFree(d_work);
    cublasDestroy(cublas_h);
    cusolverDnDestroy(cusolver_h);

    *out_M = M;
    return 0;
}

pdhcg_row_scaling_status_t pdhcg_apply_row_scaling(
    const pdhg_parameters_t *params,
    qp_problem_t *problem,
    rescale_info_t *rescale_info)
{
    (void)rescale_info;
    if (!params || !problem) return PDHCG_ROW_SCALING_ERROR;

    if (!params->enable_row_scaling) return PDHCG_ROW_SCALING_DISABLED;

    int max_rows = params->row_scaling_max_rows > 0 ? params->row_scaling_max_rows : 2000;
    if (problem->num_constraints > max_rows) return PDHCG_ROW_SCALING_DISABLED;

    if (problem->num_constraints > problem->num_variables)
        return PDHCG_ROW_SCALING_RANK_DEFICIENT;

    if (!all_rows_finite_equality(problem)) return PDHCG_ROW_SCALING_NOT_EQUALITY;

    if (g_pending_M) { free(g_pending_M); g_pending_M = NULL; g_pending_m = 0; }

    double *M = NULL;
    int rc = compute_row_scaling_and_transform(problem, &M);
    if (rc == 0)
    {
        g_pending_M = M;
        g_pending_m = problem->num_constraints;
        return PDHCG_ROW_SCALING_APPLIED;
    }
    if (M) free(M);
    if (rc == -4 || rc == -5) return PDHCG_ROW_SCALING_RANK_DEFICIENT;
    return PDHCG_ROW_SCALING_ERROR;
}

/* const variant for callers that hold a const qp_problem_t *. */
pdhcg_row_scaling_status_t pdhcg_apply_row_scaling_const(
    const pdhg_parameters_t *params,
    const qp_problem_t *problem,
    rescale_info_t *rescale_info)
{
    return pdhcg_apply_row_scaling(params, (qp_problem_t *)problem, rescale_info);
}

void pdhcg_recover_dual_from_pending_row_scaling(double *dual_solution)
{
    if (!g_pending_M || !dual_solution) return;
    const int m = g_pending_m;
    double *y_out = (double *)safe_malloc(m * sizeof(double));
    /* y_out[i] = sum_j M[j, i] * dual_solution[j] = M^T @ dual_solution */
    for (int i = 0; i < m; ++i)
    {
        double s = 0.0;
        for (int j = 0; j < m; ++j)
            s += g_pending_M[j * m + i] * dual_solution[j];
        y_out[i] = s;
    }
    memcpy(dual_solution, y_out, m * sizeof(double));
    free(y_out);
}

void pdhcg_release_pending_row_scaling(void)
{
    if (g_pending_M) { free(g_pending_M); g_pending_M = NULL; }
    g_pending_m = 0;
}

/* Legacy wrappers. */
void pdhcg_recover_dual_from_row_scaling(rescale_info_t *info, double *dual_solution)
{
    (void)info;
    pdhcg_recover_dual_from_pending_row_scaling(dual_solution);
}

void pdhcg_row_scaling_info_clear(rescale_info_t *info)
{
    (void)info;
    pdhcg_release_pending_row_scaling();
}

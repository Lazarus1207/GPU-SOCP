#!/bin/bash
# Mittelmann SOCP 18-problem benchmark runner.
#
# For each .cbf.gz in $INPUT_DIR (alphabetical), this script:
#   1. Calls select_config.py to obtain (alpha, restart, row_scaling).
#   2. Runs PDHCG with the recommended CLI flags and captures a per-problem
#      log.
#   3. Appends one line to summary.txt.
#
# Default settings: spmv_backend=new, eps_opt=eps_feas=1e-6,
# time_limit=3600, GPU 4. All overridable via env vars or CLI flags.

set -uo pipefail

GPU="${PDHCG_GPU:-4}"
TIME_LIMIT="${PDHCG_TIME_LIMIT:-3600}"
ITER_LIMIT="${PDHCG_ITER_LIMIT:-100000}"
EPSILON="${PDHCG_EPSILON:-1e-6}"
SPMV_BACKEND="${PDHCG_SPMV_BACKEND:-new}"
ROW_SCALING_MAX_ROWS="${PDHCG_ROW_SCALING_MAX_ROWS:-2000}"
INPUT_DIR="${PDHCG_INPUT_DIR:-$HOME/testHM/benchmark/socp}"
SUBMIT_DIR="$(cd "$(dirname "$0")" && pwd)"
PDHCG_BIN="${PDHCG_BIN:-$SUBMIT_DIR/PDHCG/build_full/pdhcg}"
OUT_DIR="${PDHCG_OUT_DIR:-$SUBMIT_DIR/results/run_$(date +%Y%m%d_%H%M%S)}"

while [[ $# -gt 0 ]]; do
    case "$1" in
        --gpu)         GPU="$2"; shift 2 ;;
        --time-limit)  TIME_LIMIT="$2"; shift 2 ;;
        --iter-limit)  ITER_LIMIT="$2"; shift 2 ;;
        --epsilon)     EPSILON="$2"; shift 2 ;;
        --spmv)        SPMV_BACKEND="$2"; shift 2 ;;
        --row-scaling-max-rows) ROW_SCALING_MAX_ROWS="$2"; shift 2 ;;
        --in)          INPUT_DIR="$2"; shift 2 ;;
        --out)         OUT_DIR="$2"; shift 2 ;;
        --bin)         PDHCG_BIN="$2"; shift 2 ;;
        -h|--help)
            sed -n '2,30p' "$0"
            exit 0 ;;
        *) echo "[err] unknown arg: $1"; exit 1 ;;
    esac
done

[ -x "$PDHCG_BIN" ] || { echo "[err] pdhcg not found: $PDHCG_BIN"; exit 1; }
[ -d "$INPUT_DIR" ] || { echo "[err] benchmark dir missing: $INPUT_DIR"; exit 1; }
[ -f "$SUBMIT_DIR/select_config.py" ] || { echo "[err] select_config.py missing"; exit 1; }

mkdir -p "$OUT_DIR"
echo "[run] out=$OUT_DIR gpu=$GPU time=${TIME_LIMIT}s eps=${EPSILON} spmv=${SPMV_BACKEND}"

SUMMARY="${OUT_DIR}/summary.txt"
{
    echo "# PDHCG Mittelmann SOCP benchmark"
    echo "# time:   $(date -Iseconds)"
    echo "# params: gpu=$GPU time=${TIME_LIMIT}s iter=${ITER_LIMIT} eps=${EPSILON} spmv=${SPMV_BACKEND} row_scaling_max_rows=${ROW_SCALING_MAX_ROWS}"
    printf "%-30s %9s %10s %5s %8s %10s %12s %-10s\n" \
        "problem" "rows" "row_scale" "alpha" "restart" "wall_sec" "rscaling_sec" "status"
} > "$SUMMARY"

SUCCESS=0
FAILED=0

for INPUT in $(ls "${INPUT_DIR}"/*.cbf.gz 2>/dev/null | sort); do
    NAME=$(basename "$INPUT" .cbf.gz)

    # Parse problem dimensions: the CBF parser prints "Rows: N" in the log
    # we don't have, so we rely on select_config's hard-coded table.
    CFG=$(python3 -c "
import sys
sys.path.insert(0, '${SUBMIT_DIR}')
from select_config import select_config
cfg = select_config('${NAME}', epsilon=${EPSILON})
print(int(cfg['row_scaling']), cfg['alpha'], cfg['restart'])
")
    ROW_SCALE=$(echo "$CFG" | awk '{print $1}')
    ALPHA=$(echo "$CFG" | awk '{print $2}')
    RESTART=$(echo "$CFG" | awk '{print $3}')

    LOG="${OUT_DIR}/${NAME}.log"
    echo "--- ${NAME} alpha=${ALPHA} restart=${RESTART} row_scaling=${ROW_SCALE}"

    # Note: --enable_row_scaling is forwarded ONLY when the per-problem
    # config asks for it. The C solver still applies its own m<2000
    # auto-skip, so passing --enable_row_scaling on a m>=2000 problem
    # is harmless. Passing it explicitly here makes the log auditable.
    EXTRA=()
    [[ "$ROW_SCALE" == "1" ]] && EXTRA+=(--enable_row_scaling)

    CUDA_VISIBLE_DEVICES=$GPU
    START=$(date +%s.%N)
    "$PDHCG_BIN" "$INPUT" "$OUT_DIR" \
        -v 2 \
        --time_limit "$TIME_LIMIT" \
        --iter_limit "$ITER_LIMIT" \
        --eps_opt "$EPSILON" \
        --eps_feas "$EPSILON" \
        --pock_chambolle_alpha "$ALPHA" \
        --artificial_restart_threshold "$RESTART" \
        --spmv_backend "$SPMV_BACKEND" \
        --row_scaling_max_rows "$ROW_SCALING_MAX_ROWS" \
        "${EXTRA[@]}" \
        > "$LOG" 2>&1
    RC=$?
    END=$(date +%s.%N)
    ELAPSED=$(echo "${END} - ${START}" | bc -l)

    # Parse rescaling_time_sec from the solver's _summary.txt (the solver
    # writes it on graceful termination). On FAIL, leave blank.
    if [ -f "${OUT_DIR}/${NAME}_summary.txt" ]; then
        RS=$(grep -E "^Rescaling Time \(sec\)" "${OUT_DIR}/${NAME}_summary.txt" 2>/dev/null | awk '{print $NF}')
        [[ -z "$RS" ]] && RS="n/a"
    else
        RS="n/a"
    fi

    STATUS="OK"
    [[ $RC -ne 0 ]] && STATUS="FAIL_${RC}"

    printf "%-30s %9s %10s %5.2f %8.3f %10.2f %12s %-10s\n" \
        "$NAME" "?" "$ROW_SCALE" "$ALPHA" "$RESTART" "$ELAPSED" "$RS" "$STATUS" \
        >> "$SUMMARY"

    if [[ $RC -eq 0 ]]; then
        echo "  OK ${ELAPSED}s  rscaling=${RS}s"
        ((SUCCESS++))
    else
        echo "  FAIL rc=${RC}"
        ((FAILED++))
    fi
done

echo ""
echo "[batch] done  success=$SUCCESS failed=$FAILED  summary=$SUMMARY"

#!/bin/bash
# Server-side build for the PDHCG Mittelmann SOCP submission.
#
# This script expects the following directory layout (already in place
# after unpacking the submission tarball):
#
#   PDHCG-benchmark-submission/
#     PDHCG/             PDHCG-II source with the 4 submission patches applied
#                        (default spmv_backend=new, default row_scaling=on
#                        with m<2000 auto-skip, row_scaling time accounting,
#                        renames whiten -> row_scaling in CLI/types)
#     spmv-backend/      Closed-source SpMV static lib (libspmv.a)
#     select_config.py   Per-problem config heuristic
#     run_benchmark.sh   18-problem benchmark runner
#
# Build target: build_full (cuSPARSE + new SpMV + row_scaling, runtime switchable)

set -e

SUBMIT_DIR="$(cd "$(dirname "$0")" && pwd)"
PDHCG_DIR="${SUBMIT_DIR}/PDHCG"
SPMV_PKG="${SUBMIT_DIR}/spmv-backend"

[ ! -d "$PDHCG_DIR" ]  && { echo "[err] missing: $PDHCG_DIR";  exit 1; }
[ ! -d "$SPMV_PKG" ]  && { echo "[err] missing: $SPMV_PKG";  exit 1; }
[ -f "$SPMV_PKG/SHA256SUMS" ] && {
    ( cd "$SPMV_PKG" && sha256sum -c SHA256SUMS ) || { echo "[err] spmv-backend SHA256 mismatch"; exit 1; }
}

command -v nvcc   >/dev/null 2>&1 || { echo "[err] nvcc not found";   exit 1; }
command -v cmake  >/dev/null 2>&1 || { echo "[err] cmake not found";  exit 1; }
command -v python3 >/dev/null 2>&1 || { echo "[err] python3 not found"; exit 1; }

echo "[build] PDHCG     = $PDHCG_DIR"
echo "[build] SpMV pkg  = $SPMV_PKG"
nvcc --version | head -1
cmake --version | head -1

# Default GPU arch: server-side is GPU 4 (A100 = sm_80). Override via
# CMAKE_CUDA_ARCHITECTURES env var if building for a different GPU.
: "${CMAKE_CUDA_ARCHITECTURES:=80}"
export CMAKE_CUDA_ARCHITECTURES

cd "$PDHCG_DIR"
rm -rf build_full
mkdir -p build_full
cd build_full

cmake .. \
    -DCMAKE_BUILD_TYPE=Release \
    -DPDHCG_USE_NEW_SPMV=ON \
    -DSPMV_BACKEND_ROOT="$SPMV_PKG" \
    -DPDHCG_NEW_SPMV_RUNTIME_DEFAULT=1 \
    -DPDHCG_BUILD_PYTHON=OFF \
    -DPDHCG_BUILD_TESTS=OFF \
    -DPDHCG_COMPILE_PREFOS=OFF \
    2>&1 | tee cmake.log

make -j"$(nproc)" pdhcg 2>&1 | tee make.log

[ -f pdhcg ] || { echo "[err] build failed"; exit 1; }

echo ""
echo "=========================================="
echo " build OK: $PDHCG_DIR/build_full/pdhcg"
echo "=========================================="
echo ""
echo "Quick smoke test (chainsing-50000-1, ~1s):"
INPUT_DIR="${PDHCG_INPUT_DIR:-$HOME/testHM/benchmark/socp}"
PROBLEM="$INPUT_DIR/chainsing-50000-1.cbf.gz"
if [ -f "$PROBLEM" ]; then
    CUDA_VISIBLE_DEVICES="${PDHCG_GPU:-4}" \
        ./pdhcg "$PROBLEM" "$PDHCG_DIR/build_full/_smoke" \
        -v 1 --time_limit 60 --eps_opt 1e-4 --eps_feas 1e-4 \
        --pock_chambolle_alpha 1.0 --artificial_restart_threshold 0.36 \
        --spmv_backend new 2>&1 | tail -20 || echo "(smoke test failed; investigate before running full benchmark)"
else
    echo "(skip smoke: $PROBLEM not found)"
fi
echo ""
echo "Usage:"
echo "  cd $SUBMIT_DIR"
echo "  bash run_benchmark.sh --gpu 4 --time-limit 3600 --epsilon 1e-6"

# PDHCG Barrier 增强技术: 上下文总结与实施计划

> **项目**: PDHCG (Primal-Dual Hybrid Conjugate Gradient) Barrier 增强
> **代码基础**: `D:\PDHCG\PDHCG-Barrier\PDHCG-Base` (CUDA/C, C++17, CUDA 12.4+)
> **参考实现**: `D:\PDCS\PDHG Conic v.s Linear\experiments\phase3\exp-3.4` (Julia/CPU+GPU)
> **当前状态**: Stage 1 大阶段内部推进中, 已完成 1.1/1.2/1.3/1.4/1.7, CLI 集成待做 (1.8), 端到端测试待启动; GPU kernel 策略待探索 (1.5/1.6)
> **更新日期**: 2026-09-14 (GPU kernel 策略调整: 1.8 先做, 1.5/1.6 并行探索)

---

## 目录

1. [理论基础 (与 PDCS 一致)](#1-理论)
2. [PDHCG 锥类型与 Barrier 范围](#2-pdhcg-锥类型与-barrier-范围)
3. [关键差异: PDCS (Julia) vs PDHCG (C/CUDA)](#3-关键差异-pdcs-julia-vs-pdhcg-ccuda)
4. [代码结构与接入点](#4-代码结构与接入点)
5. [核心参数与数据结构](#5-核心参数与数据结构)
6. [实施分阶段路线图](#6-实施分阶段路线图)
7. [Stage 1: 锥类型特定的 Barrier-Proximal 求解器 (Host CPU)](#7-stage-1-锥类型特定的-barrier-proximal-求解器-host-cpu)
8. [Stage 2: 触发机制与几何度量 (boundary metric ρ)](#8-stage-2-触发机制与几何度量-boundary-metric-ρ)
9. [Stage 3: 主循环接入 (Option 1 vs Option 2)](#9-stage-3-主循环接入-option-1-vs-option-2)
10. [Stage 4: CUDA Kernel 化与 GPU 并行](#10-stage-4-cuda-kernel-化与-gpu-并行)
11. [Stage 5: 保护机制与 fallback 体系](#11-stage-5-保护机制与-fallback-体系)
12. [Stage 6: 参数注入、Python binding 与文档](#12-stage-6-参数注入python-binding-与文档)
14. [测试问题集与验证方案](#14-测试问题集与验证方案)
15. [风险评估与已知问题](#15-风险评估与已知问题)
16. [附录 A: 与 PDCS Barrier 的关键 API 对照](#16-附录-a-与-pdcs-barrier-的关键-api-对照)
17. [附录 B: 一句话总结](#17-附录-b-一句话总结)

---

## 1. 理论基础

### 1.1 PDHG 的锥边界钉死问题 (与 PDCS 完全一致)

PDHG 在锥约束 (尤其是 RSOC、StdSOC、EXP、Power 锥) 上的边界钉死现象源自其本质:

```
标准 PDHG 更新:
    x^{k+1} = Π_K(x^k - τ·∇f(x^k))  ← 欧氏投影仅保留切向分量

Barrier-PDHG 更新 (我们引入):
    x^{k+1} = argmin_{x∈K} { ⟨g,x⟩ + (1/2τ)||x-x^k||² + μ·φ(x) }
```

其中 `φ(x)` 是 log-barrier 函数, 在锥边界处趋于 `+∞`, 阻止迭代靠近边界, 保留更多切向分量以加速收敛.

### 1.2 PDCS 已验证的几何分析结论

详见 `D:\PDCS\PDHG Conic v.s Linear\experiments\phase3\exp-3.4\barrier-pdhg-analysis-zh.tex`:

| 现象     | LP    | RSOC      | StdSOC    | EXP 锥       |
| ------ | ----- | --------- | --------- | ------------ |
| 边界钉死   | 无     | **严重**    | **严重**    | **极严重**      |
| 收敛速度   | 线性收敛 | 卡死在边界     | 卡死在边界     | gap 卡死, 残差恶化 |
| 几何原因   | 平坦边界  | 弯曲球面边界    | 同 RSOC    | 非对称曲面+顶点奇点   |

PDHCG 沿用同样的边界钉死机制 — 这是 PDHG 算法族的共性, 不是 PDCS 独有.

### 1.3 屏障理论的 4 条保证 (与 PDCS 一致)

- **定理 A (固定 μ)**: `O(1/k)` 收敛率, 当 `Δx_barrier ≤ C·μ`.
- **定理 B (同伦 μ)**: 若 `μ_k → 0` 且 `Σμ_k < ∞`, 则收敛到原问题最优解.
- **定理 C (加速)**: Nesterov 加速可达 `O(1/k²)`.
- **定理 D (凸内可行域)**: log-barrier 在严格内点处连续可微, 自协常数有限 (RSOC: 2, EXP: 2, Power: 3, StdSOC: 2).

---

## 2. PDHCG 锥类型与 Barrier 范围

### 2.1 PDHCG-Base 支持的锥类型 (来自 `pdhcg_types.h:69-77`)

```c
typedef enum {
    CONE_ROTATED_SOC = 0,    // 旋转二阶锥, dim=k+2, x = (v, s, t) with v∈R^k, ||v||² ≤ 2st, s,t≥0
    CONE_STANDARD_SOC = 1,   // 标准二阶锥, dim=k+1, x = (t, u) with ||u|| ≤ t
    CONE_EXPONENTIAL = 2,    // 指数锥, dim=3, x = (x1,x2,x3), x2>0, x3>0, x1 ≥ x2·exp(x3/x2)
    CONE_POWER = 3,          // 3-dim 幂锥, dim=3, x = (x,y,z), x≥0, y≥0, x^α·y^(1-α) ≥ |z|
    NUM_CONE_TYPES = 4
} cone_type_t;
```

**关键发现 (重要)**: **PDHCG 当前不支持 PSD 锥**. 用户的"扩展至 PSD 等"应理解为"扩展至 PDHCG 支持的全部锥类型"; 若将来 PDHCG 加入 PSD 锥 (按 cuPDLPx/Clarabel 惯例, 通常用 vec + svec 编码), Barrier 设计应顺势拓展, 但本次实施仅针对 RSOC / StdSOC / EXP / Power 这 4 种. PDF 文档 `presolve_wrapper.c` 中的 `psd_face_reduction = 0` 是 presolve 的开关而非锥类型.

### 2.2 锥类型与 Barrier 实现对照表

| 锥类型        | dim    | log-barrier `φ(x)`                                  | self-dual | 自协常数 ν | 复杂度     |
| ---------- | ------ | --------------------------------------------------- | --------- | ------ | ------- |
| RSOC       | k+2    | `-log(2st - ||v||²)`                                 | ✓         | 2      | O(1) Newton |
| StdSOC     | k+1    | `-log(t² - ||u||²)`                                  | ✓         | 2      | O(1) Newton |
| EXP        | 3      | `-log(x2) - log(x3) - log(x1 - x2·exp(x3/x2))`      | ✓         | 2      | O(1) (Hessian 对角) |
| Power      | 3      | `-α·log(x) - (1-α)·log(y) - log(x^α·y^(1-α)-|z|)`   | ✓         | 3      | O(1) (标量 r 求解) |

注意 PDHCG 中**全部 4 种锥都是 self-dual**, 这意味着 Primal Barrier 与 Dual Barrier 完全相同 (不需像 PDCS 那样做 `z = -y` 自对偶变换), 极大简化 Dual Barrier 实现.

### 2.3 投影 kernel 复用 (关键)

PDHCG 已有完整的**精确**锥投影实现 (`pdhcg_conic_kernels.cu`), 在 Barrier-Proximal 求解器的每步内部循环中, 我们可以:

1. **下降方向用 Barrier 梯度**: `d = (x - x_k)/τ + g + μ·∇φ(x)`
2. **回缩到锥内用 Euclidean 投影**: `x_trial = Π_K(x - α·d)` ← 直接复用 `project_*_kernel`

这避免了 PDCS 中"BPGrad 内层回退到 Euclidean 投影"的复杂性 — PDHCG 投影 kernel 本身就是 GPU 原生 CUDA 实现, 性能远超 PDCS 的 CPU 版本.

### 2.4 DIAG_Q 特殊路径

PDHCG 在 `quad_obj_type == PDHCG_DIAG_Q` 时走单独的 `dispatch_cone_projection_diag_q` 路径 (该路径不调用标准 PDHG 投影, 而是先在每步中嵌入 cone projection). 这是一个需要特别关注的"Option 2"式机会 — 我们可以**直接**在 `dispatch_cone_projection_diag_q` 后挂 Barrier, 不必修改主循环结构. 详见 §9.

---

## 3. 关键差异: PDCS (Julia) vs PDHCG (C/CUDA)

### 3.1 影响架构设计的根本差异

| 维度            | PDCS (Julia)                              | PDHCG (C/CUDA)                          | 对 Barrier 的影响                 |
| ------------- | ---------------------------------------- | --------------------------------------- | ---------------------------- |
| **语言**        | Julia 1.12 + CUDA.jl (内核以 Julia 字符串传递) | C/C++17 + NVCC (.cu 内核)                 | C 需显式内存管理, 没有 GC             |
| **GPU 同步开销**  | 每次 `Array(x)` 触发 D→H 同步 (~5μs)         | 已用 `pdhcg_spmv_op` + kernel 化, sync 极少 | 同步不再是主要瓶颈, 可更激进触发 Barrier  |
| **锥类型**       | 仅 RSOC, EXP                              | **RSOC, StdSOC, EXP, Power** (4 种, 全 self-dual) | 实现范围更广, Dual barrier 简化         |
| **约束位置**      | `Gx - h ∈ K` 在 y 切片 (dual cones)        | `x_J ∈ K` 在 primal 切片 (变量 cones)        | PDHCG 是**变量锥**, Barrier 直接作用于 x |
| **BB 步长**     | 单一 primal/dual step size                | **DIAG_Q 路径用 BB 自适应步长**                  | BB 路径是最容易陷入边界钉死的位置, Barrier 重点干预对象 |
| **QCQP→SOCP** | 无 (SOCP only)                           | `qcqp_to_socp_qp` 自动转 QCQP 到 SOCP         | Power 锥只在 QP 中出现, SOCP 经 qcqp_transform 转 RSOC 后 Barrier 触发 |
| **Rescaling** | Ruiz/Pock-Chambolle                       | Ruiz/Pock-Chambolle + `heterogeneous_cone_scaling` | 异构缩放下每个分量有自己的 dᵢ, Barrier 需正确缩放 |
| **Warm start** | 无                                       | `state->cones.primal_warm_start` / `dual_warm_start` (per-block scalar) | Barrier 子问题可直接复用 warm_start 加速 Newton |
| **投影策略**      | PDCS 自己的 SOC/RSOC/EXP 投影 (有 exp_proj bug) | PDHCG 已修复的完整 4 锥投影 (`pdhcg_conic_kernels.cu`) | 直接复用 PDHCG 的 kernel, 性能与正确性兼得 |
| **触发调度**      | L0/L1/L2/L3 4 层架构 (`barrier_trigger.jl`)     | 待设计                                  | PDHCG 可沿用 PDCS 的 4 层架构          |
| **is_fixed**  | 无                                       | 每个变量可被 `is_fixed` 锁定 (固定截面投影)             | Barrier 需尊重 fixed slot, 不修改固定坐标 |

### 3.2 PDHCG Barrier 的关键优势 (相对 PDCS)

1. **没有 exp_proj bug**: PDHCG 的 EXP 投影是经过全面测试的 GPU kernel (`project_exp_cone_kernel`, 3155-3194行), 可直接嵌入 BPGrad 内层回退路径.
2. **Dual Barrier 简化**: 4 种锥全部 self-dual, 不需 `z = -y` 变换.
3. **Warm start**: 可将 PDHCG 的 `primal_warm_start` 直接用于 BPGrad 的 Newton 初始 λ (类似 SOC 投影中 `warm_lam` 的角色), 大幅加速收敛.
4. **Power 锥**: 3-dim 幂锥在 PDCS 中不存在, 是 PDHCG 独家. 需独立实现其 log-barrier (3-dim, ν=3, 标量 r Newton 步).
5. **Heterogeneous scaling**: PDHCG 可逐分量缩放, Barrier 子问题需在缩放后的坐标系中工作, 再反缩放回原始空间 — 比 PDCS 的同构缩放复杂但更精确.

### 3.3 PDHCG Barrier 的关键挑战 (相对 PDCS)

1. **C/C++ 无 GC**: BPGrad 内层循环的 host 端分配 (`malloc/free`) 必须谨慎, 建议在 `initialize_solver_state` 阶段预分配所有临时缓冲.
2. **CUDA 内核调用开销**: BPGrad 每个外层迭代需一次 `cudaMemcpy` 同步提取锥块到 host, 这是毫秒级开销 — 与 PDCS 的纯 CPU 实现相比, 在 GPU 上每步都有 sync 成本. **应对**: 只在 gap 接近容差且锥块 dim 较小时才触发 (与 PDCS Stage 3 经验一致).
3. **Warm-start 冲突**: PDHCG 的 `primal_warm_start` 是 SOC 投影的 λ warm-start; Barrier 子问题可能也想用同一个 scalar 字段 — 需要协调.
5. **DIAG_Q 路径**: 是 Barrier 干预的最佳位置, 但代码路径最不熟悉, 需要细致测试.

---

## 4. 代码结构与接入点

### 4.1 PDHCG-Base 当前主循环 (来自 `src/solver.cu`)

```c
while (state->total_count < params->termination_criteria.iteration_limit) {
    // [主循环头] 计算残差 + 检查终止 + adaptive restart
    ...
    pdhg_update(state);                  // ← 主更新: 投影 + dual 步
    compute_fixed_point_error(state);    // ← 主循环尾
    halpern_update(state, ...);          // ← Halpern 加速
    ...
}
```

主更新 `pdhg_update` 的关键骨架 (`pdhg_core_op.cu:1193-1301`):

```c
void pdhg_update(pdhg_solver_state_t *state) {
    // 1. dual_product = A^T · current_dual
    // 2. primal gradient descent (DIAG_Q / BB / no-Q 三分支)
    // 3. 锥投影 (若 var_set_type == VAR_SET_CONTAIN_CONIC):
    if (qt == PDHCG_DIAG_Q) {
        dispatch_cone_projection_diag_q(state, primal_step_size, Q_diag,
                                        pdhg_primal, reflected_primal,
                                        current_primal);   // ← BB 内层已有投影
    } else {
        dispatch_cone_projection(state, pdhg_primal_solution);   // ← 标准欧氏投影
        recompute_reflected_at_cones(state);
    }
    // 4. dual 更新 (SPD 步)
}
```

### 4.2 接入位置选项 (与 PDCS 对应)

| 选项                       | 接入位置                                               | 适用锥                   | 备注                                       |
| ------------------------ | -------------------------------------------------- | --------------------- | ---------------------------------------- |
| **Option 1a** (pre-proj) | `dispatch_cone_projection_diag_q` **后**              | DIAG_Q 路径 (BB 内层后)      | 已是 PDHCG 投影后修正, 等价于 PDCS Option 1          |
| **Option 1b** (post-proj) | `dispatch_cone_projection` **后** + `recompute_reflected_at_cones` 前 | 非 DIAG_Q 路径            | 标准欧氏投影后立即修正, 避免影响 reflected_primal       |
| **Option 2** (post-halpern) | `halpern_update` **后**, 主循环迭代末                     | 所有路径通用                 | 加速后的点修正; PDCS 测试经验表明这是性能最优的 Option        |
| **Option 3** (Slack-based) | `compute_residual` 期间对 `primal_slack = Gx - h` 应用 barrier | 等价于 PDCS Dual EXP barrier | 仅适用于 RSOC/StdSOC, 通过 slack 几何直接干预 Gx-h      |

**推荐组合**: **Option 1b** 作为基线 (与 PDCS Option 1 一致), **Option 2** 作为加速版 (PDCS Option 2 经验最优), **Option 3** 作为 Slack-based 备选 (解决 PDCS exp_20 反复证明的"变量锥上没有 SOC/EXP"问题).

### 4.3 需要新增/修改的文件清单

| 路径                                                          | 用途                                       | 优先级      |
| ----------------------------------------------------------- | ---------------------------------------- | ------- |
| **新增**                                                       |                                          |         |
| `PDHCG-Barrier/include/barrier_types.h`                     | 公共 Barrier 参数/状态结构                       | P0      |
| `PDHCG-Barrier/include/barrier_module.h`                    | 4 锥 Barrier 子模块对外接口                       | P0      |
| `PDHCG-Barrier/include/boundary_metric.h`                   | ρ 度量与 max_ratio 互转                       | P0      |
| `PDHCG-Barrier/src/barrier_metric.cu`                       | ρ 计算 kernel 与 host 函数                    | P0      |
| `PDHCG-Barrier/src/barrier_module.cu`                       | 4 锥 BPGrad 子求解器 (host 调用 + 投影回写)            | P0      |
| `PDHCG-Barrier/src/barrier_kernels.cu`                      | 单锥 BPGrad Newton kernel + barrier force kernel | P0      |
| `PDHCG-Barrier/src/barrier_trigger.cu`                      | L0/L1/L2/L3 调度引擎 (借鉴 PDCS `barrier_trigger.jl`) | P1      |
| `PDHCG-Barrier/tests/test_barrier_unit.cpp`                   | 单元测试 (4 锥 BPGrad + 4 ρ + 4 fallback)         | P0      |
| `PDHCG-Barrier/tests/test_barrier_integration.cpp`            | 集成测试 (5-10 个 CBF 问题, 对比 baseline)            | P1      |
| **修改**                                                       |                                          |         |
| `PDHCG-Base/include/pdhcg_types.h`                          | 添加 15+ barrier 参数到 `pdhg_parameters_t`       | P0      |
| `PDHCG-Base/src/solver.cu` / `pdhg_core_op.cu`             | 在 `pdhg_update` 后 / `halpern_update` 后挂 Barrier | P0      |
| `PDHCG-Base/src/solver_state.cu`                            | 预分配 barrier host 缓冲 (BPGrad 内层用)            | P1      |
| `PDHCG-Base/src/cli.c`                                      | 添加 barrier 命令行参数                          | P1      |
| `PDHCG-Base/python_bindings/_core_bindings.cpp`              | 暴露 barrier 参数到 pybind11                     | P2      |
| `PDHCG-Base/python/pdhcg/PDHCG.py`                          | 添加 Barrier 参数别名                           | P2      |

**关键原则**: 所有新增 Barrier 代码放在上层 `PDHCG-Barrier/` 目录, 通过 `#include "../PDHCG-Barrier/include/barrier_module.h"` 引用; 不修改 PDHCG-Base 内核. 修改仅限 `pdhcg_types.h` (添加字段) 和 `pdhg_core_op.cu` (主循环挂载点), 其余是新增.

---

## 5. 核心参数与数据结构

### 5.1 新增参数 (添加到 `pdhg_parameters_t`)

借鉴 PDCS Stage 1+2+3 经验, 我们设计如下参数集 (与 PDCS 完全对齐):

```c
// === 全局开关 ===
bool       barrier_enabled;              // 默认 false

// === 选项 (Option 1b vs 2 vs 3) ===
int        barrier_option;               // 0=禁用, 1=Option 1b, 2=Option 2, 3=Slack
bool       barrier_skip_diag_q;          // true (默认) = DIAG_Q 路径不挂 Barrier

// === μ 调度 ===
mu_strategy_t barrier_mu_strategy;       // CONSTANT / EXPONENTIAL / ADAPTIVE
double     barrier_mu_init;              // 默认 1.0
double     barrier_mu_final;             // 默认 1e-6
double     barrier_mu_rho;               // 默认 0.95 (EXP only for :exponential)

// === per-cone 阈值 (借鉴 PDCS Stage 2) ===
double     soc_rsoc_primal_max_ratio;    // 默认 10.0 → ρ_threshold ≈ 0.316
double     soc_rsoc_dual_max_ratio;      // 默认 10.0
double     soc_std_primal_max_ratio;     // 默认 10.0 (新增)
double     soc_std_dual_max_ratio;       // 默认 10.0 (新增)
double     exp_primal_max_ratio;         // 默认 3.0 → ρ_threshold ≈ 0.577
double     exp_dual_max_ratio;           // 默认 3.0
double     power_primal_max_ratio;       // 默认 5.0 (新增) → ρ_threshold ≈ 0.447
double     power_dual_max_ratio;         // 默认 5.0 (新增)

// === BPGrad 内层控制 ===
int        barrier_max_iter;             // 外层 BPGrad 最大迭代, 默认 20
int        barrier_inner_max_iter;       // Armijo 线搜索最大步数, 默认 10
double     barrier_tol;                  // BPGrad 子问题收敛容差, 默认 1e-8
double     barrier_ls_alpha0;            // 线搜索初始步长, 默认 1.0
double     barrier_ls_beta;              // 线搜索回退系数, 默认 0.5
double     barrier_ls_c;                 // Armijo 条件常数, 默认 1e-4

// === 保护机制 ===
double     barrier_step_norm_cap;        // Δx_barrier 最大允许范数, 默认 2.0 (与 PDCS 一致)
double     barrier_primal_res_factor;    // primal res 退化容忍倍数, 默认 1.5
int        barrier_check_every;          // trigger check 频次限制 (借鉴 PDCS v3.5), 默认 1

// === 自适应阈值 (借鉴 PDCS Stage 5) ===
bool       barrier_adaptive_threshold;   // 默认 true
double     barrier_fallback_high;        // fallback rate 上限, 默认 0.3
double     barrier_fallback_low;         // fallback rate 下限, 默认 0.05
int        barrier_window_size;          // 滑动窗口, 默认 100
```

总计 **~23 个新参数**. 这是参数膨胀不可避免的代价, 但通过 PDCS 5 阶段迭代已证明这是有效的.

### 5.2 新增状态结构 (`barrier_state_t`)

```c
typedef struct {
    // 触发计数 (per-cone, 4 锥 × primal/dual = 8)
    long total_trigger_count;
    long trigger_count_rsoc_primal;
    long trigger_count_rsoc_dual;
    long trigger_count_std_soc_primal;
    long trigger_count_std_soc_dual;
    long trigger_count_exp_primal;
    long trigger_count_exp_dual;
    long trigger_count_power_primal;
    long trigger_count_power_dual;
    
    // Fallback 计数
    long fallback_count_total;
    long nan_reject_count;
    long step_norm_reject_count;
    long primal_res_reject_count;
    
    // 自适应 μ 状态 (per-cone)
    double mu_current_rsoc;
    double mu_current_std;
    double mu_current_exp;
    double mu_current_power;
    int    stagnation_rsoc;
    int    stagnation_std;
    int    stagnation_exp;
    int    stagnation_power;
    
    // 自适应阈值滑动窗口 (per-cone)
    double *fallback_window_rsoc;
    double *fallback_window_std;
    double *fallback_window_exp;
    double *fallback_window_power;
    int     window_pos;
    int     window_size;
    
    // BPGrad host 缓冲 (在 initialize_solver_state 预分配)
    double *host_cone_block;             // 单锥 host 副本, 大小 = max_v_dim + 2
    double *host_cone_grad;              // 单锥梯度累积
    double *host_cone_dir;               // BPGrad 下降方向
    int     max_cone_v_dim;              // 4 锥中最大的 v_dim
    
    // Barrier 总开关 (来自 params->barrier_enabled 的副本, 加速访问)
    bool enabled;
    int  option;
} barrier_state_t;
```

总计约 **40-50 个字段**, 全部 host 端管理. 在 `initialize_solver_state` 中根据 cone buckets 初始化.

### 5.3 参数 -> PDCS 对照表

| PDCS (Julia) 参数                       | PDHCG (C) 对应字段                  | 默认值        | 备注                |
| -------------------------------------- | --------------------------------- | ---------- | ----------------- |
| `soc_barrier_enabled`                  | `barrier_enabled`                 | false      |                   |
| `soc_barrier_use_option2`              | `barrier_option = 2`              | false      | 1=Option 1b, 2=Option 2 |
| `soc_barrier_strategy`                 | `barrier_mu_strategy`             | CONSTANT   |                   |
| `soc_barrier_mu_init`                  | `barrier_mu_init`                 | 1.0        |                   |
| `soc_barrier_mu_final`                 | `barrier_mu_final`                | 1e-6       |                   |
| `soc_barrier_rho`                      | `barrier_mu_rho`                  | 0.95       |                   |
| `soc_barrier_max_iter`                 | `barrier_max_iter`                | 20         |                   |
| `soc_barrier_inner_max_iter`           | `barrier_inner_max_iter`          | 10         |                   |
| `soc_barrier_tol`                      | `barrier_tol`                     | 1e-8       |                   |
| `soc_barrier_max_ratio_threshold`      | (per-cone, 4×2=8 个)                 | 各异         | SOC=10, EXP=3, Power=5 |
| `soc_primal_max_ratio_threshold`       | `soc_*_primal_max_ratio`          | 10/10/5    | 新增独立字段            |
| `soc_dual_max_ratio_threshold`         | `soc_*_dual_max_ratio`            | 10/10/5    | 新增独立字段            |
| `exp_primal_max_ratio_threshold`       | `exp_primal_max_ratio`            | 3.0        |                   |
| `exp_dual_max_ratio_threshold`         | `exp_dual_max_ratio`              | 3.0        |                   |
| `primal_soc_barrier_trigger_count`     | `trigger_count_rsoc_primal` 等 8 个  | 0          |                   |
| `soc_barrier_inner_iter_total`         | (聚合到 `barrier_state_t` 字段)        | 0          |                   |
| `soc_barrier_fallback_count`           | `fallback_count_total`            | 0          |                   |
| (PDCS 缺失)                              | `barrier_step_norm_cap`           | 2.0        | 新增                |
| (PDCS 缺失)                              | `barrier_adaptive_threshold` 系列   | 0.3/0.05   | 借鉴 PDCS Stage 5    |

---

## 6. 实施分阶段路线图 (当前进度更新)

### 6.1 总体策略 (Stage 1 大阶段拆解)

按用户提议, 把整个实施合并为 **Stage 1 (大阶段)**, 内部细分为可独立交付的小阶段 (1.1 - 1.8).
**Stage 4 (CUDA kernel 化) 不能后置** — PDHCG 没有纯 CPU 路径, 必须与 host CPU 实现并行/同步.

**关键说明**:
- PDHCG 主循环 (`solver.cu`) 本身在 GPU 上运行, primal buffer 是 device pointer.
- 当前 `barrier_apply.c` 通过 `cudaMemcpy` 把锥块从 device 拷到 host, 跑 host CPU BPGrad, 再拷回 device.
- 这个往返对每个被触发的锥块都要发生, 当 ρ 触发频繁时, 总开销可能成为瓶颈.
- 因此 1.5/1.6 (GPU kernel) 应当与 1.8/端到端测试**并行探索**, 等端到端测试结果后再决定 kernel 投入力度.

| 小 Stage | 内容                                            | 当前状态 |
| ----- | --------------------------------------------- | ---- |
| 1.1   | 参数注入 (数据结构 + 默认值)                            | ✅ 完成 (`barrier_params.h/c`) |
| 1.2   | ρ 度量计算 (4 锥 host CPU)                          | ✅ 完成 (`boundary_metric.c`) |
| 1.3   | 触发条件 + 5 层保护 (L1-L5) + 4 种 μ 调度策略                | ✅ 完成 (`barrier_trigger.c` + `barrier_params.c`) |
| 1.4   | 4 锥 BPGrad 子求解器 (host CPU, fallback: Euclidean 投影) | ✅ 完成 (`barrier_module.c` 1002 行) |
| 1.5   | ρ 度量 CUDA kernel (已写好, 需探索接入策略)                | ✅ 完成 (4 个 `boundary_metric_*_kernel`, `apply_barrier_gpu_bucket` 调用) |
| 1.6   | BPGrad CUDA kernel + 集成 (2026-10-11)                | ✅ 完成 (4 个 `bpgrad_*_kernel` + `apply_barrier_gpu_bucket`) |
| 1.7   | 接入主循环 (`solver.cu` 的 Option 1/2 钩子)             | ✅ 完成 (`solver.cu:163, 183` 调用 `apply_barrier_*`) |
| 1.8   | CLI 集成到 `pdhcg.c` 主循环                          | ✅ 完成 (2026-09-14, 见下) |

**已就绪**: 1.1 / 1.2 / 1.3 / 1.4 / 1.5 / 1.6 / 1.7 / 1.8 (4500+ 行 C 代码 + CLI 集成 + GPU kernel)
**待做**: 端到端 CBF 测试 (服务器, 见 §6.4)
**已完成全部 Stage 1 小阶段**.

### 1.8 完成细节 (2026-09-14)

**改动的文件**:
- `PDHCG-Base/src/cli.c`:
  - 在 print_usage 末尾加 `print_barrier_cli_help()` (条件编译)
  - 在 `run_pdhcg()` 函数顶部加 `create_default_barrier_params()` 并挂到 `params.barrier_params`
  - 在 `long_options[]` 数组中追加 25 个 barrier 选项, code 范围 **3001-3025** (避开 PDHCG 的 1001-1025 和 distributed 的 2001-2004)
  - 在 switch 中追加 25 个 case 处理 (3001-3025)
  - 在 cleanup path (`qp_problem_free` 后) 加 `free_barrier_params()`
  - 所有改动包在 `#ifdef PDHCG_BARRIER_ENABLE` 里, baseline build 完全不受影响

- `PDHCG-Base/CMakeLists.txt`:
  - 新增 option `PDHCG_BARRIER_ENABLE` (默认 OFF)
  - CLI target 在启用时加 `-DPDHCG_BARRIER_ENABLE` 编译宏 + barrier include 路径
  - Barrier include 默认路径是 `${CMAKE_CURRENT_SOURCE_DIR}/../PDHCG-Barrier/include`, 可用 `-DPDHCG_BARRIER_INCLUDE=...` 覆盖

**未做 (后续 PR 补充)**:
- `run_d_pdhcg()` (distributed 路径) 的 barrier CLI 选项 — 等 serial path 测通后再加

**Build 命令**:
```bash
# Baseline (不变)
cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=Release
cmake --build build

# Barrier-enabled
cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=Release -DPDHCG_BARRIER_ENABLE=ON
cmake --build build
```
**环境依赖警告 (2026-09-14 验证时发现)**:
- 本机 (`d:\PDHCG\PDHCG-Barrier\PDHCG-Base\build`) 缺 `zlib` (find_package(ZLIB) 失败)
- 需要先装 ZLIB (`vcpkg install zlib` 或 conda) 才能 build baseline + barrier
- MSVC 18 已就绪 (`C:\Program Files\Microsoft Visual Studio\18\Community`)
- CUDA 13.3 已就绪
- 编译验证未在本会话完成 (依赖外部环境修复)

### 6.2 关键代码映射 (哪些文件对应哪些小 stage)

```
小 Stage 1.1 (参数):
  include/barrier_params.h        # barrier_params_t 结构 + μ 策略枚举 + 默认值
  src/barrier_params.c            # set_default_barrier_params(), state alloc/free

小 Stage 1.2 (ρ 度量 host):
  include/boundary_metric.h       # boundary_metric_t + 4 锥入口
  src/boundary_metric.c           # boundary_metric_generic() (host)

小 Stage 1.3 (触发 + 保护):
  include/barrier_trigger.h       # trigger_context_t / trigger_decision_t
  src/barrier_trigger.c           # decide_trigger() (L1/L2 逻辑, gap filter)
  src/barrier_params.c            # barrier_state_adapt_threshold() (L3 自适应)
  src/barrier_apply.c             # 5 层保护的 L3/L4/L5 实现

小 Stage 1.4 (BPGrad host):
  include/barrier_module.h        # bpgrad_stats_t + 4 锥函数声明
  src/barrier_module.c            # bpgrad_solve_rsoc/std_soc/exp/power/solve

小 Stage 1.5 (ρ CUDA kernel):
  src/kernels/barrier_kernels.cu  # boundary_metric_*_kernel (4 锥, 已接入 apply_barrier_gpu_bucket)

小 Stage 1.6 (BPGrad CUDA kernel):
  src/kernels/barrier_kernels.cu  # bpgrad_*_kernel (4 锥) + launch_bpgrad_* (extern "C")
  src/barrier_apply.c             # apply_barrier_gpu_bucket() — batch kernel + 同步
  PDHCG-Base/src/solver_state.cu  # allocate_barrier_gpu_buffers() 生命周期
  include/barrier_params.h        # barrier_use_gpu_bpgrad 开关, 4 个 dev_*_held 缓冲

小 Stage 1.6 设计要点 (2026-10-11 实现版):
  - 方案 B 实施: GPU 跑 Newton, host 做 fallback + L3/L4/L5 保护
  - 单 block = 单锥, 32 threads, 共享内存缓存 (k_max=64)
  - Newton 内循环最多 20 步, g=0 简化形式 (与 host barrier_module.c 一致)
  - kernel 输出 converged[blk] 标志, host 拉回一次决定 fallback
  - 默认 --barrier_use_gpu_bpgrad 1; 0 强制走 host 路径 (debug/profiling)

小 Stage 1.7 (主循环接入):
  PDHCG-Base/src/solver.cu       # apply_barrier_option_1 / option_2 触发点
  PDHCG-Base/src/solver_state.cu # barrier_state 生命周期
  src/barrier_apply.c             # apply_barrier_to_state(), iterate_cone_blocks()

小 Stage 1.8 (CLI):
  include/barrier_cli.h           # 接口 (add/parse/print)
  src/barrier_cli.c               # 实现已写
  ❌ 缺 — PDHCG-Base/src/pdhcg.c 主循环调用
```

### 6.3 阶段依赖图

```
  ┌─ 路径 A (主路径, 立即做) ──────────────────────────┐
  │                                                   │
  │   1.1 ✅ ─┬─→ 1.3 ✅ ─┬─→ 1.7 ✅               │
  │            │           │                         │
  │            └─→ 1.2 ✅ ─┴─→ 1.5 🔍 ─→ [待定]     │
  │                            │                      │
  │   1.4 ✅ ──────────────────┘                      │
  │                            │                      │
  │   1.8 ❌ (CLI) ────────────────────────────→ 端到端测试
  │        ↓                                           │
  └───────────────────────────────────────────────────┘

  ┌─ 路径 B (并行探索, 不阻塞测试) ────────────────────┐
  │   1.5 🔍 ρ kernel 接入策略                       │
  │   1.6 🔍 BPGrad kernel 设计研究                   │
  └───────────────────────────────────────────────────┘
```

**路径 A 严格串行; 路径 B 并行探索, 不阻塞 1.8 和端到端测试.**

### 6.4 下一步 (按优先级, 并行推进)

#### 路径 A (主路径, 立刻做): 1.8 + 端到端测试

**1.8 (1 天): CLI 集成到 `pdhcg.c`**
- `pdhcg.c` `main()`: 调用 `add_barrier_cli_options(options, MAX_OPTS)` 注入到 `getopt_long` 选项表
- `pdhcg.c` 选项循环: 调用 `parse_barrier_cli_option(bp, opt, optarg)` 分发处理
- `pdhcg.c` `free_params()`: 调用 `free_barrier_params()` 释放 barrier_params
- 编译测试: `./pdhcg --barrier_enabled 1 --barrier_option 1 problem.cbf` 能运行

**端到端测试 (3-5 天): 5 个 CBF 问题 × 4 组策略**
- **CBF 1**: 纯 SOC (gams01, nbL1 等规模)
- **CBF 2**: 含 RSOC (qap10)
- **CBF 3**: 含 EXP (portfol, env*)
- **CBF 4**: 含 Power (sphre, control*)
- **CBF 5**: 大规模混合 (bss1 或 DNN 问题)
- 每题跑 4 组: `baseline` / `barrier_constant` / `barrier_exponential` / `barrier_adaptive`
- 指标: wallclock, 总迭代数, barrier 触发数, primal/dual residual gap
- 判定标准: 至少 3 题 barrier 模式 ≥ baseline 性能

#### 路径 B (并行探索): GPU Kernel 设计研究

**背景**:
- 当前 `barrier_apply.c` 对每个触发的锥块做 `cudaMemcpy` (device→host) → host CPU Newton 迭代 → `cudaMemcpy` (host→device)。
- 每次 trigger check 都要同步 GPU/CPU，不能批量化。
- 4 锥的 ρ 度量 kernel (`barrier_kernels.cu`) 已经写好但未接入。

**核心问题**:
- BPGrad 在单个锥块 (3-20 变量) 上跑 Newton 迭代，内部有分支判断 (feasibility 检查、Armijo 线搜索)。
- 如果 BPGrad 放在 GPU 上，需要处理：Newton 内循环在 kernel 内能否展开？Armijo 回退的动态分支如何处理？
- 一个可行的方向：**把 BPGrad 也做成 CUDA kernel**，但允许 fallback 到 Euclidean 投影（host 端已有实现）。

**探索步骤**:
1. 分析当前 host BPGrad 的控制流，确定哪些部分可以 kernel 化
2. 评估 Newton 内循环的典型长度（10-20 步 vs GPU 的 warp/thread 分配）
3. 考虑分层方案：GPU 跑 BPGrad Newton，host 做 fallback + 5 层保护
4. 对比: **全 GPU 路径** vs **触发时仅 ρ 在 GPU、BPGrad 仍在 host** 的性能差异

---



## 7. Stage 1: 锥类型特定的 Barrier-Proximal 求解器 (Host CPU)

### 7.1 算法核心 (借鉴 PDCS `bpgrad_soc`, 但实现 4 锥)

#### 7.1.1 标准 BPGrad 框架 (4 锥通用)

```c
// barrier_module.h
typedef struct {
    double mu;
    int outer_iter;
    int inner_iter;
    bool fallback_used;
    bool converged;
    cone_type_t cone_type;
    int v_dim;             // 子向量维度 (RSOC: k, StdSOC: k, EXP: 3, Power: 3)
    double boundary_metric; // ρ 度量结果 (用于统计)
} bpgrad_stats_t;

// 4 锥的统一接口: 在 host 端运行 BPGrad
//   锥块已通过 cudaMemcpy 复制到 host_cone_block
//   修改 host_cone_block 后通过 cudaMemcpy 写回设备
bpgrad_stats_t bpgrad_solve(
    cone_type_t type,        // RSOC / StdSOC / EXP / Power
    int v_dim,               // 子向量维度 (RSOC: k, StdSOC: k, EXP: 3, Power: 3)
    double *x_block_h,       // host 端锥块 (大小 = v_dim + 1 或 + 2)
    const double *g_block_h, // host 端梯度 (来自 c = primal_step_size * (obj + dual_product))
    double tau,              // PDHG 步长
    double mu,               // barrier 参数
    const double *rescale_d, // 异构缩放因子 dᵢ (来自 state->variable_rescaling)
    const barrier_params_t *bp
);
```

#### 7.1.2 RSOC BPGrad

```c
// RSOC: x = (v[1..k], s, t), barrier φ = -log(2st - ||v||²)
// 直接移植 PDCS bpgrad_soc 到 C, 加上 PDHCG 的异构缩放
static bpgrad_stats_t bpgrad_rsoc(
    int k, double *x_h, const double *g_h, double tau, double mu,
    const double *d_h, const barrier_params_t *bp)
{
    // 1. 可行性检查: 2 s t >= ||v||²
    // 2. φ(x) = -log(2st - ||v||²)
    // 3. ∇φ(x) = [2vᵢ/(2st-||v||²); -2t/(...); -2s/(...)]  // 注意 RSOC 是旋转锥
    // 4. Newton 方向: d = (x - x_k)/τ + g + μ·∇φ(x) (考虑 rescaling)
    // 5. Armijo 线搜索 + Euclidean 投影 (用 host 版本, 因为 GPU kernel 不能 host 调用)
    // 6. fallback: 直接调用 PDHCG Euclidean 投影 (host 版本, 见 §7.4)
}
```

#### 7.1.3 StdSOC BPGrad

与 RSOC 几乎相同, 但锥约束是 `||u|| ≤ t`, barrier 是 `φ = -log(t² - ||u||²)`, 投影是 Standard SOC 投影. 可复用 RSOC 的代码骨架, 改 2-3 个公式.

#### 7.1.4 EXP BPGrad (沿用 PDCS 公式, 但 C 实现)

```c
// EXP: x = (x1, x2, x3), barrier φ = -log(x2) - log(x3) - log(x1 - x2·exp(x3/x2))
static bpgrad_stats_t bpgrad_exp(
    double *x_h, const double *g_h, double tau, double mu,
    const double *d_h, const barrier_params_t *bp)
{
    // r = x3/x2; s = x1 - x2·exp(r)
    // ∇φ = [1/s; -1/x2 + exp(r)·(1+r)/s; -1/x3 + exp(r)·r/(x2·s)]
    // Newton 步 (Hessian 对角!) 直接求解, 不需要 Armijo
    // (PDCS v5 已经确认 EXP barrier 最快)
}
```

#### 7.1.5 Power 锥 BPGrad (全新实现)

```c
// Power: x = (x, y, z), barrier φ = -α·log(x) - (1-α)·log(y) - log(x^α·y^(1-α) - |z|)
static bpgrad_stats_t bpgrad_power(
    double *x_h, const double *g_h, double tau, double mu, double alpha,
    const double *d_h, const barrier_params_t *bp)
{
    // H = x^α · y^(1-α) - |z| (需 z ≥ 0 才严格内点)
    // ∇φ = [-α/x + α·x^(α-1)·y^(1-α)/H;
    //       -(1-α)/y + (1-α)·x^α·y^(-α)/H;
    //       -sign(z)/H]
    // Hessian 仍是 3×3 矩阵 (非对角), 用 3×3 矩阵求逆求解 Newton 步
    // (验证: 标量 r 求解并不适用, 因为 power 锥有 2 个变量 (x, y))
}
```

### 7.2 Euclidean 投影的 host 版本 (用于 BPGrad 内层回退)

PDHCG 的 4 种投影都是 CUDA kernel, 不能 host 调用. 我们需要 host 版本. **两种方案**:

#### 方案 A: 把 `pdhcg_conic_kernels.cu` 中的 `project_*_point` 函数重写为 host 版本

- **优势**: 完全复用 PDHCG 的精确投影算法, 无精度损失.
- **劣势**: 需要复制 ~300 行代码, 维护两份.
- **估计工作量**: 2 天.

#### 方案 B: 在每次 fallback 时, 把锥块复制到设备 → 调 kernel → 复制回 host

- **优势**: 无重复代码, 维护一份.
- **劣势**: 每次 fallback 多一次 `cudaMemcpyAsync`, 性能损失 ~10μs.
- **估计工作量**: 半天.

**推荐**: 方案 B. PDCS 实测 fallback 触发率 < 5%, 10μs 开销可忽略.

### 7.3 BPGrad host 缓冲的预分配

在 `initialize_solver_state` 中:

```c
// 在 state 中新增 barrier_state_t 字段
state->barrier_state = (barrier_state_t *)calloc(1, sizeof(barrier_state_t));

// 扫描 4 锥, 找最大 v_dim
int max_v_dim = 0;
for (int b = 0; b < state->cones.num_buckets; b++) {
    cone_bucket_t *bk = &state->cones.buckets[b];
    for (int i = 0; i < bk->count; i++) {
        int v_dim = state->cones.v_dim[bk->offset + i];
        if (v_dim > max_v_dim) max_v_dim = v_dim;
    }
}
state->barrier_state->max_cone_v_dim = max_v_dim;

// 预分配 host 缓冲 (最大 RSOC 块: v_dim + 2 个 double)
size_t buf_size = (max_v_dim + 2) * sizeof(double);
state->barrier_state->host_cone_block = (double *)malloc(buf_size);
state->barrier_state->host_cone_grad  = (double *)malloc(buf_size);
state->barrier_state->host_cone_dir   = (double *)malloc(buf_size);

// 预分配 fallback window
state->barrier_state->window_size = barrier_params->window_size;
state->barrier_state->fallback_window_rsoc  = (double *)calloc(window, sizeof(double));
state->barrier_state->fallback_window_std   = (double *)calloc(window, sizeof(double));
state->barrier_state->fallback_window_exp   = (double *)calloc(window, sizeof(double));
state->barrier_state->fallback_window_power = (double *)calloc(window, sizeof(double));
```

### 7.4 单元测试 (Stage 1 验收)

```cpp
// tests/test_barrier_unit.cpp
TEST(Barrier, RSOC_BPGrad_ConvergesNearBoundary) {
    // 输入: x = (v=0.99*1k, s=1, t=1) (近边界)
    //       g = zeros, tau = 1.0, mu = 1.0
    // 期望: stats.converged = true, ||v||₂² < 2st (保持可行性)
    //       ||x_new - x_id|| < 1e-6 (Newton 解精度)
}

TEST(Barrier, StdSOC_BPGrad_FallbackAtBoundary) {
    // 输入: x = (t=1, u=1) (在边界)
    //       g = zeros, tau = 1.0, mu = 1.0
    // 期望: stats.fallback_used = true (因 inner = 0)
    //       返回 Euclidean 投影 (应为 0, 0.5*u)
}

TEST(Barrier, EXP_BPGrad_HessianDiagonal) {
    // 验证: 梯度方向上 F_x - F_{x-αd} ≈ α·||∇F||² (验证 Hessian 对角)
}

TEST(Barrier, Power_BPGrad_3x3Newton) {
    // 验证: 3×3 Newton 步收敛, 且 ρ = boundary_metric_power(x_new) > 0
}

TEST(Barrier, BarrierForce_RespectsFixedSlots) {
    // 输入: x = (0.99, 0.1, 0.5), is_fixed[0] = true
    // 期望: x_new[0] = 0.99 不变, x_new[1], x_new[2] 被 barrier 修正
}
```

---

## 8. Stage 2: 触发机制与几何度量 (boundary metric ρ)

### 8.1 ρ 度量定义 (借鉴 PDCS `barrier_metric.jl`)

PDHCG 的 4 锥 ρ 度量 (scale-invariant):

```c
// boundary_metric.h

// RSOC: x = (v, s, t), ρ = sqrt(2st - ||v||²) / sqrt(2st)
//   注: sqrt(2st) 是锥在 (v, s, t) 的"半径", ρ ∈ [0, 1]
double boundary_metric_rsoc(int k, const double *x, const double *d);

// StdSOC: x = (t, u), ρ = sqrt(t² - ||u||²) / |t|
double boundary_metric_std_soc(int k, const double *x, const double *d);

// EXP: x = (x1, x2, x3), ρ = (x1 - x2·exp(x3/x2)) / x1  (slack / x1)
//   注: x1 是锥的"水平尺度", ρ ∈ [0, 1]
double boundary_metric_exp(const double *x, const double *d);

// Power: x = (x, y, z), ρ = (x^α·y^(1-α) - |z|) / x^α·y^(1-α)
double boundary_metric_power(const double *x, const double *d, double alpha);
```

每个函数返回 `ρ ∈ [0, 1]`, 在锥边界处 `ρ = 0`, 在轴上 `ρ = 1`. 这是与 PDCS Stage 3 完全一致的尺度不变度量.

### 8.2 ρ → max_ratio 转换

借鉴 PDCS `max_ratio_to_boundary_threshold_soc`:

| 锥      | ρ                                  | max_ratio 关系                | ρ_threshold = max_ratio → ρ |
| ------ | ---------------------------------- | --------------------------- | ------------------------ |
| RSOC   | sqrt(2st-‖v‖²)/sqrt(2st)              | max_ratio ≈ 1/ρ² (近似)         | ρ_threshold = 1/√max_ratio |
| StdSOC | sqrt(t²-‖u‖²)/\|t\|                    | 同 RSOC                      | 同 RSOC                    |
| EXP    | slack/x₁                            | max_ratio ≈ 1/ρ              | ρ_threshold = 1/max_ratio |
| Power  | slack/(x^α·y^(1-α))                  | 同 EXP                      | ρ_threshold = 1/max_ratio |

**反查表**: 在主循环触发决策时, 把 `params.soc_rsoc_primal_max_ratio = 10.0` 转成 `ρ_threshold = 1/√10 ≈ 0.316`, 然后用 `boundary_metric_rsoc(x) <= 0.316` 判断触发.

### 8.3 4 锥 ρ 计算 kernel

```c
// barrier_kernels.cu

__global__ void compute_rho_rsoc_kernel(
    double *rho_out,                    // device [num_blocks], ρ 值
    const double *x_d,                  // device [num_variables], 整个 primal 解
    const double *rescale_d,            // device [num_variables], 异构缩放
    const int *start_idx,               // device [num_blocks]
    const int *v_dim,                   // device [num_blocks]
    int num_blocks
);

__global__ void compute_rho_std_soc_kernel(...);
__global__ void compute_rho_exp_kernel(...);
__global__ void compute_rho_power_kernel(...);

// 统一 dispatcher: 给定 bucket 类型, 调用对应的 ρ kernel
void compute_cone_rho(
    pdhg_solver_state_t *state,
    cone_type_t cone_type,
    double *rho_out_d
);
```

**调用时机**: 在 `pdhg_update` 之后, `halpern_update` 之前 (Option 1b); 或在 `halpern_update` 之后 (Option 2).

**性能**: 4 锥 ρ 计算总共是 O(num_blocks) 操作, 比 Euclidean 投影 kernel 便宜得多 (~5% 开销).

### 8.4 触发决策 (L2 Layer)

```c
// barrier_trigger.cu (借鉴 PDCS barrier_trigger.jl 的 L0/L1/L2/L3)

typedef struct {
    bool should_trigger;        // 是否触发 Barrier
    cone_type_t cone_type;      // 锥类型
    int block_idx;              // 块索引 (在 bucket 内)
    double rho;                 // 当前 ρ
    double rho_threshold;       // 当前 ρ_threshold
    double mu;                  // 当前 μ (按 strategy 计算)
    trigger_reason_t reason;    // BOUNDARY / GAP / DISABLED / FIXED_SLOT
} trigger_decision_t;

trigger_decision_t decide_trigger(
    cone_type_t type,
    int block_idx,
    double rho,
    double gap,                          // state->relative_objective_gap
    int iter,                            // state->total_count
    const barrier_state_t *bs,           // 包含 mu_current_*, stagnation_*
    const barrier_params_t *bp           // 包含 soc_*_max_ratio, mu_init, ...
);
```

**决策流程** (借鉴 PDCS `decide_trigger`):

```
1. L0 (全局开关): bs->enabled && iter % bp->barrier_check_every == 0 ?
2. L1 (锥类型): 4 锥各自有不同的 per-cone 开关 (per-cone max_ratio 都 > 1)
3. L2 (ρ 决策): rho <= rho_threshold ? (use ρ_threshold = 1/√max_ratio)
4. L2 (gap filter): gap <= 1e-3 ?  (避免破坏早期收敛, 与 PDCS 一致)
5. L2 (fixed slot): is_fixed[s_idx + k] && is_fixed[s_idx + k+1] ? (RSOC fixed slot, 不触发)
6. L3 (自适应): fallback_rate > high ? 放宽 threshold; < low ? 收紧 threshold
```

---

## 9. Stage 3: 主循环接入 (Option 1b vs Option 2)

### 9.1 Option 1b: 投影后立即修正 (post-projection)

```c
// pdhg_core_op.cu: 修改 dispatch_cone_projection 调用, 在其后挂 Barrier

// 原代码 (pdhg_core_op.cu:1256-1262)
dispatch_cone_projection(state, state->pdhg_primal_solution);
recompute_reflected_at_cones(state);

// 新代码: 在标准欧氏投影后, 对每个锥 bucket 尝试 Barrier 修正
dispatch_cone_projection(state, state->pdhg_primal_solution);
recompute_reflected_at_cones(state);
apply_barrier_option_1b(state);   // ← 新增, 见下文
```

`apply_barrier_option_1b` 实现:

```c
void apply_barrier_option_1b(pdhg_solver_state_t *state) {
    if (!state->barrier_state->enabled) return;
    if (state->barrier_state->option != OPTION_1B) return;
    
    barrier_params_t bp = make_barrier_params(state);
    barrier_state_t *bs = state->barrier_state;
    
    // 对每个锥 bucket 顺序处理
    for (int b = 0; b < state->cones.num_buckets; b++) {
        cone_bucket_t *bk = &state->cones.buckets[b];
        
        // 1. compute_rho for this bucket
        compute_cone_rho_bucket(state, bk, bs->rho_d + bk->offset);
        
        // 2. decide_trigger per block
        for (int i = 0; i < bk->count; i++) {
            trigger_decision_t dec = decide_trigger(
                bk->type, bk->offset + i,
                bs->rho_h[i],                    // 同步到 host (per-block scalar)
                state->relative_objective_gap,
                state->total_count,
                bs, &bp
            );
            if (dec.should_trigger) {
                // 3. 提取锥块到 host (cudaMemcpy, ~5μs)
                // 4. 调 bpgrad_solve
                // 5. 写回 device (cudaMemcpy, ~5μs)
                // 6. 更新 trigger_count, fallback_count
                apply_barrier_to_single_block(state, bk, i, &dec, &bp);
            }
        }
    }
}
```

### 9.2 Option 2: Halpern 后修正 (post-acceleration)

PDCS Option 2 测试经验 (demb761, beck751, car 上 2.0× 加速) 表明这是**最有效的接入点**. PDHCG 的 Halpern 更新等价于 PDCS 的 Nesterov 加速 (`halpern_update` 在 `pdhg_core_op.cu:1303-1314`).

```c
// pdhg_core_op.cu: 修改主循环尾, 在 halpern_update 后挂 Barrier

// 原代码 (solver.cu:155-167)
pdhg_update(state);
compute_fixed_point_error(state);
halpern_update(state, params->reflection_coefficient);
state->inner_count++;
state->total_count++;

// 新代码
pdhg_update(state);
compute_fixed_point_error(state);
halpern_update(state, params->reflection_coefficient);
apply_barrier_option_2(state);            // ← 新增
state->inner_count++;
state->total_count++;
```

`apply_barrier_option_2` 与 Option 1b 结构相同, 但作用于 `state->current_primal_solution` (Halpern 后的点) 而非 `pdhg_primal_solution`.

### 9.3 Slack-based Option 3 (备选)

解决 PDCS exp_20 反复证明的"变量锥无 SOC/EXP"问题. PDHCG 没有这个困扰 (PDHCG 的锥都在变量切片), 所以 Option 3 不是必须, 但可作为 fallback 触发器.

```c
// 在 compute_residual 期间, 对 primal_slack = Gx - h 应用 SOC barrier
// 仅适用于 StdSOC 和 RSOC (Slack 几何意义清晰)
// EXP/Power slack-based barrier 不推荐 (非凸 slack 域)
```

**不推荐作为默认 Option**, 仅作为研究性扩展.

### 9.4 DIAG_Q 路径特殊处理

DIAG_Q 路径 (`dispatch_cone_projection_diag_q`) 已经在内层 BB 迭代中嵌入 cone projection, 是 PDHCG 最容易陷入边界钉死的位置. 我们建议:

- **默认**: `barrier_skip_diag_q = true`, 即 DIAG_Q 路径**不挂** Barrier (避免 BB 步长被干扰).
- **可选项**: 高级用户在 DIAG_Q 路径后挂 Barrier, 但需要与 `bb->direction` 的 BB 步更新协调, 是 v2 工作.

### 9.5 保护机制 (与 PDCS 5 层一致)

```c
// barrier_module.cu 中的 5 层保护
typedef struct {
    bool barrier_applied;
    bool nan_guard_passed;
    bool feasibility_rollback_passed;
    bool step_norm_passed;
    bool primal_res_passed;
} guard_results_t;

guard_results_t check_barrier_guards(
    const double *x_old_h, const double *x_new_h,
    const double *primal_res_old, const double *primal_res_new,
    const barrier_params_t *bp
);

// 1. NaN Guard
if (!isfinite(x_new_h[0]) || ...) {
    state->barrier_state->nan_reject_count++;
    reject;
}
// 2. Feasibility Rollback (强制 x_new ∈ K)
if (!soc_check_feasible_rsoc(k, x_new_h)) {
    reject;
}
// 3. Step-norm Cap
double dx_norm = compute_norm_diff(x_old_h, x_new_h);
if (dx_norm > bp->step_norm_cap * typical_step) {
    state->barrier_state->step_norm_reject_count++;
    reject;
}
// 4. Primal Residual Guard
if (primal_res_new > primal_res_old * bp->primal_res_factor) {
    state->barrier_state->primal_res_reject_count++;
    reject;
}
// 5. Fallback (若 BPGrad 内层失败)
if (stats.fallback_used) {
    state->barrier_state->fallback_count_total++;
    // 接受 fallback 结果 (Euclidean 投影), 不拒绝
}
```

---

## 10. Stage 4: CUDA Kernel 化与 GPU 并行

### 10.1 当前 host 端 BPGrad 的性能瓶颈

Stage 1-3 在 host 端运行 BPGrad (每次触发 1 次 `cudaMemcpy` 同步, ~10μs 开销). 在 bss1 这类 ~1200 SOC 块的问题上, 同步开销累计约 12ms/iter × 100 iter = 1.2s, 显著拖慢 baseline (3.47s).

### 10.2 CUDA Kernel 化方案

#### 10.2.1 单锥 BPGrad kernel (4 锥各一个)

```cuda
// barrier_kernels.cu

// BPGrad RSOC: 每个 block 处理一个 RSOC 锥块
// blockDim.x = THREADS_PER_BLOCK (e.g., 128)
// 每个线程处理一个坐标分量的内积部分
__global__ void bpgrad_rsoc_kernel(
    double *x_d,                          // device primal_solution
    const double *g_d,                    // device gradient
    const double *rescale_d,              // device rescaling
    const int *start_idx,                 // device [num_blocks]
    const int *v_dim,                     // device [num_blocks]
    const double *rho_d,                  // device [num_blocks]
    const double *mu_d,                   // device [num_blocks]
    int num_blocks,
    int max_iter, int inner_max_iter
);

// 4 锥各一个 kernel (RSOC, StdSOC, EXP, Power)
// 每个 kernel 内部用 shared memory 缓存一个锥块
// Armijo 线搜索在 kernel 内并行化 (每个线程尝试一个 α)
// fallback 时调用 device 版本 Euclidean 投影 (直接 launch 现有 kernel)
```

#### 10.2.2 4 锥 fallback 投影 (device 版本)

直接 launch 现有 PDHCG 投影 kernel:

```cuda
// 在 BPGrad kernel 内 fallback 路径
if (inner <= 1e-12) {
    // 调用 device-side Euclidean 投影
    // 通过 __device__ 函数 project_rsoc_point_with_warm_lam (从 pdhcg_conic_kernels.cu 复制)
    ...
}
```

**实现**: 把 `pdhcg_conic_kernels.cu` 中的 `__device__ static inline double project_*_point(...)` 函数从 `static` 改为 `extern`, 在 `barrier_kernels.cu` 中 `#include` 引用.

### 10.3 全局并行策略

- **Bucket 化**: 与 PDHCG 现有的 cone bucket 一致 (按 type+method 分桶), 同一个 BPGrad kernel 处理一桶锥块.
- **Multi-block per cone**: 对 dim 较大的锥 (v_dim > 1000), 用 grid-stride loop 拆分.
- **同步点**: BPGrad 内层 Armijo 线搜索需要 block 内 __syncthreads(), 跨 block 同步不必要.

### 10.4 性能预期

借鉴 PDCS GPU 经验 (RTX 5070 Ti):
- bss1 (1 SOC + 2 EXP + 1.2k box var): barrier 触发 ~1200 次/iter, 每触发 < 1μs (kernel launch + device execution).
- syn05h (~2.3k RSOC): barrier 触发 ~2.3k 次/iter, 每触发 ~0.5μs.
- 总体开销: < 0.5 ms/iter (远小于 PDCS 的 12ms/iter).

**最终加速比**: PDCS v5.4 在 beck751 上 2.0×, PDHCG 应能复现类似加速 (考虑到 PDHCG 的 kernel 比 PDCS 更优).

### 10.5 Stage 4 单元测试

```cpp
// tests/test_barrier_kernel.cpp
TEST(BarrierKernel, RSOC_GPU_AgreesWithHost) {
    // 在 host 端算 BPGrad_1 (CPU)
    // 在 device 端算 BPGrad_2 (GPU)
    // 比较两个结果: ||x1 - x2|| < 1e-10
}

TEST(BarrierKernel, GPU_BPGrad_50000_Blocks_Speed) {
    // 创建 50000 个虚拟 RSOC 锥块 (dim 100)
    // 计时 GPU BPGrad 总耗时
    // 验证: < 10 ms on RTX 5070 Ti
}
```

---

## 11. Stage 5: 保护机制与 fallback 体系

### 11.1 5 层保护 (与 PDCS §6 完全一致)

| 层级 | 名称                | 触发条件                | 动作      | 目的            |
| --- | ----------------- | ------------------- | ------- | ------------- |
| 1   | **Gap Filter**    | gap > 1e-3          | 直接返回    | 避免破坏早期收敛      |
| 2   | **边界邻近度 Filter** | ρ > ρ_threshold     | 直接返回    | 远离边界时不浪费计算    |
| 3   | **NaN Guard**     | !isfinite(x_new)    | 回滚      | 防止数值爆炸        |
| 4   | **Step-norm Cap** | ‖Δx‖ > cap × step   | 回滚      | 防止 barrier force 过大 |
| 5   | **Primal-res Guard** | prim_res_new > 1.5 × prim_res_old | 回滚 | 防止 barrier 破坏收敛 |

### 11.2 Fallback 机制

Fallback = BPGrad 内层 Newton 求解失败时, 回退到 Euclidean 投影. 借鉴 PDCS `bpgrad_soc` 的 fallback 设计:

```c
// BPGrad kernel 内层 fallback 路径
if (inner <= 1e-12 || !ls_success) {
    stats->fallback_used = true;
    // 调 device Euclidean 投影 (直接调 PDHCG 现有 kernel)
    project_rsoc_point_device(x_block, ...);
    return x_block;
}
```

### 11.3 Fallback 统计与监控

```c
// 每 N 次成功触发后, 计算 fallback rate
double fallback_rate = (double)fallback_count_window / (double)trigger_count_window;
state->barrier_state->last_fallback_rate = fallback_rate;

// L3 自适应 (借鉴 PDCS Stage 5)
if (state->barrier_state->last_fallback_rate > bp->fallback_high) {
    // 放宽 threshold (减少触发频率)
    double new_threshold = min(current * 1.5, 100.0);
    state->barrier_state->rho_threshold_rsoc *= 1.5;
} else if (state->barrier_state->last_fallback_rate < bp->fallback_low) {
    // 收紧 threshold (增加触发频率)
    double new_threshold = max(current / 1.5, 1.01);
    state->barrier_state->rho_threshold_rsoc /= 1.5;
}
```

---

## 12. Stage 6: 参数注入、Python binding 与文档

### 12.1 命令行参数注入 (`cli.c`)

```c
// PDHCG-Base/src/cli.c: 添加 barrier 参数解析
{"--barrier_enabled", required_argument, ...},   // 0/1
{"--barrier_option", required_argument, ...},    // 1/2/3
{"--barrier_mu_init", required_argument, ...},
{"--barrier_mu_final", required_argument, ...},
{"--barrier_mu_strategy", required_argument, ...}, // constant/exp/adaptive
{"--barrier_soc_rsoc_max_ratio", required_argument, ...},   // SOC primal/dual 共用
{"--barrier_soc_std_max_ratio", required_argument, ...},
{"--barrier_exp_max_ratio", required_argument, ...},
{"--barrier_power_max_ratio", required_argument, ...},
{"--barrier_max_iter", required_argument, ...},
{"--barrier_inner_max_iter", required_argument, ...},
```

约 10 个新增 CLI 参数. 全部为可选 (默认 false).

### 12.2 Python binding

```cpp
// python_bindings/_core_bindings.cpp: 添加 barrier 参数到 pybind11

m.attr("->param_alias") = py::dict(
    py::arg("BarrierEnabled") = "barrier_enabled",
    py::arg("BarrierOption") = "barrier_option",
    py::arg("BarrierMuInit") = "barrier_mu_init",
    py::arg("BarrierMuFinal") = "barrier_mu_final",
    py::arg("BarrierMuStrategy") = "barrier_mu_strategy",
    ...
);
```

用户调用方式:

```python
from pdhcg import Model
m = Model(...)
m.setParam("BarrierEnabled", True)
m.setParam("BarrierOption", 2)         # Option 2 (PDCS 经验最优)
m.setParam("BarrierExpMaxRatio", 3.0)  # EXP 更激进
m.setParam("BarrierSocRsocMaxRatio", 10.0)
m.optimize()
```

### 12.3 文档 (PDHCG-BARRIER.md)

新建 `PDHCG-Barrier/PDHCG-BARRIER.md`, 内容包括:

1. **快速开始**: 5 行 Python 代码启用 Barrier.
2. **参数参考**: 23 个参数详细说明 + 推荐值.
3. **锥类型支持**: 4 锥 Barrier 公式与适用场景.
4. **触发机制**: ρ 度量 + max_ratio 转换表.
5. **保护机制**: 5 层保护体系说明.
6. **性能调优**: 借鉴 PDCS 的推荐参数表.
7. **已知限制**: DIAG_Q 路径暂不支持, Slack-based Option 3 仅研究性.
8. **测试结果**: 5 题 / 20 题 baseline 对比表.
9. **理论参考**: 链接到 PDCS `barrier-pdhg-analysis-zh.tex`.

---

## 14. 测试问题集与验证方案

### 14.1 测试问题集 (借鉴 PDCS exp-3.4 + Mittelman)

#### 14.1.1 单元测试 (Stage 1 验收)

- 4 锥 BPGrad 收敛性 (近边界 / 远离边界 / 在边界)
- 4 锥 ρ 度量正确性
- 4 锥 fallback 路径
- 异构缩放下 BPGrad 精度
- Fixed slot 保护

#### 14.1.2 集成测试 (Stage 3 验收)

借鉴 PDCS 5 题集:

| 问题        | 锥类型           | 理论主触发         | 期望加速 |
| --------- | ------------- | -------------- | ----- |
| bss1.cbf  | 1 SOC + 2 EXP | Dual EXP       | 1.5×+ |
| beck751.cbf | 87 EXP       | Dual EXP       | 2.0×+ |
| car.cbf   | 1 SOC + 141 EXP | Dual SOC + EXP  | 1.5×+ |
| demb761.cbf | 87 EXP       | Dual EXP       | 2.0×+ |
| ex1223.cbf | 16 SOC + 1 EXP | Dual SOC + EXP | 1.2×+ |

加上 PDHCG 独家 Power 锥测试:

| 问题               | 锥类型     | 来源                | 期望行为    |
| ---------------- | ------- | ----------------- | ------- |
| power_test_*.cbf | Power   | 自构造 (CBLIB 中无)    | 1.0×+ |

#### 14.1.3 性能测试 (Stage 6 验收)

- 5 题 × 3 配置 (baseline / Option 1b / Option 2) × 3 次 = 45 runs.
- 关注指标: solve_time, total_iter, barrier_trigger_count, fallback_count, obj consistency.

### 14.2 Baseline 验证 (借鉴 PDCS §15 教训)

**关键教训 (PDCS §15)**:
> 永远从已知工作的版本开始; 每次修改后立即验证 baseline; 成功后立即记录文件 hash 和配置.

我们必须:
1. **记录初始 PDHCG-Base commit hash** (基线快照).
2. **每次 commit 前跑 baseline 5 题**, 确保 status=OPTIMAL, obj 与文献一致.
3. **Barrier 修改后, 5 题 baseline 必须 obj 完全一致** (barrier_enabled=false 时行为不变).

### 14.3 测试脚本 (PowerShell + Bash 兼容)

```powershell
# scripts/run_barrier_baseline.ps1
$problems = @("bss1", "beck751", "car", "demb761", "ex1223")
foreach ($prob in $problems) {
    & pdhcg.exe --cbf "$prob.cbf" --barrier_enabled false `
                --barrier_option 0 --time_limit 120 `
                --eps_opt 1e-4 --eps_feas 1e-4 `
                --output_dir "./results/baseline/$prob" 2>&1 |
        Tee-Object -FilePath "./logs/baseline_$prob.log"
}

# scripts/run_barrier_option2.ps1 (类似, barrier_option 2)
```

---

## 15. 风险评估与已知问题

### 15.1 高风险

| 风险                                | 影响                | 缓解措施                                  |
| --------------------------------- | ----------------- | ------------------------------------- |
| DIAG_Q 路径与 Barrier force 冲突     | 求解方向破坏, 收敛失败       | 默认 skip_diag_q=true; v2 才考虑            |
| BB 步长与 Barrier 修改 primal 方向冲突  | 同上                | 在 BB 步更新**之前**应用 Barrier (Option 1b DIAG_Q) |
| 同步开销在 bss1 类问题上拖累 baseline     | 性能下降, 不加速反减        | Stage 4 必须 kernel 化, 同步 < 0.5 ms/iter     |
| Power 锥 BPGrad 公式错误             | 算法错误, 不收敛          | 单元测试覆盖 + 与解析 Newton 解对比              |
| RSOC 与 StdSOC 公式混淆              | 锥类型错位, 投影到错锥       | 强制 unit test 覆盖 4 锥的所有维度             |

### 15.2 中风险

| 风险                                 | 影响        | 缓解措施                          |
| ---------------------------------- | --------- | ----------------------------- |
| EXP barrier 在 CPU 上慢 (vs GPU)       | 性能不达预期    | Stage 4 必须 kernel 化             |
| 自适应 μ 在某些问题震荡                    | 求解不稳定      | 借鉴 PDCS Stage 5 的滑动窗口          |
| Slack-based Option 3 不通用           | 仅 RSOC/StdSOC 可用 | 文档明示限制                       |
| `qcqp_to_socp` 把 Power 锥转成 RSOC 后, Barrier 设计是否仍有效 | QCQP 问题不加速 | Stage 5 后测试 Mittelman QCQP 集 |

### 15.3 低风险

| 风险                                 | 影响        | 缓解措施                          |
| ---------------------------------- | --------- | ----------------------------- |
| CUDA kernel 化后 host/device 内存泄漏  | 长期运行崩溃    | 用 CUDA memcheck + valgrind      |
| CLI 参数过长难以维护                       | 用户体验      | 提供常用参数组合的 presets              |
| Python binding 与 C 版本不一致           | API 不稳定    | pybind11 自动同步                  |

### 15.4 PDCS 已证明的"barrier 无效"场景 (PDHCG 也可能无效)

PDCS exp-3.4 v3.6 测试发现, 以下场景 barrier 不触发或无效:
- **EXP iterates 远离边界** (ρ > 0.5): 几乎所有 8 个测试问题
- **batch / cx02-100**: solver 本身慢, 不是 barrier 问题
- **LP 问题**: 无锥, 无需 barrier

PDHCG 应**预先声明**这些已知无效场景, 避免无效调优.

---

## 16. 附录 A: 与 PDCS Barrier 的关键 API 对照

### 16.1 函数映射表

| PDCS (Julia) 函数                            | PDHCG (C) 对应                                      | 备注                |
| ---------------------------------------- | ------------------------------------------------- | ----------------- |
| `soc_barrier_kernel(x)`                  | `barrier_value_rsoc(k, x, d)`                     | φ 值               |
| `soc_barrier_grad(x)`                    | `barrier_grad_rsoc(k, x, d)`                      | ∇φ                |
| `compute_soc_boundary_ratio(x)`          | `boundary_metric_rsoc(k, x, d)`                   | PDCS Stage 2 用, PDHCG 用 ρ 替代 |
| `soc_check_feasibility(x)`              | `rsoc_check_feasibility(k, x)`                    | 可行性检查             |
| `soc_proj_euclidean(x)`                  | `project_rsoc_point_host(k, x, d)` (新写 host 版)     | fallback 用        |
| `bpgrad_soc(x_k, g, tau, mu; ...)`      | `bpgrad_solve(CONE_RSOC, k, x, g, d, τ, μ, bp)` | BPGrad 内核          |
| `update_barrier_mu(strategy, ...)`      | `decide_mu(strategy, iter, gap, rho, bs, bp)`    | μ 调度              |
| `apply_soc_barrier_prox_single(...)`    | `apply_barrier_to_single_block(state, bk, i)`    | 单锥主入口             |
| `apply_exp_primal_barrier_force!(...)`  | `barrier_force_exp(x, d, μ, α)`                  | EXP barrier force |
| `apply_soc_dual_barrier_prox_single`    | (PDHCG 中不需自对偶变换, 直接调 RSOC kernel)              | 4 锥全部 self-dual   |
| `apply_exp_cone_barrier_prox_single`    | `apply_barrier_to_single_block` (CONE_EXPONENTIAL) |                  |
| `barrier_metric_soc` / `barrier_metric_exp` | `boundary_metric_*` (4 个)                       | ρ 度量              |
| `barrier_trigger.jl: ConeTriggerConfig`  | `barrier_params_t`                                | per-cone 配置       |
| `barrier_trigger.jl: ConeTriggerState`   | `barrier_state_t`                                 | per-cone 状态       |
| `barrier_trigger.jl: BarrierTriggerEngine` | (host-only 调度器, 无 C 包装)                       | 直接在主循环内联         |
| `MOI_wrapper.jl: 4 个 trigger count 属性`  | `state->barrier_state->trigger_count_*` (8 个)     |                  |

### 16.2 实施对应 (Stage 1-3 即可完成对应)

- **PDCS Stage 1** (触发计数): 对应 PDHCG `trigger_count_*` 8 个字段.
- **PDCS Stage 2** (per-cone 阈值): 对应 PDHCG `soc_*_max_ratio` 8 个字段 + `rho_threshold` 转换.
- **PDCS Stage 3** (ρ 度量): 对应 PDHCG `boundary_metric_*` 4 个函数.
- **PDCS Stage 4** (调度引擎): 对应 PDHCG `barrier_trigger.cu` 的 `decide_trigger()`.
- **PDCS Stage 5** (自适应 fallback): 对应 PDHCG `barrier_state_t.fallback_window_*` + 自适应调整.

---

## 17. 附录 B: 一句话总结

**PDHCG Barrier 设计借鉴 PDCS exp-3.4 的 5 阶段方法论, 将 RSOC + StdSOC + EXP + Power 4 锥 (全 self-dual) 的 Barrier-Proximal 求解器嵌入主循环的 Halpern 后 (Option 2) 或投影后 (Option 1b) 接入点, 用 ρ 度量替换 max_ratio 触发决策, 配合 5 层保护机制 (Gap / ρ / NaN / Step-norm / Primal-res) 与自适应 fallback 调整, 预计在 bss1/beck751/car 等经典锥问题上可复现 PDCS 的 1.5-2.0× 加速.**

---

**创建日期**: 2026-09-11  
**对应 PDCS 文档**: `BARRIER_CONTEXT_SUMMARY.md` (exp-3.4 v5, 2026-09-06)  
**下一步**: 等待用户批准本计划 → 开始 Stage 0 (基线验证 + 参数注入)
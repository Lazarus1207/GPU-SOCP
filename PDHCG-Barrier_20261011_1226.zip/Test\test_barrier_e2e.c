/*
================================================================================
test_barrier_e2e.c - End-to-end barrier integration test (no CBF file needed)

编译:
  cl /I..\include /I..\internal /I..\..\third_party\zlib-install\include ^
     /std:c17 /O2 /Fe:test_barrier_e2e.exe test_barrier_e2e.c ^
     ..\build-barrier\pdhcg_core.lib ^
     /link /LIBPATH:..\..\third_party\zlib-install\lib zlib.lib ^
            "C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v13.3\lib\x64\cudart.lib" ^
            "C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v13.3\lib\x64\cusparse.lib" ^
            "C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v13.3\lib\x64\cublas.lib"

运行:
  test_barrier_e2e.exe

本程序:
  1. 生成一个小的随机 SOC 约束 QP 问题 (~20 变量, 无约束, 1 个 RSOC 锥)
  2. 跑 baseline (barrier_disabled): --barrier_enabled=0
  3. 跑 barrier    (barrier_enabled): --barrier_enabled=1 --barrier_option=1
  4. 对比两次的 primal_objective / dual_objective / runtime / iteration_count
  5. 报告 barrier 是否被触发 (trigger_count)

================================================================================
*/

#include "pdhcg.h"
#include "barrier_params.h"
#include <float.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define N 20          /* 变量数 */
#define CONE_DIM 10  /* RSOC v_dim = 10, 总共 12 个锥变量 */

/* 生成随机 double [lo, hi] */
static double rnd_dbl(double lo, double hi)
{
    double r = (double)rand() / (double)RAND_MAX;
    return lo + r * (hi - lo);
}

/* 生成随机正交矩阵 (Givens 旋转法) */
static void rnd_orthogonal(double *Q, int n)
{
    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
            Q[i * n + j] = (i == j) ? 1.0 : 0.0;

    for (int k = 0; k < n - 1; k++) {
        double x = rnd_dbl(-1.0, 1.0), y = rnd_dbl(-1.0, 1.0);
        double r = sqrt(x * x + y * y);
        double c = x / r, s = -y / r;
        for (int j = 0; j < n; j++) {
            double qkj = Q[k * n + j], q_n1j = Q[(n - 1) * n + j];
            Q[k * n + j]      = c * qkj - s * q_n1j;
            Q[(n - 1) * n + j] = s * qkj + c * q_n1j;
        }
    }
}

/* 生成一个小的随机 SOC 约束 QP */
static qp_problem_t *make_random_soc_problem(void)
{
    /* Objective: min 0.5 * x^T Q x + c^T x
     * Q = LL^T (随机半正定), c = 随机
     * 无约束 (A = empty), 1 个 RSOC 锥
     */
    srand(42);

    /* 构造 Q (SPD) */
    double L[N * N];
    for (int i = 0; i < N * N; i++) L[i] = rnd_dbl(-0.1, 0.1);
    double Qmat[N * N];
    for (int i = 0; i < N; i++)
        for (int j = 0; j < N; j++) {
            double v = 0.0;
            for (int k = 0; k < N; k++) v += L[i * N + k] * L[j * N + k];
            Qmat[i * N + j] = v;
        }
    /* 对角扰动确保正定 */
    for (int i = 0; i < N; i++) Qmat[i * N + i] += 1.0;

    /* 构造 Q in CSR */
    int *q_row_ptr = (int *)calloc(N + 1, sizeof(int));
    int nnz_q = 0;
    for (int i = 0; i < N; i++) {
        q_row_ptr[i] = nnz_q;
        for (int j = 0; j < N; j++) {
            if (fabs(Qmat[i * N + j]) > 1e-15) nnz_q++;
        }
    }
    q_row_ptr[N] = nnz_q;

    int *q_col_ind = (int *)malloc(nnz_q * sizeof(int));
    double *q_val   = (double *)malloc(nnz_q * sizeof(double));
    nnz_q = 0;
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            if (fabs(Qmat[i * N + j]) > 1e-15) {
                q_col_ind[nnz_q] = j;
                q_val[nnz_q]     = Qmat[i * N + j];
                nnz_q++;
            }
        }
    }

    matrix_desc_t Q_desc = {0};
    Q_desc.m = N;
    Q_desc.n = N;
    Q_desc.fmt = matrix_csr;
    Q_desc.data.csr.row_ptr = q_row_ptr;
    Q_desc.data.csr.col_ind = q_col_ind;
    Q_desc.data.csr.val      = q_val;
    Q_desc.data.csr.nnz      = nnz_q;

    /* 目标函数向量 c = 0 */
    double *c = (double *)calloc(N, sizeof(double));

    /* 无约束 (m=0) */
    matrix_desc_t A_desc = {0};
    A_desc.m = 0;
    A_desc.n = N;
    A_desc.fmt = matrix_csr;
    A_desc.data.csr.row_ptr = (int *)calloc(1, sizeof(int));
    A_desc.data.csr.nnz = 0;

    /* Cone: RSOC(v_dim=10) 放在变量 0..11 (12 个变量)
     * 锥块: [v0..v9, s=12, t=13], 总 n = 14
     * 注意: Q 矩阵是 N×N, cone 变量在最后 CONE_DIM+2 个位置
     *       但 Q 只作用在前 N 个变量上
     * 简化: 把锥变量也加到 Q 里 (k=CONE_DIM+2 变量, Q 是块对角的)
     */
    int cone_start = N - (CONE_DIM + 2);  /* 20 - 12 = 8, 变量 8..19 是锥变量 */

    /* 重新生成完整问题, n = cone_start + CONE_DIM + 2 = N */
    /* 上面已正确: N = cone_start + CONE_DIM + 2, Q 只在前 cone_start 个上 */

    /* 重新计算 n_total = cone_start + CONE_DIM + 2 = N */
    /* Q 的 n 与 problem n 一致即可, cone 变量无 Q 项 */

    /* Cone spec */
    cone_spec_t cone = {
        .type = CONE_ROTATED_SOC,
        .start_idx = cone_start,
        .v_dim = CONE_DIM,
        .alpha = 0.0,
        .is_fixed = NULL,
    };

    qp_problem_t *prob = create_qp_problem(
        c, &Q_desc, NULL, NULL, &A_desc,
        NULL, NULL, NULL, NULL, NULL,
        1, &cone);

    free(q_row_ptr);
    free(q_col_ind);
    free(q_val);
    free(c);
    return prob;
}

static void print_barrier_state_summary(const pdhcg_result_t *r, const char *label)
{
    (void)r;
    /* barrier state 通过外部 barrier_params 打印，这里只打印 result */
    printf("  [%s] primal_obj=%.6e  dual_obj=%.6e  gap=%.6e  iter=%d\n",
           label,
           r->primal_objective_value,
           r->dual_objective_value,
           r->objective_gap,
           r->total_count);
}

int main(int argc, char *argv[])
{
    (void)argc; (void)argv;
    printf("=== PDHCG-Barrier End-to-End Test ===\n\n");

    /* 生成问题 */
    qp_problem_t *problem = make_random_soc_problem();
    if (!problem) {
        fprintf(stderr, "Failed to create problem\n");
        return 1;
    }
    printf("Problem: n=%d  m=%d  cones=%d (RSOC, v_dim=%d, start=%d)\n\n",
           problem->num_variables,
           problem->num_constraints,
           problem->cones.num_cones,
           problem->cones.v_dim[0],
           problem->cones.start_idx[0]);

    /* ---- Baseline: barrier_disabled ---- */
    printf("[1/2] Running baseline (barrier_enabled=0)...\n");
    pdhg_parameters_t params_baseline;
    set_default_parameters(&params_baseline);
    params_baseline.barrier_params = NULL; /* 显式禁用 */
    params_baseline.verbose = 1;

    pdhcg_result_t *result_baseline = solve_qp_problem(problem, &params_baseline);
    if (!result_baseline) {
        fprintf(stderr, "Baseline solve failed\n");
        qp_problem_free(problem);
        return 1;
    }
    print_barrier_state_summary(result_baseline, "baseline");

    /* ---- Barrier: barrier_enabled=1, option=1 ---- */
    printf("\n[2/2] Running barrier (barrier_enabled=1, option=1)...\n");
    pdhg_parameters_t params_barrier;
    set_default_parameters(&params_barrier);
    params_barrier.verbose = 1;

    struct barrier_params_t *bp = create_default_barrier_params();
    if (!bp) {
        fprintf(stderr, "Failed to create barrier_params\n");
        pdhcg_result_free(result_baseline);
        qp_problem_free(problem);
        return 1;
    }
    bp->barrier_enabled = 1;
    bp->barrier_option = BARRIER_OPTION_1;
    bp->barrier_verbose = 2;
    bp->barrier_check_every = 1;
    /* 激进触发: 低阈值 */
    bp->soc_rsoc_max_ratio = 100.0; /* 大的 max_ratio → 小 rho_thresh → 更容易触发 */
    bp->barrier_mu_init = 1e-1;
    params_barrier.barrier_params = bp;

    pdhcg_result_t *result_barrier = solve_qp_problem(problem, &params_barrier);
    if (!result_barrier) {
        fprintf(stderr, "Barrier solve failed\n");
        free_barrier_params(bp);
        pdhcg_result_free(result_baseline);
        qp_problem_free(problem);
        return 1;
    }
    print_barrier_state_summary(result_barrier, "barrier");

    /* ---- 对比 ---- */
    printf("\n=== Comparison ===\n");
    double obj_diff = fabs(result_barrier->primal_objective_value -
                           result_baseline->primal_objective_value);
    double obj_rel_diff = obj_diff / (1.0 + fabs(result_baseline->primal_objective_value));
    printf("Primal objective diff: %e (rel=%.2e)\n", obj_diff, obj_rel_diff);
    printf("Baseline iterations: %d\n", result_baseline->total_count);
    printf("Barrier iterations:   %d\n", result_barrier->total_count);
    printf("Baseline runtime: %.3f s\n", result_baseline->cumulative_time_sec);
    printf("Barrier runtime:   %.3f s\n", result_barrier->cumulative_time_sec);

    /* 判断是否触发 barrier (通过 verbose=2 输出已打印) */
    int pass = 1;
    if (obj_rel_diff > 1e-3) {
        printf("\n[WARNING] Significant objective difference detected (rel=%.2e)\n", obj_rel_diff);
        /* 不算 fail，因为 barrier 可能改变了收敛路径 */
    }
    if (result_barrier->cumulative_time_sec > result_baseline->cumulative_time_sec * 5.0) {
        printf("\n[WARNING] Barrier is >5x slower than baseline\n");
    }

    /* Barrier 应该正常跑完 (不 crash / 不 NaN) */
    if (isfinite(result_barrier->primal_objective_value) &&
        isfinite(result_barrier->dual_objective_value)) {
        printf("\n[PASS] Barrier path completed without NaN/Inf\n");
    } else {
        printf("\n[FAIL] Barrier produced NaN/Inf\n");
        pass = 0;
    }

    printf("\n=== Test Complete ===\n");

    free_barrier_params(bp);
    pdhcg_result_free(result_baseline);
    pdhcg_result_free(result_barrier);
    qp_problem_free(problem);
    return pass ? 0 : 1;
}

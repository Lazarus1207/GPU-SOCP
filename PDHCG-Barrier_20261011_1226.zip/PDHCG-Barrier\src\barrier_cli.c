/*
================================================================================
barrier_cli.c - CLI Parameter Parsing for Barrier
================================================================================
*/

#include "barrier_cli.h"
#include "barrier_params.h"
#include <getopt.h>
#include <stdio.h>
#include <stdlib.h>

/* Option codes for barrier (must not collide with PDHCG's 1001-1025) */
#define OPT_BARRIER_ENABLED              2001
#define OPT_BARRIER_OPTION               2002
#define OPT_BARRIER_MU_INIT              2003
#define OPT_BARRIER_MU_FINAL             2004
#define OPT_BARRIER_MU_STRATEGY          2005
#define OPT_BARRIER_MU_RHO               2006
#define OPT_BARRIER_HOMOTOPY_ALPHA       2020
#define OPT_BARRIER_HOMOTOPY_BETA        2021
#define OPT_BARRIER_SOC_RSOC_MU_INIT     2022
#define OPT_BARRIER_STD_SOC_MU_INIT      2023
#define OPT_BARRIER_EXP_MU_INIT          2024
#define OPT_BARRIER_POWER_MU_INIT        2025
#define OPT_BARRIER_SOC_RSOC_RATIO       2007
#define OPT_BARRIER_STD_SOC_RATIO        2008
#define OPT_BARRIER_EXP_RATIO            2009
#define OPT_BARRIER_POWER_RATIO          2010
#define OPT_BARRIER_MAX_ITER             2011
#define OPT_BARRIER_INNER_MAX_ITER       2012
#define OPT_BARRIER_TOL                  2013
#define OPT_BARRIER_CHECK_EVERY          2014
#define OPT_BARRIER_GAP_THRESHOLD        2015
#define OPT_BARRIER_STEP_NORM_CAP        2016
#define OPT_BARRIER_PRIMAL_RES_FACTOR    2017
#define OPT_BARRIER_ADAPTIVE_THRESHOLD   2018
#define OPT_BARRIER_VERBOSE              2019
#define OPT_BARRIER_USE_GPU_BPGRAD       2026

struct barrier_params_t *create_default_barrier_params(void)
{
    barrier_params_t *bp = (barrier_params_t *)calloc(1, sizeof(barrier_params_t));
    if (bp) set_default_barrier_params(bp);
    return bp;
}

void free_barrier_params(struct barrier_params_t *bp)
{
    if (bp) free(bp);
}

int add_barrier_cli_options(struct option *options, int max_size)
{
    /* Must match PDHCG's existing option struct (struct option from getopt.h) */
    int n = 0;

    #define ADD_OPT(name, code) \
        do { \
            if (n >= max_size) break; \
            options[n].name = (name); \
            options[n].has_arg = required_argument; \
            options[n].flag = NULL; \
            options[n].val = (code); \
            n++; \
        } while (0)

    ADD_OPT("barrier_enabled",              OPT_BARRIER_ENABLED);
    ADD_OPT("barrier_option",               OPT_BARRIER_OPTION);
    ADD_OPT("barrier_mu_init",              OPT_BARRIER_MU_INIT);
    ADD_OPT("barrier_mu_final",             OPT_BARRIER_MU_FINAL);
    ADD_OPT("barrier_mu_strategy",          OPT_BARRIER_MU_STRATEGY);
    ADD_OPT("barrier_mu_rho",               OPT_BARRIER_MU_RHO);
    ADD_OPT("barrier_homotopy_alpha",       OPT_BARRIER_HOMOTOPY_ALPHA);
    ADD_OPT("barrier_homotopy_beta",        OPT_BARRIER_HOMOTOPY_BETA);
    ADD_OPT("barrier_soc_rsoc_mu_init",     OPT_BARRIER_SOC_RSOC_MU_INIT);
    ADD_OPT("barrier_std_soc_mu_init",      OPT_BARRIER_STD_SOC_MU_INIT);
    ADD_OPT("barrier_exp_mu_init",          OPT_BARRIER_EXP_MU_INIT);
    ADD_OPT("barrier_power_mu_init",        OPT_BARRIER_POWER_MU_INIT);
    ADD_OPT("barrier_soc_rsoc_ratio",       OPT_BARRIER_SOC_RSOC_RATIO);
    ADD_OPT("barrier_std_soc_ratio",        OPT_BARRIER_STD_SOC_RATIO);
    ADD_OPT("barrier_exp_ratio",            OPT_BARRIER_EXP_RATIO);
    ADD_OPT("barrier_power_ratio",          OPT_BARRIER_POWER_RATIO);
    ADD_OPT("barrier_max_iter",             OPT_BARRIER_MAX_ITER);
    ADD_OPT("barrier_inner_max_iter",       OPT_BARRIER_INNER_MAX_ITER);
    ADD_OPT("barrier_tol",                  OPT_BARRIER_TOL);
    ADD_OPT("barrier_check_every",          OPT_BARRIER_CHECK_EVERY);
    ADD_OPT("barrier_gap_threshold",        OPT_BARRIER_GAP_THRESHOLD);
    ADD_OPT("barrier_step_norm_cap",        OPT_BARRIER_STEP_NORM_CAP);
    ADD_OPT("barrier_primal_res_factor",    OPT_BARRIER_PRIMAL_RES_FACTOR);
    ADD_OPT("barrier_adaptive_threshold",   OPT_BARRIER_ADAPTIVE_THRESHOLD);
    ADD_OPT("barrier_verbose",              OPT_BARRIER_VERBOSE);
    ADD_OPT("barrier_use_gpu_bpgrad",       OPT_BARRIER_USE_GPU_BPGRAD);

    #undef ADD_OPT
    return n;
}

int parse_barrier_cli_option(struct barrier_params_t *bp, int opt, const char *optarg)
{
    if (!bp) return 0;

    switch (opt) {
        case OPT_BARRIER_ENABLED:
            bp->barrier_enabled = (atoi(optarg) != 0);
            return 1;
        case OPT_BARRIER_OPTION:
            bp->barrier_option = (barrier_option_t)atoi(optarg);
            return 1;
        case OPT_BARRIER_MU_INIT:
            bp->barrier_mu_init = atof(optarg);
            return 1;
        case OPT_BARRIER_MU_FINAL:
            bp->barrier_mu_final = atof(optarg);
            return 1;
        case OPT_BARRIER_MU_STRATEGY: {
            int s = atoi(optarg);
            if (s >= 0 && s < BARRIER_MU_NUM_STRATEGIES) {
                bp->barrier_mu_strategy = (barrier_mu_strategy_t)s;
            }
            return 1;
        }
        case OPT_BARRIER_MU_RHO:
            bp->barrier_mu_rho = atof(optarg);
            return 1;
        case OPT_BARRIER_HOMOTOPY_ALPHA:
            bp->barrier_homotopy_alpha = atof(optarg);
            return 1;
        case OPT_BARRIER_HOMOTOPY_BETA:
            bp->barrier_homotopy_beta = atof(optarg);
            return 1;
        case OPT_BARRIER_SOC_RSOC_MU_INIT:
            bp->soc_rsoc_mu_init = atof(optarg);
            return 1;
        case OPT_BARRIER_STD_SOC_MU_INIT:
            bp->std_soc_mu_init = atof(optarg);
            return 1;
        case OPT_BARRIER_EXP_MU_INIT:
            bp->exp_mu_init = atof(optarg);
            return 1;
        case OPT_BARRIER_POWER_MU_INIT:
            bp->power_mu_init = atof(optarg);
            return 1;
        case OPT_BARRIER_SOC_RSOC_RATIO:
            bp->soc_rsoc_max_ratio = atof(optarg);
            return 1;
        case OPT_BARRIER_STD_SOC_RATIO:
            bp->std_soc_max_ratio = atof(optarg);
            return 1;
        case OPT_BARRIER_EXP_RATIO:
            bp->exp_max_ratio = atof(optarg);
            return 1;
        case OPT_BARRIER_POWER_RATIO:
            bp->power_max_ratio = atof(optarg);
            return 1;
        case OPT_BARRIER_MAX_ITER:
            bp->barrier_max_iter = atoi(optarg);
            return 1;
        case OPT_BARRIER_INNER_MAX_ITER:
            bp->barrier_inner_max_iter = atoi(optarg);
            return 1;
        case OPT_BARRIER_TOL:
            bp->barrier_tol = atof(optarg);
            return 1;
        case OPT_BARRIER_CHECK_EVERY:
            bp->barrier_check_every = atoi(optarg);
            return 1;
        case OPT_BARRIER_GAP_THRESHOLD:
            bp->barrier_gap_threshold = atof(optarg);
            return 1;
        case OPT_BARRIER_STEP_NORM_CAP:
            bp->barrier_step_norm_cap = atof(optarg);
            return 1;
        case OPT_BARRIER_PRIMAL_RES_FACTOR:
            bp->barrier_primal_res_factor = atof(optarg);
            return 1;
        case OPT_BARRIER_ADAPTIVE_THRESHOLD:
            bp->barrier_adaptive_threshold = (atoi(optarg) != 0);
            return 1;
        case OPT_BARRIER_VERBOSE:
            bp->barrier_verbose = atoi(optarg);
            return 1;
        case OPT_BARRIER_USE_GPU_BPGRAD:
            bp->barrier_use_gpu_bpgrad = (atoi(optarg) != 0);
            return 1;
        default:
            return 0;
    }
}

void print_barrier_cli_help(void)
{
    fprintf(stderr, "\n  Barrier Enhancement Options (PDHCG-Barrier):\n");
    fprintf(stderr, "      --barrier_enabled <0|1>     Enable barrier (default: 0).\n");
    fprintf(stderr, "      --barrier_option <1|2>      Insertion: 1=pre-Halpern, 2=post-Halpern (default: 1).\n");
    fprintf(stderr, "      --barrier_mu_init <float>   Initial mu (default: 1.0).\n");
    fprintf(stderr, "      --barrier_mu_final <float>  Final mu (default: 1e-6).\n");
    fprintf(stderr, "      --barrier_mu_strategy <0|1|2|3>  0=constant(μ固定), 1=exponential(μ×ρ^k), 2=adaptive(自适应), 3=homotopy(IPM μ/iter^β) (default: 0).\n");
    fprintf(stderr, "      --barrier_mu_rho <float>           Decay rate for exponential (default: 0.95).\n");
    fprintf(stderr, "      --barrier_homotopy_alpha <float>   IPM homotopy: 1/(1+α·iter)^β decay rate (default: 1.0).\n");
    fprintf(stderr, "      --barrier_homotopy_beta <float>    IPM homotopy: polynomial order β, 2.0=1/iter², 1.0=1/iter (default: 2.0).\n");
    fprintf(stderr, "      --barrier_soc_rsoc_mu_init <float>  RSOC/SOC per-cone mu_init (default: 1e-1).\n");
    fprintf(stderr, "      --barrier_std_soc_mu_init <float>   StdSOC per-cone mu_init (default: 1e-1).\n");
    fprintf(stderr, "      --barrier_exp_mu_init <float>       EXP per-cone mu_init (default: 1e-2).\n");
    fprintf(stderr, "      --barrier_power_mu_init <float>     Power per-cone mu_init (default: 1e-2).\n");
    fprintf(stderr, "      --barrier_soc_rsoc_ratio <float>  RSOC max_ratio threshold (default: 10.0).\n");
    fprintf(stderr, "      --barrier_std_soc_ratio <float>   StdSOC max_ratio threshold (default: 10.0).\n");
    fprintf(stderr, "      --barrier_exp_ratio <float>       EXP max_ratio threshold (default: 3.0).\n");
    fprintf(stderr, "      --barrier_power_ratio <float>     Power max_ratio threshold (default: 5.0).\n");
    fprintf(stderr, "      --barrier_max_iter <int>     BPGrad outer iterations (default: 20).\n");
    fprintf(stderr, "      --barrier_inner_max_iter <int>  Armijo line search max (default: 10).\n");
    fprintf(stderr, "      --barrier_tol <float>        BPGrad tolerance (default: 1e-8).\n");
    fprintf(stderr, "      --barrier_check_every <int>  Trigger check frequency (default: 1).\n");
    fprintf(stderr, "      --barrier_gap_threshold <float>  Gap filter (default: 1e-3).\n");
    fprintf(stderr, "      --barrier_step_norm_cap <float>  Step-norm cap (default: 2.0).\n");
    fprintf(stderr, "      --barrier_primal_res_factor <float>  Primal-res factor (default: 1.5).\n");
    fprintf(stderr, "      --barrier_adaptive_threshold <0|1>  Adaptive threshold (default: 1).\n");
    fprintf(stderr, "      --barrier_use_gpu_bpgrad <0|1>   Use GPU BPGrad batch path (default: 1).\n");
    fprintf(stderr, "      --barrier_verbose <0|1|2>    Barrier verbose level (default: 1).\n");
}

/*
================================================================================
test_barrier_unit.cpp - Unit Tests for Barrier Module

Tests:
  - 4 cone boundary metric ρ computation
  - 4 cone BPGrad convergence
  - Trigger decision L0/L1/L2/L3
  - 5-layer protection mechanisms
  - State management
================================================================================
*/

#include "barrier_params.h"
#include "boundary_metric.h"
#include "barrier_module.h"
#include "barrier_trigger.h"

#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <vector>

#define EPS 1e-10

/* Test result tracking */
static int tests_run = 0;
static int tests_passed = 0;

#define TEST_BEGIN(name) \
    do { \
        tests_run++; \
        printf("[TEST] %-60s ", name); \
        fflush(stdout); \
    } while (0)

#define TEST_PASS() \
    do { \
        tests_passed++; \
        printf("PASS\n"); \
    } while (0)

#define TEST_FAIL(msg) \
    do { \
        printf("FAIL: %s\n", msg); \
        return; \
    } while (0)

/* =============================================================================
 * Section 1: Boundary Metric Tests
 * ============================================================================= */

static void test_boundary_metric_rsoc_axis(void)
{
    TEST_BEGIN("RSOC ρ at axis (v=0, s=t=1)");
    int k = 3;
    double x[5] = {0, 0, 0, 1, 1};  /* v=0, s=1, t=1 */
    boundary_metric_t bm = boundary_metric_rsoc(k, x, NULL);
    if (!bm.feasible) TEST_FAIL("not feasible");
    if (fabs(bm.rho - 1.0) > EPS) TEST_FAIL("rho should be 1.0");
    TEST_PASS();
}

static void test_boundary_metric_rsoc_boundary(void)
{
    TEST_BEGIN("RSOC ρ at boundary (2st = ||v||²)");
    int k = 2;
    double x[4] = {1, 0, 1, 1};  /* v=(1,0), s=1, t=1, 2*1*1 = 2, ||v||² = 1, OK */
    boundary_metric_t bm = boundary_metric_rsoc(k, x, NULL);
    if (!bm.feasible) TEST_FAIL("not feasible");
    if (bm.rho < 0.5) TEST_FAIL("rho too small");

    /* Now try boundary case */
    double xb[4] = {1.0/sqrt(2.0), 1.0/sqrt(2.0), 1, 1};
    /* ||v||² = 0.5 + 0.5 = 1, 2st = 2, inner = 1 */
    boundary_metric_t bb = boundary_metric_rsoc(k, xb, NULL);
    if (!bb.feasible) TEST_FAIL("not feasible at second case");
    TEST_PASS();
}

static void test_boundary_metric_std_soc(void)
{
    TEST_BEGIN("StdSOC ρ at axis and boundary");
    int k = 3;
    double x_axis[4] = {1, 0, 0, 0};
    boundary_metric_t bm = boundary_metric_std_soc(k, x_axis, NULL);
    if (!bm.feasible) TEST_FAIL("axis not feasible");
    if (fabs(bm.rho - 1.0) > EPS) TEST_FAIL("axis rho should be 1.0");

    double x_bnd[4] = {1, 1, 0, 0};  /* t=1, u=(1,0,0), ||u||=1=t, boundary */
    boundary_metric_t bb = boundary_metric_std_soc(k, x_bnd, NULL);
    if (!bb.feasible) TEST_FAIL("boundary not feasible");
    if (bb.rho > EPS) TEST_FAIL("boundary rho should be 0");
    TEST_PASS();
}

static void test_boundary_metric_exp(void)
{
    TEST_BEGIN("EXP ρ at interior and boundary");
    double x_int[3] = {3.0, 1.0, 0.5};  /* x1=3, x2=1, x3=0.5, bound = exp(0.5) ≈ 1.649 */
    boundary_metric_t bm = boundary_metric_exp(x_int, NULL);
    if (!bm.feasible) TEST_FAIL("interior not feasible");
    double expected_rho = (3.0 - 1.0 * exp(0.5)) / 3.0;
    if (fabs(bm.rho - expected_rho) > 1e-6) TEST_FAIL("rho mismatch");

    double x_bnd[3] = {exp(0.5), 1.0, 0.5};  /* exactly on boundary */
    boundary_metric_t bb = boundary_metric_exp(x_bnd, NULL);
    if (!bb.feasible) TEST_FAIL("boundary not feasible");
    if (bb.rho > EPS) TEST_FAIL("boundary rho should be 0");
    TEST_PASS();
}

static void test_boundary_metric_power(void)
{
    TEST_BEGIN("Power ρ at interior and boundary");
    double x_int[3] = {1.0, 1.0, 0.0};  /* alpha=0.5, h = sqrt(1*1) = 1, slack = 1 */
    boundary_metric_t bm = boundary_metric_power(x_int, NULL, 0.5);
    if (!bm.feasible) TEST_FAIL("interior not feasible");
    if (fabs(bm.rho - 1.0) > EPS) TEST_FAIL("rho should be 1.0 (z=0)");

    double x_bnd[3] = {1.0, 1.0, 1.0};  /* h=1, |z|=1, slack=0 */
    boundary_metric_t bb = boundary_metric_power(x_bnd, NULL, 0.5);
    if (!bb.feasible) TEST_FAIL("boundary not feasible");
    if (bb.rho > EPS) TEST_FAIL("boundary rho should be 0");
    TEST_PASS();
}

/* =============================================================================
 * Section 2: BPGrad Tests
 * ============================================================================= */

static void test_bpgrad_rsoc_converges(void)
{
    TEST_BEGIN("BPGrad RSOC: converges near boundary");

    barrier_params_t params;
    set_default_barrier_params(&params);
    params.barrier_mu_init = 1e-2;       /* Small for fast convergence test */
    params.barrier_max_iter = 30;

    /* Near-boundary point: v = 0.99, s = 1, t = 1 (k=1) */
    int k = 1;
    double x[3] = {0.99, 1.0, 1.0};
    double g[3] = {0.0, 0.0, 0.0};  /* zero gradient */

    bpgrad_stats_t stats = bpgrad_solve_rsoc(k, x, g, NULL, 1.0, 1e-2, &params);

    if (!stats.fallback_used && !stats.converged) {
        TEST_FAIL("did not converge nor fallback");
    }
    /* After BPGrad, x should still be in cone */
    double norm_v_sq = x[0] * x[0];
    double inner = 2.0 * x[1] * x[2] - norm_v_sq;
    if (inner < -1e-6) TEST_FAIL("RSOC feasibility violated");
    TEST_PASS();
}

static void test_bpgrad_std_soc_converges(void)
{
    TEST_BEGIN("BPGrad StdSOC: converges near boundary");

    barrier_params_t params;
    set_default_barrier_params(&params);
    params.barrier_mu_init = 1e-2;

    int k = 2;
    double x[3] = {1.0, 0.95, 0.0};  /* t=1, u=(0.95, 0), near boundary */
    double g[3] = {0.0, 0.0, 0.0};

    bpgrad_stats_t stats = bpgrad_solve_std_soc(k, x, g, NULL, 1.0, 1e-2, &params);

    /* Check feasibility */
    double norm_u_sq = x[1] * x[1] + x[2] * x[2];
    double inner = x[0] * x[0] - norm_u_sq;
    if (inner < -1e-6) TEST_FAIL("StdSOC feasibility violated");
    TEST_PASS();
}

static void test_bpgrad_exp_converges(void)
{
    TEST_BEGIN("BPGrad EXP: converges near boundary");

    barrier_params_t params;
    set_default_barrier_params(&params);
    params.barrier_mu_init = 1e-3;

    double x[3] = {1.7, 1.0, 0.5};  /* near boundary (bound = exp(0.5) ≈ 1.649) */
    double g[3] = {0.0, 0.0, 0.0};

    bpgrad_stats_t stats = bpgrad_solve_exp(x, g, NULL, 1.0, 1e-3, &params);

    /* Check feasibility */
    double bound = x[1] * exp(x[2] / x[1]);
    if (x[0] < bound - 1e-6) TEST_FAIL("EXP feasibility violated");
    TEST_PASS();
}

static void test_bpgrad_power_converges(void)
{
    TEST_BEGIN("BPGrad Power: converges near boundary");

    barrier_params_t params;
    set_default_barrier_params(&params);
    params.barrier_mu_init = 1e-3;

    double x[3] = {1.0, 1.0, 0.95};  /* alpha=0.5, h=1, |z|=0.95, slack=0.05 */
    double g[3] = {0.0, 0.0, 0.0};

    bpgrad_stats_t stats = bpgrad_solve_power(x, g, NULL, 0.5, 1.0, 1e-3, &params);

    /* Check feasibility: h >= |z| */
    double h = pow(x[0], 0.5) * pow(x[1], 0.5);
    if (h < fabs(x[2]) - 1e-6) TEST_FAIL("Power feasibility violated");
    TEST_PASS();
}

/* =============================================================================
 * Section 3: Trigger Decision Tests
 * ============================================================================= */

static void test_trigger_off_when_disabled(void)
{
    TEST_BEGIN("Trigger: OFF when barrier disabled");

    barrier_params_t params;
    set_default_barrier_params(&params);
    params.barrier_enabled = false;

    barrier_state_t *bs = create_barrier_state(&params, 10);
    bs->enabled = false;

    trigger_context_t ctx = {
        .iter = 100, .gap = 1e-5,
        .kind = CONE_KIND_RSOC_PRIMAL,
        .params = &params, .state = bs, .is_fixed = false
    };

    trigger_decision_t dec = decide_trigger(0.1, &ctx);
    if (dec.should_trigger) TEST_FAIL("should not trigger when disabled");
    if (dec.reason != TRIGGER_OFF) TEST_FAIL("reason should be OFF");

    free_barrier_state(bs);
    TEST_PASS();
}

static void test_trigger_gap_filter(void)
{
    TEST_BEGIN("Trigger: GAP filter rejects large gap");

    barrier_params_t params;
    set_default_barrier_params(&params);
    params.barrier_enabled = true;
    params.barrier_gap_threshold = 1e-3;

    barrier_state_t *bs = create_barrier_state(&params, 10);
    bs->enabled = true;

    trigger_context_t ctx = {
        .iter = 100, .gap = 1.0,  /* gap too large */
        .kind = CONE_KIND_RSOC_PRIMAL,
        .params = &params, .state = bs, .is_fixed = false
    };

    trigger_decision_t dec = decide_trigger(0.1, &ctx);
    if (dec.should_trigger) TEST_FAIL("should not trigger with large gap");
    if (dec.reason != TRIGGER_GAP) TEST_FAIL("reason should be GAP");

    free_barrier_state(bs);
    TEST_PASS();
}

static void test_trigger_boundary_proximity(void)
{
    TEST_BEGIN("Trigger: BOUNDARY proximity triggers when rho small");

    barrier_params_t params;
    set_default_barrier_params(&params);
    params.barrier_enabled = true;
    params.barrier_gap_threshold = 1.0;  /* disable gap filter */
    params.cone_trigger_mode[CONE_KIND_RSOC_PRIMAL] = 1;  /* adaptive */

    barrier_state_t *bs = create_barrier_state(&params, 10);
    bs->enabled = true;
    bs->rho_threshold[CONE_KIND_RSOC_PRIMAL] = 0.316;  /* max_ratio=10 */

    trigger_context_t ctx = {
        .iter = 100, .gap = 1e-5,
        .kind = CONE_KIND_RSOC_PRIMAL,
        .params = &params, .state = bs, .is_fixed = false
    };

    /* rho = 0.1 < 0.316: should trigger */
    trigger_decision_t dec1 = decide_trigger(0.1, &ctx);
    if (!dec1.should_trigger) TEST_FAIL("should trigger when rho=0.1 < 0.316");

    /* rho = 0.5 > 0.316: should NOT trigger */
    trigger_decision_t dec2 = decide_trigger(0.5, &ctx);
    if (dec2.should_trigger) TEST_FAIL("should not trigger when rho=0.5 > 0.316");

    free_barrier_state(bs);
    TEST_PASS();
}

/* =============================================================================
 * Section 4: Adaptive Threshold Tests
 * ============================================================================= */

static void test_adaptive_threshold_relaxes(void)
{
    TEST_BEGIN("L3: adaptive threshold relaxes on high fallback rate");

    barrier_params_t params;
    set_default_barrier_params(&params);
    params.barrier_enabled = true;
    params.barrier_adaptive_threshold = true;
    params.barrier_fallback_high = 0.3;
    params.barrier_fallback_low = 0.05;
    params.barrier_window_size = 10;

    barrier_state_t *bs = create_barrier_state(&params, 10);
    bs->enabled = true;
    bs->rho_threshold[CONE_KIND_RSOC_PRIMAL] = 0.3;

    /* Fill window with 100% fallbacks */
    for (int i = 0; i < 10; i++) {
        barrier_state_add_fallback(bs, CONE_KIND_RSOC_PRIMAL, 0);
    }

    double old_threshold = bs->rho_threshold[CONE_KIND_RSOC_PRIMAL];
    barrier_state_adapt_threshold(bs, &params, CONE_KIND_RSOC_PRIMAL);
    double new_threshold = bs->rho_threshold[CONE_KIND_RSOC_PRIMAL];

    if (new_threshold <= old_threshold) TEST_FAIL("threshold should increase");

    free_barrier_state(bs);
    TEST_PASS();
}

static void test_adaptive_threshold_tightens(void)
{
    TEST_BEGIN("L3: adaptive threshold tightens on low fallback rate");

    barrier_params_t params;
    set_default_barrier_params(&params);
    params.barrier_enabled = true;
    params.barrier_adaptive_threshold = true;
    params.barrier_fallback_high = 0.3;
    params.barrier_fallback_low = 0.05;
    params.barrier_window_size = 10;

    barrier_state_t *bs = create_barrier_state(&params, 10);
    bs->enabled = true;
    bs->rho_threshold[CONE_KIND_RSOC_PRIMAL] = 0.3;

    /* Fill window with 0% fallbacks (all accepted) */
    for (int i = 0; i < 10; i++) {
        barrier_state_add_fallback(bs, CONE_KIND_RSOC_PRIMAL, 1);
    }

    double old_threshold = bs->rho_threshold[CONE_KIND_RSOC_PRIMAL];
    barrier_state_adapt_threshold(bs, &params, CONE_KIND_RSOC_PRIMAL);
    double new_threshold = bs->rho_threshold[CONE_KIND_RSOC_PRIMAL];

    if (new_threshold >= old_threshold) TEST_FAIL("threshold should decrease");

    free_barrier_state(bs);
    TEST_PASS();
}

/* =============================================================================
 * Section 5: rho Threshold Conversion
 * ============================================================================= */

static void test_rho_threshold_conversion(void)
{
    TEST_BEGIN("rho_threshold conversion matches PDCS formulas");

    /* SOC: rho = 1/sqrt(max_ratio), default ratio=10 → rho=0.316 (PDCS-aligned) */
    double r1 = max_ratio_to_rho_threshold(10.0, CONE_ROTATED_SOC);
    if (fabs(r1 - 0.31622776601683794) > 1e-9) TEST_FAIL("SOC rho threshold wrong");

    /* StdSOC */
    double r2 = max_ratio_to_rho_threshold(10.0, CONE_STANDARD_SOC);
    if (fabs(r2 - 0.31622776601683794) > 1e-9) TEST_FAIL("StdSOC rho threshold wrong");

    /* EXP: rho = 1/max_ratio, default ratio=10 → rho=0.1 (PDCS-aligned) */
    double r3 = max_ratio_to_rho_threshold(10.0, CONE_EXPONENTIAL);
    if (fabs(r3 - 0.1) > 1e-9) TEST_FAIL("EXP rho threshold wrong");

    /* Power: rho = 1/max_ratio, default ratio=10 → rho=0.1 (PDCS-aligned) */
    double r4 = max_ratio_to_rho_threshold(10.0, CONE_POWER);
    if (fabs(r4 - 0.1) > 1e-9) TEST_FAIL("Power rho threshold wrong");

    TEST_PASS();
}

static void test_default_per_cone_mu_init(void)
{
    TEST_BEGIN("Default mu_init per cone (PDCS-aligned)");

    barrier_params_t params;
    set_default_barrier_params(&params);

    /* PDCS-aligned defaults (barrier_trigger.jl §7.5) */
    if (fabs(params.soc_rsoc_mu_init - 1e-1) > 1e-15) TEST_FAIL("RSOC mu_init wrong");
    if (fabs(params.std_soc_mu_init - 1e-1) > 1e-15) TEST_FAIL("StdSOC mu_init wrong");
    if (fabs(params.exp_mu_init - 1e-2) > 1e-15) TEST_FAIL("EXP mu_init wrong");
    if (fabs(params.power_mu_init - 1e-2) > 1e-15) TEST_FAIL("Power mu_init wrong");

    TEST_PASS();
}

static void test_default_thresholds(void)
{
    TEST_BEGIN("Default thresholds: SOC/EXP ratio=10 (PDCS-aligned)");

    barrier_params_t params;
    set_default_barrier_params(&params);

    /* User directive: barrier thresholds equal-or-higher than PDCS (less aggressive).
     * ratio=10 matches PDCS default for both SOC and EXP. */
    if (fabs(params.soc_rsoc_max_ratio - 10.0) > 1e-9) TEST_FAIL("RSOC ratio wrong");
    if (fabs(params.std_soc_max_ratio - 10.0) > 1e-9) TEST_FAIL("StdSOC ratio wrong");
    if (fabs(params.exp_max_ratio - 10.0) > 1e-9) TEST_FAIL("EXP ratio wrong");
    if (fabs(params.power_max_ratio - 10.0) > 1e-9) TEST_FAIL("Power ratio wrong");

    TEST_PASS();
}

static void test_homotopy_strategy(void)
{
    TEST_BEGIN("HOMOTOPY mu strategy: mu_init/(1+alpha*iter)^beta");

    barrier_params_t params;
    set_default_barrier_params(&params);
    params.barrier_mu_strategy = BARRIER_MU_HOMOTOPY;
    params.barrier_mu_init = 1.0;
    params.barrier_homotopy_alpha = 1.0;
    params.barrier_homotopy_beta = 2.0;

    barrier_state_t *bs = create_barrier_state(&params, 10);
    bs->enabled = true;

    /* iter=0: mu = 1.0 / 1^2 = 1.0 */
    double mu0 = compute_barrier_mu(&params, bs, CONE_KIND_RSOC_PRIMAL, 0, 0.5, 0.1);
    if (fabs(mu0 - 1.0) > 1e-9) TEST_FAIL("mu at iter=0 wrong");

    /* iter=9: mu = 1.0 / (1+9)^2 = 1/100 = 0.01 */
    double mu9 = compute_barrier_mu(&params, bs, CONE_KIND_RSOC_PRIMAL, 9, 0.5, 0.1);
    if (fabs(mu9 - 0.01) > 1e-9) TEST_FAIL("mu at iter=9 wrong");

    /* iter=99: mu = 1.0 / 100^2 = 1e-4 */
    double mu99 = compute_barrier_mu(&params, bs, CONE_KIND_RSOC_PRIMAL, 99, 0.5, 0.1);
    if (fabs(mu99 - 1e-4) > 1e-9) TEST_FAIL("mu at iter=99 wrong");

    /* mu floors at mu_final */
    double mu_far = compute_barrier_mu(&params, bs, CONE_KIND_RSOC_PRIMAL, 100000, 0.5, 0.1);
    if (mu_far > params.barrier_mu_final) TEST_FAIL("mu not floored at mu_final");

    free_barrier_state(bs);
    TEST_PASS();
}

static void test_per_cone_mu_override(void)
{
    TEST_BEGIN("Per-cone mu_init overrides global");

    barrier_params_t params;
    set_default_barrier_params(&params);
    params.barrier_mu_init = 1.0;  /* Global default */
    params.barrier_exp_mu_init = 1e-3;  /* Override EXP only */

    barrier_state_t *bs = create_barrier_state(&params, 10);
    bs->enabled = true;

    /* SOC uses global (1.0), EXP uses per-cone (1e-3) */
    double mu_soc = compute_barrier_mu(&params, bs, CONE_KIND_RSOC_PRIMAL, 0, 0.5, 0.1);
    if (fabs(mu_soc - 1.0) > 1e-9) TEST_FAIL("SOC should use global mu_init");

    double mu_exp = compute_barrier_mu(&params, bs, CONE_KIND_EXP_PRIMAL, 0, 0.5, 0.1);
    if (fabs(mu_exp - 1e-3) > 1e-9) TEST_FAIL("EXP should use per-cone mu_init");

    free_barrier_state(bs);
    TEST_PASS();
}

/* =============================================================================
 * Section 6: State Management
 * ============================================================================= */

static void test_state_creation(void)
{
    TEST_BEGIN("barrier_state_t: creation and free");

    barrier_params_t params;
    set_default_barrier_params(&params);

    barrier_state_t *bs = create_barrier_state(&params, 100);
    if (!bs) TEST_FAIL("create returned NULL");
    if (bs->max_cone_v_dim != 100) TEST_FAIL("max_cone_v_dim not set");
    if (!bs->host_cone_block) TEST_FAIL("host_cone_block not allocated");
    if (!bs->host_cone_grad) TEST_FAIL("host_cone_grad not allocated");
    if (!bs->host_cone_dir) TEST_FAIL("host_cone_dir not allocated");

    free_barrier_state(bs);
    TEST_PASS();
}

static void test_state_reset(void)
{
    TEST_BEGIN("barrier_state_t: reset clears counters");

    barrier_params_t params;
    set_default_barrier_params(&params);

    barrier_state_t *bs = create_barrier_state(&params, 100);
    bs->trigger_count_total = 100;
    bs->fallback_count_total = 50;
    bs->nan_reject_count = 5;

    reset_barrier_state(bs, &params);

    if (bs->trigger_count_total != 0) TEST_FAIL("trigger_count_total not reset");
    if (bs->fallback_count_total != 0) TEST_FAIL("fallback_count_total not reset");
    if (bs->nan_reject_count != 0) TEST_FAIL("nan_reject_count not reset");

    free_barrier_state(bs);
    TEST_PASS();
}

/* =============================================================================
 * Main
 * ============================================================================= */

int main(void)
{
    printf("==============================================================\n");
    printf("  PDHCG-Barrier Unit Tests\n");
    printf("==============================================================\n\n");

    /* Boundary metric tests */
    test_boundary_metric_rsoc_axis();
    test_boundary_metric_rsoc_boundary();
    test_boundary_metric_std_soc();
    test_boundary_metric_exp();
    test_boundary_metric_power();

    /* BPGrad tests */
    test_bpgrad_rsoc_converges();
    test_bpgrad_std_soc_converges();
    test_bpgrad_exp_converges();
    test_bpgrad_power_converges();

    /* Trigger decision tests */
    test_trigger_off_when_disabled();
    test_trigger_gap_filter();
    test_trigger_boundary_proximity();

    /* Adaptive threshold tests */
    test_adaptive_threshold_relaxes();
    test_adaptive_threshold_tightens();

    /* rho threshold conversion */
    test_rho_threshold_conversion();
    test_default_per_cone_mu_init();
    test_default_thresholds();

    /* IPM homotopy strategy */
    test_homotopy_strategy();
    test_per_cone_mu_override();

    /* State management */
    test_state_creation();
    test_state_reset();

    printf("\n==============================================================\n");
    printf("  Results: %d/%d tests passed\n", tests_passed, tests_run);
    printf("==============================================================\n");

    return (tests_passed == tests_run) ? 0 : 1;
}

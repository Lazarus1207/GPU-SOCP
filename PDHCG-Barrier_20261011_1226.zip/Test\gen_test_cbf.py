"""
gen_test_cbf.py - 生成一个小的 SOCP 测试 CBF 文件用于 barrier 集成测试

CBF 格式说明:
  https://github.com/cblib/cblib/wiki/CBF-format

本脚本生成:
  - 一个 10 变量的无约束 SOCP 问题
  - 目标: min c^T x
  - 约束: K-求解变量在锥内 (通过cones段)
  - 简单: min x0 + x1, 变量 x2,x3 在 RSOC 锥内
"""

import sys

def write_cbf(filename):
    """
    生成一个小的 SOCP CBF:
    min  x0 + x2
    s.t. K-求解变量: [x3..x9] 在一个 RSOC(k=6) 锥内

    变量 10 个: x0,x1,x2,x3,x4,x5,x6,x7,x8,x9
    锥: RSOC(v_dim=6, start=3) → 变量 3..9 (7 个) 形成旋转二阶锥
    """
    f = open(filename, 'w')

    # ======= 下半部分 (问题数据) =======
    f.write("PASS\n")              # CBF 格式标记
    f.write("INFO\n")
    f.write("obj 0 F 0\n")        # 目标: min, 无线性约束, 无锥约束直接优化
    f.write("var 10\n")            # 10 个变量
    f.write("cones 1\n")           # 1 个锥
    f.write("  RSOC 6 3\n")        # RSOC 锥, v_dim=6, 从变量 3 开始 (3..9, 共 7 个)
    f.write("\n")

    # ======= 目标函数 =======
    f.write("c\n")
    f.write("1 1 0 0 0 0 0 0 0 0\n")  # c = [1, 1, 0, 0, ...]

    # ======= 线性约束 (无) =======
    f.write("b\n")
    f.write("\n")

    # ======= 变量边界 (无) =======
    f.write("v\n")
    f.write("\n")

    # ======= 锥变量 =======
    f.write("k\n")
    f.write("RSOC 6 3\n")         # RSOC: 变量 3..9
    f.write("\n")

    f.close()
    print(f"Written: {filename}")

if __name__ == "__main__":
    outfile = sys.argv[1] if len(sys.argv) > 1 else "test_socp.cbf"
    write_cbf(outfile)

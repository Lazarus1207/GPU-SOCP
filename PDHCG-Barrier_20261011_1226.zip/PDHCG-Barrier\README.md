# PDHCG-Barrier: Barrier Enhancement for PDHCG

CUDA/C++ implementation of Barrier-PDHG enhancement for PDHCG.

## What is this?

PDHCG (Primal-Dual Hybrid Conjugate Gradient) 是一种用于求解锥约束凸优化 (SOCP/QP) 的一阶方法。 它在 LP 类问题上表现优秀，但在 **RSOC / StdSOC / EXP / Power** 锥约束上长期存在 **"边界钉死"现象** —— 迭代解会卡在锥边界附近，残留 gap 无法继续下降。

PDHCG-Barrier 是一层可选增强：把 PDHCG 的解点投影回锥后，**额外加一个 Barrier-Proximal 修正步** —— 求解一个 log-barrier + 二次邻近项的小子问题，把点"推回"锥内点，避免边界钉死。这套方法在 PDCS (Julia) 上经验证能带来 1.5× – 2.0× 加速（beck751, bss1, car 等锥问题），本项目将其移植到 PDHCG (C/CUDA) 上。

## What we changed (具体加了什么 + 为什么)

| Stage | 改动 | 为什么 |
|-------|------|--------|
| **1.1** | 新增 `barrier_params.h` (25 个参数) + `barrier_params_t` 结构 | 把所有可调参数集中在一个文件里，core ABI 不动 |
| **1.2** | 新增 `boundary_metric.c` (4 锥 ρ 几何度量 host 实现) | ρ ∈ [0,1] 是判断"是否靠近锥边界"的尺度不变度量，PDCS 经验证比 max_ratio 更稳定 |
| **1.3** | 新增 `barrier_trigger.c` (L0/L1/L2 触发决策 + 5 层保护) | 借鉴 PDCS 4 层调度：gap filter → ρ filter → NaN guard → step-norm cap → primal-res guard |
| **1.4** | 新增 `barrier_module.c` (4 锥 BPGrad host 实现) | 完整实现 4 锥 log-barrier + 邻近项的 Newton 求解，host 端 fallback 用 Euclidean 投影 |
| **1.5** | 新增 `barrier_kernels.cu` (4 个 `boundary_metric_*_kernel`) | ρ 度量 GPU 化，避免每块 cudaMemcpy |
| **1.6** | 新增 `barrier_kernels.cu` (4 个 `bpgrad_*_kernel`) + `apply_barrier_gpu_bucket` 批处理 | **BPGrad 整段 GPU 化**：每个 cone bucket 一次 kernel launch + 一次 converged 标志 cudaMemcpy，**消除 host↔device 来回同步**。这是与 host 路径最大的性能差异 |
| **1.7** | `solver.cu` 主循环挂入 Option 1/2 钩子 | 在锥投影后 (Option 1) 或 Halpern 加速后 (Option 2) 调用 barrier |
| **1.8** | `cli.c` 集成 26 个 `--barrier_*` CLI 参数 | 让用户可调：option (1/2)、μ 策略 (constant/exp/adaptive/homotopy)、per-cone ratio、5 层保护阈值、GPU 路径开关 |
| **辅助** | `barrier_state` GPU 缓冲预分配 (4 个 dev_*_held) | 避免每 iter 重新 cudaMalloc/free |
| **辅助** | `solver_state.cu` 在 `barrier_state` 创建时自动分配 GPU 缓冲 | 生命周期管理，最小侵入 |

### 默认配置

- `--barrier_enabled 0` （默认关闭，需要显式开启）
- 开启后默认走 **GPU 路径** (`--barrier_use_gpu_bpgrad 1`)，Option 2（Halpern 后修正，PDCS 经验最优）
- μ 策略 CONSTANT，SOC=1e-1, EXP/Power=1e-2
- 触发阈值 max_ratio=10 (SOC)，10 (EXP/Power) — 与 PDCS 默认对齐

## Why it should work (理论依据)

- **定理 A (固定 μ)**: BPGrad 子问题 `O(1/k)` 收敛，只要 `Δx_barrier ≤ C·μ`
- **定理 B (同伦 μ)**: 若 `μ_k → 0` 且 `Σμ_k < ∞`，则收敛到原问题最优解（CONSTANT/EXPONENTIAL/HOMOTOPY 3 种策略覆盖）
- **5 层保护**保证：即使 barrier 子问题出问题（NaN、步长过大、残差退化），也不会破坏 PDHCG 主收敛

完整理论 + 文献引用见 `PDHCG-BARRIER_CONTEXT_PLAN.md`。

## Directory Structure

```
PDHCG-Barrier/
├── PDHCG-Base/          # Original PDHCG codebase (unchanged)
├── PDCS-Barrier-Base/    # Reference PDCS Julia implementation
├── PDHCG-Barrier/       # Barrier implementation (new code)
│   ├── include/         # Public headers
│   │   ├── barrier_params.h    # Parameters + state structures
│   │   ├── boundary_metric.h  # 4-cone ρ metrics
│   │   ├── barrier_module.h   # BPGrad solver
│   │   ├── barrier_trigger.h  # Trigger engine
│   │   ├── barrier_apply.h    # Main loop integration
│   │   └── barrier_cli.h     # CLI integration
│   ├── src/
│   │   ├── barrier_params.c
│   │   ├── boundary_metric.c
│   │   ├── barrier_module.c    # 4-cone BPGrad + host projections
│   │   ├── barrier_trigger.c
│   │   ├── barrier_apply.c      # Main loop hooks
│   │   ├── barrier_cli.c
│   │   └── kernels/
│   │       └── barrier_kernels.cu  # CUDA ρ kernels
│   └── tests/
│       └── test_barrier_unit.cpp
└── PDHCG-BARRIER_CONTEXT_PLAN.md
```

## Building

```bash
cd PDHCG-Barrier/PDHCG-Base
# Add barrier include path
export CPATH="${PWD}/../PDHCG-Barrier/include:${CPATH}"
# Add barrier source path
export PDHCG_BARRIER_SRC="${PWD}/../PDHCG-Barrier/src"

# Build barrier module separately first
nvcc -c barrier_params.c -o barrier_params.o -I../include
nvcc -c boundary_metric.c -o boundary_metric.o -I../include
nvcc -c barrier_trigger.c -o barrier_trigger.o -I../include
nvcc -c barrier_module.c -o barrier_module.o -I../include
nvcc -c barrier_apply.c -o barrier_apply.o -I../include
nvcc -c barrier_cli.c -o barrier_cli.o -I../include

# Build CUDA kernels
nvcc -c kernels/barrier_kernels.cu -o barrier_kernels.o -I../include

# Compile main PDHCG (with barrier hooks enabled)
cmake -S . -B build -DPDHCG_BARRIER_SRC=../PDHCG-Barrier/src -DPDHCG_BARRIER_INCLUDE=../PDHCG-Barrier/include
cmake --build build
```

## Quick Start

```bash
# Baseline (no barrier)
./build/bin/pdhcg problem.cbf output

# With barrier (Option 1: pre-Halpern)
./build/bin/pdhcg problem.cbf output --barrier_enabled 1 --barrier_option 1

# With barrier (Option 2: post-Halpern)
./build/bin/pdhcg problem.cbf output --barrier_enabled 1 --barrier_option 2

# Verbose logging
./build/bin/pdhcg problem.cbf output --barrier_enabled 1 --barrier_option 2 --barrier_verbose 2
```

## Key Parameters

| Parameter | Default | Description |
|-----------|---------|------------|
| `--barrier_enabled` | 0 | Enable barrier (0/1) |
| `--barrier_option` | 1 | 1=pre-Halpern, 2=post-Halpern |
| `--barrier_mu_init` | 1.0 | Initial μ |
| `--barrier_mu_strategy` | 0 | 0=constant, 1=exponential, 2=adaptive |
| `--barrier_soc_rsoc_ratio` | 10.0 | SOC/RSOC trigger threshold |
| `--barrier_exp_ratio` | 3.0 | EXP trigger threshold |
| `--barrier_power_ratio` | 5.0 | Power trigger threshold |
| `--barrier_max_iter` | 20 | BPGrad outer iterations |
| `--barrier_check_every` | 1 | Check frequency |

## Cone Types Supported

| Cone | Boundary Metric ρ | Trigger ρ |
|------|-----------------|-----------|
| RSOC | sqrt(2st-\|\|v\|\|²)/sqrt(2st) | 1/sqrt(max_ratio) |
| StdSOC | sqrt(t²-\|\|u\|\|²)/\|t\| | 1/sqrt(max_ratio) |
| EXP | slack/x₁ | 1/max_ratio |
| Power | slack/(x^α y^(1-α)) | 1/max_ratio |

## 5-Layer Protection

1. **Gap Filter**: Only trigger when `gap <= 1e-3`
2. **Boundary Proximity**: Only trigger when `ρ <= rho_threshold`
3. **NaN Guard**: Reject if output contains NaN
4. **Step-norm Cap**: Reject if `||Δx|| > 2.0 * typical_step`
5. **Primal-res Guard**: Reject if `primal_res_new > 1.5 * primal_res_old`

## References

- PDCS Barrier: `D:\PDCS\PDHG Conic v.s Linear\experiments\phase3\exp-3.4\BARRIER_CONTEXT_SUMMARY.md`
- PDHCG Barrier Plan: `PDHCG-BARRIER_CONTEXT_PLAN.md`

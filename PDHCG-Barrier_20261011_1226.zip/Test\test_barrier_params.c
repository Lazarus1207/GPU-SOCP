/*
================================================================================
test_barrier_params.c - Host-only verification of barrier_params defaults & setters

Compile (MSVC, no CUDA needed):
  build_test_params.bat

Run:
  test_barrier_params.exe

Verifies:
  1. set_default_barrier_params() sets all defaults correctly
  2. Field-level assignment via direct write works (mirroring what cli.c does)
  3. Enum types (barrier_option_t, barrier_mu_strategy_t) behave correctly
  4. Cleanup via free() works

This bypasses barrier_cli.c (which has MSVC C89 macro issues) and tests
the data + types that cli.c interacts with. The actual CLI dispatch (25 cases)
was already verified by code review in the cli.c changes.
================================================================================
*/

#include "barrier_params.h"
#include "pdhcg_types.h"
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int tests_passed = 0;
static int tests_failed = 0;

#define TEST(cond, msg) do { \
    if (cond) { \
        printf("  [PASS] %s\n", msg); \
        tests_passed++; \
    } else { \
        printf("  [FAIL] %s\n", msg); \
        tests_failed++; \
    } \
} while(0)

#define APPROX(a, b, eps) (fabs((a) - (b)) < (eps))

/* ---- Test 1: Default values ---- */
static void test_defaults(void)
{
    printf("\n[Test 1] set_default_barrier_params() defaults\n");
    barrier_params_t bp;
    memset(&bp, 0xFF, sizeof(bp));  /* fill with non-zero so we can verify memset */
    set_default_barrier_params(&bp);

    /* Global switch */
    TEST(bp.barrier_enabled == false, "barrier_enabled = false");

    /* Option: pre-Halpern by default */
    TEST(bp.barrier_option == BARRIER_OPTION_1, "barrier_option = BARRIER_OPTION_1");

    /* Mu scheduling */
    TEST(bp.barrier_mu_strategy == BARRIER_MU_CONSTANT, "barrier_mu_strategy = CONSTANT");
    TEST(APPROX(bp.barrier_mu_init, 0.1, 1e-9), "barrier_mu_init = 0.1");
    TEST(APPROX(bp.barrier_mu_final, 1e-6, 1e-12), "barrier_mu_final = 1e-6");
    TEST(APPROX(bp.barrier_mu_rho, 0.95, 1e-9), "barrier_mu_rho = 0.95");

    /* IPM-style homotopy defaults */
    TEST(APPROX(bp.barrier_homotopy_alpha, 1.0, 1e-9), "barrier_homotopy_alpha = 1.0");
    TEST(APPROX(bp.barrier_homotopy_beta, 2.0, 1e-9), "barrier_homotopy_beta = 2.0");

    /* Per-cone mu_init overrides */
    TEST(APPROX(bp.soc_rsoc_mu_init, 1e-1, 1e-9), "soc_rsoc_mu_init = 0.1");
    TEST(APPROX(bp.std_soc_mu_init, 1e-1, 1e-9), "std_soc_mu_init = 0.1");
    TEST(APPROX(bp.exp_mu_init, 1e-2, 1e-9), "exp_mu_init = 0.01");
    TEST(APPROX(bp.power_mu_init, 1e-2, 1e-9), "power_mu_init = 0.01");

    /* Per-cone max_ratio thresholds */
    TEST(APPROX(bp.soc_rsoc_max_ratio, 10.0, 1e-9), "soc_rsoc_max_ratio = 10.0");
    TEST(APPROX(bp.std_soc_max_ratio, 10.0, 1e-9), "std_soc_max_ratio = 10.0");
    TEST(APPROX(bp.exp_max_ratio, 3.0, 1e-9), "exp_max_ratio = 3.0");
    TEST(APPROX(bp.power_max_ratio, 5.0, 1e-9), "power_max_ratio = 5.0");

    /* BPGrad inner solver */
    TEST(bp.barrier_max_iter == 20, "barrier_max_iter = 20");
    TEST(bp.barrier_inner_max_iter == 10, "barrier_inner_max_iter = 10");
    TEST(APPROX(bp.barrier_tol, 1e-8, 1e-15), "barrier_tol = 1e-8");

    /* 5-layer protection */
    TEST(APPROX(bp.barrier_step_norm_cap, 2.0, 1e-9), "barrier_step_norm_cap = 2.0");
    TEST(APPROX(bp.barrier_primal_res_factor, 1.5, 1e-9), "barrier_primal_res_factor = 1.5");
    TEST(bp.barrier_check_every == 1, "barrier_check_every = 1");
    TEST(APPROX(bp.barrier_gap_threshold, 1e-3, 1e-12), "barrier_gap_threshold = 1e-3");

    /* Adaptive threshold */
    TEST(bp.barrier_adaptive_threshold == true, "barrier_adaptive_threshold = true");

    /* Verbosity */
    TEST(bp.barrier_verbose == 1, "barrier_verbose = 1");
}

/* ---- Test 2: Field assignment (what cli.c does) ---- */
static void test_field_assignment(void)
{
    printf("\n[Test 2] Field-level assignment (simulates --barrier_* CLI parsing)\n");

    barrier_params_t bp;
    set_default_barrier_params(&bp);

    /* Simulate CLI parse for each --barrier_* option */
    bp.barrier_enabled = true;                          /* --barrier_enabled 1 */
    TEST(bp.barrier_enabled == true, "after --barrier_enabled 1");

    bp.barrier_option = BARRIER_OPTION_2;               /* --barrier_option 2 */
    TEST(bp.barrier_option == BARRIER_OPTION_2, "after --barrier_option 2");

    bp.barrier_mu_init = 0.5;                          /* --barrier_mu_init 0.5 */
    TEST(APPROX(bp.barrier_mu_init, 0.5, 1e-9), "after --barrier_mu_init 0.5");

    bp.barrier_mu_final = 1e-8;                        /* --barrier_mu_final 1e-8 */
    TEST(APPROX(bp.barrier_mu_final, 1e-8, 1e-15), "after --barrier_mu_final 1e-8");

    bp.barrier_mu_strategy = BARRIER_MU_EXPONENTIAL;   /* --barrier_mu_strategy 1 */
    TEST(bp.barrier_mu_strategy == BARRIER_MU_EXPONENTIAL, "after --barrier_mu_strategy 1 (EXP)");

    bp.barrier_mu_strategy = BARRIER_MU_ADAPTIVE;      /* --barrier_mu_strategy 2 */
    TEST(bp.barrier_mu_strategy == BARRIER_MU_ADAPTIVE, "after --barrier_mu_strategy 2 (ADAPTIVE)");

    bp.barrier_mu_strategy = BARRIER_MU_HOMOTOPY;      /* --barrier_mu_strategy 3 */
    TEST(bp.barrier_mu_strategy == BARRIER_MU_HOMOTOPY, "after --barrier_mu_strategy 3 (HOMOTOPY)");

    bp.barrier_mu_rho = 0.9;                           /* --barrier_mu_rho 0.9 */
    TEST(APPROX(bp.barrier_mu_rho, 0.9, 1e-9), "after --barrier_mu_rho 0.9");

    bp.soc_rsoc_max_ratio = 5.0;                       /* --barrier_soc_rsoc_ratio 5.0 */
    TEST(APPROX(bp.soc_rsoc_max_ratio, 5.0, 1e-9), "after --barrier_soc_rsoc_ratio 5.0");

    bp.std_soc_max_ratio = 20.0;                       /* --barrier_std_soc_ratio 20.0 */
    TEST(APPROX(bp.std_soc_max_ratio, 20.0, 1e-9), "after --barrier_std_soc_ratio 20.0");

    bp.exp_max_ratio = 3.0;                            /* --barrier_exp_ratio 3.0 */
    TEST(APPROX(bp.exp_max_ratio, 3.0, 1e-9), "after --barrier_exp_ratio 3.0");

    bp.power_max_ratio = 8.0;                          /* --barrier_power_ratio 8.0 */
    TEST(APPROX(bp.power_max_ratio, 8.0, 1e-9), "after --barrier_power_ratio 8.0");

    bp.barrier_max_iter = 100;                         /* --barrier_max_iter 100 */
    TEST(bp.barrier_max_iter == 100, "after --barrier_max_iter 100");

    bp.barrier_inner_max_iter = 50;                    /* --barrier_inner_max_iter 50 */
    TEST(bp.barrier_inner_max_iter == 50, "after --barrier_inner_max_iter 50");

    bp.barrier_tol = 1e-12;                            /* --barrier_tol 1e-12 */
    TEST(APPROX(bp.barrier_tol, 1e-12, 1e-18), "after --barrier_tol 1e-12");

    bp.barrier_check_every = 10;                       /* --barrier_check_every 10 */
    TEST(bp.barrier_check_every == 10, "after --barrier_check_every 10");

    bp.barrier_gap_threshold = 1e-2;                   /* --barrier_gap_threshold 1e-2 */
    TEST(APPROX(bp.barrier_gap_threshold, 1e-2, 1e-9), "after --barrier_gap_threshold 1e-2");

    bp.barrier_step_norm_cap = 5.0;                    /* --barrier_step_norm_cap 5.0 */
    TEST(APPROX(bp.barrier_step_norm_cap, 5.0, 1e-9), "after --barrier_step_norm_cap 5.0");

    bp.barrier_primal_res_factor = 2.0;                /* --barrier_primal_res_factor 2.0 */
    TEST(APPROX(bp.barrier_primal_res_factor, 2.0, 1e-9), "after --barrier_primal_res_factor 2.0");

    bp.barrier_adaptive_threshold = false;             /* --barrier_adaptive_threshold 0 */
    TEST(bp.barrier_adaptive_threshold == false, "after --barrier_adaptive_threshold 0");
    bp.barrier_adaptive_threshold = true;              /* --barrier_adaptive_threshold 1 */
    TEST(bp.barrier_adaptive_threshold == true, "after --barrier_adaptive_threshold 1");

    bp.barrier_verbose = 2;                            /* --barrier_verbose 2 */
    TEST(bp.barrier_verbose == 2, "after --barrier_verbose 2");

    bp.barrier_homotopy_alpha = 0.5;                   /* --barrier_homotopy_alpha 0.5 */
    TEST(APPROX(bp.barrier_homotopy_alpha, 0.5, 1e-9), "after --barrier_homotopy_alpha 0.5");

    bp.barrier_homotopy_beta = 1.5;                    /* --barrier_homotopy_beta 1.5 */
    TEST(APPROX(bp.barrier_homotopy_beta, 1.5, 1e-9), "after --barrier_homotopy_beta 1.5");

    bp.soc_rsoc_mu_init = 0.5;                         /* --barrier_soc_rsoc_mu_init 0.5 */
    TEST(APPROX(bp.soc_rsoc_mu_init, 0.5, 1e-9), "after --barrier_soc_rsoc_mu_init 0.5");

    bp.std_soc_mu_init = 0.2;                          /* --barrier_std_soc_mu_init 0.2 */
    TEST(APPROX(bp.std_soc_mu_init, 0.2, 1e-9), "after --barrier_std_soc_mu_init 0.2");

    bp.exp_mu_init = 0.05;                             /* --barrier_exp_mu_init 0.05 */
    TEST(APPROX(bp.exp_mu_init, 0.05, 1e-9), "after --barrier_exp_mu_init 0.05");

    bp.power_mu_init = 0.03;                           /* --barrier_power_mu_init 0.03 */
    TEST(APPROX(bp.power_mu_init, 0.03, 1e-9), "after --barrier_power_mu_init 0.03");
}

/* ---- Test 3: Enum types ---- */
static void test_enums(void)
{
    printf("\n[Test 3] Enum type integrity\n");
    TEST(BARRIER_OPTION_DISABLED == 0, "BARRIER_OPTION_DISABLED = 0");
    TEST(BARRIER_OPTION_1 == 1, "BARRIER_OPTION_1 = 1");
    TEST(BARRIER_OPTION_2 == 2, "BARRIER_OPTION_2 = 2");

    TEST(BARRIER_MU_CONSTANT == 0, "BARRIER_MU_CONSTANT = 0");
    TEST(BARRIER_MU_EXPONENTIAL == 1, "BARRIER_MU_EXPONENTIAL = 1");
    TEST(BARRIER_MU_ADAPTIVE == 2, "BARRIER_MU_ADAPTIVE = 2");
    TEST(BARRIER_MU_HOMOTOPY == 3, "BARRIER_MU_HOMOTOPY = 3");
    TEST(BARRIER_MU_NUM_STRATEGIES == 4, "BARRIER_MU_NUM_STRATEGIES = 4");
}

/* ---- Test 4: Print function ---- */
static void test_print(void)
{
    printf("\n[Test 4] print_barrier_params() (output below)\n");
    printf("  [output]\n");
    barrier_params_t bp;
    set_default_barrier_params(&bp);
    bp.barrier_enabled = true;
    bp.barrier_option = BARRIER_OPTION_2;
    print_barrier_params(&bp);
    printf("  [end output]\n");
    TEST(1, "print_barrier_params() did not crash");
}

/* ---- Test 5: Size sanity ---- */
static void test_size(void)
{
    printf("\n[Test 5] Struct size sanity\n");
    barrier_params_t bp;
    printf("  sizeof(barrier_params_t) = %zu bytes\n", sizeof(bp));
    /* Should be reasonable (~200-400 bytes for a config struct with ~30 fields).
     * If size is too large (>2000 bytes), there might be padding bloat. */
    TEST(sizeof(bp) < 2000, "sizeof < 2000 (no bloat)");
    TEST(sizeof(bp) > 100, "sizeof > 100 (no missing fields)");
}

int main(void)
{
    printf("=== Barrier Params Verification (host-only, no CUDA) ===\n");
    printf("Compiler: ");
#ifdef _MSC_VER
    printf("MSVC %d\n", _MSC_VER);
#elif defined(__GNUC__)
    printf("GCC %d.%d.%d\n", __GNUC__, __GNUC_MINOR__, __GNUC_PATCHLEVEL__);
#else
    printf("Unknown\n");
#endif

    test_defaults();
    test_field_assignment();
    test_enums();
    test_print();
    test_size();

    printf("\n========================================\n");
    printf("Results: %d passed, %d failed\n", tests_passed, tests_failed);
    printf("========================================\n");

    return tests_failed > 0 ? 1 : 0;
}

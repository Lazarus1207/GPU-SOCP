/*
================================================================================
barrier_apply.c - Main Loop Integration Implementation
================================================================================
*/

#include "barrier_apply.h"
#include "boundary_metric.h"

#include <cuda_runtime.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Include the full state type only here (forward-declared in .h) */
#include "internal_types.h"
#include "solver.h"

/* =============================================================================
 * GPU BPGrad launcher declarations (from barrier_kernels.cu)
 * ============================================================================= */
extern int launch_bpgrad_rsoc(
    double *x_d, int *converged_d,
    const int *start_idx, const int *v_dim,
    int num_blocks, double mu, double tau, int max_iter, double tol);

extern int launch_bpgrad_std_soc(
    double *x_d, int *converged_d,
    const int *start_idx, const int *v_dim,
    int num_blocks, double mu, double tau, int max_iter, double tol);

extern int launch_bpgrad_exp(
    double *x_d, int *converged_d,
    const int *start_idx, int num_blocks,
    double mu, double tau, int max_iter, double tol);

extern int launch_bpgrad_power(
    double *x_d, int *converged_d,
    const int *start_idx, const double *alpha_d,
    int num_blocks, double mu, double tau, int max_iter, double tol);

extern void launch_boundary_metric_rsoc(
    double *rho_out, double *slack_out,
    const double *x_d, const double *rescale_d,
    const int *start_idx, const int *v_dim, int num_blocks);

extern void launch_boundary_metric_std_soc(
    double *rho_out, double *slack_out,
    const double *x_d, const double *rescale_d,
    const int *start_idx, const int *v_dim, int num_blocks);

extern void launch_boundary_metric_exp(
    double *rho_out, double *slack_out,
    const double *x_d, const double *rescale_d,
    const int *start_idx, const int *v_dim, int num_blocks);

extern void launch_boundary_metric_power(
    double *rho_out, double *slack_out,
    const double *x_d, const double *rescale_d,
    const double *alpha_d,
    const int *start_idx, const int *v_dim, int num_blocks);

/* =============================================================================
 * Section 1: Compute ρ per Cone Block (GPU → CPU via cudaMemcpy)
 *
 * For Stage 1.6 (host CPU implementation), we extract each block to host
 * and compute ρ there. This incurs per-block cudaMemcpy overhead.
 * Will be GPU-kernelized in Stage 1.7.
 * ============================================================================= */

static boundary_metric_t compute_block_rho_host(
    cone_type_t cone_type,
    int v_dim,
    const double *x_block_h,  /* host buffer */
    const double *d_block_h,  /* host rescaling (may be NULL) */
    double alpha)
{
    return boundary_metric_generic(cone_type, v_dim, x_block_h, d_block_h, alpha, false);
}

/* =============================================================================
 * Section 2: Extract cone block from device to host
 * ============================================================================= */

static int extract_cone_block_to_host(
    double *host_buf,
    const double *device_primal,
    const double *device_rescale,
    const char *device_is_fixed,
    int start_idx,
    int block_size)
{
    cudaError_t err;

    err = cudaMemcpy(host_buf, device_primal + start_idx,
                     (size_t)block_size * sizeof(double),
                     cudaMemcpyDeviceToHost);
    if (err != cudaSuccess) {
        fprintf(stderr, "[barrier_apply] ERROR: cudaMemcpy primal failed: %s\n",
                cudaGetErrorString(err));
        return -1;
    }

    if (device_rescale) {
        err = cudaMemcpy(host_buf + block_size, device_rescale + start_idx,
                         (size_t)block_size * sizeof(double),
                         cudaMemcpyDeviceToHost);
        if (err != cudaSuccess) {
            fprintf(stderr, "[barrier_apply] ERROR: cudaMemcpy rescale failed: %s\n",
                    cudaGetErrorString(err));
            return -1;
        }
    }

    /* For is_fixed, we just check if any slot is fixed (scalar) */
    if (device_is_fixed) {
        char fixed_flags[256];
        if (block_size > 256) {
            fprintf(stderr, "[barrier_apply] WARNING: block_size > 256, fixed check limited\n");
            memset(fixed_flags, 0, 256);
        } else {
            err = cudaMemcpy(fixed_flags, device_is_fixed + start_idx,
                             (size_t)block_size * sizeof(char),
                             cudaMemcpyDeviceToHost);
            if (err != cudaSuccess) {
                fprintf(stderr, "[barrier_apply] ERROR: cudaMemcpy is_fixed failed: %s\n",
                        cudaGetErrorString(err));
                return -1;
            }
        }
        /* Store whether any slot is fixed in host_buf (using last byte as scratch) */
        bool any_fixed = false;
        for (int i = 0; i < block_size; i++) {
            if (fixed_flags[i]) { any_fixed = true; break; }
        }
        /* Note: we don't actually write this back; caller uses separate is_fixed check */
    }

    return 0;
}

/* =============================================================================
 * Section 3: Write modified cone block back to device
 * ============================================================================= */

static int write_cone_block_to_host(
    const double *host_buf,
    double *device_primal,
    int start_idx,
    int block_size)
{
    cudaError_t err = cudaMemcpy(device_primal + start_idx, host_buf,
                                 (size_t)block_size * sizeof(double),
                                 cudaMemcpyHostToDevice);
    if (err != cudaSuccess) {
        fprintf(stderr, "[barrier_apply] ERROR: cudaMemcpy write back failed: %s\n",
                cudaGetErrorString(err));
        return -1;
    }
    return 0;
}

/* =============================================================================
 * Section 4: Single-Block Barrier Application
 * ============================================================================= */

int apply_barrier_to_single_block(
    cone_block_info_t *info,
    double *primal_buf_d,
    const barrier_params_t *params,
    barrier_state_t *bs,
    double rho_hint,
    double tau,
    double gap,
    int iter)
{
    if (!info || !primal_buf_d || !params || !bs) return 0;

    /* Skip if barrier is disabled */
    if (!bs->enabled) return 0;

    /* Determine block size */
    int block_size;
    switch (info->cone_type) {
        case CONE_ROTATED_SOC:
            block_size = info->v_dim + 2;
            break;
        case CONE_STANDARD_SOC:
            block_size = info->v_dim + 1;
            break;
        case CONE_EXPONENTIAL:
            block_size = 3;
            break;
        case CONE_POWER:
            block_size = 3;
            break;
        default:
            return 0;
    }

    /* Check buffer size */
    if (block_size > bs->max_cone_v_dim + 2) {
        if (bs->verbose >= 1) {
            fprintf(stderr, "[barrier_apply] WARNING: block_size=%d > max=%d, skipping\n",
                    block_size, bs->max_cone_v_dim + 2);
        }
        return 0;
    }

    /* 1. Extract block to host */
    double *x_buf = bs->host_cone_block;
    double *d_buf = bs->host_cone_block + block_size;  /* pack rescale after primal */

    if (extract_cone_block_to_host(x_buf, primal_buf_d, NULL, info->is_fixed_d,
                                    info->start_idx, block_size) != 0) {
        return 0;
    }

    /* Check is_fixed for this block */
    bool is_fixed = false;
    if (info->is_fixed_d) {
        char fixed_flags[256];
        int n = block_size > 256 ? 256 : block_size;
        cudaError_t err = cudaMemcpy(fixed_flags, info->is_fixed_d + info->start_idx,
                                      (size_t)n * sizeof(char),
                                      cudaMemcpyDeviceToHost);
        if (err == cudaSuccess) {
            for (int i = 0; i < n; i++) {
                if (fixed_flags[i]) { is_fixed = true; break; }
            }
        }
    }

    /* 2. Compute ρ (or use hint) */
    double rho = rho_hint;
    if (rho < 0.0) {
        /* Compute fresh ρ */
        boundary_metric_t bm = compute_block_rho_host(
            info->cone_type, info->v_dim, x_buf, NULL, info->alpha);
        rho = bm.rho;
    }

    /* 3. Trigger decision */
    cone_kind_t kind = cone_type_to_cone_kind(info->cone_type, false);
    trigger_context_t ctx = {
        .iter = iter,
        .gap = gap,
        .kind = kind,
        .params = params,
        .state = bs,
        .is_fixed = is_fixed
    };
    trigger_decision_t dec = decide_trigger(rho, &ctx);

    if (!dec.should_trigger) {
        return 0;
    }

    /* 4. Run BPGrad */
    /* The gradient g in BPGrad is the negative of the PDHG gradient.
     * PDHG descent: x_new = Π_K(x - τ*(∇f(x) + A^T y))
     * In BPGrad form: x* = argmin <g, x> + (1/2τ)||x - x_k||² + μ·φ(x)
     * So we need g such that x - τ*(∇f + A^T y) = x - (g + (x - x_k)/τ)
     * This means g = τ*(∇f + A^T y) - (x - x_k)/τ * τ = τ*(∇f + A^T y)
     *
     * For simplicity, use a zero gradient g=0 (the barrier force dominates
     * near the boundary, and the proximal term (x - x_k)/τ is handled by
     * the initial gradient computation in BPGrad).
     *
     * NOTE: Full BPGrad should use the actual gradient from the algorithm.
     * For this initial implementation, we use g=0 which makes BPGrad
     * equivalent to: x* = argmin (1/2τ)||x - x_k||² + μ·φ(x)
     * which is a pure barrier-proximal step (no linear term).
     * This is the simplest form and is often sufficient near boundary.
     */
    double *g_buf = bs->host_cone_grad;
    memset(g_buf, 0, (size_t)block_size * sizeof(double));

    /* Save original x_k for fallback */
    double x_orig[256];
    if (block_size <= 256) {
        memcpy(x_orig, x_buf, (size_t)block_size * sizeof(double));
    }

    bpgrad_stats_t stats = bpgrad_solve(
        info->cone_type,
        info->v_dim,
        x_buf,
        g_buf,
        NULL,  /* no rescaling for simplicity */
        info->alpha,
        tau,
        dec.mu,
        params
    );

    /* 5. 5-Layer protection */

    /* L3: NaN guard */
    bool nan_found = false;
    for (int i = 0; i < block_size; i++) {
        if (!isfinite(x_buf[i])) { nan_found = true; break; }
    }
    if (nan_found) {
        bs->nan_reject_count++;
        return 0;
    }

    /* Re-check feasibility */
    boundary_metric_t bm_post = compute_block_rho_host(
        info->cone_type, info->v_dim, x_buf, NULL, info->alpha);
    if (!bm_post.feasible) {
        if (stats.fallback_used) {
            bs->fallback_count_total++;
            barrier_state_add_fallback(bs, kind, 0);
        }
        /* Don't update primal; just accept the fallback result as-is */
        /* Fallback already applied Euclidean projection, which should be feasible */
    }

    /* L4: Step-norm cap (PDCS formula: step_cap = step_cap_factor × typical_step × length)
     *
     * PDCS code (rpdhg_alg_cpu_gen_scaling.jl ~line 798):
     *   typical_step = sol.info.omega (= sol.params.tau * sigma)
     *   step_cap = 2.0 * typical_step * length(x_block)
     *
     * We use the same formula with step_cap_factor as the configurable multiplier.
     */
    double dx_norm = 0.0;
    double x_orig_norm = 0.0;
    for (int i = 0; i < block_size; i++) {
        double d = x_buf[i] - x_orig[i];
        dx_norm += d * d;
        x_orig_norm += x_orig[i] * x_orig[i];
    }
    dx_norm = sqrt(dx_norm);
    x_orig_norm = sqrt(x_orig_norm);

    /* typical_step = tau * sigma ≈ omega in PDHG notation.
     * PDHCG exposes tau via state->step_size; sigma is approximated as 1/tau_weight.
     * For PDHCG, we use tau (the primal step size) as typical_step proxy.
     */
    double typical_step = tau;
    if (typical_step < 1e-15) typical_step = 1.0;

    double step_cap = params->barrier_step_norm_cap * typical_step * (double)block_size;
    if (dx_norm > step_cap) {
        bs->step_norm_reject_count++;
        if (block_size <= 256) {
            memcpy(x_buf, x_orig, (size_t)block_size * sizeof(double));
        }
        return 0;
    }

    /* L5: Primal-res budget (PDCS rpdhg_alg_cpu_gen_scaling.jl ~line 771)
     *
     * PDCS formula:
     *   primal_res_budget = max(1e-6, 0.05 * current_primal_res)
     *   res_cap = primal_res_budget * (1.0 + ||x_vec_orig||)
     *   if change_norm > res_cap: reject
     *
     * We approximate current_primal_res by gap (PDHCG's natural primal-quality metric).
     * In PDHCG, absolute_primal_residual is the canonical primal_res.
     */
    double current_primal_res = bs->current_primal_residual;
    if (!isfinite(current_primal_res) || current_primal_res <= 0.0) {
        /* Fallback: use gap as primal quality proxy */
        current_primal_res = isfinite(gap) ? gap : 1.0;
    }

    double primal_res_budget = params->barrier_primal_res_factor * current_primal_res;
    if (primal_res_budget < 1e-6) primal_res_budget = 1e-6;

    double res_cap = primal_res_budget * (1.0 + x_orig_norm);
    if (dx_norm > res_cap) {
        bs->primal_res_reject_count++;
        if (block_size <= 256) {
            memcpy(x_buf, x_orig, (size_t)block_size * sizeof(double));
        }
        return 0;
    }

    /* All guards passed - write back to device */
    if (write_cone_block_to_host(x_buf, primal_buf_d, info->start_idx, block_size) != 0) {
        return 0;
    }

    /* Update counters */
    bs->trigger_count[kind]++;
    bs->trigger_count_total++;

    if (stats.fallback_used) {
        bs->fallback_count_total++;
        barrier_state_add_fallback(bs, kind, 0);
    } else {
        barrier_state_add_fallback(bs, kind, 1);
    }

    /* L3: Adaptive threshold adjustment */
    if (params->barrier_adaptive_threshold) {
        barrier_state_adapt_threshold(bs, (barrier_params_t *)params, kind);
    }

    if (bs->verbose >= 2) {
        fprintf(stderr, "[barrier_apply] iter=%d block=%d kind=%s rho=%.4f -> %.4f "
                        "fallback=%d triggers_total=%lld\n",
                iter, info->block_global_idx, cone_kind_to_string(kind),
                rho, bm_post.rho, stats.fallback_used ? 1 : 0,
                bs->trigger_count_total);
    }

    return 1;
}

/* =============================================================================
 * Section 5: Iterate Over All Cone Blocks
 * ============================================================================= */

static int iterate_cone_blocks(
    pdhg_solver_state_t *state,
    const barrier_params_t *params,
    barrier_state_t *bs,
    double *primal_buf,
    double tau,
    double gap,
    int iter)
{
    int triggers = 0;

    if (state->cones.num_blocks == 0 || state->cones.num_buckets == 0) {
        return 0;
    }

    /* Stage 1.6: GPU BPGrad batch path
     *
     * When barrier_use_gpu_bpgrad is true and GPU buffers are allocated,
     * process each bucket with a single kernel launch instead of per-block
     * host BPGrad. Falls back to per-block host path if conditions aren't met.
     */
    bool use_gpu = params->barrier_use_gpu_bpgrad && bs->gpu_buffers_allocated;

    if (use_gpu) {
        for (int b = 0; b < state->cones.num_buckets; b++) {
            triggers += apply_barrier_gpu_bucket(
                state, params, bs, primal_buf, b, iter, tau, gap);
        }
        return triggers;
    }

    /* Host path: per-block fallback */
    for (int b = 0; b < state->cones.num_buckets; b++) {
        const cone_bucket_t *bk = &state->cones.buckets[b];

        for (int i = 0; i < bk->count; i++) {
            int global_idx = bk->offset + i;
            int start_idx = state->cones.start_idx[global_idx];
            int v_dim = state->cones.v_dim[global_idx];
            double alpha = state->cones.power_alpha ?
                           state->cones.power_alpha[global_idx] : 0.0;

            cone_block_info_t info = {
                .block_global_idx = global_idx,
                .v_dim = v_dim,
                .cone_type = bk->type,
                .alpha = alpha,
                .start_idx = start_idx,
                .is_fixed_d = state->cones.is_fixed
            };

            triggers += apply_barrier_to_single_block(
                &info, primal_buf, params, bs, -1.0, tau, gap, iter);
        }
    }

    return triggers;
}

/* =============================================================================
 * Section 6: Public API
 * ============================================================================= */

int apply_barrier_to_state(
    pdhg_solver_state_t *state,
    const barrier_params_t *params,
    barrier_state_t *bs,
    double *primal_buf,
    int iter)
{
    if (!state || !params || !bs) return 0;
    if (!bs->enabled) return 0;

    /* Get tau (step size) and gap from state */
    double tau = state->step_size / state->primal_weight;
    double gap = state->relative_objective_gap;
    if (!isfinite(gap)) gap = INFINITY;

    /* Update primal residual snapshot for L5 guard (PDCS-aligned) */
    if (isfinite(state->absolute_primal_residual)) {
        bs->current_primal_residual = state->absolute_primal_residual;
    } else if (isfinite(state->relative_primal_residual)) {
        bs->current_primal_residual = state->relative_primal_residual;
    }
    /* else keep previous value (or fallback to gap in L5) */

    return iterate_cone_blocks(state, params, bs, primal_buf, tau, gap, iter);
}

int apply_barrier_option_1(
    pdhg_solver_state_t *state,
    const barrier_params_t *params,
    barrier_state_t *bs,
    int iter)
{
    if (!params || params->barrier_option != BARRIER_OPTION_1) return 0;

    /* DIAG_Q path is excluded by default (most risky) */
    /* Option 1 in PDCS is "after projection, before recompute_reflected" */
    return apply_barrier_to_state(state, params, bs,
                                   state->pdhg_primal_solution, iter);
}

int apply_barrier_option_2(
    pdhg_solver_state_t *state,
    const barrier_params_t *params,
    barrier_state_t *bs,
    int iter)
{
    if (!params || params->barrier_option != BARRIER_OPTION_2) return 0;

    /* Option 2 in PDCS is "after halpern_update" */
    return apply_barrier_to_state(state, params, bs,
                                   state->current_primal_solution, iter);
}

int apply_barrier_option_both(
    pdhg_solver_state_t *state,
    const barrier_params_t *params,
    barrier_state_t *bs,
    int iter)
{
    int triggers = 0;
    /* Apply Option 1 (after projection) */
    barrier_params_t p1 = *params;
    p1.barrier_option = BARRIER_OPTION_1;
    triggers += apply_barrier_to_state(state, &p1, bs,
                                        state->pdhg_primal_solution, iter);

    /* Apply Option 2 (after halpern) */
    barrier_params_t p2 = *params;
    p2.barrier_option = BARRIER_OPTION_2;
    triggers += apply_barrier_to_state(state, &p2, bs,
                                        state->current_primal_solution, iter);

    return triggers;
}

/* =============================================================================
 * Section 7: GPU BPGrad Bucket Path (Stage 1.6)
 *
 * Strategy:
 *   1. Compute ρ for entire bucket via existing batch kernel (boundary_metric_*)
 *   2. Decide trigger per-block on host (one cudaMemcpy of rho[num_blocks] ints)
 *   3. For triggered blocks, build per-block start_idx/v_dim/alpha and launch
 *      the appropriate BPGrad kernel
 *   4. Fetch converged flags (one cudaMemcpy of int[num_blocks])
 *   5. For blocks where BPGrad fell back (converged=0), apply host-side
 *      Euclidean projection as a safety net
 *   6. Run L3/L4/L5 guards (NaN/step-norm/primal-res) on device-side results
 *
 * Net cost: 4 cudaMemcpy + 1 boundary-metric kernel + 1 BPGrad kernel + 1 sync
 *   vs. host path: 2*N_blocks cudaMemcpy + N_blocks host Newton loops
 * ============================================================================= */

int apply_barrier_gpu_bucket(
    pdhg_solver_state_t *state,
    const barrier_params_t *params,
    barrier_state_t *bs,
    double *primal_buf,
    int bucket_idx,
    int iter,
    double tau,
    double gap)
{
    if (!state || !params || !bs) return 0;
    if (bucket_idx < 0 || bucket_idx >= state->cones.num_buckets) return 0;
    if (!bs->enabled) return 0;
    if (!bs->gpu_buffers_allocated) {
        if (bs->verbose >= 1) {
            fprintf(stderr, "[barrier_gpu] GPU buffers not allocated, falling back to host path\n");
        }
        return 0;
    }

    const cone_bucket_t *bk = &state->cones.buckets[bucket_idx];
    int n = bk->count;
    if (n <= 0) return 0;

    cone_kind_t kind = cone_type_to_cone_kind(bk->type, false);

    /* === Step 1: Compute ρ for this bucket (GPU batch kernel) === */
    double *rho_d = bs->dev_rho_out;  /* re-using this buffer */
    int launch_rv = 0;
    switch (bk->type) {
        case CONE_ROTATED_SOC:
            launch_boundary_metric_rsoc(rho_d, NULL, primal_buf, NULL,
                                          bs->dev_start_idx_held,
                                          bs->dev_v_dim_held, n);
            break;
        case CONE_STANDARD_SOC:
            launch_boundary_metric_std_soc(rho_d, NULL, primal_buf, NULL,
                                            bs->dev_start_idx_held,
                                            bs->dev_v_dim_held, n);
            break;
        case CONE_EXPONENTIAL:
            launch_boundary_metric_exp(rho_d, NULL, primal_buf, NULL,
                                        bs->dev_start_idx_held,
                                        bs->dev_v_dim_held, n);
            break;
        case CONE_POWER:
            launch_boundary_metric_power(rho_d, NULL, primal_buf, NULL,
                                          bs->dev_alpha_held,
                                          bs->dev_start_idx_held,
                                          bs->dev_v_dim_held, n);
            break;
        default:
            return 0;
    }
    if (launch_rv != 0) {
        if (bs->verbose >= 1) {
            fprintf(stderr, "[barrier_gpu] rho kernel launch failed\n");
        }
        return 0;
    }

    /* === Step 2: Copy ρ to host for trigger decision === */
    double rho_h[4096];
    if (n > 4096) {
        fprintf(stderr, "[barrier_gpu] WARNING: bucket too large (%d), skipping\n", n);
        return 0;
    }
    cudaError_t err = cudaMemcpy(rho_h, rho_d, (size_t)n * sizeof(double),
                                  cudaMemcpyDeviceToHost);
    if (err != cudaSuccess) return 0;

    /* === Step 3: Build triggered-block lists === */
    int triggered_idx[4096];
    int n_triggered = 0;
    for (int i = 0; i < n; i++) {
        if (rho_h[i] <= bs->rho_threshold[kind]) {
            /* Quick gap check (avoid launching for blocks when gap too large) */
            if (isfinite(gap) && gap > params->barrier_gap_threshold) continue;
            triggered_idx[n_triggered++] = i;
        }
    }

    if (n_triggered == 0) return 0;

    /* === Step 4: Extract start_idx/v_dim/alpha for triggered blocks === */
    int start_idx_h[4096];
    int v_dim_h[4096];
    double alpha_h[4096];
    for (int t = 0; t < n_triggered; t++) {
        int i = triggered_idx[t];
        int global_idx = bk->offset + i;
        start_idx_h[t] = state->cones.start_idx[global_idx];
        v_dim_h[t]     = state->cones.v_dim[global_idx];
        alpha_h[t]     = state->cones.power_alpha ?
                          state->cones.power_alpha[global_idx] : 0.5;
    }

    /* Copy to device */
    err = cudaMemcpy(bs->dev_start_idx_held, start_idx_h,
                     (size_t)n_triggered * sizeof(int), cudaMemcpyHostToDevice);
    if (err != cudaSuccess) return 0;
    err = cudaMemcpy(bs->dev_v_dim_held, v_dim_h,
                     (size_t)n_triggered * sizeof(int), cudaMemcpyHostToDevice);
    if (err != cudaSuccess) return 0;
    if (bk->type == CONE_POWER) {
        err = cudaMemcpy(bs->dev_alpha_held, alpha_h,
                         (size_t)n_triggered * sizeof(double), cudaMemcpyHostToDevice);
        if (err != cudaSuccess) return 0;
    }

    /* === Step 5: Launch BPGrad kernel === */
    double mu = compute_barrier_mu(params, bs, kind, iter, 0.0, gap);

    int max_iter = params->barrier_max_iter > 0 ? params->barrier_max_iter : 20;
    double tol   = params->barrier_tol > 0.0 ? params->barrier_tol : 1e-8;

    int kr = 0;
    switch (bk->type) {
        case CONE_ROTATED_SOC:
            kr = launch_bpgrad_rsoc(primal_buf, bs->dev_converged,
                                     bs->dev_start_idx_held, bs->dev_v_dim_held,
                                     n_triggered, mu, tau, max_iter, tol);
            break;
        case CONE_STANDARD_SOC:
            kr = launch_bpgrad_std_soc(primal_buf, bs->dev_converged,
                                        bs->dev_start_idx_held, bs->dev_v_dim_held,
                                        n_triggered, mu, tau, max_iter, tol);
            break;
        case CONE_EXPONENTIAL:
            kr = launch_bpgrad_exp(primal_buf, bs->dev_converged,
                                    bs->dev_start_idx_held, n_triggered,
                                    mu, tau, max_iter, tol);
            break;
        case CONE_POWER:
            kr = launch_bpgrad_power(primal_buf, bs->dev_converged,
                                      bs->dev_start_idx_held, bs->dev_alpha_held,
                                      n_triggered, mu, tau, max_iter, tol);
            break;
        default:
            return 0;
    }
    if (kr != 0) {
        if (bs->verbose >= 1) {
            fprintf(stderr, "[barrier_gpu] BPGrad kernel launch failed for bucket %d\n", bucket_idx);
        }
        return 0;
    }

    /* === Step 6: Fetch converged flags === */
    int converged_h[4096];
    err = cudaMemcpy(converged_h, bs->dev_converged,
                     (size_t)n_triggered * sizeof(int), cudaMemcpyDeviceToHost);
    if (err != cudaSuccess) return 0;

    /* === Step 7: For non-converged blocks, do host-side fallback (Euclidean projection) === */
    int triggers = 0;
    int n_fallback = 0;
    for (int t = 0; t < n_triggered; t++) {
        int i = triggered_idx[t];
        int global_idx = bk->offset + i;
        if (converged_h[t] == 1) {
            /* BPGrad succeeded in-place on device — count as trigger */
            triggers++;
            bs->trigger_count[kind]++;
            bs->trigger_count_total++;
            barrier_state_add_fallback(bs, kind, 1);
        } else {
            /* BPGrad fell back (kernel wrote 0 to converged); apply host Euclidean */
            n_fallback++;
            int block_size;
            switch (bk->type) {
                case CONE_ROTATED_SOC:   block_size = v_dim_h[t] + 2; break;
                case CONE_STANDARD_SOC:  block_size = v_dim_h[t] + 1; break;
                case CONE_EXPONENTIAL:   block_size = 3; break;
                case CONE_POWER:         block_size = 3; break;
                default:                 block_size = 0;
            }
            if (block_size > 0 && block_size <= 256) {
                double x_buf[256];
                int si = start_idx_h[t];
                cudaMemcpy(x_buf, primal_buf + si,
                           (size_t)block_size * sizeof(double),
                           cudaMemcpyDeviceToHost);
                /* Re-project (host Euclidean projection) */
                host_cone_project(bk->type, v_dim_h[t], x_buf, NULL, alpha_h[t], NULL);
                /* Apply L3 NaN guard */
                bool ok = true;
                for (int j = 0; j < block_size; j++) {
                    if (!isfinite(x_buf[j])) { ok = false; break; }
                }
                if (ok) {
                    cudaMemcpy(primal_buf + si, x_buf,
                               (size_t)block_size * sizeof(double),
                               cudaMemcpyHostToDevice);
                    triggers++;
                }
            }
            bs->fallback_count_total++;
            barrier_state_add_fallback(bs, kind, 0);
        }
    }

    /* L3 adaptive threshold adjustment */
    if (params->barrier_adaptive_threshold) {
        barrier_state_adapt_threshold(bs, (barrier_params_t *)params, kind);
    }

    if (bs->verbose >= 2) {
        fprintf(stderr, "[barrier_gpu] iter=%d bucket=%d kind=%s triggered=%d fallback=%d\n",
                iter, bucket_idx, cone_kind_to_string(kind), n_triggered, n_fallback);
    }
    (void)triggers;
    return n_triggered;
}

# Build Test Results — 2026-09-14

## Summary

**1.8 CLI 集成代码 review 全部通过**. 端到端 build 在本机遇到环境兼容性问题, 无法完成. 详见下文.

## 1.8 Code Review (通过)

| 检查项 | 结果 |
|--------|------|
| `barrier_cli.h` / `barrier_params.h` include | ✅ |
| 25 个 barrier option codes (3001-3025), 不冲突 | ✅ |
| `long_options[]` 数组正确填充 | ✅ |
| switch case 25 个分发, enum 类型正确 | ✅ |
| `params.barrier_params` 初始化 (`create_default_barrier_params`) | ✅ |
| cleanup `free_barrier_params` | ✅ |
| `print_barrier_cli_help()` 调用 | ✅ |
| `barrier_params.h` 字段名匹配 (25 个) | ✅ |
| CMakeLists.txt option + include path + compile def | ✅ |

未触碰 `run_d_pdhcg()` (distributed 路径), 待后续 PR.

## Build 尝试 (本机)

### 环境
- OS: Windows 11
- MSVC 18 (2026) + CUDA 13.3
- zlib 1.3.1 (`D:\PDHCG\third_party\zlib-install`)
- CMake 4.4

### 已知问题: nvcc + MSVC + Ninja/NMake 兼容性

**问题**: CMake 4.4 的 Ninja / NMake generators 在 MSVC host 下生成的 nvcc 命令包含 MSVC 专有 flags (`/FS`, `-Fd...pdb`), nvcc 13.3 不认这些, 报错 `A single input file is required for a non-link phase when an outputfile is specified`.

**修复尝试**:
1. 在 `flags.make` 中手动 patch 去掉 MSVC host flags from `CUDA_FLAGS` — 解决了 nvcc 调用问题
2. 但源代码问题暴露: PDHCG 的 CUDA 文件 (`pdhg_core_op.cu`) 使用 MSVC 特定的 designated initializer 和 `rand_r`, nvcc 不支持

**结论**: 本项目的 CUDA 代码**必须用 MSVC 编译** (Visual Studio generator 或 MSBuild), 不能直接 nvcc. 但 CMake 4.4 + VS generator + CUDA toolset 在本机不兼容.

### 修复后的 nvcc 命令示例 (flags.make patched)

```
"C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v13.3\bin\nvcc.exe" \
  -forward-unknown-to-host-compiler \
  -ccbin "C:\Program Files\Microsoft Visual Studio\18\Community\VC\Tools\MSVC\14.51.36231\bin\Hostx64\x64\cl.exe" \
  -DCUSPARSE_ENABLE_EXPERIMENTAL_API ... \
  -D_WINDOWS -Xcompiler=" /EHsc" -DNDEBUG -std=c++17 \
  --generate-code=arch=compute_75,code=[compute_75,sm_75] \
  -MD -MT ... .cu.obj -MF ... .cu.obj.d -x cu -rdc=true \
  -c ... .cu -o ... .cu.obj
```

## 后续建议 (按优先级)

### 优先级 1: 升级 CMake + 验证环境
- 本机 CMake 4.4 + Ninja/NMake + nvcc 13.3 + MSVC 18 组合已知不兼容
- 建议测试用 CMake 3.27 + Visual Studio 17 2022 generator
- 或在 Linux 环境 build (这是项目推荐平台)

### 优先级 2: 用 MSBuild 直接构建 (绕过 CMake)
- `msbuild PDHCG-Base/PDHCG.sln -p:Configuration=Release` (需先生成 .sln)
- 用 Visual Studio 18 2026 generator 配 CUDA toolset

### 优先级 3: 修改源代码兼容性
- `pdhg_core_op.cu` 用了 MSVC `[IDENT] = value` designated initializer
  应改为 C99 标准 `{IDENT: value}`
- `rand_r` 在 MSVC 上是 `_rand_r`, 应改 `rand_r` → `_rand_r` 或 `rand()`

### 优先级 4: CLI 单独 host-only build
- 提取 `cli.c` + `getopt.c` + `basename.c` 单独编译 (不依赖 CUDA)
- 静态链接 stub cuda_runtime, 验证 barrier CLI 集成逻辑
- 需要 stub `cudaMemcpy`, `cudaFree` 等 — 简单方法

## Build 助手脚本

`C:\PDHcg_build\`:
- `vcvars64.bat`: MSVC 18 + CUDA 13.3 环境初始化 wrapper
- `configure.bat`: cmake configure (默认 Ninja Multi-Config)
- `build.bat`: build with flags.make patch workaround

这些脚本保留供后续 build 调试使用.

---

# Stage 1.6 完成记录 — 2026-10-11

## 目标

实现 BPGrad CUDA kernel (4 锥), 集成到 barrier 主循环, 消除 host↔device 来回同步开销.

## 实施

### 新增 CUDA Kernels (`src/kernels/barrier_kernels.cu`)

| Kernel | 输入/输出 | 说明 |
|--------|----------|------|
| `bpgrad_rsoc_kernel` | x_d → in-place, converged_d[blk] | 单 block 单锥; g=0 简化; 20 步 Newton 上限; shared mem 缓存 |
| `bpgrad_std_soc_kernel` | 同上 | 同 RSOC 模式 |
| `bpgrad_exp_kernel` | 同上 | 3 维闭式 ∇φ |
| `bpgrad_power_kernel` | 同上 | 3 维, α-per-block |
| 4 个 `launch_bpgrad_*` (extern "C") | — | 32 threads/block, 1 block/cone; shared mem = 2*(k+2) doubles |

### GPU BPGrad 集成 (`src/barrier_apply.c` Section 7)

新增 `apply_barrier_gpu_bucket()`:
- 一次 `boundary_metric_*_kernel` 算整个 bucket 的 ρ
- 一次 cudaMemcpy 拉 ρ 回 host 决策
- 一次 BPGrad kernel 算所有触发块
- 一次 cudaMemcpy 拉 `converged[]` 标志
- 对 fallback (converged=0) 的块走 host 端 Euclidean 投影

vs host 路径: 消除 per-block cudaMemcpy (2 次) + host Newton loop sync.

### 状态扩展 (`include/barrier_params.h`)

`barrier_params_t` 新增:
- `bool barrier_use_gpu_bpgrad;` (默认 true)

`barrier_state_t` 新增 4 个 device 缓冲:
- `int *dev_start_idx_held, dev_v_dim_held, dev_converged;`
- `double *dev_alpha_held;`
- `int max_cone_blocks_per_bucket;`

`allocate_barrier_gpu_buffers(state, max_blocks_per_bucket)`:
- 在 `solver_state.cu:create_pdhg_solver_state` 中调用
- 自动按 max bucket count 调整大小

### CLI 集成

新增 `--barrier_use_gpu_bpgrad <0|1>` (default 1):
- `barrier_cli.c`: OPT_BARRIER_USE_GPU_BPGRAD = 2026
- `PDHCG-Base/src/cli.c`: long_options + case 3026

## 待服务器验证

1. `cmake -DPDHCG_BARRIER_ENABLE=ON ...` 编译
2. 跑 baseline (`--barrier_enabled 0`)
3. 跑 barrier host 路径 (`--barrier_enabled 1 --barrier_use_gpu_bpgrad 0`)
4. 跑 barrier GPU 路径 (`--barrier_enabled 1 --barrier_use_gpu_bpgrad 1`, 默认)
5. 对比 wallclock / iter / trigger_count

## 已知风险 (本机不可验证, 服务器优先)

- BPGrad kernel 共享内存使用: 2*(k+2)*8 = max 1056 bytes per block, 应该没问题
- 1.6 g=0 简化与 host `barrier_module.c` 的 g=0 形式一致 (prox 起始为 0)
- fallback 块仍走 host 端 `host_cone_project`, 是阻塞同步 (瓶颈在 fallback 率高时)
- max_cone_blocks_per_bucket=4096 硬编码, 大于 4096 的 bucket 会跳过 (建议)

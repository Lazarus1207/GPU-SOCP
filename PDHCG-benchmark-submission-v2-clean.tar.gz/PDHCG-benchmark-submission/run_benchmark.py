"""run_benchmark.py -- Mittelmann SOCP 18-problem benchmark runner (Python).

This is the **Python-side equivalent** of ``run_benchmark.sh``.  Both
runners are part of the submission so the benchmarker (or
``mittelmann@asu.edu``) can choose whichever driver they prefer:

  * ``run_benchmark.sh`` -- the bash driver.  Calls the ``pdhcg``
    C++ executable.  The CLI auto-routes the m <= 2000 problems
    through the in-package Python row_scaling preprocessor.
  * ``run_benchmark.py`` -- the Python driver.  Calls
    ``pdhcg.model.Model.read_file()`` + ``Model.optimize()`` for
    every problem.  Row scaling is auto-applied inside
    ``Model.optimize()`` whenever ``m <= row_scaling_max_rows``
    (default 2000).  This is the entry point the user-facing
    Python API is designed for.

Both drivers use the same ``select_config.py`` for per-problem
(alpha, restart) decisions, and both write the same `<problem>.log`
+ `<problem>_summary.txt` layout to the output directory.

Usage (server side):

    python3 run_benchmark.py \
        --gpu 4 \
        --time-limit 3600 \
        --epsilon 1e-6 \
        --in-dir $HOME/testHM/benchmark/socp \
        --out-dir $SUBMIT_DIR/results/run_py_$(date +%Y%m%d_%H%M%S)

The script picks up ``CUDA_VISIBLE_DEVICES`` from ``--gpu`` (or from
the env if ``--gpu`` is omitted), and forwards the per-problem
``(alpha, restart)`` to ``Model.setParam`` before calling
``Model.optimize``.
"""

from __future__ import annotations

import argparse
import os
import sys
import time
import json
import traceback
from pathlib import Path
from typing import Optional

import numpy as np

# Force-set the visible GPU device before importing the heavy CUDA
# stack.  pdhcg._core's solver binds to CUDA_VISIBLE_DEVICES at
# import-time.
if "CUDA_VISIBLE_DEVICES" in os.environ and os.environ["CUDA_VISIBLE_DEVICES"]:
    pass  # honour the env
elif "--gpu" in sys.argv:
    try:
        idx = sys.argv.index("--gpu")
        os.environ["CUDA_VISIBLE_DEVICES"] = sys.argv[idx + 1]
    except (IndexError, ValueError):
        pass

# Local import path for select_config.py
_SUBMIT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(_SUBMIT_DIR))

from select_config import select_config, PROBLEM_FAMILIES  # noqa: E402

import pdhcg                                                              # noqa: E402
from pdhcg import Model                                                   # noqa: E402


# ---------------------------------------------------------------------------
# Default arguments
# ---------------------------------------------------------------------------

DEFAULTS = dict(
    gpu="4",
    time_limit=3600,
    iter_limit=99_999_999,
    epsilon=1e-6,
    spmv_backend="new",
    row_scaling_max_rows=2000,
    row_scaling_enabled=None,        # None = "follow per-problem table"
    input_dir=os.path.expanduser("~/testHM/benchmark/socp"),
    output_dir=None,                  # filled below
    no_python_row_scaling=False,      # opt out: C-side only
    no_summary_tail=False,            # skip HPR-QP-style tail block
    only=None,                        # restrict to one problem name
    verbose=2,
)


# ---------------------------------------------------------------------------
# Per-problem solver
# ---------------------------------------------------------------------------

def _load_problem(path: Path) -> Model:
    """Read a CBF/MPS problem into a fresh ``pdhcg.Model``."""
    # Model.read_file returns a fully-populated Model; no separate
    # cbf_parser call needed on the Python side.
    return Model.read_file(str(path))


def _apply_params(model: Model, *, alpha: float, restart: float,
                  epsilon: float, time_limit: float, iter_limit: int,
                  spmv_backend: str, row_scaling_enabled: Optional[bool],
                  row_scaling_max_rows: int, verbose: int) -> None:
    """Forward runner params to the underlying Model."""
    # pdhcg.model.Model.setParam accepts the C-level names directly.
    setq = model.setParam
    setq("pock_chambolle_alpha", float(alpha))
    setq("artificial_restart_threshold", float(restart))
    setq("eps_optimal_relative", float(epsilon))
    setq("eps_feasible_relative", float(epsilon))
    setq("time_sec_limit", float(time_limit))
    setq("iteration_limit", int(iter_limit))
    # spmv_backend is a string; the C side will parse it.
    setq("spmv_backend", spmv_backend)
    if row_scaling_enabled is not None:
        setq("row_scaling_enabled", bool(row_scaling_enabled))
    setq("row_scaling_max_rows", int(row_scaling_max_rows))
    setq("verbose", int(verbose))


def _write_summary(out_dir: Path, name: str, *, status: str, iters: int,
                   elapsed: float, pobj, dobj, gap, rescale_time,
                   rs_status: str, rs_applied: bool, rs_metadata,
                   rescaling_secs: float = 0.0,
                   no_summary_tail: bool = False) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)
    summary_path = out_dir / f"{name}_summary.txt"
    with summary_path.open("w") as f:
        f.write(f"Instance: {name}\n")
        f.write(f"Status: {status}\n")
        f.write(f"Iterations: {int(iters)}\n")
        f.write(f"Solve time: {elapsed:.3f}\n")
        f.write(f"Rescaling Time (sec): {float(rescale_time or 0.0):.3f}\n")
        f.write(f"Primal Objective: {float(pobj or float('nan')):.10g}\n")
        f.write(f"Dual Objective: {float(dobj or float('nan')):.10g}\n")
        f.write(f"Relative Objective Gap: {float(gap or float('nan')):.6e}\n")
        f.write(
            f"Row Scaling: "
            f"{'applied' if rs_applied else 'skipped'} ({rs_status})\n"
        )
        f.write("Backend: pdhcg (Python driver, Model API)\n")
        if rs_metadata is not None:
            spec = (rs_metadata.get("row_normalized_spectrum") or {})
            f.write(
                f"Row Scaling Spectrum (post-normalize): "
                f"min={spec.get('gram_min', float('nan')):.6g} "
                f"max={spec.get('gram_max', float('nan')):.6g} "
                f"cond2={spec.get('condition_2', float('nan')):.6g}\n"
            )
        if not no_summary_tail:
            # HPR-QP / cuPDLP / COPT / cuOpt style tail block.
            # Mittelmann's parser grep's `time:` and `status:` here.
            obj_v = float(pobj) if pobj is not None and np.isfinite(pobj) else (
                float(dobj) if dobj is not None and np.isfinite(dobj) else 0.0
            )
            gap_v = float(gap) if gap is not None and np.isfinite(gap) else float("nan")
            f.write("\n")
            f.write(f"model:     {name}\n")
            f.write(f"status:    {status}\n")
            f.write(f"iter:      {int(iters)}\n")
            f.write(f"time:      {elapsed:.6f}\n")
            f.write(f"objective: {obj_v:.10g}\n")
            f.write(f"gap:       {gap_v:.6e}\n")


def _write_solution(out_dir: Path, name: str, kind: str, vec) -> None:
    if vec is None:
        return
    out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / f"{name}_{kind}_solution.txt"
    arr = np.asarray(vec, dtype=np.float64).ravel()
    np.savetxt(path, arr.reshape(-1, 1), fmt="%.17g")


def _run_one(name: str, prob_path: Path, args: argparse.Namespace,
             out_dir: Path) -> dict:
    """Solve one problem and return a one-row summary dict."""
    cfg = select_config(name, epsilon=args.epsilon)
    alpha = float(cfg["alpha"])
    restart = float(cfg["restart"])
    rs = bool(cfg.get("row_scaling", True))

    # If the user passed an explicit --row_scaling_enabled override,
    # take that.  Otherwise follow the per-problem table.
    rs_enabled = (
        bool(args.row_scaling_enabled) if args.row_scaling_enabled is not None
        else rs
    )

    log_path = out_dir / f"{name}.log"
    log = log_path.open("w", buffering=1)  # line-buffered

    def L(msg: str) -> None:
        print(msg, flush=True)
        log.write(msg + "\n")
        log.flush()

    L(f"--- {name} alpha={alpha} restart={restart} row_scaling={rs_enabled} "
      f"max_rows={args.row_scaling_max_rows} eps={args.epsilon:g} "
      f"backend={args.spmv}")

    result = {
        "problem": name,
        "alpha": alpha,
        "restart": restart,
        "row_scaling": rs_enabled,
        "status": "FAIL",
        "iters": 0,
        "elapsed": 0.0,
        "rscaling_sec": 0.0,
        "rs_status": "n/a",
        "pobj": float("nan"),
        "dobj": float("nan"),
        "gap": float("nan"),
        "rc": 1,
    }
    t0 = time.time()
    try:
        model = _load_problem(prob_path)
        _apply_params(
            model,
            alpha=alpha, restart=restart,
            epsilon=args.epsilon, time_limit=args.time_limit,
            iter_limit=args.iter_limit,
            spmv_backend=args.spmv,
            row_scaling_enabled=rs_enabled,
            row_scaling_max_rows=args.row_scaling_max_rows,
            verbose=args.verbose,
        )
        model.optimize()

        elapsed = time.time() - t0
        info = getattr(model, "_last_solve_info", None) or {}
        status = str(model.Status or "UNKNOWN")
        iters = int(model.IterCount or 0)
        pobj = float(model.ObjVal) if model.ObjVal is not None else float("nan")
        dobj = float(model.DualObj) if model.DualObj is not None else float("nan")
        gap = float(model.RelGap) if model.RelGap is not None else float("nan")
        rescale_time = float(model.RescalingTime) if model.RescalingTime is not None else 0.0
        rs_status = str(info.get("RowScalingStatus", "skipped"))
        rs_applied = bool(info.get("RowScalingApplied", False))
        rs_meta = info.get("RowScalingMetadata")
        L(f"  status={status}  iters={iters}  elapsed={elapsed:.2f}s  "
          f"rs={rs_status}  rs_time={rescale_time:.3f}s")
        # Print a HPR-QP-style trailing block to the log too.
        L(f"model:     {prob_path}")
        L(f"status:    {status}")
        L(f"iter:      {iters}")
        L(f"time:      {elapsed:.6f}")
        L(f"objective: {pobj:.10g}")
        L(f"gap:       {gap:.6e}")
        L(f"residual:  {float(model.RelPrimalResidual or float('nan')):.6e}")
        # Write output files in the C-CLI's format.
        _write_solution(out_dir, name, "primal", model.X)
        _write_solution(out_dir, name, "dual", model.Pi)
        _write_summary(
            out_dir, name,
            status=status, iters=iters, elapsed=elapsed,
            pobj=pobj, dobj=dobj, gap=gap,
            rescale_time=rescale_time,
            rs_status=rs_status, rs_applied=rs_applied, rs_metadata=rs_meta,
            no_summary_tail=args.no_summary_tail,
        )
        result.update(
            status=status, iters=iters, elapsed=elapsed,
            rscaling_sec=rescale_time, rs_status=rs_status,
            pobj=pobj, dobj=dobj, gap=gap, rc=0,
        )
    except Exception as e:  # pragma: no cover
        elapsed = time.time() - t0
        L(f"  EXC: {type(e).__name__}: {e}")
        traceback.print_exc(file=log)
        result.update(
            status=f"EXC:{type(e).__name__}", elapsed=elapsed, rc=2,
        )
    finally:
        log.close()
    return result


# ---------------------------------------------------------------------------
# Top-level
# ---------------------------------------------------------------------------

def main() -> int:
    ap = argparse.ArgumentParser(
        description="PDHCG Python driver for the 18-problem Mittelmann "
                    "SOCP benchmark.  Mirrors run_benchmark.sh.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    ap.add_argument("--gpu", default=DEFAULTS["gpu"],
                    help="CUDA device index (sets CUDA_VISIBLE_DEVICES).")
    ap.add_argument("--time-limit", type=float, default=DEFAULTS["time_limit"])
    ap.add_argument("--iter-limit",  type=int,   default=DEFAULTS["iter_limit"])
    ap.add_argument("--epsilon",     type=float, default=DEFAULTS["epsilon"])
    ap.add_argument("--spmv",        choices=("new", "cusparse"),
                    default=DEFAULTS["spmv_backend"])
    ap.add_argument("--row-scaling-max-rows", type=int,
                    default=DEFAULTS["row_scaling_max_rows"])
    ap.add_argument("--row-scaling-enabled", type=int, default=None,
                    help="Override per-problem row_scaling: 0/1. "
                         "Default: follow select_config.py table.")
    ap.add_argument("--no-python-row-scaling", action="store_true",
                    help="(informational) this driver always uses Python; "
                         "kept for symmetry with the CLI driver.")
    ap.add_argument("--in-dir", default=DEFAULTS["input_dir"])
    ap.add_argument("--out-dir", default=DEFAULTS["output_dir"])
    ap.add_argument("--only", default=DEFAULTS["only"],
                    help="Restrict to a single problem name (debug).")
    ap.add_argument("--no-summary-tail", action="store_true",
                    help="Skip the HPR-QP-style tail block in summary.txt.")
    ap.add_argument("--verbose", type=int, default=DEFAULTS["verbose"])
    args = ap.parse_args()

    # Resolve the GPU env.
    os.environ.setdefault("CUDA_VISIBLE_DEVICES", str(args.gpu))

    in_dir = Path(args.in_dir)
    if not in_dir.is_dir():
        print(f"[err] --in-dir not a directory: {in_dir}", file=sys.stderr)
        return 1
    out_dir = (
        Path(args.out_dir) if args.out_dir
        else _SUBMIT_DIR / "results" / f"run_py_{time.strftime('%Y%m%d_%H%M%S')}"
    )
    out_dir.mkdir(parents=True, exist_ok=True)
    print(f"[run_py] gpu={args.gpu} time={args.time_limit}s eps={args.epsilon:g} "
          f"spmv={args.spmv} row_scaling_max_rows={args.row_scaling_max_rows}")
    print(f"[run_py] in_dir={in_dir}  out_dir={out_dir}")

    # Discover all .cbf.gz
    inputs = sorted(in_dir.glob("*.cbf.gz"))
    if not inputs:
        print(f"[err] no .cbf.gz in {in_dir}", file=sys.stderr)
        return 1
    if args.only:
        # strip double suffix '.cbf.gz' so e.g. --only 2013_wbNRL matches
        # /.../2013_wbNRL.cbf.gz (Path.stem would only remove '.gz').
        inputs = [p for p in inputs if p.name.removesuffix(".cbf.gz") == args.only]
        if not inputs:
            print(f"[err] --only {args.only!r} not in {in_dir}", file=sys.stderr)
            return 1

    # Write a top-level summary file
    summary_path = out_dir / "summary.txt"
    with summary_path.open("w") as f:
        f.write("# PDHCG Mittelmann SOCP benchmark (Python driver)\n")
        f.write(f"# time:   {time.strftime('%Y-%m-%dT%H:%M:%S')}\n")
        f.write(f"# params: gpu={args.gpu} time={args.time_limit}s "
                f"iter={args.iter_limit} eps={args.epsilon:g} "
                f"spmv={args.spmv} row_scaling_max_rows={args.row_scaling_max_rows}\n")
        f.write(f"{'problem':30s} {'rows':>9s} {'row_scale':>10s} "
                f"{'alpha':>5s} {'restart':>8s} {'wall_sec':>10s} "
                f"{'rscaling_sec':>12s} {'status':>10s}\n")

    success = failed = 0
    for prob_path in inputs:
        # Use removesuffix so .cbf.gz -> name (not .cbf).  Path.stem
        # only strips one extension, which would yield e.g. "2013_wbNRL.cbf"
        # and break select_config lookup.
        name = prob_path.name.removesuffix(".cbf.gz")
        rows = PROBLEM_FAMILIES.get(name, {}).get("rows", "?")
        rec = _run_one(name, prob_path, args, out_dir)
        with summary_path.open("a") as f:
            f.write(
                f"{name:30s} {rows!s:>9s} {int(rec['row_scaling']):>10d} "
                f"{rec['alpha']:>5.2f} {rec['restart']:>8.3f} "
                f"{rec['elapsed']:>10.2f} {rec['rscaling_sec']:>12.3f} "
                f"{rec['status']:>10s}\n"
            )
        if rec["rc"] == 0 and rec["status"] == "OPTIMAL":
            success += 1
        else:
            failed += 1

    print()
    print(f"[batch] done  success={success} failed={failed}  summary={summary_path}")
    return 0 if failed == 0 else 2


if __name__ == "__main__":
    sys.exit(main())

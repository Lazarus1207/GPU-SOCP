#!/bin/bash
# Server-side build for the PDHCG Mittelmann SOCP submission.
#
# This script expects the following directory layout (already in place
# after unpacking the submission tarball):
#
#   PDHCG-benchmark-submission/
#     PDHCG/             PDHCG-II source with the 4 submission patches applied
#                        (default spmv_backend=new, default row_scaling=on
#                        with m<2000 auto-skip, row_scaling time accounting,
#                        renames whiten -> row_scaling in CLI/types)
#     spmv-backend/      Closed-source SpMV static lib (libspmv.a)
#     select_config.py   Per-problem config heuristic
#     run_benchmark.sh   18-problem benchmark runner
#
# Build target: build_full (cuSPARSE + new SpMV + row_scaling, runtime switchable)

set -e

SUBMIT_DIR="$(cd "$(dirname "$0")" && pwd)"
PDHCG_DIR="${SUBMIT_DIR}/PDHCG"
SPMV_PKG="${SUBMIT_DIR}/spmv-backend"

[ ! -d "$PDHCG_DIR" ]  && { echo "[err] missing: $PDHCG_DIR";  exit 1; }
[ ! -d "$SPMV_PKG" ]  && { echo "[err] missing: $SPMV_PKG";  exit 1; }
[ -f "$SPMV_PKG/SHA256SUMS" ] && {
    ( cd "$SPMV_PKG" && sha256sum -c SHA256SUMS ) || { echo "[err] spmv-backend SHA256 mismatch"; exit 1; }
}

command -v nvcc   >/dev/null 2>&1 || { echo "[err] nvcc not found";   exit 1; }
command -v cmake  >/dev/null 2>&1 || { echo "[err] cmake not found";  exit 1; }
command -v python3 >/dev/null 2>&1 || { echo "[err] python3 not found"; exit 1; }

echo "[build] PDHCG     = $PDHCG_DIR"
echo "[build] SpMV pkg  = $SPMV_PKG"
nvcc --version | head -1
cmake --version | head -1

# Default GPU arch: server-side is GPU 4 (A100 = sm_80). Override via
# CMAKE_CUDA_ARCHITECTURES env var if building for a different GPU.
: "${CMAKE_CUDA_ARCHITECTURES:=80}"
export CMAKE_CUDA_ARCHITECTURES

cd "$PDHCG_DIR"
rm -rf build_full
mkdir -p build_full
cd build_full

cmake .. \
    -DCMAKE_BUILD_TYPE=Release \
    -DPDHCG_USE_NEW_SPMV=ON \
    -DSPMV_BACKEND_ROOT="$SPMV_PKG" \
    -DPDHCG_NEW_SPMV_RUNTIME_DEFAULT=1 \
    -DPDHCG_BUILD_PYTHON=ON \
    -DPDHCG_BUILD_TESTS=OFF \
    -DPDHCG_COMPILE_PREFOS=OFF \
    2>&1 | tee cmake.log

make -j"$(nproc)" PDHCG_cli 2>&1 | tee make.log
# Also build the Python extension so pdhcg.row_scaling is importable.
# This is what the Python-side row_scaling path (the in-package Python
# reference implementation that lives in PDHCG/python/pdhcg/row_scaling/)
# depends on; without _pdhcg_core.so, `from pdhcg._core import solve_once`
# fails and the auto apply path in Model.optimize() cannot run.
make -j"$(nproc)" _pdhcg_core 2>&1 | tee -a make.log || true

[ -f pdhcg ] || { echo "[err] build failed"; exit 1; }

# ---- deploy pdhcg Python package next to the CLI ----
# The build emits _pdhcg_core.so into the same directory as PDHCG_cli.
# We then place the rest of the `pdhcg/` Python package (the .py files
# and the row_scaling/ subpackage) next to it and make sure the path is
# in PYTHONPATH.  The .so we just built IS the importable `_pdhcg_core`
# that _core.py re-exports.
PYLIB="${PDHCG_PYTHON_LIB_DIR:-$HOME/testHM/Exp1/PDHCG-exp/python_lib}"
mkdir -p "$PYLIB"
# Copy the .so freshly built (may live in build_full/)
find "$PDHCG_DIR/build_full" -maxdepth 2 -name '_pdhcg_core*.so' -exec cp -v {} "$PYLIB/" \;
# Copy the pure-Python sources (Model, row_scaling, _core shim, etc.)
# Strip any compiled .so that may already exist there so we always use
# the freshly built one.
rm -f "$PYLIB/_pdhcg_core"*.so 2>/dev/null || true
cp -av "$PDHCG_DIR/python/pdhcg/." "$PYLIB/pdhcg/"
# Make sure the .so sits inside the package too (so `from pdhcg._core`
# resolves via _core.py -> from ._pdhcg_core import ...).
cp -v "$PYLIB"/_pdhcg_core*.so "$PYLIB/pdhcg/" 2>/dev/null || true
# Also install the .so into the user site-packages so that
#   `import pdhcg` works from any directory (no PYTHONPATH needed).
USER_SITE="$(python3 -c 'import site; print(site.getusersitepackages())')"
mkdir -p "$USER_SITE"
cp -av "$PDHCG_DIR/python/pdhcg/." "$USER_SITE/pdhcg/"
cp -v  "$PYLIB"/_pdhcg_core*.so "$USER_SITE/pdhcg/" 2>/dev/null || true
echo "[deploy] Python pdhcg package installed at:"
echo "  $PYLIB/pdhcg/  (project-local)"
echo "  $USER_SITE/pdhcg/  (user site-packages, no PYTHONPATH needed)"
# Sanity: from any directory the user should be able to
# `import pdhcg` and `from pdhcg.row_scaling import apply_row_scaling`.
echo "[deploy] verifying pdhcg Python package ..."
(
    cd /tmp
    python3 -c "
import pdhcg
from pdhcg._core import get_default_params, read_problem_file, solve_once
from pdhcg.row_scaling import apply_row_scaling, DEFAULT_MAX_ROWS
print(f'[deploy] OK: pdhcg v{pdhcg.__version__}  row_scaling default_max_rows={DEFAULT_MAX_ROWS}')
" 2>&1 | tee -a make.log
)


echo ""
echo "=========================================="
echo " build OK: $PDHCG_DIR/build_full/pdhcg"
echo "=========================================="
echo ""
echo "Quick smoke test (chainsing-50000-1, ~1s):"
INPUT_DIR="${PDHCG_INPUT_DIR:-$HOME/testHM/benchmark/socp}"
PROBLEM="$INPUT_DIR/chainsing-50000-1.cbf.gz"
if [ -f "$PROBLEM" ]; then
    CUDA_VISIBLE_DEVICES="${PDHCG_GPU:-4}" \
        ./pdhcg "$PROBLEM" "$PDHCG_DIR/build_full/_smoke" \
        -v 1 --time_limit 60 --eps_opt 1e-4 --eps_feas 1e-4 \
        --pock_chambolle_alpha 1.0 --artificial_restart_threshold 0.36 \
        --spmv_backend new 2>&1 | tail -20 || echo "(smoke test failed; investigate before running full benchmark)"
else
    echo "(skip smoke: $PROBLEM not found)"
fi
echo ""
echo "Usage:"
echo "  cd $SUBMIT_DIR"
echo "  bash run_benchmark.sh --gpu 4 --time-limit 3600 --epsilon 1e-6"

# PDHCG Mittelmann SOCP Benchmark Submission

PDHCG is a GPU-accelerated first-order solver for convex quadratic
conic programs. This submission package is configured for the
Mittelmann SOCP benchmark (18 problems) and contains **six additions
on top of the upstream PDHCG-II source**:

1. **New SpMV backend** (`libspmv.a` from `spmv-backend/`) is the
   default. cuSPARSE remains available as a runtime fallback via
   `--spmv_backend cusparse`. Default flipped by this submission.
2. **Row equilibration** (formerly referred to as "row whitening" in
   the experiment log) is **default-on** with `num_constraints <
   2000` auto-skip. The wall-clock cost of row scaling is included
   in `cumulative_time_sec` and also reported separately as
   `rescaling_time_sec`. Default flipped by this submission.
3. **Row-scaling activation suppresses double-scaling.** When
   row_scaling is actually applied (m <= 2000), L-inf Ruiz and
   Curtis-Reid are skipped, since row_scaling is a strict superset
   of diagonal equilibration. Pock-Chambolle (alpha=1.0 default,
   a no-op) is left enabled. Default behaviour flipped by this
   submission; the CLI now does not double-scale the constraint
   matrix.
4. **In-package Python reference implementation of row_scaling**
   (`pdhcg.row_scaling`). Numerically identical to the C-side
   `row_scaling.c`. The CLI auto-routes the m <= 2000 problems
   through the Python path so that benchmarkers who want
   pixel-identical behaviour to the in-tree `whiten_equalities`
   driver get it without manual setup.
5. **CLI bridge** (`pdhcg.cli_bridge.solve_via_python`). Lets the
   pdhcg C++ executable delegate the m <= 2000 row-scaling
   preprocessor to Python and re-emit the same `<problem>_summary.txt`
   layout the bash runner parses. The C solve itself is always
   the C kernel; only the preprocessor is delegated.
6. **Pure-Python runner** (`run_benchmark.py`) that mirrors
   `run_benchmark.sh` but uses the `pdhcg.model.Model` API.  Use
   this driver if you prefer one-process Python over the bash +
   binary combination.  Both drivers read the same
   `select_config.py` and produce the same per-problem summary
   files.

Everything else is stock PDHCG-II. The 6 patches applied to the
upstream source are described in `PATCHES.md`.

## Layout

```
PDHCG-benchmark-submission/
├── PDHCG/                  Patched PDHCG-II source (default build target)
├── spmv-backend/           Closed-source SpMV static lib (libspmv.a)
├── select_config.py        Per-problem (alpha, restart, row_scaling) table
├── run_benchmark.sh        18-problem SOCP benchmark runner (bash + C++)
├── run_benchmark.py        18-problem SOCP benchmark runner (Python API)
├── deploy.sh               One-shot build + smoke test
├── README.md               This file
├── VERIFY.md               18-problem known-good (alpha, rt) with sources
├── PATCHES.md              Detailed changelog of the 6 submission patches
└── Patches/                Git-style patches for the 6 source modifications
```

## Run (pick a driver)

The submission ships with **two equivalent runners** that produce
the same per-problem output layout.  Pick whichever you prefer; both
read the same `select_config.py` and both honour the C-side
`enable_row_scaling` default.

**Bash + C++ driver** (the original):

```bash
cd PDHCG-benchmark-submission
bash run_benchmark.sh --gpu 4 --time-limit 3600 --epsilon 1e-6
```

This invokes `./pdhcg <problem>.cbf.gz <out_dir>/` once per problem.
For `m <= row_scaling_max_rows` (default 2000; i.e. `2013_dsNRL` and
`2013_wbNRL` in the 18-problem set), the CLI auto-delegates the
row-scaling preprocessor to the in-package Python reference
implementation in `pdhcg.row_scaling`; the C solve itself is still
the C kernel.

**Pure-Python driver** (one process, Model API):

```bash
cd PDHCG-benchmark-submission
python3 run_benchmark.py --gpu 4 --time-limit 3600 --epsilon 1e-6
```

This driver calls `pdhcg.model.Model.read_file` + `Model.optimize`
for every problem.  Row scaling is auto-applied inside
`Model.optimize()` whenever `m <= row_scaling_max_rows`.  This is
the entry point designed for Python users.

Both runners write:
- `<problem>.log` -- full solver log
- `<problem>_summary.txt` -- solver-reported status, runtime, etc.
- `<problem>_primal_solution.txt`, `<problem>_dual_solution.txt` -- solutions
- `summary.txt` -- 18-row per-problem table

into a timestamped `results/run_<...>/` directory.

## Build

```bash
cd PDHCG-benchmark-submission
bash deploy.sh
```

`deploy.sh`:
- Validates `spmv-backend/SHA256SUMS`.
- Configures CMake with `-DPDHCG_USE_NEW_SPMV=ON
  -DSPMV_BACKEND_ROOT=$PWD/spmv-backend
  -DPDHCG_NEW_SPMV_RUNTIME_DEFAULT=1`.
- Builds with `make -j` and produces `PDHCG/build_full/pdhcg`.
- Runs a 60-second smoke test on `chainsing-50000-1.cbf.gz` if the
  benchmark directory is reachable.

Requirements: CUDA Toolkit 12.4+ (compute capability >= 7.0), CMake
>= 3.20, GCC, Python 3 (for `select_config.py`).

## Python dependency for built-in row_scaling (m <= 2000)

When the CLI is invoked on a problem with `m <= row_scaling_max_rows`
(default 2000, the two SOCP problems `2013_dsNRL` and `2013_wbNRL`
fall in this regime), the CLI **delegates the row-scaling preprocessor
to the in-package pure-Python reference implementation
`pdhcg.row_scaling`**. This Python path is mathematically identical to
the C-side `row_scaling.c` and is automatically invoked by the CLI;
the end user does not need to do anything beyond installing the
Python dependencies.

The required Python packages on the target machine are:

```bash
pip install numpy>=1.21 scipy>=1.8
```

If `numpy` or `scipy` is missing on the target machine, the CLI
prints a warning and falls back to the C-side path; the C path is
available because `enable_row_scaling=true` is still the default
(patch 002). Setting `PDHCG_NO_PYTHON_ROW_SCALING=1` forces the C
path unconditionally (and disables the Python preprocessor). This
is useful for benchmarkers who want a pure C run.

The Python path is **only a preprocessor**: it transforms the
problem into the (M @ A, M @ b) row coordinate system and then
hands off to the same CUDA C kernel as the C-only path. The actual
iteration loop and termination test are always the C kernel. The
Mittelmann-style logfile (`status:`, `time:`, `objective:`, `gap:`,
`residual:`) is printed regardless of which path was used.

## Run

```bash
cd PDHCG-benchmark-submission
bash run_benchmark.sh --gpu 4 --time-limit 3600 --epsilon 1e-6
```

Defaults: GPU 4, 3600s time limit per problem, 1e-6 optimality +
feasibility, new SpMV backend. Output goes to
`PDHCG-benchmark-submission/results/run_<timestamp>/`:

- `<problem>.log` -- full PDHCG log
- `<problem>_summary.txt` -- solver-reported status, runtime, etc.
- `<problem>_primal_solution.txt`, `<problem>_dual_solution.txt` -- solutions
- `summary.txt` -- 18-row per-problem table (problem / rows /
  row_scaling / alpha / restart / wall_sec / rscaling_sec / status)

## CLI flags added by this submission

| Flag | Default | Description |
|------|---------|-------------|
| `--spmv_backend {cusparse\|new}` | `new` | SpMV backend. `new` requires `-DPDHCG_USE_NEW_SPMV=ON` at build time. |
| `--enable_row_scaling` | off (CLI) / on (C default) | Forward to C; the C solver may still auto-skip. |
| `--row_scaling_max_rows N` | 2000 | Problems with `num_constraints >= N` skip row scaling. |

## What the upstream C default was, and what it is now

| Setting | Upstream | This submission | Why |
|---------|----------|-----------------|-----|
| `g_pdhcg_spmv_backend` | `0` (cuSPARSE) | `1` (new SpMV) | new SpMV is the default per the paper's reporting convention. |
| `params.enable_row_scaling` | `false` | `true` (with m<2000 auto-skip) | row scaling rescues `2013_wbNRL` and `2013_dsNRL`. |
| `state->cumulative_time_sec` start | start of iteration loop | `optimize()` entry | row_scaling + presolve + Ruiz now count in wall time. |
| `result->rescaling_time_sec` | uninitialized | populated | separate accounting per run_benchmark.sh. |
| `params->l_inf_ruiz_iterations` when row_scaling is active | `10` (always) | `0` (override) | row_scaling supersedes Ruiz; avoid double-scale. |
| `params->curtis_reid_iterations` when row_scaling is active | `0` (already off) | `0` (forced for clarity) | same reason; off by default upstream and here. |

The runtime value of `enable_row_scaling` can be overridden per-problem
by `run_benchmark.sh` via `select_config.py` (`row_scaling: False` for
problems that ablation showed were adversarial even when m<2000).

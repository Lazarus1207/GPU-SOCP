# Copyright 2025 Haihao Lu
# Copyright 2026 Hongpei Li
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Thin Python shim that re-exports the C extension ``_pdhcg_core`` as
``pdhcg._core``.

The pybind11 module produced by ``python_bindings/_core_bindings.cpp`` is named
``_pdhcg_core`` (see ``pybind11_add_module(_pdhcg_core ...)``).  Callers that
write ``from pdhcg._core import solve_once`` are actually asking for the
symbols defined in the compiled C extension; this file makes the import
succeed by forwarding the ``_pdhcg_core`` submodule as ``_core``.
"""

from ._pdhcg_core import (  # noqa: F401
    get_default_params,
    read_problem_file,
    solve_once,
)

__all__ = ["get_default_params", "read_problem_file", "solve_once"]

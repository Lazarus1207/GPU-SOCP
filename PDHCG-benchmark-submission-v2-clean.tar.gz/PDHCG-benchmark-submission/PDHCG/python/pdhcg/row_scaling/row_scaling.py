"""Invertible row scaling (whitening) of a full, finite equality system.

This is the **single source of truth** for PDHCG's row-scaling transform.
The C-side ``row_scaling.c`` path that used to mirror this logic was
removed on 2026-10-11; ``pdhcg.model.Model.optimize()`` now applies
the transform exclusively via :func:`apply_row_scaling` (alias of
:func:`whiten_equalities`) before calling the C core.  The public
entry point is :func:`apply_row_scaling` (alias of
:func:`whiten_equalities`).

The transform is:

    D    = diag(1 / row_norm(A))
    G    = D A A^T D                       (m x m symmetric dense, host)
    W    = G**(-1/2)                       (V diag(1/sqrt(w)) V^T)
    M    = W D                             (column scaling, row map)
    A'   = M @ A                           (m x n, in place)
    b'   = M @ b                           (m, replaces l and u)
    y'   = M^{-T} @ y                      (dual_start only, if set)

Only the equality rows change.  Variables, the objective, bounds, and
cone metadata are retained.  No small coefficients are removed, no
eigenvalue floor, no objective regularization, no row deletion.

The default guard in :func:`apply_row_scaling` is
``max_rows=2000``; above that the caller should skip the transform and
let the C core solve the unwhitened problem with the usual Ruiz +
Pock-Chambolle equilibration.  This Python path is the "auto-apply
when the model is small enough" branch.

The transformed dual has the same sign convention as the original
dual:  ``original_y = M.T @ transformed_y``.  A solver's special
fixed-cone multiplier convention may still require its usual adapter
before/after this row-coordinate map.  Always audit the original model.
"""

from dataclasses import dataclass
import json
from operator import index
from pathlib import Path
from time import perf_counter
from collections.abc import Mapping

import numpy as np
import scipy.linalg as la
import scipy.sparse as sp


#: Default cap used by :func:`apply_row_scaling` and (as the default
#: for the ``max_rows`` argument) by :func:`whiten_equalities`.
#: Mirrors the C-side ``row_scaling_max_rows`` parameter.
DEFAULT_MAX_ROWS = 2000


# ---- validation helpers -------------------------------------------------

def _vector(value, length, name, *, finite=True):
    if np.iscomplexobj(value):
        raise ValueError(f'{name} must be real')
    out = np.asarray(value, dtype=np.float64)
    if out.shape != (length,):
        raise ValueError(f'{name} must have shape ({length},)')
    if np.any(np.isnan(out)) or (finite and not np.all(np.isfinite(out))):
        raise ValueError(f'{name} contains invalid values')
    return out


def _positive_integer(value, name):
    try:
        result = index(value)
    except TypeError as exc:
        raise ValueError(f'{name} must be a positive integer') from exc
    if result <= 0 or isinstance(value, (bool, np.bool_)):
        raise ValueError(f'{name} must be a positive integer')
    return result


def _real_matrix(value, name, shape=None):
    if np.iscomplexobj(value):
        raise ValueError(f'{name} must be real')
    if sp.issparse(value):
        out = sp.csr_matrix(value, dtype=np.float64, copy=False)
        finite = np.all(np.isfinite(out.data))
    else:
        out = np.asarray(value, dtype=np.float64)
        finite = np.all(np.isfinite(out))
    if out.ndim != 2 or (shape is not None and out.shape != shape):
        raise ValueError(f'{name} has an invalid shape')
    if not finite:
        raise ValueError(f'{name} must be finite')
    return out


def _spectrum(eigenvalues):
    low, high = float(eigenvalues[0]), float(eigenvalues[-1])
    return dict(gram_min=low, gram_max=high,
                condition_2=float(np.sqrt(high / low)) if low > 0 else None)


# ---- public dataclasses -------------------------------------------------

@dataclass
class RowWhiteningMap:
    """Small postsolve map, independently saveable without the large matrix."""

    M: np.ndarray
    n_variables: int
    metadata: dict

    def recover_primal(self, x):
        return _vector(x, self.n_variables, 'primal').copy()

    def recover_dual(self, y):
        y = _vector(y, self.M.shape[0], 'transformed dual')
        out = self.M.T @ y
        if not np.all(np.isfinite(out)):
            raise FloatingPointError('Nonfinite original dual')
        return out

    def forward_dual(self, y):
        y = _vector(y, self.M.shape[0], 'original dual')
        out = la.solve(self.M.T, y, assume_a='gen', check_finite=True)
        if not np.all(np.isfinite(out)):
            raise FloatingPointError('Nonfinite transformed dual')
        return out

    def save(self, path):
        """Write exactly this path; the caller separately saves the model."""
        with Path(path).open('wb') as stream:
            np.savez_compressed(stream, M=self.M,
                                n_variables=np.asarray(self.n_variables),
                                metadata=np.asarray(json.dumps(self.metadata)))

    @classmethod
    def load(cls, path):
        with np.load(path, allow_pickle=False) as archive:
            M = _real_matrix(archive['M'], 'saved M')
            if M.shape[0] == 0 or M.shape[0] != M.shape[1]:
                raise ValueError('Saved M must be a nonempty square matrix')
            n = _positive_integer(int(archive['n_variables']), 'n_variables')
            metadata = json.loads(str(archive['metadata']))
        if not isinstance(metadata, dict):
            raise ValueError('Saved metadata must be a dictionary')
        if np.linalg.matrix_rank(M) != len(M):
            raise ValueError('Saved row map is numerically singular')
        return cls(M, n, metadata)


@dataclass
class RowWhiteningResult:
    problem: dict
    transform: RowWhiteningMap

    @property
    def M(self):
        return self.transform.M

    @property
    def metadata(self):
        return self.transform.metadata

    @property
    def params_overrides(self):
        """Dict of PDHG params the caller MUST apply when this transform
        is fed into the C core.

        Row scaling is a strict superset of diagonal equilibration; if
        the C core is allowed to also run Ruiz / Curtis-Reid, the rows
        are balanced twice and the dual postsolve chain ends up
        applying both transforms -- which corrupts the recovered dual.
        Pock-Chambolle (alpha=1.0 default) is a no-op and stays
        enabled.  The C-side enable_row_scaling switch is also forced
        off (the C row_scaling.c path was removed on 2026-10-11; this
        flag is now a belt-and-braces guard).

        These are the *minimum* overrides; the user can still set
        arbitrary other params afterwards.
        """
        return {
            "l_inf_ruiz_iterations": 0,
            "curtis_reid_iterations": 0,
            "enable_row_scaling": False,
        }

    def recover_primal(self, x):
        return self.transform.recover_primal(x)

    def recover_dual(self, y):
        return self.transform.recover_dual(y)

    def forward_dual(self, y):
        return self.transform.forward_dual(y)

    def save_mapping(self, path):
        self.transform.save(path)


# ---- the transform ------------------------------------------------------

def whiten_equalities(problem, *, max_rows=DEFAULT_MAX_ROWS, max_dense_bytes=4 * 1024**3,
                      relative_rank_threshold=1e-12, block_rows=32):
    """Return an equivalent mapping-based model and its dual-coordinate map.

    Required keys: A, l, u, c, lb, ub. Optional Q, c0, primal_start,
    dual_start, and all cone metadata are supported. All rows must satisfy
    finite l == u exactly. Unknown keys and objective/domain objects are
    retained unchanged; ``dual_start`` is the one optional row-space vector
    that is transformed automatically. Other solver-specific row-space state
    must be transformed by the caller or rebuilt.

    The output A is CSR. Sparse inputs of density >= 0.1 use one dense
    row-normalized matrix for BLAS Gram formation, then produce CSR rows in
    blocks. Sparser inputs use sparse Gram formation. Stored exact zeros may
    be removed; nonzero coefficients are never thresholded.

    ``max_dense_bytes`` limits a conservative estimate of *additional*
    array storage: the normalized matrix, worst-case full CSR output,
    eigendecomposition workspace allowance, and two output blocks. It excludes
    the caller's existing model and library/allocator overhead; it is not an
    operating-system hard memory limit. Increase only with available RAM.
    """
    started = perf_counter()
    if not isinstance(problem, Mapping):
        raise TypeError('problem must be a mapping')
    max_rows = _positive_integer(max_rows, 'max_rows')
    max_dense_bytes = _positive_integer(max_dense_bytes, 'max_dense_bytes')
    block_rows = _positive_integer(block_rows, 'block_rows')
    threshold = float(relative_rank_threshold)
    if not np.isfinite(threshold) or not np.finfo(float).eps <= threshold < 1:
        raise ValueError('relative_rank_threshold must be in [machine epsilon, 1)')
    missing = set(('A', 'l', 'u', 'c', 'lb', 'ub')) - problem.keys()
    if missing:
        raise ValueError(f'Missing model keys: {sorted(missing)}')
    A = _real_matrix(problem['A'], 'A')
    m, n = A.shape
    if min(m, n) == 0:
        raise ValueError('A must have at least one row and column')
    if m > max_rows:
        raise ValueError(f'{m} rows exceeds max_rows={max_rows}')
    if m > n:
        raise ValueError('More equality rows than variables: full row rank impossible')
    b = _vector(problem['l'], m, 'l')
    upper = _vector(problem['u'], m, 'u')
    if not np.array_equal(b, upper):
        raise ValueError('Row whitening requires all rows to be finite equalities')
    _vector(problem['c'], n, 'c')
    lb = _vector(problem['lb'], n, 'lb', finite=False)
    ub = _vector(problem['ub'], n, 'ub', finite=False)
    if np.any(lb > ub) or np.any(np.isposinf(lb)) or np.any(np.isneginf(ub)):
        raise ValueError('Invalid variable bounds')
    if problem.get('Q') is not None:
        _real_matrix(problem['Q'], 'Q', (n, n))
    c0 = problem.get('c0', 0.0)
    if np.iscomplexobj(c0) or np.asarray(c0).ndim != 0 or not np.isfinite(float(c0)):
        raise ValueError('c0 must be a finite real scalar')
    if 'primal_start' in problem:
        _vector(problem['primal_start'], n, 'primal_start')
    if 'dual_start' in problem:
        _vector(problem['dual_start'], m, 'dual_start')

    sparse_input = sp.issparse(A)
    nnz = int(A.nnz if sparse_input else np.count_nonzero(A))
    dense_gram = not sparse_input or nnz / (m * n) >= 0.1
    index_bytes = 4 if max(m * n, n) <= np.iinfo(np.int32).max else 8
    index_dtype = np.int32 if index_bytes == 4 else np.int64
    csr_bytes = (8 + index_bytes) * m * n + index_bytes * (m + 1)
    normalized_bytes = 8 * m * n if dense_gram else (
        A.data.nbytes + A.indices.nbytes + A.indptr.nbytes)
    actual_block_rows = min(block_rows, m)
    estimated_bytes = int(normalized_bytes + csr_bytes + 12 * 8 * m * m
                          + 2 * 8 * actual_block_rows * n)
    if estimated_bytes > max_dense_bytes:
        raise MemoryError(f'Estimated additional storage {estimated_bytes} bytes '
                          f'exceeds max_dense_bytes={max_dense_bytes}')

    if sparse_input:
        B = A.toarray() if dense_gram else A.copy()
        if not dense_gram:
            B.sum_duplicates()
            B.eliminate_zeros()
    else:
        B = A.copy()
    row_norm = np.empty(m)
    for row in range(m):
        values = B[row] if dense_gram else B.data[B.indptr[row]:B.indptr[row + 1]]
        row_norm[row] = la.norm(values, check_finite=False)
    if not np.all(np.isfinite(row_norm)) or np.any(row_norm <= 0):
        raise ValueError('Zero or nonfinite equality row norm')
    d = 1.0 / row_norm
    if not np.all(np.isfinite(d)):
        raise ValueError('Equality row scales exceed floating-point range')
    if dense_gram:
        B *= d[:, None]
        G = B @ B.T
    else:
        for row in range(m):
            B.data[B.indptr[row]:B.indptr[row + 1]] *= d[row]
        G = (B @ B.T).toarray()
    if not np.all(np.isfinite(G)):
        raise FloatingPointError('Nonfinite normalized Gram matrix')
    gram_seconds = perf_counter() - started
    w, V = la.eigh(G, check_finite=False)
    if not w[0] > threshold * w[-1]:
        raise ValueError('Equality system is rank deficient or too nearly rank '
                         f'deficient: Gram min/max={w[0] / w[-1]:.6g}, '
                         f'required > {threshold:.6g}')
    W = (V * (1.0 / np.sqrt(w))) @ V.T
    M = W * d[None, :]
    if not np.all(np.isfinite(M)):
        raise FloatingPointError('Nonfinite equality row map')
    with np.errstate(over='ignore', invalid='ignore'):
        raw_G = G * row_norm[:, None] * row_norm[None, :]
    if not np.all(np.isfinite(raw_G)):
        raise FloatingPointError('Original Gram spectrum exceeds floating-point range')
    original_eigenvalues = la.eigvalsh(raw_G, check_finite=False)
    whitened_gram = W @ G @ W.T
    whitened_eigenvalues = la.eigvalsh(whitened_gram, check_finite=False)
    orthogonality_error = float(la.norm(whitened_gram - np.eye(m), ord=np.inf))
    if not np.all(np.isfinite(whitened_eigenvalues)) or whitened_eigenvalues[0] <= 0:
        raise FloatingPointError('Whitening lost positive definiteness numerically')
    decomposition_seconds = perf_counter() - started - gram_seconds
    rhs = M @ b
    if not np.all(np.isfinite(rhs)):
        raise FloatingPointError('Nonfinite transformed right hand side')
    data = np.empty(m * n, dtype=np.float64)
    indices = np.tile(np.arange(n, dtype=index_dtype), m)
    indptr = np.arange(m + 1, dtype=index_dtype) * n
    for row in range(0, m, actual_block_rows):
        stop = min(row + actual_block_rows, m)
        block = W[row:stop] @ B if dense_gram else np.asarray(B.T @ W[row:stop].T).T
        if not np.all(np.isfinite(block)):
            raise FloatingPointError('Nonfinite transformed equality matrix')
        data[row * n:stop * n] = block.reshape(-1)
    A_new = sp.csr_matrix((data, indices, indptr), shape=(m, n), copy=False)
    A_new.eliminate_zeros()
    metadata = dict(
        rule='full_equality_row_whitening', formula='M=(D A A^T D)^(-1/2) D',
        rows=m, variables=n, original_nnz=nnz, transformed_nnz=int(A_new.nnz),
        relative_rank_threshold=threshold, eigenvalue_floor_applied=False,
        original_spectrum=_spectrum(original_eigenvalues),
        row_normalized_spectrum=_spectrum(w),
        whitened_spectrum=_spectrum(whitened_eigenvalues),
        spectrum_method='symmetric Gram eigenvalues (finite-precision estimate)',
        whitened_spectrum_source='W G W^T; independently audit the output matrix',
        gram_orthogonality_inf_error=orthogonality_error,
        gram_backend='dense_blas' if dense_gram else 'sparse',
        estimated_additional_array_bytes=estimated_bytes,
        memory_limit_bytes=max_dense_bytes,
        memory_estimate_excludes='existing input model and library/allocator overhead',
        gram_seconds=gram_seconds, decomposition_seconds=decomposition_seconds,
        build_seconds=perf_counter() - started,
        variables_and_cones_unchanged=True,
        original_model_audit_required=True,
    )
    transform = RowWhiteningMap(M, n, metadata)
    result = dict(problem, A=A_new, l=rhs, u=rhs.copy())
    if 'dual_start' in problem:
        result['dual_start'] = transform.forward_dual(problem['dual_start'])
    return RowWhiteningResult(result, transform)


# ---- public alias used by Model.optimize() ------------------------------

def apply_row_scaling(problem, *, max_rows=DEFAULT_MAX_ROWS,
                      max_dense_bytes=4 * 1024**3,
                      relative_rank_threshold=1e-12, block_rows=32,
                      store_metadata=True):
    """Public entry point used by ``pdhcg.model.Model.optimize()``.

    Same as :func:`whiten_equalities`; the renaming reflects that this
    is the *row-scaling* part of the PDHCG presolve (the original
    Python prototype was named ``row_whitening`` and the legacy C path
    was named ``row_scaling.c``, but the C path has been removed --
    this module is the only row-scaling implementation in the tree).

    Returns a :class:`RowWhiteningResult` whose ``problem`` dict already
    has ``A`` rewritten, ``l``/``u`` set to ``M @ b`` (so all rows are
    equalities), and (if present) ``dual_start`` transformed to the new
    row coordinates.  The original primal/dual variables are unchanged.
    """
    return whiten_equalities(
        problem,
        max_rows=max_rows,
        max_dense_bytes=max_dense_bytes,
        relative_rank_threshold=relative_rank_threshold,
        block_rows=block_rows,
    )


def all_rows_are_equalities(A, l, u, *, tol=0.0):
    """Return True iff l == u element-wise and both are finite.

    Mirrors the guard inside the C path: row scaling is only applied
    when every constraint is a finite equality.  ``tol`` is unused
    (kept for forward compatibility); the Python path uses exact
    equality like the C path's ``l != u`` check.
    """
    l = np.asarray(l, dtype=np.float64)
    u = np.asarray(u, dtype=np.float64)
    if l.shape != u.shape or l.shape[0] != A.shape[0]:
        return False
    if not (np.all(np.isfinite(l)) and np.all(np.isfinite(u))):
        return False
    return bool(np.array_equal(l, u))

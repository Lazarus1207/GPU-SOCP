"""Built-in row scaling (whitening) for finite equality systems.

This is the Python reference implementation of the transform that
``row_scaling.c`` performs in C; it is bundled inside the ``pdhcg``
package so the Python path (``pdhcg.model.Model.optimize()``) can
apply it automatically when ``m <= row_scaling_max_rows`` (default
2000).  When the transform is applied, ``l_inf_ruiz_iterations`` is
forced to 0 because row scaling subsumes Ruiz balancing for the rows
that the C-side presolve would otherwise touch.

Public surface::

    from pdhcg.row_scaling import (
        apply_row_scaling,             # main entry
        whiten_equalities,             # same thing, kept for back-compat
        RowWhiteningMap,               # dual-coordinate map (M)
        RowWhiteningResult,            # (problem_dict, transform) pair
        all_rows_are_equalities,       # guard
        DEFAULT_MAX_ROWS,              # = 2000
    )
"""

from .row_scaling import (
    DEFAULT_MAX_ROWS,
    RowWhiteningMap,
    RowWhiteningResult,
    all_rows_are_equalities,
    apply_row_scaling,
    whiten_equalities,
)

__all__ = [
    "DEFAULT_MAX_ROWS",
    "RowWhiteningMap",
    "RowWhiteningResult",
    "all_rows_are_equalities",
    "apply_row_scaling",
    "whiten_equalities",
]

"""CLI -> Python bridge.

This module is the entry point invoked by the pdhcg CLI when
``m <= row_scaling_max_rows`` and the user has not opted out.  It

1. Re-reads the problem from ``filename`` via ``pdhcg._core.read_problem_file``.
2. Builds a :class:`pdhcg.model.Model` and applies the in-package Python
   row-scaling path (which auto-fires from ``Model.optimize()``).
3. Calls ``optimize()`` and writes the standard CLI output files
   (summary, _primal_solution.txt, _dual_solution.txt) into
   ``output_dir`` so downstream bash tools that parse those files
   (run_benchmark.sh, the tail_parse.py post-processor) work without
   any change.

The CLI is expected to pass:

    solve_via_python(
        filename='/abs/path/to/problem.cbf.gz',
        output_dir='/abs/path/to/out/',
        params={...}        # the params dict the CLI accumulated
    )

The params dict's keys are the C-level names (``eps_optimal_relative``,
``pock_chambolle_alpha``, ...); the Model's setParam accepts both
C-level names and the user-friendly aliases (e.g. ``OptimalityTol``).
"""

from __future__ import annotations

import os
import sys
import time
import traceback
from pathlib import Path

# Import numpy first so a clean error surfaces immediately if it is
# missing, rather than failing deep inside solve_via_python.
import numpy as np

# scipy is a hard dependency for pdhcg.row_scaling.  We import it
# eagerly here so the CLI's `importlib.util.find_spec("scipy")` probe
# and this module's own import stay in lockstep.
try:
    import scipy  # noqa: F401
except Exception as _scipy_err:  # pragma: no cover
    print(f"[cli_bridge] ERROR: scipy is not importable: {_scipy_err}",
          file=sys.stderr)
    raise

import pdhcg
from pdhcg import Model
from pdhcg._core import get_default_params
from pdhcg.row_scaling import DEFAULT_MAX_ROWS


def _coerce_params(p: dict) -> dict:
    """Coerce the CLI's params dict to the keys the C extension understands.

    The CLI passes keys like ``'eps_optimal_relative'`` (already C-level),
    ``'l_inf_ruiz_iterations'`` (already C-level), ``'spmv_backend'``
    (string 'new' or 'cusparse'), etc.  This function normalises a few
    aliases so Model.setParam is happy on both Python- and CLI-driven
    paths.
    """
    out = dict(p or {})
    # spmv_backend may be a string from the CLI; the C side uses an int
    # enum but the Model layer handles both.  Pass it through as-is.
    if "spmv_backend" in out and isinstance(out["spmv_backend"], str):
        # Model.setParam will accept the string; the C side will parse it.
        pass
    return out


def _write_solution(vec, path: str) -> None:
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    arr = np.asarray(vec, dtype=np.float64).ravel()
    np.savetxt(path, arr.reshape(-1, 1), fmt="%.17g")


def _write_summary(
    *,
    output_dir: str,
    instance: str,
    status: str,
    iters: int,
    elapsed: float,
    pobj, dobj, gap,
    rel_p_res, rel_d_res,
    rescale_time,
    row_scaling_status: str,
    row_scaling_applied: bool,
    row_scaling_metadata: dict | None,
) -> None:
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    path = out / f"{instance}_summary.txt"
    with path.open("w") as f:
        f.write(f"Instance: {instance}\n")
        f.write(f"Status: {status}\n")
        f.write(f"Iterations: {int(iters)}\n")
        f.write(f"Solve time: {elapsed:.3f}\n")
        f.write(f"Rescaling Time (sec): {rescale_time:.3f}\n")
        f.write(f"Primal Objective: {pobj:.10g}\n")
        f.write(f"Dual Objective: {dobj:.10g}\n")
        f.write(f"Relative Objective Gap: {gap:.6e}\n")
        f.write(f"Relative Primal Residual: {rel_p_res:.6e}\n")
        f.write(f"Relative Dual Residual: {rel_d_res:.6e}\n")
        f.write(
            f"Row Scaling: "
            f"{'applied' if row_scaling_applied else 'skipped'} "
            f"({row_scaling_status})\n"
        )
        if row_scaling_metadata is not None:
            spec = row_scaling_metadata.get("row_normalized_spectrum") or {}
            f.write(
                f"Row Scaling Spectrum (post-normalize): "
                f"min={spec.get('gram_min', float('nan')):.6g} "
                f"max={spec.get('gram_max', float('nan')):.6g} "
                f"cond2={spec.get('condition_2', float('nan')):.6g}\n"
            )
        # Wall-clock breakdown the C side writes; mirror the fields.
        f.write(f"Backend: pdhcg (Python path, row_scaling via pdhcg.row_scaling)\n")
        # Trailing block in HPR-QP / cuPDLP / COPT / cuOpt format so
        # Mittelmann's parser (which grep's `time:` and `status:`) and
        # our own tail_parse.py both work without modification.
        obj_v = pobj if np.isfinite(pobj) else (dobj if np.isfinite(dobj) else 0.0)
        gap_v = gap if np.isfinite(gap) else float("nan")
        res_v = rel_p_res if np.isfinite(rel_p_res) else float("nan")
        f.write("\n")
        f.write(f"model:     {filename}\n")
        f.write(f"status:    {status}\n")
        f.write(f"iter:      {int(iters)}\n")
        f.write(f"time:      {elapsed:.6f}\n")
        f.write(f"objective: {obj_v:.10g}\n")
        f.write(f"gap:       {gap_v:.6e}\n")
        f.write(f"residual:  {res_v:.6e}\n")


def solve_via_python(*, filename: str, output_dir: str, params: dict) -> int:
    """Run the Python-side row_scaling + C-side solve.

    Returns 0 on success (status OPTIMAL or similar), 1 on failure.
    """
    t0 = time.time()
    print(f"[cli_bridge] reading {filename}", flush=True)
    try:
        model = Model.read_file(filename)
    except Exception as e:
        print(f"[cli_bridge] failed to read problem: {e}", file=sys.stderr)
        return 1

    # Apply CLI params on top of the defaults.  Model's _params is the
    # C-side default dict with row_scaling_enabled/row_scaling_max_rows
    # already set to ON by Model.__init__.
    for k, v in _coerce_params(params).items():
        # Skip keys the C side doesn't recognise so we don't choke on
        # forward-compatible additions.  C extension will raise on unknown
        # keys; we silently skip.
        try:
            model.setParam(k, v)
        except Exception as e:
            print(f"[cli_bridge] skip param {k}={v!r}: {e}", flush=True)

    print(
        f"[cli_bridge] m={model.num_constrs}  "
        f"row_scaling_enabled={model.getParam('row_scaling_enabled')}  "
        f"row_scaling_max_rows={model.getParam('row_scaling_max_rows')}",
        flush=True,
    )

    try:
        model.optimize()
    except Exception as e:
        print(f"[cli_bridge] optimize() raised: {e}", file=sys.stderr)
        traceback.print_exc()
        return 1

    elapsed = time.time() - t0
    instance = Path(filename).stem

    # Pull diagnostics the C summary expects.
    info = getattr(model, "_last_solve_info", None) or {}
    status = str(model.Status) if model.Status is not None else "UNKNOWN"
    iters = int(model.IterCount) if model.IterCount is not None else 0
    pobj = float(model.ObjVal) if model.ObjVal is not None else float("nan")
    dobj = float(model.DualObj) if model.DualObj is not None else float("nan")
    gap = float(model.RelGap) if model.RelGap is not None else float("nan")
    rel_p_res = (
        float(model.RelPrimalResidual) if model.RelPrimalResidual is not None
        else float("nan")
    )
    rel_d_res = (
        float(model.RelDualResidual) if model.RelDualResidual is not None
        else float("nan")
    )
    rescale_time = (
        float(model.RescalingTime) if model.RescalingTime is not None
        else 0.0
    )
    rs_status = str(info.get("RowScalingStatus", "skipped"))
    rs_applied = bool(info.get("RowScalingApplied", False))
    rs_meta = info.get("RowScalingMetadata")

    print(
        f"[cli_bridge] done  status={status}  iters={iters}  "
        f"elapsed={elapsed:.2f}s  rs={rs_status}",
        flush=True,
    )
    # Print a HPR-QP/Mittelmann-style trailing block.  Mittelmann's
    # benchmark parser grep's the stdout for `status:` and `time:` lines,
    # so we emit the exact same shape that HPR-QP, cuPDLP, and COPT
    # produce:
    #
    #     model:     {filename}
    #     status:    OPTIMAL | TIME_LIMIT | INFEASIBLE | ...
    #     iter:      <int>
    #     time:      <float seconds>
    #     objective: <float>
    #     gap:       <float>
    #     residual:  <float>
    #     iter_4:    <int>   (optional; for the 1e-4 fallback run)
    #     time_4:    <float>
    #     iter_6:    <int>   (optional; for the 1e-6 baseline run)
    #     time_6:    <float>
    #
    # This guarantees the submission looks identical to a "normal"
    # PDHCG run regardless of whether the row_scaling preprocessor
    # was the C path or the in-package Python path.
    obj = pobj if np.isfinite(pobj) else (dobj if np.isfinite(dobj) else 0.0)
    print(f"model:     {filename}", flush=True)
    print(f"status:    {status}", flush=True)
    print(f"iter:      {int(iters)}", flush=True)
    print(f"time:      {elapsed:.6f}", flush=True)
    print(f"objective: {obj:.10g}", flush=True)
    gap_v = gap if np.isfinite(gap) else float("nan")
    print(f"gap:       {gap_v:.6e}", flush=True)
    res_v = rel_p_res if np.isfinite(rel_p_res) else float("nan")
    print(f"residual:  {res_v:.6e}", flush=True)

    # Write output files in the C-CLI's format.
    out_dir = Path(output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    if model.X is not None:
        _write_solution(model.X, str(out_dir / f"{instance}_primal_solution.txt"))
    if model.Pi is not None:
        _write_solution(model.Pi, str(out_dir / f"{instance}_dual_solution.txt"))
    _write_summary(
        output_dir=output_dir,
        instance=instance,
        status=status,
        iters=iters,
        elapsed=elapsed,
        pobj=pobj, dobj=dobj, gap=gap,
        rel_p_res=rel_p_res, rel_d_res=rel_d_res,
        rescale_time=rescale_time,
        row_scaling_status=rs_status,
        row_scaling_applied=rs_applied,
        row_scaling_metadata=rs_meta,
    )
    # Exit-code mirror: 0 for OPTIMAL, 2 for non-optimal-but-finite.
    return 0 if status == "OPTIMAL" else 2


if __name__ == "__main__":
    # Manual smoke (no args): just import everything.
    print("pdhcg.cli_bridge OK", flush=True)
